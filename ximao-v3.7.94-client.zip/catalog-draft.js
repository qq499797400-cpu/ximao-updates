'use strict';
(() => {
 const generic={name:'通用保真',tpl:{img:true,zh:true,en:false,attrs:true,fixed:{}},
  prompt:'按真实商品和目标平台规则生成主图、场景图、细节图与使用图；保持原色、造型、印字及数量；无证据不写尺寸、材质、性能或认证；不默认添加节日风格。'};
 const clean=x=>String(x??'').normalize('NFKC').toLowerCase().trim().replace(/\s+/g,' ');
 const christmas=/圣诞|christmas|\bxmas\b|\bx-mas\b/i;
 const otherHoliday=/万圣|halloween|复活节|\beaster\b/i;
 function preferenceKey(v){
  const shop=String(v.shop??'');
  const cat=clean(v.category);
  if(!/^\d{1,32}$/.test(shop)||!cat||cat==='未分类')return '';
  // This workbench handles the PDDKJ site. Use the full category path, not its displayed leaf.
  return JSON.stringify(['PDDKJ',shop,cat.replace(/\s*[/>]\s*/g,' > ')]);
 }
 function template(v,presets,prefs){
  const title=clean(v.title),category=clean(v.category);
  const material=category+' '+title;
  const seasonal=christmas.test(material)&&!otherHoliday.test(material)&&!/(?:非|不是|不含)圣诞|\bnon[- ]christmas\b/i.test(material);
  if(typeof v.manual==='string'&&(!v.manual||v.manual===generic.name||presets.some(p=>p?.name===v.manual)))return v.manual;
  const eligible=presets.filter(p=>p?.name&&p.name!==generic.name&&(!christmas.test(p.name)||seasonal));
  const key=preferenceKey(v), remembered=key&&prefs&&Object.hasOwn(prefs,key)?prefs[key]:'';
  if(remembered===generic.name||eligible.some(p=>p.name===remembered))return remembered;
  const holiday=seasonal&&eligible.find(p=>p.name==='圣诞节日装饰');
  if(holiday)return holiday.name;
  const pick=(target,field)=>eligible.reduce((best,p)=>{
   let rank=0;
   for(const term of (Array.isArray(p.cats)?p.cats:[])){
    const word=clean(term);
    if(word.length<2||(!seasonal&&christmas.test(word)))continue;
    if(field==='title'&&christmas.test(p.name)&&!christmas.test(word))continue;
    if(target.includes(word))rank=Math.max(rank,word.length);
   }
   if(rank>best.rank)return {rank,name:p.name,ambiguous:false};
   if(rank&&rank===best.rank&&p.name!==best.name)return {...best,ambiguous:true};
   return best;
  },{rank:0,name:'',ambiguous:false});
  const actual=pick(category,'category');
  if(actual.rank&&!actual.ambiguous)return actual.name;
  const fromTitle=pick(title,'title');
  if(fromTitle.rank&&!fromTitle.ambiguous)return fromTitle.name;
  return generic.name;
 }
 const labels={
  material:'材质',color:'颜色',size:'尺寸／尺码',quantity:'包装数量',
  fabric:'面料成分',power:'额定功率',interface:'接口',weight:'净重',capacity:'容量',model:'型号'
 };
 const aliases={
  material:['材质','材料','主要材质','产品材质','material'],
  color:['颜色','色号','颜色名称','color','colour'],
  size:['尺寸','尺码','大小','规格尺寸','产品尺寸','size','dimensions'],
  quantity:['包装数量','数量','件数','每包数量','包装件数','pack quantity','pack count'],
  fabric:['面料成分','成分含量','纤维成分','fabric composition','composition'],
  power:['功率','额定功率','rated power','power'],
  interface:['接口','连接接口','interface','connector'],
  weight:['净重','产品净重','net weight'],
  capacity:['容量','容积','capacity'],model:['型号','产品型号','model']
 };
 const aliasMap=new Map(Object.entries(aliases).flatMap(([id,values])=>values.map(x=>[clean(x),id])));
 const fields=category=>{
  const cat=clean(category);
  return ['material','color','size','quantity',
   ...(/服装|女装|男装|纺织|内衣|apparel|clothing/.test(cat)?['fabric']:[]),
   ...(/数码|电子|电器|充电|computer|electronics/.test(cat)?['model','power','interface']:[]),
   ...(/容器|水杯|水壶|杯具|收纳箱|bottle|container/.test(cat)?['capacity']:[])];
 };
 function certain(field,raw){
  const t=clean(raw);
  if(!t||t.length>180||/[\u0000-\u001f]/.test(t)||/(?:^[-—\/]+$|未知|不确定|不明|可选|任选|随机|待定|待核|待填|不同批次|实物为准|以.+为准|可能|推测|疑似|约莫|质感|风格|类似|不详|未标注|未提供|不是|并非|不含|不适用|无数据|(?:^|\s)(?:unknown|n\/a|tbd|unspecified)(?:\s|$)|^[-—]*无$)/i.test(t))return false;
  if(field==='material'&&/(?:^|\s)(?:look|like|style|effect)(?:\s|$)/i.test(t))return false;
  if(field==='quantity'&&!/^\d{1,7}\s*(?:件|个|只|条|套|张|片|包|瓶|支|枚|双|盒|卷|对|pcs?\.?|pieces?|pairs?|sets?|rolls?|bottles?)?$/.test(t))return false;
  return true;
 }
 function extract(category,facts){
  const fieldsWanted=fields(category), known=Object.create(null), conflicts=new Set();
  for(const line of String(facts??'').slice(0,12000).split(/\r?\n/)){
   const m=line.match(/^\s*[-•*]?\s*([^:：=]{1,30})\s*[:：=]\s*(.+?)\s*$/);
   const field=m&&aliasMap.get(clean(m[1]));
   if(!field||!certain(field,m[2])||conflicts.has(field))continue;
   if(!known[field])known[field]={value:m[2],evidence:line.trim()};
   else if(clean(known[field].value)!==clean(m[2])){delete known[field];conflicts.add(field);}
  }
  return {fields:fieldsWanted,known,conflicts:[...conflicts],missing:fieldsWanted.filter(k=>!known[k])};
 }
 function cited(facts,rows,allowed){
  if(!Array.isArray(rows))return [];
  return rows.slice(0,30).filter(r=>{
   if(!r||!allowed.includes(r.field)||typeof r.value!=='string'||typeof r.evidence!=='string')return false;
   const {value,evidence}=r;
   return certain(r.field,value)&&certain('',evidence)&&facts.includes(evidence)&&evidence.includes(value);
  }).map(r=>({field:r.field,value:r.value.trim(),evidence:r.evidence.trim()}));
 }
 globalThis.xtCatalog={generic,labels,template,preferenceKey,extract,cited,certain,parameterKey:x=>aliasMap.get(clean(x))};
})();
