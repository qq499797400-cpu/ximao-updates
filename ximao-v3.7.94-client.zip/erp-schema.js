'use strict';
(() => {
 const clean=t=>String(t??'').normalize('NFKC').trim().replace(/\s+/g,' ').toLowerCase();
 const pathOf=p=>clean(p).replace(/\s*[>\/]\s*/g,' > ');
 const fieldLabel=x=>clean(x).replace(/^\*\s*|\s*[:*]$/g,'').trim();
 const plain=(x,max)=>typeof x==='string'&&x.trim().length>0&&x.trim().length<=max&&!/[\u0000-\u001f\u007f]/.test(x);
 const idOf=x=>{
  const s=String(x??'');
  if(!/^\d{1,32}$/.test(s)||(typeof x==='number'&&!Number.isSafeInteger(x)))throw Error('缺少可识别的类目、字段或选项 ID。');
  return s;
 };
 const unique=(arr,d)=>{
  if(new Set(arr).size!==arr.length)throw Error(d+'包含重复 ID，停止映射。');
 };
 function parse(raw) {
  if(raw?.site!=='PDDKJ'||!plain(raw.categoryPath,220)||!Array.isArray(raw.fields)||!raw.fields.length||raw.fields.length>300)
   throw Error('类目资料必须包含 Temu 妙手类目 ID、完整路径和字段。');
  const categoryId=idOf(raw.categoryId), fields=raw.fields.map(f=>{
   if(!plain(f?.label,150))throw Error('类目资料里缺少字段名称。');
   const kind=['text','enum','number'].includes(f.kind)?f.kind:'unsupported';
   const options=kind==='enum'&&Array.isArray(f.options)?f.options.map(o=>{
    if(!plain(o?.label,180))throw Error('类目资料里有未命名的选项。');
    return {id:idOf(o.id),label:o.label.trim()};
   }):[];
   unique(options.map(o=>o.id),'字段选项');
   return {id:idOf(f.id),label:f.label.trim(),kind,conditional:!!f.conditional,required:typeof f.required==='boolean'?f.required:null,
    unit:kind==='number'&&plain(f.unit,16)?f.unit.trim():'',options};
  });
  unique(fields.map(f=>f.id),'字段');
  return {site:'PDDKJ',categoryId,categoryPath:raw.categoryPath.trim(),fields,
   skuCount:Number.isSafeInteger(raw.skuCount)&&raw.skuCount>=0?raw.skuCount:0};
 }
 function fromMiaoshou(categoryId,categoryPath,network){
  if(!Array.isArray(network?.productAttributeRules)||!Array.isArray(network?.saleAttributeRules))throw Error('未读到妙手类目规则，请重新选类目。');
  return parse({site:'PDDKJ',categoryId,categoryPath,skuCount:network.saleAttributeRules.length,fields:network.productAttributeRules.map(f=>{
   const multiUnit=Array.isArray(f.valueUnit)?f.valueUnit.filter(Boolean):[];
   const hasEnum=f.controlType===1&&Array.isArray(f.values)&&f.values.length>0&&!(f.chooseMaxNum>1);
   return {id:f.templatePid,label:f.name,kind:hasEnum?'enum':f.controlType===0&&f.propertyValueType===1&&multiUnit.length===1?'number':'unsupported',
    required:f.required,conditional:f.showType!==0||!!f.parentTemplatePid||!!f.showCondition,unit:multiUnit[0],
    options:hasEnum?f.values.map(v=>({id:v.vid,label:v.name})):[]};
  })});
 }
 function exactFacts(notes){
  const facts=new Map();
  for(const line of String(notes??'').slice(0,12000).split(/\r?\n/)){
   const m=line.match(/^\s*[-•*]?\s*([^:：=]{1,100})[:：=]\s*(.*?)\s*$/);
   if(!m||!xtCatalog.certain('',m[2]))continue;
   const k=fieldLabel(m[1]),prior=facts.get(k);
   if(!facts.has(k))facts.set(k,m[2]);
   else if(prior===null||clean(prior)!==clean(m[2]))facts.set(k,null);
  }return facts;
 }
 function plan(schema,draftCategory,parameters,notes){
  if(pathOf(schema.categoryPath)!==pathOf(draftCategory))throw Error('草稿和妙手类目不一致，不能映射。');
  const matched=[],missingRequired=[],needsReview=[];
  const byLabel=new Map(), facts=exactFacts(notes);
  for(const f of schema.fields)byLabel.set(fieldLabel(f.label),(byLabel.get(fieldLabel(f.label))||0)+1);
  function hold(f,reason,hard=false){
   const state={fieldId:f.id,label:f.label,reason};
   if(f.required===true)missingRequired.push(state);
   else if(hard||reason!=='资料无对应值')needsReview.push(state);
  }
  for(const f of schema.fields){
   const descriptor={fieldId:f.id,label:f.label};
   if(f.conditional){needsReview.push({...descriptor,reason:'条件属性，需在妙手核对触发条件'});continue;}
   if(f.required===null){hold(f,'必填状态未知',true);continue;}
   if(byLabel.get(fieldLabel(f.label))>1){hold(f,'同名字段，需人工区分');continue;}
   const k=xtCatalog.parameterKey(fieldLabel(f.label));
   const parameter=k&&parameters?.[k]?.value, literal=facts.get(fieldLabel(f.label));
   if(literal===null||(parameter&&literal&&clean(parameter)!==clean(literal))){hold(f,'规格资料冲突');continue;}
   const value=parameter||literal;
   if(typeof value!=='string'||!xtCatalog.certain(k||'',value)){hold(f,'资料无对应值');continue;}
   if(f.kind==='enum'){
    const hits=f.options.filter(o=>clean(o.label)===clean(value));
    if(hits.length!==1){hold(f,hits.length?'枚举名称不唯一':'无法按原文匹配枚举');continue;}
    matched.push({...descriptor,optionId:hits[0].id,value:hits[0].label});continue;
   }
   if(f.kind==='number'){
    const m=value.normalize('NFKC').trim().match(/^(\d+(?:\.\d+)?)(?:\s*([^\d\s].*))?$/);
    if(!m||clean(m[2])!==clean(f.unit)){hold(f,'数字或单位不匹配，未换算');continue;}
    matched.push({...descriptor,value:m[1],...(f.unit?{unit:f.unit}:{})});continue;
   }
   if(f.kind==='text'){matched.push({...descriptor,value});continue;}
   hold(f,'字段类型尚不支持');
  }
  return {site:schema.site,categoryId:schema.categoryId,categoryPath:schema.categoryPath,
   skuFieldsToReview:schema.skuCount,matched,missingRequired,needsReview,ready:missingRequired.length===0&&!schema.fields.some(f=>f.required===null||f.conditional)};
 }
 globalThis.xtErpSchema={parse,fromMiaoshou,plan};
})();
