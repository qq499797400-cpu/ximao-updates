'use strict';
(() => {
 if(window.__xtCateSchemaHook)return;
 window.__xtCateSchemaHook=true;
 const prefix='/api/platform/pddkj/move/collect_box/';
 const observe=url=>{
  try{
   const u=new URL(url,location.href);
   if(u.origin!==location.origin)return null;
   if(u.pathname===prefix+'getCategoryAttributeRules')return {kind:'rules',cid:u.searchParams.get('cid')};
   if(u.pathname===prefix+'rematchCollectItemInfo')return {kind:'match'};
  }catch{}
  return null;
 };
 const send=payload=>window.postMessage({source:'xt-miaoshou-category',...payload},location.origin);
 let count=0, cur=null;
 function start(q){
  if(q.kind==='rules'&&/^\d{1,32}$/.test(q.cid||'')){cur={seq:++count,cid:q.cid};send({step:'loading',...cur});}
  return cur;
 }
 function receive(request,scope,result){
  if(!scope||scope!==cur||!result||result.result==='fail')return;
  if(request.kind==='match'){
   if(String(result.rematchCollectItemInfo?.cid)===scope.cid)send({step:'matched',...scope});
   return;
  }
  if(!Array.isArray(result.productAttributeRules)||result.productAttributeRules.length>300||!Array.isArray(result.saleAttributeRules))return;
  const fields=result.productAttributeRules.map(f=>({
   templatePid:f.templatePid,name:f.name,required:f.required,controlType:f.controlType,
   propertyValueType:f.propertyValueType,chooseMaxNum:f.chooseMaxNum,parentTemplatePid:f.parentTemplatePid,
   showType:f.showType,showCondition:!!f.showCondition,valueUnit:f.valueUnit,
   values:Array.isArray(f.values)?f.values.slice(0,2000).map(v=>({vid:v.vid,name:v.name})):[]
  }));
  // Only schema definitions cross into the extension; the rematch product payload stays on the page.
  send({step:'rules',...scope,network:{productAttributeRules:fields,saleAttributeRules:result.saleAttributeRules.map(()=>null)}});
 }
 const f=window.fetch;
 window.fetch=function(input,init){
  const q=observe(typeof input==='string'?input:(input?.url||input?.href)), state=q&&start(q);
  const ret=f.apply(this,arguments);
  if(q)ret.then(r=>{if(r.ok)r.clone().json().then(j=>receive(q,state,j)).catch(()=>{});},()=>{});
  return ret;
 };
 const open=XMLHttpRequest.prototype.open,sendXHR=XMLHttpRequest.prototype.send,pending=new WeakMap();
 XMLHttpRequest.prototype.open=function(method,url){
  const q=observe(url);if(q)pending.set(this,q);else pending.delete(this);
  return open.apply(this,arguments);
 };
 XMLHttpRequest.prototype.send=function(){
  const q=pending.get(this);
  if(q){const state=start(q);this.addEventListener('load',()=>{
   if(this.status===200)try{receive(q,state,this.responseType==='json'?this.response:JSON.parse(this.responseText));}catch{}
  },{once:true});}
  return sendXHR.apply(this,arguments);
 };
})();
