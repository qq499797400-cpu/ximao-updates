// hook_main.js — 页面主世界钩子（运行在页面自己的 JS 环境里）
// 1) 捕获编辑页 getCollectItemInfo 响应 → detailId + 标题/英文标题/图片列表
// 2) 捕获采集箱列表响应 → 商品数组（id/标题/图片），供「一键洗图」直接建单
(function () {
  if (window.__msHook) return;
  window.__msHook = true;

  var lastReqDetailId = '';

  function report(payload) {
    // v3.7.94 安全收紧：原来 targetOrigin 用 '*'，而 payload 含导入配置全文、店铺接口原始响应、标题/图片，
    // 页面上任何跨源 iframe 都能收到。改成只发给同源窗口（异常环境才退回 '*'）。
    var origin = '';
    try { origin = location.origin; } catch (e) {}
    if (!origin || origin === 'null') origin = '*';
    try { window.postMessage(Object.assign({ source: 'ms-ai-hook' }, payload), origin); } catch (e) {}
  }

  // v3.7.66 自愈：页面自己提交「导入任务」时，把表单里的 setting（导入配置 JSON）完整截下来存档。
  // 客户手动导入一次 → 插件永久拿到真实导入配置 → 之后全自动直连，不再依赖 getLast 的历史记录。
  function handleImportCreate(bodyText) {
    if (!bodyText || typeof bodyText !== 'string') return;
    var m = /(?:^|&)setting=([^&]*)/.exec(bodyText);
    if (!m) return;
    var s = '';
    try { s = decodeURIComponent(m[1].replace(/\+/g, '%20')); } catch (e) { s = m[1]; }
    if (s && s.length > 2) report({ importSetting: s });
  }

  function pickDetailId(text) {
    if (!text || typeof text !== 'string') return '';
    var m = /detailId["'\s:=]+(\d{6,})/.exec(text);
    return m ? m[1] : '';
  }

  /* ---------------- 编辑页详情 ---------------- */
  function handleResponse(text) {
    if (!text || typeof text !== 'string') return;
    try {
      var j = JSON.parse(text);
      var info = j && j.shopCollectItemInfo;
      if (!info) return;
      var id = String(info.collectBoxDetailId || info.detailId || lastReqDetailId || '');
      // v2.2.7：整包转发（产品属性/品牌/材料/工艺等全字段都在 info 里），并补上派生 enTitle 保持兼容
      var full = Object.assign({}, info, { enTitle: (info.multiLanguageTitleMap && info.multiLanguageTitleMap.en) || info.enTitle || '' });
      report({ detailId: id, info: full });
    } catch (e) {}
  }

  /* ---------------- 采集箱列表：从响应里挖商品数组 ---------------- */
  var ID_KEYS = ['commonCollectBoxDetailId', 'collectBoxDetailId', 'detailId', 'itemId', 'id'];   // v3.7.42 公用采集箱
  var STRONG_ID_KEYS = ['commonCollectBoxDetailId', 'collectBoxDetailId', 'detailId'];   // 列表行必有；字典/选项只有笼统的 id
  var TITLE_KEYS = ['title', 'itemTitle', 'productTitle', 'goodsTitle', 'name'];
  var IMG_KEYS = ['imgUrls', 'images', 'imageUrls', 'carouselImageUrls', 'carouselImgUrls',
    'mainImageUrls', 'mainImageList', 'picUrls', 'imgs', 'pictures', 'mainImg', 'picUrl', 'thumbnail', 'thumbnailUrl', 'coverImgUrl'];

  // 列表接口白名单：只认 search/list/page/query 类；工艺选项(getItemOpt)、属性、类目、字典一律不碰
  var LIST_OK_RE = /(search|list|page|query|items)/i;
  var LIST_BAD_RE = /(opt|option|attr|category|cate|dict|enum|tag|group|label|stat|count|template|remark)/i;
  function isListUrl(u) {
    u = String(u || '');
    if (!/collect_box/i.test(u)) return false;
    if (/getCollectItemInfo/i.test(u)) return false;   // 详情走专门通道
    if (LIST_BAD_RE.test(u)) return false;
    return LIST_OK_RE.test(u);
  }

  function pickFirst(o, keys) {
    for (var i = 0; i < keys.length; i++) {
      var v = o[keys[i]];
      if (v != null && v !== '' && !(Array.isArray(v) && !v.length)) return v;
    }
    return '';
  }

  function asUrlList(v) {
    var out = [];
    (function take(x, d) {
      if (!x || d > 3) return;
      if (typeof x === 'string') { if (/^https?:\/\//.test(x)) out.push(x); return; }
      if (Array.isArray(x)) { for (var i = 0; i < x.length; i++) take(x[i], d + 1); return; }
      if (typeof x === 'object') {
        ['url', 'imgUrl', 'imageUrl', 'src', 'picUrl', 'path'].forEach(function (k) { if (x[k]) take(x[k], d + 1); });
      }
    })(v, 0);
    return out;
  }

  // 在任意层级找「元素带商品 ID 的对象数组」，取最长的那个
  function digItems(root) {
    var best = null;
    (function walk(v, d) {
      if (!v || d > 7) return;
      if (Array.isArray(v)) {
        if (v.length && v[0] && typeof v[0] === 'object') {
          var hasId = ID_KEYS.some(function (k) { return v[0][k] != null && v[0][k] !== ''; });
          if (hasId && (!best || v.length > best.length)) best = v;
        }
        for (var i = 0; i < Math.min(v.length, 3); i++) walk(v[i], d + 1);
        return;
      }
      if (typeof v === 'object') {
        for (var k in v) { if (Object.prototype.hasOwnProperty.call(v, k)) walk(v[k], d + 1); }
      }
    })(root, 0);
    return best || [];
  }

  function normalizeList(arr) {
    var out = [];
    for (var i = 0; i < arr.length; i++) {
      var o = arr[i];
      if (!o || typeof o !== 'object') continue;
      // 强 ID（collectBoxDetailId/detailId）= 真实列表行；只有笼统 id 时必须带图，否则当成字典/选项丢弃
      var id = String(pickFirst(o, STRONG_ID_KEYS) || '');
      var imgs = asUrlList(pickFirst(o, IMG_KEYS));
      if (!id) {
        id = String(pickFirst(o, ['itemId', 'id']) || '');
        if (!id || !imgs.length) continue;
      }
      var title = String(pickFirst(o, TITLE_KEYS) || '');
      if (!title && !imgs.length) continue;
      out.push({ id: id, title: title, imgs: imgs });
    }
    return out;
  }

  function handleListResponse(text, url) {
    if (!text || typeof text !== 'string' || text.length > 8 * 1024 * 1024) return;
    if (!isListUrl(url)) return;
    var j;
    try { j = JSON.parse(text); } catch (e) { return; }
    var arr = digItems(j);
    if (!arr.length) return;
    var items = normalizeList(arr);
    if (!items.length) return;
    report({ list: { items: items, url: String(url || '').slice(0, 300), at: Date.now() } });
  }

  /* ---------------- 网络钩子 ---------------- */
  var of = window.fetch;
  if (of) {
    window.fetch = function (input, init) {
      var url = typeof input === 'string' ? input : (input && input.url) || '';
      var body = (init && typeof init.body === 'string') ? init.body : '';
      var isDetail = /getCollectItemInfo/i.test(url);
      var isList = isListUrl(url);
      var isImportCreate = /createCollectBoxImportItemTask/i.test(url);
      var isShopApi = /\/api\/.*(shop)/i.test(url) && !isList && !isDetail && !isImportCreate;   // v3.7.66 店铺接口探测
      if (isDetail) {
        // v3.7.94 修复：原来只有解析到 id 才覆盖，解析失败时沿用上一次的 id，
        // 响应里又没带 id 时就会把新商品的数据挂到上一个商品 id 上。每次请求都重置。
        lastReqDetailId = pickDetailId(body) || pickDetailId(url) || '';
      }
      if (isImportCreate && body) handleImportCreate(body);
      var ret = of.apply(this, arguments);
      if (isDetail || isList || isShopApi) {
        try {
          ret.then(function (res) {
            try {
              res.clone().text().then(function (t) {
                if (isDetail) handleResponse(t); else if (isList) handleListResponse(t, url); else report({ shopProbe: { url: String(url).slice(0, 200), text: String(t || '').slice(0, 4000), at: Date.now() } });
              });
            } catch (e) {}
            return res;
          });
        } catch (e) {}
      }
      return ret;
    };
  }

  var oo = XMLHttpRequest.prototype.open, os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__msUrl = u; return oo.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (b) {
    var self = this;
    var url = String(this.__msUrl || '');
    var isDetail = /getCollectItemInfo/i.test(url);
    var isList = isListUrl(url);
    var isImportCreate = /createCollectBoxImportItemTask/i.test(url);
    var isShopApi = /\/api\/.*(shop)/i.test(url) && !isList && !isDetail && !isImportCreate;
    if (isDetail) {
      var did = pickDetailId(typeof b === 'string' ? b : '') || pickDetailId(url);
      if (did) lastReqDetailId = did;
    }
    if (isImportCreate && typeof b === 'string') handleImportCreate(b);
    if (isDetail || isList || isShopApi) {
      this.addEventListener('readystatechange', function () {
        if (self.readyState !== 4) return;
        try {
          if (isDetail) handleResponse(self.responseText);
          else if (isList) handleListResponse(self.responseText, url);
          else report({ shopProbe: { url: String(url).slice(0, 200), text: String(self.responseText || '').slice(0, 4000), at: Date.now() } });
        } catch (e) {}
      });
    }
    return os.apply(this, arguments);
  };

  // 给插件侧留一个「主动拉取」的解析入口，复用同一套挖法
  window.__msExtractItems = function (json) {
    try { return normalizeList(digItems(json)); } catch (e) { return []; }
  };
})();
