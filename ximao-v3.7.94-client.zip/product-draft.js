'use strict';
const get=id=>document.getElementById(id);
const form=get('form'), status=get('status'), result=get('result'), grid=get('fields'), suggestions=get('suggestions');
const inputs=new Map();
let active, liveSchema;
const transfer=new URLSearchParams(location.hash.slice(1)).get('category');
if(transfer){
 chrome.runtime.sendMessage({cmd:'xtNewApiCategorySchema',id:transfer}).then(r=>{
  if(!r?.ok)throw Error(r?.error||'读取失败。');
  liveSchema=xtErpSchema.parse(r.data);
  get('category').value=liveSchema.categoryPath;get('category').readOnly=true;
  get('schema-status').textContent='来自当前妙手类目 '+liveSchema.categoryId+'。核对后仅导出草稿，不自动填写到平台或发布。';
 }).catch(e=>{get('schema-status').textContent=e.message;});
}
function meta(){
 return {name:get('name').value.trim(),category:get('category').value.trim(),facts:get('facts').value.trim()};
}
function stillSame(a){ const x=meta();return a.name===x.name&&a.category===x.category&&a.facts===x.facts;}
function headerState(){
 const missing=Array.from(inputs.values()).filter(x=>!x.value.trim()).length;
 if(active&&liveSchema&&stillSame(active))renderSchema(project().erpFieldPlan);
 status.textContent=missing?'已填写 '+(inputs.size-missing)+' 项；'+missing+' 项待确认。':'当前草稿 '+inputs.size+' 个参数均已填写，请核对后使用。';
}
function element(tag,text){
 const n=document.createElement(tag);
 if(text)n.textContent=text;
 return n;
}
function analyze(){
 if(!form.reportValidity())return null;
 const data=meta(), draft=xtCatalog.extract(data.category,data.facts);
 active={...data,draft};inputs.clear();grid.replaceChildren();suggestions.replaceChildren();
 for(const field of [...new Set([...draft.fields,...Object.keys(draft.known),...draft.conflicts])]){
  const row=element('div'), label=element('label',xtCatalog.labels[field]), input=element('input');
  const known=draft.known[field];
  input.id='draft-'+field;input.maxLength=180;input.value=known?.value||'';input.placeholder='待确认';
  label.htmlFor=input.id;inputs.set(field,input);
  const note=element('small',known?'原文：'+known.evidence:draft.conflicts.includes(field)?'资料有冲突，需要人工确认，未自动填。':'资料未找到明确值，可核实后手填。');
  input.addEventListener('input',headerState);
  row.append(label,input,note);grid.append(row);
 }
 result.hidden=false;headerState();return active;
}
form.addEventListener('submit',e=>{e.preventDefault();analyze();});
get('ai').addEventListener('click',async e=>{
 const data=active&&stillSame(active)?active:analyze();
 if(!data)return;
 if(!data.facts){status.textContent='先填一段可核对的供货或规格资料。';return;}
 const todo=data.draft.missing.filter(k=>!data.draft.conflicts.includes(k)&&!inputs.get(k)?.value.trim());
 if(!todo.length){status.textContent='没有需要 AI 提取的字段。已有冲突仍需人工确认。';return;}
 const btn=e.currentTarget;btn.disabled=true;status.textContent='正在让 New API 整理资料原文…';
 try{
  const r=await chrome.runtime.sendMessage({cmd:'xtNewApiAnalyzeDraft',category:data.category,facts:data.facts,fields:todo});
  if(active!==data||!stillSame(data)){status.textContent='规格资料已变化，请重新提取。';return;}
  if(!r?.ok)throw Error(r?.error||'分析请求未完成。');
  const rows=xtCatalog.cited(data.facts,r.data,todo);
  suggestions.replaceChildren(element('h2','AI 建议（核对后再采用）'));
  for(const row of rows){
   const card=element('div'), description=element('p',xtCatalog.labels[row.field]+'：'+row.value+' ｜ 原文：'+row.evidence);
   const use=element('button','核对后采用');
   use.type='button';
   use.addEventListener('click',()=>{
    if(active!==data||!stillSame(data))return;
    const input=inputs.get(row.field);
    if(!input)return;
    input.value=row.value;use.disabled=true;headerState();
   });
   card.append(description,use);suggestions.append(card);
  }
  status.textContent=rows.length?'AI 找到 '+rows.length+' 条有原文的建议。没有自动填写。':'没有找到可核对的原文，继续保留待确认。';
 }catch(e){status.textContent=e.message||'分析失败，仍可手填。';}
 finally{btn.disabled=false;}
});
function renderSchema(plan){
 const list=get('schema-rows');list.replaceChildren();get('schema-plan').hidden=false;
 for(const row of plan.matched)list.append(element('li','已对应：'+row.label+' = '+row.value+(row.unit?' '+row.unit:'')));
 for(const row of plan.missingRequired)list.append(element('li','缺必填：'+row.label+'（'+row.reason+'）'));
 for(const row of plan.needsReview)list.append(element('li','待核对：'+row.label+'（'+row.reason+'）'));
 if(plan.skuFieldsToReview)list.append(element('li','另有 '+plan.skuFieldsToReview+' 条 SKU 规则，须在妙手核对；未自动生成规格或库存。'));
}
function project(){
 const parameters={},missing=[];
 for(const [field,input] of inputs){
  const value=input.value.trim();
  if(!xtCatalog.certain(field,value)){missing.push(field);continue;}
  const known=active.draft.known[field];
  parameters[field]=known?.value===value?{value,source:'资料明确字段',evidence:known.evidence}:{value,source:'人工确认'};
 }
 const out={title:active.name,category:active.category,parameters,missing};
 if(liveSchema)out.erpFieldPlan=xtErpSchema.plan(liveSchema,active.category,parameters,active.facts);
 return out;
}
get('export').addEventListener('click',()=>{
 if(!active||!stillSame(active)){status.textContent='商品资料已修改，请重新提取再下载。';return;}
 let out;try{out=project();}catch(e){status.textContent=e.message;return;}
 const missing=out.missing;
 const url=URL.createObjectURL(new Blob([JSON.stringify(out,null,2)],{type:'application/json'}));
 const a=element('a');a.href=url;a.download='洗图猫-商品草稿.json';a.click();
 setTimeout(()=>URL.revokeObjectURL(url),1000);
 status.textContent='已下载草稿'+(missing.length?'，'+missing.length+' 项仍待确认':'')+'。没有提交妙手。';
});
