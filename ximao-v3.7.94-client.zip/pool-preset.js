'use strict';
// ===== 站点池（客户版：预设为空，请在本扩展的「接口设置」页面添加你自己的生图站点） =====
// 添加方法：浏览器扩展栏 → 洗图猫 → 接口设置 → 「⓿ 生图站点池」→ 点「读取模型」选模型 → 「➕ 添加站点」→「保存站点池」。
// 也可点「📥 导入站点 JSON」批量导入（洗图台导出的 {stations:[…]} 格式）。
// 支持任何 OpenAI 图片接口兼容的网关（New API / one-api 等中转站）。
//   name/base/key/model/req(json|form)/outFmt(''|'jpeg')/outComp/weight/on/cost
const XT_POOL_PRESET = [];
