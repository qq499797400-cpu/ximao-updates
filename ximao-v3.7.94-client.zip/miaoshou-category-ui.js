'use strict';
(() => {
 const texts={start:'读取此类目到自建草稿',wait:'请先在当前创建表单重新选择一次末级类目',done:'正在打开草稿…'};
 const current=()=>{
  const candidates=[...document.querySelectorAll('.jx-cascader.category-selector input.jx-input__inner')];
  return candidates.map(input=>({input,box:input.closest('.jx-form-item'),overlay:input.closest('.jx-overlay,[role="dialog"]')}))
   .find(x=>x.input.getBoundingClientRect().width&&x.box&&x.overlay&&
    x.box.querySelector('label')?.textContent.trim()==='产品类别'&&
    [...x.overlay.querySelectorAll('button')].some(b=>b.textContent.trim()==='确定创建'));
 };
 let snapshot,trackedInput,timer;
 window.addEventListener('message',e=>{
  if(e.source!==window||e.origin!==location.origin||e.data?.source!=='xt-miaoshou-category')return;
  const m=e.data,found=current();
  if(!found||!Number.isSafeInteger(m.seq)||!/^\d{1,32}$/.test(m.cid))return;
  if(m.step==='loading'){snapshot={seq:m.seq,cid:m.cid,at:Date.now()};trackedInput=found.input;return;}
  if(trackedInput!==found.input||m.seq!==snapshot?.seq||m.cid!==snapshot.cid)return;
  if(m.step==='matched'){snapshot.path=found.input.value.trim();return;}
  if(m.step==='rules'&&m.network){snapshot.network=m.network;}
 });
 function insert(){
  const form=current();if(!form)return;
  // v3.7.94 修复：SPA 重新挂载输入框时，旧按钮闭包还指着旧 form.input，且下方 early-return 会让按钮永不重建
  // → 点按钮永远提示「请先重新选择末级类目」。输入框换了就把旧按钮/状态清掉，下面重新插入。
  if(form.input!==trackedInput){
   snapshot=null;trackedInput=form.input;
   document.querySelectorAll('.xt-capture-category,.xt-capture-status').forEach(n=>n.remove());
  }
  if(form.box.querySelector('.xt-capture-category'))return;
  const btn=document.createElement('button'),status=document.createElement('span');
  btn.type='button';btn.className='xt-capture-category';btn.textContent=texts.start;btn.style.margin='8px';
  status.className='xt-capture-status';status.setAttribute('role','status');
  btn.addEventListener('click',async()=>{
   if(!snapshot?.path||!snapshot.network||trackedInput!==form.input||form.input!==current()?.input||
     form.input.value.trim()!==snapshot.path||Date.now()-snapshot.at>600000){status.textContent=texts.wait;return;}
   btn.disabled=true;status.textContent=texts.done;
   try{
    const schema=xtErpSchema.fromMiaoshou(snapshot.cid,snapshot.path,snapshot.network);
    const r=await chrome.runtime.sendMessage({cmd:'xtNewApiOpenDraft',schema});
    if(!r?.ok)throw Error(r?.error||'不能打开自建草稿。');
    status.textContent='已读取类目和字段，未提交妙手。';
   }catch(e){status.textContent=e.message||'读取失败。';}
   finally{btn.disabled=false;}
  });
  form.box.append(btn,status);
 }
 new MutationObserver(()=>{clearTimeout(timer);timer=setTimeout(insert,100);}).observe(document.body,{childList:true,subtree:true});
 insert();
})();
