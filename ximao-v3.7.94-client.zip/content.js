/* 妙手 AI 助手 v1.9.5 — 编辑页单商品：AI 改标题 + 智能洗图（多机位分镜 + 提示词悬停）
 *
 * 只在商品编辑页工作：AI 生成新标题/新图后，直接写进妙手编辑页的输入框和轮播图（走妙手自己的上传），
 * 不调保存接口 —— 用户确认后自己点妙手的「保存修改」。
 *
 * 已实测确认：
 *  - 编辑页标题输入框 placeholder：请输入产品标题 / 请输入英语标题
 *  - 编辑页「上传图片」按钮点击后出现 input[type=file][accept*=image]，DataTransfer 注入即走妙手自身上传
 *  - 中转站 images/edits 必须 JSON+base64 传原图（multipart 会忽略原图）
 *  - 英文标题 ≤250 字符
 */
(function () {
  if (window.__msAiHelper) return;
  window.__msAiHelper = true;

  var CB = '/api/platform/pddkj/move/collect_box/';
  var UPLOAD = '/api/picture/picture/uploadPictureFile';

  // 中转站实测可用模型（GET /v1/models 返回的就这几个）
  var SETTINGS_VER = 15;
  var DEFAULT_MODEL = 'gpt-image-2.5-sunburst';
  var MODEL_OPTIONS = [
    'gpt-image-2.5-sunburst',
    'gpt-image-2.6-sunburst',
    'gpt-image-2.5-flare',
    'gpt-image-2.6-flare',
    'gpt-image-2'
  ];
  var TEXT_MODEL_OPTIONS = ['deepseek-flash', 'deepseek-v4-pro'];

  var DEFAULT_SETTINGS = {
    // 文本模型（改标题 + 看图出补图方案）
    textBaseUrl: '',
    textApiKey: '',
    textModel: 'deepseek-flash',
    imgBaseUrl: '',
    imgApiKey: '',
    imgModel: DEFAULT_MODEL,
    // 目标图片总数（妙手轮播图上限 10）
    targetCount: 10,
    concurrency: 10,
    // 思考强度：low 最快（实测 17s vs high 23s），只影响分析阶段
    reasoningEffort: 'low',
    // true = 全部原图强制洗图（不保留任何原图）；false = 智能保留干净原图（默认强制全洗，防同质化最彻底）
    washAll: true,
    // true = POD 微改模式：保持产品与主题不变，重绘中央图案（防平台图案查重/查版权）
    podMode: false,
    imgPerMin: 10,
    cfgVer: SETTINGS_VER,
    titlePrompt: '你是跨境电商（Temu/拼多多跨境）资深运营。根据商品原标题和页面参数，重写更有转化的中文标题和英文标题。要求：中文标题保留核心品类词与关键卖点、卖点前置，去掉冗余符号/重复词/店铺名，120字以内，不含品牌名、侵权词、极限词（最/第一/顶级/国家级）；英文标题地道母语表达，核心关键词前置，220字符以内。只输出一个 JSON 对象：{"zh":"中文标题","en":"英文标题"}，不要输出任何其他文字。\n原标题：{{title}}\n页面参数：{{attrs}}',
    planPrompt: '你是跨境电商（Temu）视觉设计总监。任务：逐张分析现有轮播图，判断每张「保留还是洗掉重做」，再规划要补充的新图。洗图目的：防止 TEMU 平台检测同质化与同款核价——要换掉的是背景、场景、模特、构图和版式，产品本身（造型/颜色/图案/文字/材质）必须保持可辨认的一致。\n中文标题参考：{{title}}\n英文标题参考：{{en}}\n页面参数：{{attrs}}\n现有轮播图 {{n}} 张（我按顺序全部发给你看，index 从 0 到 {{n}}-1），目标共 {{target}} 张。\n要求：\n1) 标题：结合图片真实细节给出更优的中文标题(≤120字)和英文标题(≤220字符)，不含品牌名/极限词/侵权词。\n2) images：逐张判断现有 {{n}} 张图，必须正好 {{n}} 条，index 从 0 到 {{n}}-1 一一对应、不得遗漏：\n   - action="keep"：这张图已经干净合规——白底图背景纯净、无水印、无品牌logo、无促销牛皮癣文字、画质清晰。直接保留原图，不重新生成（省时间省费用），type 给这张图的实际类型，prompt 留空字符串。判断要偏保守：没明确看到水印/品牌/促销字就一律 keep；白底图、尺寸对比图、细节图默认 keep；只有场景图和带人物/模特的图默认 wash（必须换场景换人来防同质化）。\n   - action="wash"：这张图必须重做——带水印/品牌logo/促销文字，或背景杂乱需要换背景、有模特需要换人换场景、构图质量差。给出 type 和 prompt：洗成什么类型、怎么画（换全新背景/场景/模特/构图，产品本身不变）。\n   - 信息元素区分：只有第三方水印、竞品logo才要去掉；原图里的商品信息文字（顶部英文标语横幅、2D Flat 平面工艺角标、右下角尺寸/厚度标注圆牌 Side thickness 等提醒买家的元素）必须保留——洗图 prompt 里要写明「保留原图顶部标语横幅文字/角标/尺寸标注牌，重绘样式但文字内容不变」。\n   - 白底图、尺寸图只要干净无水印，一律 keep，不要浪费生成额度。整体目标：能 keep 就 keep，通常一轮只该洗 2~5 张。\n   - 位置守恒（重要）：action="wash" 的 type 必须与该 index 原图的实际类型/用途一致——原位置是什么类型就洗成什么类型的新图（例如原位置是使用方法图，就只能洗成新的使用方法图），只换背景/构图/机位/模特，绝不改变该位置承担的信息角色；新的营销图类型只能出现在 addShots 里。\n   - 首位白底：images[0]（第一张）必须是白底主图——干净合规就 keep（type 仍标"白底主图"），不合规就 wash 且 type="白底主图"；addShots 不得再出现白底主图。\n   - 禁止虚构：所有图只呈现参考图里能看到的产品面貌，不得凭空猜测生成产品的背面/底部/内部结构。\n3) addShots：洗完后还缺哪些营销图类型，补到 {{target}} 张。场景类图（卖点主图/场景图）一律按平台爆款公式：暖色节日场景+灯串虚化光斑+2~3 个节日道具点缀（礼物盒/松枝/松果/灯笼），产品占 55%~65%。优先：卖点图解、注意事项图、使用方法图、安装方法图、竞品对比图、场景图、细节材质图、模特图、包装配件图。\n   - 尺寸对比图：产品旁放一个无品牌的通用日常参照物（手掌/硬币/矿泉水瓶等）做大小对比，禁止出现任何真实品牌商品。\n   - 竞品对比图：只对比"普通同类产品"，禁止真实品牌或 logo。\n   - 安装方法图：分步展示安装/悬挂方式，可有手部动作演示。\n类型去重：除白底主图外，同一种类型在 images(wash) + addShots 里最多出现一次。\n每条 prompt 中文 80-150 字，直接用于图生图。每条必须写清这张图的拍摄机位与景别（正面/侧面45°/背面/俯拍/仰拍/平铺/特写），并且所有 prompt 之间机位景别背景必须明显不同、交替出现，禁止 10 张全是正面平视；洗图的 prompt 要写明「重新设计构图和机位，不要沿用原图构图」。卖点类图必须基于产品真实特征（材质/工艺/尺寸/安装方式/使用场景）提炼具体卖点，不要套话。图上避免大段中文，只允许极短英文或数字标注。\n只输出严格 JSON，不要 markdown 代码块：\n{"zh":"","en":"","productBrief":"","images":[{"index":0,"action":"keep","type":"","reason":""},{"index":1,"action":"wash","type":"","prompt":""}],"addShots":[{"type":"","prompt":"","refIndex":0}]}',
    imagePrompt: '【图生图总则】这是按分镜重新创作，不是修图：输出画面的机位、构图、摆放位置必须与参考图明显不同；产品本身（造型轮廓/主要配色/核心图案与印字）保持可辨认一致。环境风格要与产品气质匹配——可以借鉴参考图里契合产品的场景氛围（色调、节日元素、道具风格），但要在新构图中重新组织，不要原样照搬整张参考图的陈设。\n【信息元素·按需保留】只有当参考图本身带有信息元素时才保留对应元素：顶部英文标语横幅、2D Flat 平面工艺角标、尺寸/厚度标注圆牌等——保留其文字内容（可重绘样式、放在该图版式自然的位置），文字不得丢失或改写；参考图里没有的元素不要凭空添加，更不要给每张图都强行复制同一条横幅（是否带横幅由该图分镜决定）。\n【禁止虚构】不得生成参考图中看不到的产品面貌（背面/底部/内部结构），不得编造未经提供的尺寸数字。\n产品的工艺质感（木纹肌理、浮雕立体层次、彩绘与印刷细节）必须保留并提升精细度，达到平台爆款的水准：色彩饱满、边缘清晰、细节丰富。无第三方水印、无边框，输出1:1正方形高清商业图片。',
  };

  /* ================= 通用 ================= */
  var S = {
    settings: Object.assign({}, DEFAULT_SETTINGS),
    detailCache: {}
  };

  function $(sel, root) { return (root || document).querySelector(sel); }
  var toastEl = null, toastTimer = null;
  function toast(msg) {
    try {
      if (!toastEl) {
        toastEl = document.createElement('div');
        toastEl.className = 'ms-toast';
        document.body.appendChild(toastEl);
      }
      toastEl.textContent = msg;
      toastEl.classList.add('show');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, 2600);
    } catch (e) {}
  }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function persist() {
    try { chrome.storage.local.set({ msSettings: S.settings }); } catch (e) {}
  }
  function loadSettings(cb) {
    try {
      chrome.storage.local.get('msSettings', function (r) {
        var st = (r && r.msSettings) || {};
        S.settings = Object.assign({}, DEFAULT_SETTINGS, st);
        ['baseUrl','apiKey','textBaseUrl','textApiKey','imgBaseUrl','imgApiKey'].forEach(function (k) { delete S.settings[k]; });
        if (st.cfgVer !== SETTINGS_VER) {
          S.settings.concurrency = 10;
          S.settings.imgPerMin = 10;
          S.settings.titlePrompt = DEFAULT_SETTINGS.titlePrompt;
          S.settings.planPrompt = DEFAULT_SETTINGS.planPrompt;
          S.settings.imagePrompt = DEFAULT_SETTINGS.imagePrompt;
          // 默认强制全洗：一张原图都不留（防同质化最彻底），想智能保留可在面板取消勾选
          S.settings.washAll = true;
          S.settings.cfgVer = SETTINGS_VER;
          persist();
        }
        cb && cb();
      });
    } catch (e) { cb && cb(); }
  }
  function sendBg(msg) {
    return new Promise(function (res, rej) {
      if (msg.cmd === 'chat' || msg.cmd === 'imageEdit') { delete msg.apiKey; delete msg.baseUrl; }
      chrome.runtime.sendMessage(msg, function (resp) {
        if (chrome.runtime.lastError) return rej(new Error(chrome.runtime.lastError.message));
        if (!resp) return rej(new Error('AI 服务无响应（后台已休眠，重试一次即可）'));
        if (!resp.ok) return rej(new Error(resp.error || 'AI 请求失败'));
        res(resp.data);
      });
    });
  }
  function truncateWords(s, max) {
    s = String(s || '').replace(/\s+/g, ' ').trim();
    if (s.length <= max) return s;
    var cut = s.slice(0, max);
    var sp = cut.lastIndexOf(' ');
    if (sp > max * 0.6) cut = cut.slice(0, sp);
    return cut.replace(/[,，、\-\s]+$/, '');
  }
  function parseTitleJson(raw) {
    var t = String(raw || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
    var m = t.match(/\{[\s\S]*\}/);
    if (m) {
      try {
        var j = JSON.parse(m[0]);
        if (j.zh || j.en) return { zh: String(j.zh || '').trim(), en: String(j.en || '').trim() };
      } catch (e) {}
    }
    var zh = (t.match(/"zh"\s*:\s*"([^"]*)/) || [])[1] || '';
    var en = (t.match(/"en"\s*:\s*"([^"]*)/) || [])[1] || '';
    if (zh || en) return { zh: zh.trim(), en: en.trim() };
    var lines = t.split('\n').map(function (x) { return x.replace(/^[\d\.\-\*\s"']+|["',]+$/g, '').trim(); }).filter(Boolean);
    var zh2 = lines.filter(function (l) { return /[\u4e00-\u9fa5]/.test(l); })[0] || '';
    var en2 = lines.filter(function (l) { return /^[A-Za-z0-9 ,\-']{10,}$/.test(l) && !/[\u4e00-\u9fa5]/.test(l); })[0] || '';
    return { zh: zh2, en: en2 };
  }
  function aiTitle(originalTitle, attrs) {
    var prompt = S.settings.titlePrompt
      .replace('{{title}}', originalTitle)
      .replace('{{attrs}}', attrs || '（无）');
    return sendBg({
      cmd: 'chat',
      baseUrl: S.settings.textBaseUrl,
      apiKey: S.settings.textApiKey,
      model: S.settings.textModel,
      maxTokens: 1200,
      temperature: 0.5,
      messages: [{ role: 'user', content: prompt }]
    }).then(function (content) {
      var r = parseTitleJson(content);
      if (!r.zh && !r.en) throw new Error('AI 未返回可用标题');
      return { zh: truncateWords(r.zh, 120), en: truncateWords(r.en, 245) };
    });
  }

  // 用文本模型看图 → 输出 {zh,en,productBrief,replaceShots[],appendShots[]}
  function aiPlan(info, attrs, pi, visionUrls) {
    var prompt = S.settings.planPrompt
      .replace('{{title}}', info.title || '')
      .replace('{{en}}', info.enTitle || '')
      .replace('{{attrs}}', attrs || '（无）')
      .replace('{{n}}', String(pi.n))
      .replace('{{target}}', String(pi.target))
      .replace('{{append}}', String(pi.append));
    // 「全部洗图」模式：覆盖智能保留判据，所有原图一律 wash
    if (S.settings.washAll) {
      prompt += '\n【模式覆盖·最高优先级】用户本轮选择了「全部原图强制洗图」：images 数组里所有 index 必须全部 action="wash"，绝对禁止任何 keep；每张洗成不同的类型、明显换机位换背景换构图，产品本身保持可辨认一致。';
    }
    // POD 微改模式：每条 prompt 都要指导生图模型重绘中央图案；保留原图=保留原图案，所以 POD 模式强制全洗
    if (S.settings.podMode) {
      prompt += '\n【POD 微改模式·最高优先级】用户做 POD（按需印刷）生产，平台的图案原创度检测会判同款。第一：images 里所有 index 一律 action="wash"、禁止任何 keep（保留原图=保留原图案， POD 下不允许）。第二：每一条 prompt 除了背景/机位要求外，必须额外写明「重绘图案」指令：保留产品形态（挂牌/挂饰等形状与工艺）和主题（节日、文字内容、主色调、元素类别都不变），但中央印刷图案必须重新创作——元素重新排布、增删装饰细节（如换成不同的节日元素组合、改变元素大小占比与位置关系、重绘边框花纹与背景纹理）、文字用相近但不同样式的字体重新排版；新图案与原图案放在一起必须能看出是「同主题的新设计」而不是同一张图。把每张图具体的图案改法（改哪些元素、怎么重排）写进该条 prompt。第三：POD 模式下整套图里禁止出现"白底主图"类型（白底图和尺寸图信息重复且不带卖点），「首位白底」规则作废；images[0]（第一张主图）必须 type="卖点主图"——选产品最有卖点、最能展示特色的一面做主视觉，场景化/版式化展示，其余位置按原图类型洗图。第四（全套一致性·最高优先级）：images[0] 的 prompt 是整套图的主设计定稿——必须把重绘后图案的完整设计规范写清楚（元素清单、排布方式、配色、边框、字体风格）；其余每条 prompt 必须以「图案与主设计图完全一致」开头并复述同一设计规范，只按该图分镜改变机位/景别/背景/展示方式，绝不允许每张图各自发明不同图案；全部图的主体（产品形态、体积比例、材质、颜色、形状）必须完全一致，看起来就是同一件产品的同一套新设计在不同场景拍摄。';
    }

    var content = [{ type: 'text', text: prompt }];
    // 全部原图按顺序发送（要逐张判断 keep/wash，必须每张都看到）
    var urls = (visionUrls || []).filter(Boolean).slice(0, 10);
    urls.forEach(function (u) { content.push({ type: 'image_url', image_url: { url: u } }); });
    plog('🧠 分析提示词 → ' + S.settings.textModel + '（附图 ' + urls.length + ' 张）',
      prompt + '\n\n—— 附带的原图（顺序对应 index 0..' + (urls.length - 1) + '）——\n' + urls.map(function (u, i) { return 'index ' + i + ': ' + u; }).join('\n'));

    // 深度思考模型：思考 token 也占用 max_tokens，思考被截断时加大上限重试一次
    function call(tokens) {
      return sendBg({
        cmd: 'chat',
        baseUrl: S.settings.textBaseUrl,
        apiKey: S.settings.textApiKey,
        model: S.settings.textModel,
        maxTokens: tokens,
        temperature: 0.4,
        reasoningEffort: S.settings.reasoningEffort || 'low',
        messages: [{ role: 'user', content: content }]
      });
    }

    return call(10000).catch(function (e) {
      if (/截断|空内容/.test(String(e.message))) return call(24000);
      throw e;
    }).then(function (raw) {
      return parsePlanJson(raw);
    });
  }

  function parsePlanJson(raw) {
    var t = String(raw || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
    var s1 = t.indexOf('{'), e1 = t.lastIndexOf('}');
    if (s1 >= 0 && e1 > s1) t = t.slice(s1, e1 + 1);
    var j = null;
    try { j = JSON.parse(t); } catch (err) {}
    if (!j) throw new Error('分析结果不是合法 JSON：' + String(raw).slice(0, 80));

    function norm(x) {
      return {
        type: String(x.type || '电商图').slice(0, 14),
        prompt: String(x.prompt || ''),
        refIndex: Math.max(0, parseInt(x.refIndex, 10) || 0)
      };
    }

    var replaceShots = (Array.isArray(j.replaceShots) ? j.replaceShots : []).filter(function (x) {
      return x && x.prompt;
    }).map(function (x) {
      var o = norm(x);
      o.index = Math.max(0, parseInt(x.index, 10) || 0);
      return o;
    });
    var appendShots = (Array.isArray(j.appendShots) ? j.appendShots : []).filter(function (x) {
      return x && x.prompt;
    }).map(norm);
    // 兼容旧格式
    if (!replaceShots.length && !appendShots.length && Array.isArray(j.shots)) {
      appendShots = j.shots.filter(function (x) { return x && x.prompt; }).map(norm);
    }

    // 新格式：images[] 逐张 keep/wash 判断
    var images = (Array.isArray(j.images) ? j.images : []).map(function (x) {
      return {
        index: Math.max(0, parseInt(x && x.index, 10) || 0),
        action: String(x && x.action || '').toLowerCase() === 'keep' ? 'keep' : 'wash',
        reason: String(x && x.reason || '').slice(0, 60),
        type: String(x && x.type || '').slice(0, 14),
        prompt: String(x && x.prompt || '')
      };
    });
    var addShots = (Array.isArray(j.addShots) ? j.addShots : []).filter(function (x) {
      return x && x.prompt;
    }).map(norm);

    return {
      zh: String(j.zh || '').trim(),
      en: String(j.en || '').trim(),
      brief: String(j.productBrief || '').trim(),
      existingTypes: Array.isArray(j.existingTypes) ? j.existingTypes : [],
      images: images,
      replaceShots: replaceShots,
      appendShots: appendShots.length ? appendShots : addShots,
      addShots: addShots
    };
  }

  // 每种图类型的专属分镜要求（每张图只用自己那一条，避免所有图长一个样）
  // 每条第一行是【硬性验收】：不满足就等于生成失败，放在最前面让生图模型第一眼就看到
  var TYPE_PROMPTS = {
    '卖点主图': '【分镜：卖点主图】\n【硬性验收】轮播第一张必须最能展示产品特色与卖点：产品完整清晰、是绝对视觉主角（占画面 55%~65%），禁止纯白棚拍背景。\n然后按平台爆款公式搭建画面：暖色调节日氛围场景（挂件挂在木门/墙面/壁炉钩上且麻绳挂钩可见，摆件放在木质桌面/壁炉台/床头柜上），背景有 Christmas 灯串虚化光斑或暖黄灯光，前景用节日道具点缀（礼物盒、松枝、松果、浆果、蝴蝶结、灯笼选 2~3 个）制造层次但不抢戏；机位选最能展示产品工艺与图案的角度，产品浮雕细节清晰锐利，让人一眼想点进来。',
    '白底主图': '【分镜：白底主图】\n【硬性验收】最终画面里除产品本身及其原有的信息标注元素（如 2D Flat 角标、尺寸/厚度标注圆牌）外必须一片纯白：绝对禁止出现桌子、木桌、房间、墙面、装饰物、绿植、包装。这不是修饰原图——必须把产品从参考图的场景里抠出来，重新放到纯白背景（RGB 255,255,255）上；原有的信息标注元素重绘后放到产品旁边的合适位置。\n然后：产品居中、完整清晰，四周自然留白不刻意放大；柔和棚拍光，只留极淡接地图投影；边缘锐利、材质清晰。',
    '场景图': '【分镜：场景图】\n【硬性验收】背景必须是具体真实的生活环境（能看到墙面材质、家具、绿植或光线层次），禁止纯白棚拍背景；摆放位置和机位必须与参考图明显不同（参考图在桌上，你就换成门上/墙面/壁炉边等完全不同的位置），但场景风格必须与产品气质匹配——优先沿用参考图中契合产品的氛围（色调、节日元素、道具风格）在新构图里重现，不要配一个和产品毫无关联的随机场景。\n然后按爆款套路搭场景：暖色调氛围+背景 Christmas 灯串虚化光斑或壁炉/灯笼暖光，画面里用 2~3 个节日道具（礼物盒/松枝/松果/浆果/蝴蝶结）点缀层次；挂件类必须挂在真实的门/墙/壁炉钩上并露出麻绳或挂钩；产品占画面 50%~65% 是视觉焦点，其余留给环境叙事。',
    '细节材质图': '【分镜：细节材质图】\n【硬性验收】画面必须是被镜头极度放大的某一个局部，禁止出现完整产品轮廓；机位禁止正面平视，必须从侧面 45°、斜俯拍、贴地仰拍中选一个；只能拍参考图里可见的部位，禁止虚构背面/底部等看不到的面。\n然后：可拍浮雕图案的立体层次与彩绘笔触（展现 2D 工艺的浮雕质感）、木纹与印刷层断面、图案某个角落、挂绳打结与五金件、边缘厚度；让局部充满画面，浅景深背景完全虚化，不出现文字标注。',
    '使用方法图': '【分镜：使用方法图】\n【硬性验收】画面必须出现真人的手部或半身正在操作产品（如把挂饰挂到门把手上、调整挂钩、擦拭产品），画面里没有人视为生成失败；禁止只摆拍产品。\n然后：产品按真实比例呈现，背景是适度虚化的真实环境，像抓拍的生活照片，禁止纯白背景。',
    '卖点图解': '【分镜：卖点图解】\n【硬性验收】画面必须是信息图版式：产品 + 3 条细引线 + 3 个不超过 3 个词的英文卖点短语（如 Solid Wood / Easy Hang / 16cm Wide）；只输出一张产品照片、没有任何标注文字视为失败；卖点必须来自产品真实特征（材质/工艺/尺寸/安装方式），禁止套话。\n然后：产品用斜 45° 或微俯视机位，不要正面平拍；浅色版面、留白充足、信息层级清晰。',
    '尺寸图': '【分镜：尺寸对比图】\n【硬性验收】画面里必须有一个日常参照物（成人手掌、硬币、矿泉水瓶或标准门框）与产品同框对比，没有参照物视为失败；只能标注参数里给过的真实尺寸数字，没有就绝不写数字。\n然后：背景浅色、构图简洁，可用微俯视角顺带展示厚度与立体感。',
    '注意事项图': '【分镜：注意事项图】\n【硬性验收】画面必须是信息图版式：2~3 条使用注意事项，每条配极简图标 + 极短英文（如 Indoor Use / Wipe Clean / Keep Dry）；只输出产品照片、没有任何图标文字视为失败。\n然后：产品占画面一部分即可，版面留白充足，浅色背景，干净专业。',
    '安装方法图': '【分镜：安装方法图】\n【硬性验收】画面必须是 2~3 个步骤的分步构图，每一步都有人的手部动作且标数字 1/2/3；只有一个静态画面、没有步骤感视为失败。\n然后：每步机位不同（特写手部、中景墙面、完成态全景交替）；真实环境背景，像高质量说明书但更有质感。',
    '模特图': '【分镜：模特图】\n【硬性验收】画面必须出现真实人物，并且人物是画面主角（占画面至少三分之一）：有人正在把产品挂到门上/墙上，或双手持产品面对镜头展示；画面里没有人、或人只有一只边缘小手，都视为生成失败。\n然后：人物可半身或全身，面部不必清晰，动作真实自然；产品按真实比例清晰可辨；居家或节日氛围环境，自然光，生活方式摄影质感。',
    '包装配件图': '【分镜：包装配件图】\n【硬性验收】必须是俯拍平铺（flat lay）构图：产品 + 包装 + 配件同时出现在画面里，单拍产品视为失败。\n然后：整齐摆在浅色木纹或浅灰背景上，构图有序、光线均匀，可加一小段麻绳或挂钩增加信息量。',
    '竞品对比图': '【分镜：竞品对比图】\n【硬性验收】必须是左右分屏版式：左半边顶部标注 Our Product，放的是参考图里的本品——产品图案、颜色与参考图完全一致，并且必须清晰锐利，绝对禁止把本品画模糊或画虚；右半边顶部标注 Others，放一个造型朴素、色调偏灰的普通同类产品（无任何真实品牌/logo）；中间细分隔线；不是左右分屏、或本品出现在右边、或本品模糊，都视为失败。\n然后：两边机位与光线一致，背景浅色、版式干净。'
  };

  // 类型优先级（分派时按此顺序补齐，确保不重复）
  var TYPE_ORDER = ['卖点主图', '白底主图', '场景图', '细节材质图', '使用方法图', '安装方法图', '卖点图解', '尺寸图', '注意事项图', '模特图', '包装配件图', '竞品对比图'];

  function normalizeType(t) {
    var raw = String(t || '').replace(/[\s·、,，]/g, '');
    for (var i = 0; i < TYPE_ORDER.length; i++) {
      var k = TYPE_ORDER[i];
      if (raw.indexOf(k.slice(0, 4)) >= 0 || k.indexOf(raw.slice(0, 3)) >= 0) return k;
    }
    if (/卖点主图|主视觉|hero/i.test(raw)) return '卖点主图';
    if (/主图|白底/.test(raw)) return '白底主图';
    if (/场景|生活/.test(raw)) return '场景图';
    if (/细节|材质/.test(raw)) return '细节材质图';
    if (/安装/.test(raw)) return '安装方法图';
    if (/使用/.test(raw)) return '使用方法图';
    if (/卖点/.test(raw)) return '卖点图解';
    if (/尺寸/.test(raw)) return '尺寸图';
    if (/注意/.test(raw)) return '注意事项图';
    if (/模特|人物/.test(raw)) return '模特图';
    if (/包装|配件/.test(raw)) return '包装配件图';
    if (/对比|竞品/.test(raw)) return '竞品对比图';
    return '场景图';
  }

  function shotPromptFor(shot) {
    var parts = [];
    var tp = TYPE_PROMPTS[shot.type];
    if (tp) parts.push(tp);
    if (shot.prompt) parts.push('【本图单独要求】' + shot.prompt);
    if (S.settings.podMode) {
      parts.push('【POD 图案微改】这是 POD 印刷图案的重新创作：主题（节日、文字内容、主色调、元素类别）与产品形态不变，但中央印刷图案必须重新设计——重新排布元素、增删装饰细节、重绘边框与背景纹理、字体重新排版，最终图案与参考图上的原图案必须明显不同，能看出是同主题的新设计；重绘精细度要对齐平台爆款插画：色彩饱满、浮雕立体感强、元素细节丰富，同时保证印刷质量：边缘清晰、颜色饱满、适合平面印刷。');
    }
    if (S.settings.imagePrompt) parts.push(S.settings.imagePrompt);
    return parts.join('\n\n');
  }

  function aiImageEdit(imageUrl, shotPrompt, shot) {
    var promptText = shot ? shotPromptFor(shot) : ((shotPrompt || '') + '\n\n' + (S.settings.imagePrompt || ''));
    return sendBg({
      cmd: 'imageEdit',
      baseUrl: S.settings.imgBaseUrl,
      apiKey: S.settings.imgApiKey,
      model: S.settings.imgModel,
      prompt: promptText,
      imageUrl: imageUrl,
      size: '1024x1024'
    });
  }
  function pLimit(n) {
    var active = 0, q = [];
    function next() {
      while (active < n && q.length) {
        var job = q.shift();
        active++;
        Promise.resolve().then(job).then(function () { active--; next(); }, function () { active--; next(); });
      }
    }
    return function (fn) {
      return new Promise(function (res, rej) {
        q.push(function () { return Promise.resolve().then(fn).then(res, rej); });
        next();
      });
    };
  }

  /* ================= 编辑页模式 ================= */
  var E = {
    active: false,        // 编辑页打开中
    info: null,           // {title, enTitle, imgUrls[]}
    detailId: '',
    running: false,
    titleState: '待处理', imgState: '待处理',
    titleOk: false, imgOk: false,
    newZh: '', newEn: '', newImgDataUrl: '',
    shots: [], planBrief: '', imgUrls: [],
    advices: [],
    log: [],
    prompts: [],       // 实际下发的提示词记录 {t, kind, text}
    promptOpen: false  // 提示词日志面板是否展开
  };

  // 并发 + 每分钟窗口限流：防止短时间突发触发中转站 RPM 限制（实测突发12个请求尾延迟到400s+）
  function pRate(maxConc, perWindow, windowMs) {
    var active = 0, q = [], stamps = [];
    function prune() {
      var now = Date.now();
      stamps = stamps.filter(function (t) { return now - t < windowMs; });
    }
    function next() {
      prune();
      while (active < maxConc && stamps.length < perWindow && q.length) {
        var job = q.shift();
        active++;
        stamps.push(Date.now());
        Promise.resolve().then(job).then(function () { active--; next(); }, function () { active--; next(); });
      }
      if (q.length) {
        var oldest = stamps[0] || 0;
        var wait = Math.max(800, windowMs - (Date.now() - oldest) + 200);
        setTimeout(next, wait);
      }
    }
    return function (fn) {
      return new Promise(function (res, rej) {
        q.push(function () { return Promise.resolve(fn()).then(res, rej); });
        next();
      });
    };
  }

  // 记录实际下发的提示词（面板可查看 + 控制台 [ms-ai] 前缀）
  function plog(kind, text) {
    try {
      E.prompts.push({ t: new Date().toLocaleTimeString(), kind: kind, text: String(text || '') });
      if (E.prompts.length > 40) E.prompts.shift();
      console.log('%c[ms-ai] ' + kind + '\n' + text, 'color:#7c4dff');
    } catch (e) {}
  }

  function elog(msg) {
    E.log.unshift('[' + new Date().toLocaleTimeString() + '] ' + msg);
    if (E.log.length > 60) E.log.pop();
    renderEditLog();
  }

  function findEditorOverlay() {
    var ovs = document.querySelectorAll('.jx-overlay');
    for (var i = 0; i < ovs.length; i++) {
      var o = ovs[i];
      var st = getComputedStyle(o);
      if (st.display === 'none' || st.visibility === 'hidden') continue;
      var r = o.getBoundingClientRect();
      if (r.width < 500) continue;
      var zh = o.querySelector('input[placeholder="请输入产品标题"]');
      if (zh || /产品轮播图/.test(o.textContent)) return o;
    }
    return null;
  }

  function getEditorContext(ov) {
    var zh = ov.querySelector('input[placeholder="请输入产品标题"]');
    var en = ov.querySelector('input[placeholder="请输入英语标题"], input[placeholder="请输入英文标题"]');
    // 轮播图第一张原图 URL
    var srcImg = '';
    var area = tileListEl(ov) || ov.querySelector('.product-picture-list');
    if (area) {
      var imgs = area.querySelectorAll('img.jx-image__inner, img');
      for (var i = 0; i < imgs.length; i++) {
        var s = imgs[i].currentSrc || imgs[i].src || '';
        if (/kwcdn|chengji|oss|aliyuncs|http/.test(s) && imgs[i].offsetWidth > 40) { srcImg = s.split('?')[0]; break; }
      }
    }
    return { zh: zh, en: en, srcImg: srcImg };
  }

  function setNativeValue(input, val) {
    var proto = input.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    var desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(input, val);
    else input.value = val;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function fillTitleInputs(ov, zh, en) {
    var ctx = getEditorContext(ov);
    if (!ctx.zh && !ctx.en) throw new Error('编辑页里没找到标题输入框');
    if (ctx.zh && zh) setNativeValue(ctx.zh, zh);
    if (ctx.en && en) setNativeValue(ctx.en, en);
  }

  function dataUrlToJpegFile(dataUrl, maxSide) {
    return new Promise(function (res, rej) {
      var img = new Image();
      img.onload = function () {
        try {
          var size = Math.max(img.width, img.height);
          var side = Math.min(Math.max(size, 1024), maxSide || 1600);
          // 保证 1:1（妙手要求宽高比 1:1 且 >800px）
          var c = document.createElement('canvas');
          c.width = side; c.height = side;
          var ctx = c.getContext('2d');
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, side, side);
          var scale = Math.min(side / img.width, side / img.height);
          var w = img.width * scale, h = img.height * scale;
          ctx.drawImage(img, (side - w) / 2, (side - h) / 2, w, h);
          var out = c.toDataURL('image/jpeg', 0.9);
          var bin = atob(out.split(',')[1]);
          var bytes = new Uint8Array(bin.length);
          for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
          res(new File([bytes], 'ai_' + Date.now() + '.jpg', { type: 'image/jpeg' }));
        } catch (e) { rej(e); }
      };
      img.onerror = function () { rej(new Error('AI 图片解码失败')); };
      img.src = dataUrl;
    });
  }

  function waitFor(fn, timeout, step) {
    var t0 = Date.now();
    return new Promise(function (res, rej) {
      (function poll() {
        var v = fn();
        if (v) return res(v);
        if (Date.now() - t0 > (timeout || 8000)) return rej(new Error('等待超时'));
        setTimeout(poll, step || 300);
      })();
    });
  }

  // 只认「产品轮播图」那一个容器，避免把页面里别的图片列表算进来导致索引错位
  function tileListEl(ov) {
    var lists = ov.querySelectorAll('.product-picture-list');
    for (var i = 0; i < lists.length; i++) {
      var r = lists[i].getBoundingClientRect();
      if (r.width > 100 && r.height > 40) return lists[i];
    }
    return lists.length ? lists[0] : null;
  }
  function tileItems(ov) {
    try {
      var list = tileListEl(ov);
      if (!list) return [];
      return Array.prototype.slice.call(list.querySelectorAll('.product-picture-item')).filter(function (it) {
        var r = it.getBoundingClientRect();
        if (r.width < 20 || r.height < 20) return false;
        var st = getComputedStyle(it);
        return st.display !== 'none' && st.visibility !== 'hidden';
      });
    } catch (e) { return []; }
  }

  // 编辑页当前轮播图所有图片地址（按显示顺序）
  function getTileSrcs(ov) {
    var out = [];
    tileItems(ov).forEach(function (it) {
      var im = it.querySelector('img');
      if (im && im.src) out.push(im.src);
    });
    return out;
  }

  function visiblePopperImageInput() {
    var ps = document.querySelectorAll('.jx-popper, .el-popover, .jx-tooltip');
    for (var i = 0; i < ps.length; i++) {
      var p = ps[i], st = getComputedStyle(p);
      if (st.display === 'none' || st.visibility === 'hidden') continue;
      if (p.getBoundingClientRect().width < 50) continue;
      var f = p.querySelector('input[type=file]');
      if (f && /image/.test(f.accept || '')) return f;
    }
    return null;
  }

  function injectFile(input, file) {
    var dt = new DataTransfer();
    dt.items.add(file);
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // tileIndex 有值 = 用该瓦片的「上传图片」图标原地替换那一张（洗图）；否则追加到末尾
  function injectImageToEditor(ov, file, tileIndex) {
    var hasTile = (typeof tileIndex === 'number' && tileIndex >= 0);
    var target = hasTile ? tileItems(ov)[tileIndex] : null;
    var oldSrc = target ? ((target.querySelector('img') || {}).src || '') : '';
    var cntBefore = currentImgCount(ov);

    var snapshot = function () { return Array.prototype.slice.call(document.querySelectorAll('input[type=file]')); };
    var before = snapshot();

    var trigger = null;
    if (hasTile) {
      // 替换必须走对应瓦片，瓦片不存在绝不能静默变成追加（会多出一张重复图）
      if (!target) return Promise.reject(new Error('原图第 ' + (tileIndex + 1) + ' 张不存在，无法替换'));
      trigger = target.querySelector('.operate-btn-group .shopee-icon-shangchuantupian') ||
                target.querySelector('.shopee-icon-shangchuantupian');
      if (!trigger) return Promise.reject(new Error('原图第 ' + (tileIndex + 1) + ' 张没有替换入口'));
    } else {
      // 追加必须加到「产品轮播图」这个容器，别加到外包装图片那边
      var list = tileListEl(ov);
      trigger = (list && list.querySelector('.add-image-box')) ||
                (list && list.parentElement && list.parentElement.querySelector('.add-image-box')) ||
                ov.querySelector('.add-image-box');
    }
    if (!trigger) return Promise.reject(new Error('没找到图片添加入口'));

    trigger.click();

    // 只认“点击后新挂载”的 file input，避免用到上一次残留的陈旧节点
    var findNew = function () {
      var now = snapshot();
      for (var i = now.length - 1; i >= 0; i--) {
        if (before.indexOf(now[i]) < 0 && /image/.test(now[i].accept || '')) return now[i];
      }
      return visiblePopperImageInput();
    };

    return waitFor(findNew, 9000, 250).then(function (input) {
      if (!input) throw new Error('上传入口未挂载（可重试）');
      injectFile(input, file);

      if (hasTile) {
        // 替换：张数不变，靠图片地址变化来确认
        return waitFor(function () {
          var it = tileItems(ov)[tileIndex];
          var src = it ? ((it.querySelector('img') || {}).src || '') : '';
          return (src && src !== oldSrc) ? true : null;
        }, 30000, 700).then(function () { return true; }).catch(function () { return null; });
      }

      return waitFor(function () {
        var ov2 = findEditorOverlay() || ov;
        return currentImgCount(ov2) > cntBefore ? true : null;
      }, 20000, 700).then(function () { return true; }).catch(function () { return null; });
    });
  }

  // ===== v1.9.5 批量写入：批量删除旧图 + 一次性批量上传新图（实测比逐张排队快一个量级）=====
  function realClickEl(el) {
    try {
      el.scrollIntoView({ block: 'center' });
      var r = el.getBoundingClientRect();
      var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      var deep = document.elementFromPoint(cx, cy) || el;
      ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (ev) {
        var C = ev.indexOf('pointer') === 0 ? (window.PointerEvent || MouseEvent) : MouseEvent;
        deep.dispatchEvent(new C(ev, { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy }));
      });
    } catch (e) {}
  }

  // 可见且文字精确匹配的元素（button 优先，其次叶子 span/div/li）
  function visTextEls(txt) {
    var out = [];
    Array.prototype.slice.call(document.querySelectorAll('button,span,div,li,th,td')).forEach(function (el) {
      var t = (el.textContent || '').trim();
      if (t !== txt) return;
      var r = el.getBoundingClientRect();
      if (r.width < 5 || r.height < 5) return;
      if (el.tagName === 'BUTTON' || el.children.length === 0) out.push({ el: el, top: r.top, left: r.left, r: r });
    });
    out.sort(function (a, b) { return a.top - b.top; });
    return out.map(function (x) { return x; });
  }

  function waitMs(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  // 点确认弹窗里的「确定」（轮播图批量删除会弹）
  function confirmDialogOnce() {
    return waitFor(function () {
      var items = visTextEls('确定').filter(function (x) { return x.r.left > 400 && x.r.top > 100 && x.r.top < 950; });
      return items.length ? items[items.length - 1].el : null;
    }, 4000, 200).catch(function () { return null; });
  }

  // hook 图片类 file input 的 click，捕获「本地上传」菜单真正使用的那个输入框
  function hookImageInputs(state) {
    Array.prototype.slice.call(document.querySelectorAll('input[type=file]')).forEach(function (inp) {
      if (!/image/.test(inp.accept || '') || inp.__msHooked) return;
      inp.__msHooked = true;
      var orig = inp.click.bind(inp);
      inp.click = function () { state.hit = inp; try { return orig(); } catch (e) {} };
    });
  }

  // 批量删除轮播图全部旧图 → 批量上传新图（顺序=数组顺序，主图在前）
  function batchWriteCarousel(ov, okShots) {
    var n = okShots.length;
    // A. 批量删除（轮播图已是 0 张就跳过；确认弹窗没出现也继续）
    return Promise.resolve().then(function () {
      var ov0 = findEditorOverlay() || ov;
      if (currentImgCount(ov0) === 0) return null;
      var dels = visTextEls('批量删除');
      if (!dels.length) throw new Error('找不到轮播图「批量删除」按钮');
      var el = dels[0].el;
      realClickEl(el);
      return confirmDialogOnce().catch(function () { return null; }).then(function (ok) {
        if (ok) realClickEl(ok);
        return waitFor(function () {
          var ov2 = findEditorOverlay() || ov;
          return currentImgCount(ov2) === 0 ? true : null;
        }, 15000, 300).catch(function () { return null; });
      });
    }).then(function () {
      // B. 批量上传：hook → 上传图片 → 本地上传 → 直接把全部文件塞进同一个 input
      var state = { hit: null };
      hookImageInputs(state);
      var ups = visTextEls('上传图片');
      if (!ups.length) throw new Error('找不到轮播图「上传图片」按钮');
      var up = ups[0];
      realClickEl(up.el);
      return waitFor(function () {
        // 注意：realClickEl 会滚动页面，必须每次重新测量按钮位置
        var bTop = up.el.getBoundingClientRect().top;
        var items = visTextEls('本地上传').filter(function (x) {
          return x.r.top > bTop && x.r.top < bTop + 500 && x.r.left > 500;
        });
        return items.length ? items[0].el : null;
      }, 6000, 150).catch(function () { return null; }).then(function (local) {
        if (!local) throw new Error('上传菜单里找不到「本地上传」');
        realClickEl(local);
        return waitFor(function () { return state.hit; }, 6000, 100).catch(function () { return null; });
      }).then(function (inp) {
        if (!inp) throw new Error('上传组件未响应（file input 未挂载）');
        var dt = new DataTransfer();
        okShots.forEach(function (s) { dt.items.add(s.file); });
        inp.files = dt.files;
        inp.dispatchEvent(new Event('change', { bubbles: true }));
        elog('⬆ 已提交 ' + n + ' 张，等待妙手接收…');
        return waitFor(function () {
          var ov2 = findEditorOverlay() || ov;
          return currentImgCount(ov2) >= n ? true : null;
        }, 90000, 300).catch(function () { throw new Error('上传已提交但 90 秒内张数未到 ' + n + '（妙手接收慢或被校验拦截）'); });
      });
    });
  }

  // SKU 预览图同步：切到销售属性标签，把每个 SKU 的预览图换成主图
  function syncSkuPreviews(masterFile) {
    var tabs = visTextEls('销售属性');
    if (!tabs.length) return Promise.resolve(0);
    realClickEl(tabs[tabs.length - 1].el);
    return waitMs(1500).then(function () {
      var heads = visTextEls('预览图');
      if (!heads.length) return Promise.resolve(0);
      var hx = heads[0].r.left, hy = heads[0].r.top;
      var tiles = Array.prototype.slice.call(document.querySelectorAll('.product-picture-item')).filter(function (t) {
        var r = t.getBoundingClientRect();
        return r.width > 30 && Math.abs(r.left - hx) < 140 && r.top > hy && r.top < hy + 700;
      });
      var count = 0;
      var chain = Promise.resolve();
      tiles.forEach(function (tile) {
        chain = chain.then(function () {
          tile.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
          return waitMs(350);
        }).then(function () {
          var oldSrc = (tile.querySelector('img') || {}).src || '';
          var trig = tile.querySelector('.shopee-icon-shangchuantupian');
          if (!trig) return;
          var before = Array.prototype.slice.call(document.querySelectorAll('input[type=file]'));
          trig.click();
          return waitFor(function () {
            var now = Array.prototype.slice.call(document.querySelectorAll('input[type=file]'));
            for (var i = now.length - 1; i >= 0; i--) {
              if (before.indexOf(now[i]) < 0 && /image/.test(now[i].accept || '')) return now[i];
            }
            return null;
          }, 8000, 200).catch(function () { return null; }).then(function (inp) {
            if (!inp) return;
            injectFile(inp, masterFile);
            return waitFor(function () {
              var im = tile.querySelector('img');
              return im && im.src && im.src !== oldSrc ? true : null;
            }, 15000, 400).catch(function () { return null; }).then(function () { count++; });
          });
        });
      });
      return chain.then(function () { return count; });
    });
  }

  function ensureEditorInfo() {
    // v3.7.94 修复：原来只要缓存里已有标题就直接返回，切换商品/SKU 后仍用上一个商品的标题建提示词，
    // 导致洗出来的图跟当前商品不符。这里先跟页面上的实时标题比对，不一致就重读。
    if (E.info && E.info.title) {
      try {
        var ovC = findEditorOverlay();
        var liveZh = ovC && getEditorContext(ovC).zh ? String(getEditorContext(ovC).zh.value || '').trim() : '';
        if (!liveZh || liveZh === E.info.title) return Promise.resolve(E.info);
        E.info = null;
      } catch (eS) { return Promise.resolve(E.info); }
    }
    var ov = findEditorOverlay();
    if (!ov) throw new Error('没有检测到打开的编辑页');
    var ctx = getEditorContext(ov);
    var zhTitle = ctx.zh ? ctx.zh.value.trim() : '';
    var enTitle = ctx.en ? ctx.en.value.trim() : '';
    if (!zhTitle) throw new Error('编辑页标题为空，无法识别商品');
    E.info = { title: zhTitle, enTitle: enTitle, imgUrls: ctx.srcImg ? [ctx.srcImg] : [] };
    return Promise.resolve(E.info);
  }

  // 🔄 刷新：重新读当前打开的编辑页（切换 SKU / 切换商品后用）
  function refreshEditor(btn) {
    if (E.running) { elog('任务进行中，稍后再刷新'); return; }
    var ov = findEditorOverlay();
    if (!ov) { elog('❌ 没检测到打开的编辑页（先打开一个商品的编辑页）'); return; }
    var ctx = getEditorContext(ov);
    var zh = ctx.zh ? String(ctx.zh.value || '').trim() : '';
    var en = ctx.en ? String(ctx.en.value || '').trim() : '';
    if (!zh && !en) { elog('❌ 页面里没读到标题，刷新失败'); return; }

    // 上一轮的生成结果对当前商品已无意义，清掉
    E.newZh = ''; E.newEn = ''; E.newImgDataUrl = '';
    E.titleOk = false; E.imgOk = false;
    E.titleState = '待处理'; E.titleCls = '';
    E.imgState = '待处理'; E.imgCls = '';
    E.advices = [];
    E.info = { title: zh, enTitle: en, imgUrls: ctx.srcImg ? [ctx.srcImg] : [] };
    renderEdit();
    elog('🔄 已刷新当前商品：' + zh.slice(0, 24) + (ctx.srcImg ? '（已读到主图）' : '（未读到主图）'));

    if (btn) {
      btn.disabled = true;
      setTimeout(function () { btn.disabled = false; }, 700);
    }

    // 有 detailId 时再从服务端拉一次最新详情，校准图片列表
    if (E.detailId) {
      getDetail(E.detailId, true).then(function (info) {
        var imgs = Array.isArray(info.imgUrls) ? info.imgUrls : [];
        if (imgs.length) E.info.imgUrls = imgs;
        renderEdit();
      }).catch(function () {});
    }
  }

  function edSetState(which, text, cls) {
    if (which === 'title') { E.titleState = text; E.titleCls = cls || ''; }
    else { E.imgState = text; E.imgCls = cls || ''; }
    renderEditStatus();
  }

  // 读编辑页表单里可见的属性（label → 值），给文本模型当分析依据
  function getPageAttrs(ov) {
    var out = [], seen = {};
    var items = ov.querySelectorAll('.jx-form-item, .el-form-item');
    for (var i = 0; i < items.length && out.length < 24; i++) {
      var lab = items[i].querySelector('.jx-form-item__label, .el-form-item__label, label');
      var labText = lab ? String(lab.textContent || '').replace(/[\*：:\s]+/g, '') : '';
      if (!labText || labText.length > 12 || seen[labText]) continue;
      var val = '';
      var inputs = items[i].querySelectorAll('input, textarea');
      for (var k = 0; k < inputs.length; k++) {
        var inp = inputs[k];
        if (inp.type === 'file' || inp.type === 'hidden') continue;
        var v = String(inp.value || '').trim();
        if (v && !/^(请选择|请输入)/.test(v)) { val = v; break; }
      }
      if (!val) {
        var sel = items[i].querySelector('.jx-select__selected, .jx-input__inner, .selected-value');
        if (sel) val = String(sel.textContent || '').trim();
      }
      if (!val || val.length > 80) continue;
      seen[labText] = 1;
      out.push(labText + '：' + val);
    }
    return out.join('\n');
  }

  function currentImgCount(ov) {
    var box = tileListEl(ov) || ov.querySelector('.product-picture-list');
    var m = (box || { textContent: '' }).textContent.match(/当前\s*(\d+)\s*张/);
    if (m) return parseInt(m[1], 10);
    return tileItems(ov).length;
  }

  // 模型没给够方案时的兜底提示词
  var FALLBACK_SHOTS = [
    { type: '白底主图', prompt: '亚马逊标准白底主图：纯白背景（RGB 255,255,255），产品完整居中、清晰突出，四周自然留白，专业影棚柔和布光，只允许极淡的接地图投影，无道具无文字无水印，产品所有细节边缘清晰锐利，1:1正方形高清商业摄影。' },
    { type: '场景图', prompt: '亚马逊A+级生活场景图：把产品放进真实使用场景（门口/墙面/客厅等与用途匹配的环境），产品大小自然、是视觉焦点但不占满画面，环境有生活气息和层次，背景轻微虚化，自然窗光暖调氛围，画面干净，产品外观不变，1:1正方形高清。' },
    { type: '细节材质图', prompt: '亚马逊级细节图：从侧面45°或斜俯拍等非正面机位微距特写产品的某个局部（木纹、印刷颗粒、挂绳五金），浅景深，45度侧光勾勒立体感，局部充满画面，纯色浅灰虚化背景，产品图案文字不变，1:1正方形。' },
    { type: '使用方法图', prompt: '亚马逊使用场景图：有人的手部或半身入镜，展示产品正在被挂上/使用的真实动作，产品按真实比例呈现，背景是适度虚化的真实环境，像抓拍的生活照片，无任何文字标注，1:1正方形高清。' },
    { type: '卖点图解', prompt: '亚马逊A+级卖点图：产品以斜45°或微俯视机位展示，周围干净留白，根据产品真实特征提炼3个卖点，用极细引线引出极短英文单词（如 Wooden / Easy Hang / Solid Wood），版式专业、信息层级清晰，无衬线字体，产品本身完全不变，1:1正方形。' }
  ];

  function fallbackShot(i) {
    var f = FALLBACK_SHOTS[i % FALLBACK_SHOTS.length];
    return { type: f.type, prompt: f.prompt, refIndex: 0 };
  }

  function edRun(mode) {
    if (E.running) return elog('任务进行中，请稍候');
    if (E.descBusy) return elog('描述图同步进行中，请稍候');
    var ov = findEditorOverlay();
    if (!ov) { elog('❌ 没检测到打开的编辑页（先打开一个商品的编辑页）'); renderEdit(); return; }

    E.running = true;
    E.mode = mode || 'all';
    E.advices = [];
    E.shots = [];
    E.prompts = [];
    E.planBrief = '';
    renderEdit();

    var doTitle = mode !== 'img';
    var doImg = mode !== 'title';

    // v3.7.94 修复：ensureEditorInfo 是同步函数，异常（编辑页标题为空/没检测到编辑页）会直接冒泡，
    // 跳过下面的 .catch → E.running 卡在 true，按钮永久禁用且日志无报错。包一层 Promise 让异常走同一 catch。
    Promise.resolve().then(ensureEditorInfo).then(function (info) {
      var ov2 = findEditorOverlay() || ov;
      var tileSrcs = getTileSrcs(ov2);
      var imgs = tileSrcs.length ? tileSrcs : (info.imgUrls || []).slice();
      var attrs = getPageAttrs(ov2);
      var n = imgs.length;
      var target = Math.min(10, Math.max(3, parseInt(S.settings.targetCount, 10) || 10));
      var appendCount = doImg ? Math.max(0, target - n) : 0;

      if (doTitle) edSetState('title', 'AI 分析中…', 'busy');
      if (doImg) edSetState('img', 'AI 看图分析中…（逐张判断保留/重做）', 'busy');
      renderEdit();
      elog('开始分析：现有图 ' + n + ' 张，目标 ' + target + ' 张，读取到 ' + (attrs ? attrs.split('\n').length : 0) + ' 条页面参数');

      return aiPlan(info, attrs, { n: n, target: target, append: appendCount }, imgs).catch(function (e) {
        elog('⚠️ 看图分析失败（' + String(e.message).slice(0, 50) + '），改用纯文本分析');
        return aiPlan(info, attrs, { n: n, target: target, append: appendCount }, []);
      }).then(function (plan) {
        E.planBrief = plan.brief || '';
        elog('🧠 产品理解：' + (plan.brief || '（无）').slice(0, 60));
        if (plan.existingTypes && plan.existingTypes.length) elog('现有图已覆盖：' + plan.existingTypes.join('、'));

        if (doTitle) {
          var zh = plan.zh || info.title, en = plan.en || '';
          E.newZh = truncateWords(zh, 120);
          E.newEn = truncateWords(en, 245);
          try {
            fillTitleInputs(ov2, E.newZh, E.newEn);
            E.titleOk = true;
            edSetState('title', '✅ 已填入页面', 'ok');
            elog('标题已填入：' + E.newZh.slice(0, 24) + '…');
            E.advices.push('标题已填进「产品标题」「英文标题」，核对后自己保存');
          } catch (e) {
            edSetState('title', '❌ ' + e.message.slice(0, 30), 'err');
            elog('❌ 填标题失败：' + e.message);
          }
        }

        if (!doImg) return null;

        // 智能决策：images[] 逐张 keep/wash；模型没给 images 时回退到全部 wash
        var decisions = {};
        (plan.images || []).forEach(function (d) {
          if (d.index >= 0 && d.index < n && !decisions[d.index]) decisions[d.index] = d;
        });
        var hasDecisions = Object.keys(decisions).length >= Math.min(n, 3);

        // 兼容旧格式 replaceShots：视为全部 wash
        var repMap = {};
        if (!hasDecisions) {
          (plan.replaceShots || []).forEach(function (r) {
            var idx = parseInt(r.index, 10);
            if (idx >= 0 && idx < n && !repMap[idx]) repMap[idx] = r;
          });
        }

        // 类型去重分派：同一轮里每种图只出现一次
        var usedTypes = {};
        var hasSize = /尺寸|长|宽|高|cm|mm/i.test(attrs || '');
        // v3.7.94 修复：白底主图只能出现在第一张。原实现里 usedTypes['白底主图']=1 是在循环之后才设的，
        // 非首张仍可能被 pickType 分到白底主图。这里按位置直接禁用。
        function pickType(prefer, noWhite) {
          var t = prefer ? normalizeType(prefer) : '';
          if (noWhite && t === '白底主图') t = '';
          if (t && !usedTypes[t]) { usedTypes[t] = 1; return t; }
          for (var k = 0; k < TYPE_ORDER.length; k++) {
            var c = TYPE_ORDER[k];
            if (usedTypes[c]) continue;
            if (c === '白底主图' && noWhite) continue;
            if (c === '尺寸图' && !hasSize) continue;
            usedTypes[c] = 1;
            return c;
          }
          return t || '场景图';
        }

        var shots = [];
        var keepCount = 0;
        for (var i = 0; i < n; i++) {
          var d = decisions[i];
          // v3.7.94 修复：勾了「全部原图强制洗图」或 POD 模式时，提示词只是建议，模型仍可能返回 keep。
          // 这里在代码层硬性忽略 keep，保证用户选的模式一定生效（POD 下保留原图=保留原图案，必须全洗）。
          if (!S.settings.washAll && !S.settings.podMode && hasDecisions && d && d.action === 'keep') {
            keepCount++;
            shots.push({
              slot: 'keep',
              tileIndex: i,
              order: shots.length + 1,
              type: d.type ? normalizeType(d.type) : '原图',
              prompt: '',
              reason: d.reason || '干净合规',
              refIndex: i,
              status: '保留',
              dataUrl: '',
              keepUrl: imgs[i]
            });
            continue;
          }
          var hit = hasDecisions ? d : repMap[i];
          var fb = fallbackShot(i);
          var ty = pickType(hit && hit.type, i > 0);
          var pr = (hit && hit.prompt) ? hit.prompt : fb.prompt;
          if (S.settings.podMode) {
            // POD 模式：白底主图一律替换为卖点主图（含兜底 prompt）
            if (ty === '白底主图') {
              ty = '卖点主图';
              pr = '把产品从原图场景里完整抠出，重新创作：中央印刷图案按 POD 微改要求重绘（主题不变、排布重画），产品作为绝对主角做有氛围感的卖点展示，禁止纯白棚拍背景，保留产品原有的信息标注元素。';
            }
          } else {
            // 位置守恒兜底①：第一张（index 0）必须是白底主图
            if (i === 0 && ty !== '白底主图') {
              ty = '白底主图';
              pr = '把产品从原图场景里抠出，重新放到纯白背景（RGB 255,255,255）上；产品居中完整，保留产品原有的信息标注元素（2D Flat 角标/尺寸牌）。';
            }
          }
          shots.push({
            slot: 'replace',
            tileIndex: i,
            order: shots.length + 1,
            type: ty,
            prompt: pr,
            refIndex: i,
            status: '排队中',
            dataUrl: ''
          });
        }
        // 位置守恒兜底②：白底主图只能出现在第一张（POD 模式下则完全禁用白底主图），补图绝不再生成白底
        usedTypes['白底主图'] = 1;
        if (S.settings.podMode) usedTypes['卖点主图'] = 1;
        var addSrc = hasDecisions ? (plan.addShots || []) : (plan.appendShots || []);
        var apps = addSrc.slice(0, appendCount);
        for (var j = apps.length; j < appendCount; j++) apps.push(fallbackShot(n + j));
        apps.forEach(function (a) {
          shots.push({
            slot: 'append',
            order: shots.length + 1,
            type: pickType(a.type),
            prompt: a.prompt || fallbackShot(n).prompt,
            refIndex: Math.max(0, Math.min(n - 1, parseInt(a.refIndex, 10) || 0)),
            status: '排队中',
            dataUrl: ''
          });
        });

        E.shots = shots;
        var genCount = shots.length - keepCount;
        elog('洗图方案：保留 ' + keepCount + ' 张原图（干净合规，直接跳过生成），洗 ' +
          (n - keepCount) + ' 张' + (appendCount ? ('，另补 ' + appendCount + ' 张') : '') +
          ' → 实际需生成 ' + genCount + ' 张，预计 ' + Math.ceil(genCount / Math.max(2, Math.min(10, parseInt(S.settings.imgPerMin, 10) || 8))) + ' 个批次');
        shots.forEach(function (x) {
          if (x.slot === 'keep') elog('  ⊘ 原图' + (x.tileIndex + 1) + ' 保留（' + x.reason + '）');
        });
        edSetState('img', '0/' + genCount + ' 生成中…', 'busy');
        renderEdit();

        var done = 0, replaced = 0, appended = 0;
        var perMin = Math.max(2, Math.min(20, parseInt(S.settings.imgPerMin, 10) || 10));
        var maxConc = Math.max(2, Math.min(20, parseInt(S.settings.concurrency, 10) || 10));
        var limit = pRate(maxConc, perMin, 60000);

        function tick(stage) {
          edSetState('img', '生成 ' + done + '/' + genCount + ' · 替换 ' + replaced + '/' + (n - keepCount) +
            ' · 追加 ' + appended + '/' + appendCount + (keepCount ? ' · 保留 ' + keepCount : '') + (stage ? ' · ' + stage : ''), 'busy');
        }

        // 全部按下发（中转站支持并发），失败自动重试一次
        // POD 模式：第一张生成的图是「主设计定稿」，其余所有图全部参考主设计图生成，
        // 保证整套图的图案/主体/体积/材质/颜色/形状完全一致
        var masterShot = S.settings.podMode ? (shots.filter(function (s) { return s.slot !== 'keep'; })[0] || null) : null;
        var masterGen = null;
        var genOnce = function (shot) {
          var ref = (masterShot && shot !== masterShot && masterShot.dataUrl)
            ? masterShot.dataUrl
            : (imgs[Math.min(shot.refIndex, imgs.length - 1)] || imgs[0]);
          // 记录实际下发的生图提示词（= 类型分镜 + 本图要求 + 通用约束）
          plog('🖼 生图提示词 → ' + S.settings.imgModel + ' · ' +
            (shot.slot === 'replace' ? ('洗图' + (shot.tileIndex + 1)) : '补图') + ' · ' + shot.type,
            '【参考原图】' + ref + '\n\n' + shotPromptFor(shot));
          return aiImageEdit(ref, shot.prompt, shot).then(function (data) {
            var u = data.dataUrl || data.url;
            if (!u) throw new Error('未返回图片');
            return u;
          });
        };

        var gens = shots.map(function (shot) {
          if (shot.slot === 'keep') return Promise.resolve(null); // 保留：不生成不注入
          var task = function () {
            shot.status = '生成中';
            shot.t0 = Date.now();
            elog('▶ 开始生成：' + (shot.slot === 'replace' ? ('洗图' + (shot.tileIndex + 1) + ' · ') : '补图 · ') + shot.type);
            renderEdit();
            var run = function () {
              return genOnce(shot).catch(function () {
                return new Promise(function (r) { setTimeout(r, 800); }).then(function () { return genOnce(shot); });
              }).then(function (u) {
              shot.dataUrl = u;
              shot.status = '已生成';
              done++;
              tick();
              elog('✔ ' + shot.type + ' 用时 ' + Math.round((Date.now() - shot.t0) / 1000) + 's');
              renderEdit();
              return u;
              }).catch(function (e) {
                shot.status = '失败';
                done++;
                tick();
                elog('❌ [' + shot.type + '] ' + String(e.message).slice(0, 40) + '（' + Math.round((Date.now() - shot.t0) / 1000) + 's）');
                renderEdit();
                return null;
              });
            };
            // POD：非主图必须等主设计图出来才开跑（主图在 shots 最前，其 promise 先赋值）
            if (masterShot && shot !== masterShot && masterGen) {
              return masterGen.then(function (mu) { return run(); });
            }
            return run();
          };
          var pr = limit(task);
          if (shot === masterShot) masterGen = pr;
          return pr;
        });

        // 注入阶段：0 保留时走批量链路（批量删除+批量上传，快一个量级）；有保留图时走旧逐张链（保留图不动）
        var injectP;
        if (keepCount === 0) {
          injectP = Promise.all(gens).then(function () {
            // 转码并行前置（CPU 活，不再挤在串行链上）
            var todo = shots.filter(function (s) { return s.dataUrl && !s.file; });
            if (todo.length) {
              tick('并行转码 ' + todo.length + ' 张…');
              elog('⏬ 全部生成完毕，并行转码 ' + todo.length + ' 张');
            }
            return Promise.all(todo.map(function (s) {
              return dataUrlToJpegFile(s.dataUrl).then(function (f) { s.file = f; }).catch(function () {});
            }));
          }).then(function () {
            var okShots = shots.filter(function (s) { return s.file; });
            if (!okShots.length) throw new Error('没有一张图生成成功');
            // 排序：洗图按原位置（主图在前），补图殿后 → 批量上传后顺序即最终顺序
            okShots.sort(function (a, b) {
              var ra = a.slot === 'replace' ? a.tileIndex : 1000 + a.order;
              var rb = b.slot === 'replace' ? b.tileIndex : 1000 + b.order;
              return ra - rb;
            });
            tick('批量写入 ' + okShots.length + ' 张（删旧+传新）');
            return batchWriteCarousel(ov2, okShots).then(function () {
              okShots.forEach(function (s) {
                s.injected = true;
                if (s.slot === 'replace') replaced++; else appended++;
                elog('✅ ' + (s.slot === 'replace' ? '洗图' + (s.tileIndex + 1) : '补图') + ' · ' + s.type + ' 已写入轮播图');
              });
              renderEdit();
              // SKU 预览图同步换主图（第一张 = 主图）
              var masterFile = okShots[0] && okShots[0].file;
              if (masterFile) {
                tick('同步 SKU 预览图…');
                return syncSkuPreviews(masterFile).then(function (c) {
                  if (c) elog('✅ SKU 预览图已换成主图（' + c + ' 个 SKU）');
                  else elog('ℹ️ 没有找到需要同步的 SKU 预览图');
                }).catch(function (e) {
                  elog('⚠️ SKU 预览图同步失败（可手动换）：' + String(e.message).slice(0, 60));
                });
              }
            });
          });
        } else {
          // 有保留图：走旧逐张链（replace 原位替换 + append 追加），保留的原图不受影响
          var chain = Promise.resolve();
          shots.forEach(function (shot, i) {
            chain = chain.then(function () {
              return gens[i].then(function (u) {
                if (!u) return;
                if (shot.slot === 'append' && currentImgCount(ov2) >= 10) {
                  elog('⚠️ 轮播图已满 10 张，「' + shot.type + '」未追加');
                  return;
                }
                tick(shot.slot === 'replace' ? ('替换原图 ' + (shot.tileIndex + 1)) : ('追加 ' + shot.type));
                return dataUrlToJpegFile(u)
                  .then(function (file) {
                    return injectImageToEditor(ov2, file, shot.slot === 'replace' ? shot.tileIndex : null);
                  })
                  .then(function (confirmed) {
                    // v3.7.94：只有确实观察到新图才算写入成功，超时/上传失败（confirmed 为 null）时不再虚报
                    if (confirmed) { if (shot.slot === 'replace') replaced++; else appended++; }
                    shot.injected = true;
                    tick();
                    elog((confirmed ? '✅ ' : '⚠️ ') + (shot.slot === 'replace'
                      ? ('原图 ' + (shot.tileIndex + 1) + ' 已替换为「' + shot.type + '」')
                      : ('已追加「' + shot.type + '」')) + (confirmed ? '' : '（未确认，妙手可能仍在上传，请翻页核对）'));
                    renderEdit();
                  }).catch(function (e) {
                    elog('❌ ' + (shot.slot === 'replace' ? '替换' : '追加') + '失败：' + String(e.message).slice(0, 40));
                  });
              });
            });
          });
          injectP = chain;
        }

        return injectP.then(function () {
          E.imgOk = (replaced + appended) > 0 || (keepCount === n && genCount === 0 && appendCount === 0);
          E.newImgDataUrl = (shots.filter(function (x) { return x.dataUrl; })[0] || {}).dataUrl || '';
          if (!E.imgOk) throw new Error('没有一张图成功写入页面');
          edSetState('img', '✅ 保留 ' + keepCount + ' 张 · 洗 ' + replaced + '/' + (n - keepCount) + ' 张' +
            (appendCount ? (' · 追加 ' + appended + '/' + appendCount + ' 张') : '') +
            '（现共 ' + currentImgCount(ov2) + ' 张）', 'ok');
          if (keepCount) E.advices.push(keepCount + ' 张原图干净合规已保留未动，省 ' + keepCount + ' 次生成（约 $' + (keepCount * 0.06).toFixed(2) + '）');
          if (replaced) E.advices.push('洗过的图已原位替换（顺序不变），调主图直接拖拽排序即可');
        });
      });
    }).then(function () {
      E.advices.push('核对无误后点妙手底部「保存修改」（插件不代你保存）');
      elog('=== 完成 ===');
      E.running = false;
      renderEdit();
    }).catch(function (e) {
      elog('❌ ' + e.message);
      E.running = false;
      renderEdit();
    });
  }

  /* ---------------- 编辑页面板 UI ---------------- */
  var editPanel, editBuilt = false;   // v3.2.1 旧版紫色 AI 浮球已删除，统一入口=小猫咪球（collectbox）

  function buildEditPanel(root) {
    editPanel = el('div', 'ms-ai-panel ms-ed-panel');

    var head = el('div', 'ms-head');
    head.appendChild(el('div', 'ms-title', '编辑页 AI 助手'));
    var tools = el('div', 'ms-head-tools');
    var btnRefresh = el('button', 'ms-mini', '🔄');
    btnRefresh.title = '刷新当前商品（切换 SKU / 商品后点一下）';
    btnRefresh.onclick = function () { refreshEditor(btnRefresh); };
    var btnSet = el('button', 'ms-mini', '⚙');
    btnSet.title = 'API 设置';
    btnSet.onclick = function () { toggleSettings(editPanel); };
    var btnMax = el('button', 'ms-mini', '⛶');
    btnMax.title = '放大 / 缩小面板';
    btnMax.onclick = function () { editPanel.classList.toggle('big'); };
    var btnPrm = el('button', 'ms-mini', '📝');
    btnPrm.title = '查看实际下发的提示词';
    btnPrm.onclick = function () {
      E.promptOpen = !E.promptOpen;
      renderPrompts();
      var pb = document.getElementById('ms-prompt-box');
      if (pb) { pb.classList.toggle('open', E.promptOpen); if (E.promptOpen) pb.scrollIntoView({ block: 'nearest' }); }
    };
    var btnClose = el('button', 'ms-mini', '×');
    btnClose.onclick = function () { editPanel.classList.remove('open'); };
    tools.appendChild(btnRefresh); tools.appendChild(btnSet); tools.appendChild(btnPrm); tools.appendChild(btnMax); tools.appendChild(btnClose);
    head.appendChild(tools);
    editPanel.appendChild(head);

    var orig = el('div', 'ms-ed-orig');
    orig.id = 'ms-ed-orig';
    editPanel.appendChild(orig);

    var actions = el('div', 'ms-actions');
    var washRow = el('label', 'ms-check');
    var washCk = document.createElement('input');
    washCk.type = 'checkbox';
    washCk.checked = !!S.settings.washAll;
    washCk.onchange = function () { S.settings.washAll = washCk.checked; persist(); };
    washRow.appendChild(washCk);
    washRow.appendChild(el('span', null, '全部原图强制洗图（不留原图，防同质化最彻底）'));
    actions.appendChild(washRow);
    var podRow = el('label', 'ms-check');
    var podCk = document.createElement('input');
    podCk.type = 'checkbox';
    podCk.checked = !!S.settings.podMode;
    podCk.onchange = function () { S.settings.podMode = podCk.checked; if (podCk.checked) { washCk.checked = true; S.settings.washAll = true; persist(); } };
    podRow.appendChild(podCk);
    podRow.appendChild(el('span', null, 'POD 微改模式（主题不变、重绘图案，防图案查重，自动强制全洗）'));
    actions.appendChild(podRow);
    var bAll = el('button', 'ms-btn primary wide', '⚡ 一键洗图 + 改标题');
    bAll.id = 'ms-ed-run-all';
    bAll.onclick = function () { edRun('all'); };
    actions.appendChild(bAll);
    var row2 = el('div', 'ms-actions');
    var bT = el('button', 'ms-btn', '✏️ 只改标题');
    bT.id = 'ms-ed-run-title';
    bT.onclick = function () { edRun('title'); };
    var bI = el('button', 'ms-btn', '🖼 只洗图');
    bI.id = 'ms-ed-run-img';
    bI.onclick = function () { edRun('img'); };
    row2.appendChild(bT); row2.appendChild(bI);
    var row3 = el('div', 'ms-actions');
    var bD = el('button', 'ms-btn wide', '🧩 描述图同步（删旧描述图→写入轮播图）');
    bD.id = 'ms-ed-run-desc';
    bD.title = '自动执行：编辑描述 → 批量操作 → 批量图片处理 → 批量删除 → 上传图片 → 使用产品图片 → 全选 → 确定 → 保存';
    bD.onclick = function () { descSync(); };
    row3.appendChild(bD);
    editPanel.appendChild(actions);
    editPanel.appendChild(row2);
    editPanel.appendChild(row3);

    var status = el('div', 'ms-ed-status');
    status.id = 'ms-ed-status';
    editPanel.appendChild(status);

    var result = el('div', 'ms-ed-result');
    result.id = 'ms-ed-result';
    editPanel.appendChild(result);

    var advice = el('div', 'ms-ed-advice');
    advice.id = 'ms-ed-advice';
    editPanel.appendChild(advice);

    var promptBox = el('div', 'ms-prompt-box');
    promptBox.id = 'ms-prompt-box';
    editPanel.appendChild(promptBox);

    var logBox = el('div', 'ms-log ms-ed-log');
    logBox.id = 'ms-ed-log';
    editPanel.appendChild(logBox);

    editPanel.appendChild(buildSettings());
    root.appendChild(editPanel);
    editBuilt = true;
  }

  // 提示词日志渲染
  function renderPrompts() {
    var box = document.getElementById('ms-prompt-box');
    if (!box) return;
    box.innerHTML = '';
    box.classList.toggle('open', !!E.promptOpen);
    if (!E.promptOpen) return;

    var headRow = el('div', 'ms-prompt-head');
    headRow.appendChild(el('span', 'ms-prompt-title', '提示词日志（' + E.prompts.length + ' 条）'));
    var cpAll = el('button', 'ms-mini', '复制全部');
    cpAll.onclick = function () {
      copyText(E.prompts.map(function (x) { return '===== ' + x.t + ' ' + x.kind + ' =====\n' + x.text; }).join('\n\n'));
      cpAll.textContent = '已复制'; setTimeout(function () { cpAll.textContent = '复制全部'; }, 1200);
    };
    var dl = el('button', 'ms-mini', '下载txt');
    dl.onclick = function () {
      var txt = E.prompts.map(function (x) { return '===== ' + x.t + ' ' + x.kind + ' =====\n' + x.text; }).join('\n\n');
      downloadText(txt, '妙手AI提示词日志-' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '') + '.txt');
    };
    headRow.appendChild(cpAll);
    headRow.appendChild(dl);
    box.appendChild(headRow);

    if (!E.prompts.length) {
      box.appendChild(el('div', 'ms-prompt-empty', '还没有发送过提示词。点「⚡ 一键洗图 + 改标题」后这里会显示完整提示词。'));
      return;
    }
    E.prompts.slice().reverse().forEach(function (x) {
      var item = el('div', 'ms-prompt-item');
      var bar = el('div', 'ms-prompt-bar');
      bar.appendChild(el('span', 'ms-prompt-kind', x.kind));
      var cp = el('button', 'ms-mini', '复制');
      cp.onclick = function () { copyText(x.text); cp.textContent = '已复制'; setTimeout(function () { cp.textContent = '复制'; }, 1200); };
      bar.appendChild(cp);
      item.appendChild(bar);
      var pre = document.createElement('pre');
      pre.className = 'ms-prompt-text';
      pre.textContent = x.text;
      item.appendChild(pre);
      box.appendChild(item);
    });
  }

  // 点击放大查看生成图
  function showZoom(src) {
    var old = document.getElementById('ms-zoom-overlay');
    if (old) old.remove();
    var ov = el('div', 'ms-zoom-overlay');
    ov.id = 'ms-zoom-overlay';
    var im = document.createElement('img');
    im.src = src;
    ov.appendChild(im);
    ov.appendChild(el('div', 'ms-zoom-tip', '点击任意位置关闭'));
    ov.onclick = function () { ov.remove(); };
    document.body.appendChild(ov);
  }

  function downloadText(text, filename) {    try {
      var blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
    } catch (e) { elog('❌ 下载失败：' + e.message); }
  }

  // ===== 描述图同步：删掉描述里的旧图，再把轮播图批量写入描述 =====
  // 采用「可见文字驱动」：按按钮文字查找并用真实命中点（最内层元素）点击。
  // 实测结论：妙手部分按钮（如「编辑描述」）的事件绑在内层元素上，直接 dispatch 到外层容器无效，
  // 必须通过 elementFromPoint 找到几何中心最内层元素再派发事件（冒泡会经过所有祖先）。
  function allRoots() {
    // v3.4.4 递归收集 iframe（含嵌套）+ Shadow DOM——导入菜单/弹窗可能渲染在隔离层里，querySelector 直接搜不到
    var roots = [document];
    function walk(doc, depth) {
      if (depth > 5) return;
      try {
        Array.prototype.slice.call(doc.querySelectorAll('iframe')).forEach(function (f) {
          try {
            if (f.contentDocument && roots.indexOf(f.contentDocument) < 0) {
              roots.push(f.contentDocument);
              walk(f.contentDocument, depth + 1);
            }
          } catch (e) {}
        });
      } catch (e) {}
      try {
        var hosts = doc.querySelectorAll('*');
        for (var i = 0; i < hosts.length; i++) {
          var sr = hosts[i].shadowRoot;
          if (sr && roots.indexOf(sr) < 0) {
            roots.push(sr);
            walk(sr, depth + 1);
          }
        }
      } catch (e) {}
    }
    walk(document, 0);
    return roots;
  }

  // 找所有可见、叶子级的候选元素；优先返回视口中心附近的一个
  function findBtnAll(re) {
    var found = [];
    allRoots().forEach(function (doc) {
      var win = doc.defaultView;
      Array.prototype.slice.call(doc.querySelectorAll('button,a,span,div,li,td,p,label')).forEach(function (x) {
        var t = (x.textContent || '').replace(/\s+/g, '');
        if (!t || t.length > 16 || !re.test(t)) return;
        var r = x.getBoundingClientRect();
        if (r.width < 5 || r.height < 5) return;
        if (win && (win.getComputedStyle(x).display === 'none' || win.getComputedStyle(x).visibility === 'hidden')) return;
        var hasSameChild = Array.prototype.slice.call(x.children || []).some(function (c) {
          return re.test((c.textContent || '').replace(/\s+/g, ''));
        });
        if (hasSameChild) return;
        found.push(x);
      });
    });
    if (!found.length) return [];
    var cx = window.innerWidth / 2, cy = window.innerHeight / 2;
    found.sort(function (a, b) {
      var ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
      var da = Math.abs(ra.left + ra.width / 2 - cx) + Math.abs(ra.top + ra.height / 2 - cy);
      var db = Math.abs(rb.left + rb.width / 2 - cx) + Math.abs(rb.top + rb.height / 2 - cy);
      return da - db;
    });
    return found;
  }

  function findBtn(re) {
    var all = findBtnAll(re);
    return all.length ? all[0] : null;
  }

  // v3.5.6 真实点击通道状态：在 ego/被其他调试器占用的浏览器里 chrome.debugger 挂不上，
  // 所有 trusted 点击都会失效（合成点击对妙手的下拉/弹层又无效），
  // 必须把「通道已死」暴露给 collectbox.js 让 RPA 快速降级直连，而不是无限重做
  var realClickState = { down: false, err: '' };
  function markRealClick(ok, err) {
    realClickState = ok ? { down: false, err: '' } : { down: true, err: String(err || 'realClick 失败') };
  }

  // 通过 background 的 chrome.debugger 派发真实受信点击（部分下拉/弹层组件对合成事件不响应）
  function sendRealClick(x, y) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ cmd: 'realClick', x: Math.round(x), y: Math.round(y) }, function (res) {
          if (chrome.runtime.lastError) { markRealClick(false, chrome.runtime.lastError.message); return resolve(false); }
          var ok = !!(res && res.ok);
          markRealClick(ok, res && res.error);
          resolve(ok);
        });
      } catch (e) { markRealClick(false, e && e.message); resolve(false); }
    });
  }

  // 通过 background 的 chrome.debugger 派发真实受信悬停（v3.2.6：妙手「导入」按钮悬停才弹下拉）
  function sendRealHover(x, y) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ cmd: 'realHover', x: Math.round(x), y: Math.round(y) }, function (res) {
          if (chrome.runtime.lastError) { markRealClick(false, chrome.runtime.lastError.message); return resolve(false); }
          var ok = !!(res && res.ok);
          markRealClick(ok, res && res.error);
          resolve(ok);
        });
      } catch (e) { markRealClick(false, e && e.message); resolve(false); }
    });
  }

  async function hoverBtn(elm) {
    try {
      elm.scrollIntoView({ block: 'center' });
      var r = elm.getBoundingClientRect();
      var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      // 1) 真实受信悬停（mouseMoved）
      await sendRealHover(cx, cy);
      // 2) 合成事件兜底：mouseover/mouseenter/mousemove/pointer 序列都打一遍
      var deep = document.elementFromPoint(cx, cy);
      if (!deep || (deep !== elm && !elm.contains(deep))) deep = elm;
      ['pointerover', 'pointerenter', 'pointermove', 'mouseover', 'mouseenter', 'mousemove'].forEach(function (ev) {
        var Ctor = ev.indexOf('pointer') === 0 ? (window.PointerEvent || MouseEvent) : MouseEvent;
        try {
          deep.dispatchEvent(new Ctor(ev, { bubbles: ev.indexOf('enter') < 0, cancelable: true, view: window, clientX: cx, clientY: cy }));
        } catch (e) {}
      });
      return true;
    } catch (e) { return false; }
  }

  async function clickBtn(elm) {
    try {
      elm.scrollIntoView({ block: 'center' });
      var r = elm.getBoundingClientRect();
      var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      // 1) 真实受信点击
      var ok = await sendRealClick(cx, cy);
      if (ok) return true;
      // 2) 兜底：合成事件打到最内层元素（冒泡会经过所有祖先）
      var deep = document.elementFromPoint(cx, cy);
      if (!deep || (deep !== elm && !elm.contains(deep))) deep = elm;
      ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (ev) {
        var Ctor = ev.indexOf('pointer') === 0 ? window.PointerEvent || MouseEvent : MouseEvent;
        deep.dispatchEvent(new Ctor(ev, { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy }));
      });
      return true;
    } catch (e) { return false; }
  }

  // 步骤执行：最多重试 attempts 次，每次找不到就等一会
  async function dStep(name, re, waitMs, attempts) {
    for (var i = 0; i < (attempts || 12); i++) {
      var b = findBtn(re);
      if (b) { clickBtn(b); elog('🧩 ' + name + ' ✓'); await dSleep(waitMs || 1500); return true; }
      await dSleep(500);
    }
    elog('❌ 描述同步在「' + name + '」这步找不到按钮');
    return false;
  }

  function snapButtons() {
    var out = [];
    allRoots().forEach(function (doc) {
      Array.prototype.slice.call(doc.querySelectorAll('button,a,[role="button"],li')).forEach(function (x) {
        var t = (x.textContent || '').replace(/\s+/g, '').slice(0, 12);
        if (!t || t.length < 2) return;
        var r = x.getBoundingClientRect();
        if (r.width < 8 || r.height < 8 || r.bottom < 0 || r.top > window.innerHeight) return;
        out.push(t);
      });
    });
    return out.slice(0, 60).join(' | ');
  }

  function dSleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  async function descSync() {
    if (E.descBusy) { elog('描述同步正在执行中，请稍候'); return; }
    if (E.running) { elog('洗图/改标题任务进行中，请等它结束后再同步描述'); return; }
    E.descBusy = true;
    function setp(msg) { edSetState('img', '🧩 描述同步 · ' + msg, 'busy'); }
    setp('启动');
    var ok = true;
    try {
      ok = ok && await dStep('打开编辑描述', /^编辑描述$/, 2500);
      ok = ok && await dStep('点批量操作', /^批量操作$/, 1200);
      ok = ok && await dStep('点批量图片处理', /^批量图片处理$/, 1500);
      ok = ok && await dStep('点批量删除', /^批量删除$/, 1200);
      ok = ok && await dStep('确认删除', /^确定$/, 1500, 8);
      ok = ok && await dStep('点上传图片', /^上传图片$/, 1800);
      ok = ok && await dStep('选使用产品图片', /使用产品图片/, 2000);
      if (ok) {
        // 只勾「产品图」分区的复选框（全部选中会把 SKU 图/详情图也带进来）
        var secOk = false;
        var lbl = findBtn(/^产品图$/);
        if (lbl) {
          var box = lbl;
          for (var d = 0; d < 4 && box && !secOk; d++) {
            box = box.parentElement;
            if (!box) break;
            var ck = box.querySelector('label[class*="checkbox"], .jx-checkbox, [class*="checkbox"], input[type="checkbox"]');
            if (ck) { await clickBtn(ck); secOk = true; elog('🧩 已勾选产品图分区 ✓'); }
          }
        }
        if (!secOk) {
          var allCk = findBtn(/全部选中/);
          if (allCk) { await clickBtn(allCk); elog('🧩 兜底：已全部选中 ✓'); secOk = true; }
        }
        if (!secOk) { ok = false; elog('❌ 找不到产品图选择器'); }
        await dSleep(1000);
      }
      ok = ok && await dStep('点确定插入', /^确定$/, 2500);
      if (ok) {
        // 回到批量弹窗：全选新插入的图，再保存
        var bAll = findBtn(/^全选$/);
        if (bAll) { clickBtn(bAll); elog('🧩 已全选新图 ✓'); await dSleep(800); }
        ok = await dStep('保存批量弹窗', /^保存$/, 2000, 8);
      }
      if (ok) {
        // 编辑产品描述弹窗自己的保存
        ok = await dStep('保存描述编辑', /^保存$/, 2000, 8);
      }
      if (ok) {
        edSetState('img', '✅ 描述图同步完成：描述旧图已删、轮播图已写入，请人工核对', 'ok');
        elog('✅ 描述图同步流程执行完毕，请在页面上核对描述内容');
      } else {
        elog('🔎 当前页面可点元素快照（把这段发我即可校准）：' + snapButtons());
        edSetState('img', '❌ 描述同步中断（详情看日志）', 'err');
      }
    } catch (e) {
      elog('❌ 描述同步失败：' + e.message);
      elog('🔎 页面可点元素快照：' + snapButtons());
      edSetState('img', '❌ 描述同步失败：' + e.message + '（详情看日志）', 'err');
    } finally {
      E.descBusy = false;
      renderEdit();
    }
  }

  function renderEditLog() {
    var box = $('#ms-ed-log');
    if (!box) return;
    box.innerHTML = '';
    E.log.slice(0, 12).forEach(function (l) {
      box.appendChild(el('div', 'ms-log-line', l));
    });
  }

  function renderEditStatus() {
    var box = $('#ms-ed-status');
    if (!box) return;
    box.innerHTML = '';
    function row(label, state, cls) {
      var r = el('div', 'ms-ed-st-row');
      r.appendChild(el('span', 'ms-ed-st-label', label));
      var v = el('span', 'ms-ed-st-val ' + (cls || ''), state);
      r.appendChild(v);
      box.appendChild(r);
    }
    row('标题', E.titleState, E.titleCls);
    row('图片', E.imgState, E.imgCls);
  }

  // 悬浮显示某张图的完整生图提示词
  var shotTipEl = null;
  function showShotTip(anchor, text) {
    try {
      if (!shotTipEl) {
        shotTipEl = document.createElement('div');
        shotTipEl.className = 'ms-shot-pop';
        document.body.appendChild(shotTipEl);
      }
      shotTipEl.textContent = text || '（这张图还没有提示词）';
      shotTipEl.style.display = 'block';
      shotTipEl.style.visibility = 'hidden';
      var pr = shotTipEl.getBoundingClientRect();
      var r = anchor.getBoundingClientRect();
      var left = Math.max(10, Math.min(r.right - pr.width, window.innerWidth - pr.width - 10));
      var top = r.top - pr.height - 8;
      if (top < 10) top = r.bottom + 8;
      shotTipEl.style.left = Math.round(left) + 'px';
      shotTipEl.style.top = Math.round(top) + 'px';
      shotTipEl.style.visibility = 'visible';
    } catch (e) {}
  }
  function hideShotTip() {
    if (shotTipEl) shotTipEl.style.display = 'none';
  }

  function copyText(t) {
    try {
      var ta = document.createElement('textarea');
      ta.value = t;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    } catch (e) {}
  }

  function renderEdit() {
    if (!editBuilt) return;
    var orig = $('#ms-ed-orig');
    if (orig) {
      var t = E.info && E.info.title ? E.info.title : (findEditorOverlay() && getEditorContext(findEditorOverlay()).zh ? getEditorContext(findEditorOverlay()).zh.value : '');
      orig.textContent = '原标题：' + (t || '（未识别，打开编辑页后自动识别）');
    }
    var runBtn = $('#ms-ed-run-all');
    if (runBtn) {
      runBtn.disabled = E.running;
      runBtn.textContent = E.running
        ? (E.mode === 'title' ? '⏳ 改标题中…（看图分析，约 20-40 秒）'
          : (E.mode === 'img' ? '⏳ 洗图中…（按张数，约 2-6 分钟）'
            : '⏳ 处理中…（分析 + 并发生图）'))
        : '⚡ 一键洗图 + 改标题';
    }
    var runT = $('#ms-ed-run-title'), runI = $('#ms-ed-run-img'), runD = $('#ms-ed-run-desc');
    if (runT) runT.disabled = E.running;
    if (runI) runI.disabled = E.running;
    if (runD) runD.disabled = E.running || E.descBusy;
    renderEditStatus();

    var res = $('#ms-ed-result');
    if (res) {
      res.innerHTML = '';
      if (E.newZh || E.newEn) {
        res.appendChild(el('div', 'ms-ed-sec', '生成结果'));
        function line(label, text) {
          var r = el('div', 'ms-ed-line');
          r.appendChild(el('span', 'ms-ed-line-label', label));
          r.appendChild(el('span', 'ms-ed-line-text', text));
          var cp = el('button', 'ms-mini', '复制');
          cp.onclick = function () { copyText(text); cp.textContent = '已复制'; setTimeout(function () { cp.textContent = '复制'; }, 1200); };
          r.appendChild(cp);
          res.appendChild(r);
        }
        if (E.newZh) line('中文', E.newZh);
        if (E.newEn) line('英文', E.newEn);
      }

      if (E.planBrief) {
        res.appendChild(el('div', 'ms-ed-brief', '🧠 ' + E.planBrief.slice(0, 90)));
      }

      if (E.shots && E.shots.length) {
        var keepCnt2 = E.shots.filter(function (x) { return x.slot === 'keep'; }).length;
        var washCnt = E.shots.filter(function (x) { return x.slot === 'replace'; }).length;
        var appCnt = E.shots.length - washCnt - keepCnt2;
        res.appendChild(el('div', 'ms-ed-sec', '生成方案（' +
          (keepCnt2 ? '保留 ' + keepCnt2 : '') + (keepCnt2 && (washCnt || appCnt) ? ' · ' : '') +
          (washCnt ? '洗图 ' + washCnt : '') + (washCnt && appCnt ? ' + ' : '') + (appCnt ? '补图 ' + appCnt : '') + '）'));
        var grid = el('div', 'ms-shot-grid');
        E.shots.forEach(function (s, i) {
          var card = el('div', 'ms-shot-card' + (s.slot === 'keep' ? ' keep' : ''));
          var ph = el('div', 'ms-shot-ph', (s.dataUrl || s.keepUrl) ? '' : String(i + 1));
          if (s.dataUrl || s.keepUrl) {
            var im2 = document.createElement('img');
            im2.src = s.dataUrl || s.keepUrl;
            ph.appendChild(im2);
            ph.title = '点击放大查看';
            ph.onclick = function () { showZoom(s.dataUrl || s.keepUrl); };
          }
          card.appendChild(ph);
          card.appendChild(el('div', 'ms-shot-type',
            (s.slot === 'keep' ? '保留' + (s.tileIndex + 1) + ' · ' : (s.slot === 'replace' ? '洗图' + (s.tileIndex + 1) + ' · ' : '补图 · ')) + s.type));
          card.appendChild(el('div', 'ms-shot-status ' + (s.status === '已生成' || s.status === '保留' ? 'ok' : (s.status === '失败' ? 'err' : '')), s.status));
          // 悬停查看这张图实际下发的完整生图提示词
          var tipBtn = el('div', 'ms-shot-tipbtn', '📝');
          tipBtn.title = '悬停查看这张图的生图提示词';
          tipBtn.onmouseenter = function () { showShotTip(tipBtn, shotPromptFor(s)); };
          tipBtn.onmouseleave = hideShotTip;
          card.appendChild(tipBtn);
          grid.appendChild(card);
        });
        res.appendChild(grid);
      } else if (E.newImgDataUrl) {
        var ir = el('div', 'ms-ed-imgrow');
        ir.appendChild(el('span', 'ms-ed-line-label', '新图'));
        var im = document.createElement('img');
        im.src = E.newImgDataUrl;
        im.className = 'ms-ed-thumb';
        ir.appendChild(im);
        ir.appendChild(el('span', 'ms-ed-imgtip', '已注入编辑页轮播图'));
        res.appendChild(ir);
      }
    }

    var adv = $('#ms-ed-advice');
    if (adv) {
      adv.innerHTML = '';
      if (E.advices.length) {
        adv.appendChild(el('div', 'ms-ed-sec', '💡 建议'));
        E.advices.forEach(function (a) { adv.appendChild(el('div', 'ms-ed-advice-item', '· ' + a)); });
      }
    }
    renderEditLog();
    renderPrompts();
  }

  function openEditPanel() {
    if (!editBuilt) buildEditPanel(root);
    editPanel.classList.add('open');
    renderEdit();
  }

  /* ================= 妙手接口（编辑页刷新校准用） ================= */
  function apiPost(path, obj) {
    var body = new URLSearchParams();
    Object.keys(obj).forEach(function (k) { if (obj[k] != null) body.append(k, obj[k]); });
    return fetch(CB + path, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString()
    }).then(function (r) { return r.text(); }).then(function (t) {
      try { return JSON.parse(t); } catch (e) { throw new Error('返回非JSON: ' + t.slice(0, 160)); }
    });
  }
  function getDetail(id, force) {
    if (!force && S.detailCache[id]) return Promise.resolve(S.detailCache[id]);
    return apiPost('getCollectItemInfo', { detailId: id }).then(function (j) {
      var info = j.shopCollectItemInfo;
      if (!info) throw new Error('详情为空');
      S.detailCache[id] = info;
      return info;
    });
  }

  /* ================= 设置面板（两个模式共用） ================= */
  var modelSelects = [];
  var modelFetch = {
    text: { at: 0, loading: false, ids: [] },
    img: { at: 0, loading: false, ids: [] }
  };

  // 两个面板各有一份设置区，必须按「自己所在的面板」去找，不能用全局 #id（会命中另一个隐藏面板）
  function toggleSettings(panel) {
    if (!panel) return;
    var s = panel.querySelector('.ms-settings');
    if (!s) return;
    var open = s.classList.toggle('open');
    if (open) {
      s.scrollIntoView({ block: 'nearest' });
      if (!modelFetch.text.at && S.settings.textApiKey) refreshModels('text', true);
      if (!modelFetch.img.at && S.settings.imgApiKey) refreshModels('img', true);
    }
  }

  function fillModelSelect(sel, cur, kind) {
    var st = modelFetch[kind] || modelFetch.img;
    var base = (kind === 'text' ? TEXT_MODEL_OPTIONS : MODEL_OPTIONS).slice();
    st.ids.forEach(function (id) { if (base.indexOf(id) < 0) base.push(id); });
    if (cur && base.indexOf(cur) < 0) base.unshift(cur);
    sel.innerHTML = '';
    base.forEach(function (id) {
      var o = document.createElement('option');
      o.value = id; o.textContent = id;
      sel.appendChild(o);
    });
    if (cur) sel.value = cur;
  }

  function refreshModels(kind, silent) {
    var st = modelFetch[kind];
    if (!st || st.loading) return;
    st.loading = true;
    var baseUrl = kind === 'text' ? S.settings.textBaseUrl : S.settings.imgBaseUrl;
    var apiKey = kind === 'text' ? S.settings.textApiKey : S.settings.imgApiKey;
    chrome.runtime.sendMessage({ cmd: 'models', baseUrl: baseUrl, apiKey: apiKey }, function (resp) {
      st.loading = false;
      if (!resp || !resp.ok) {
        if (!silent) elog('❌ 拉取' + (kind === 'text' ? '文本' : '生图') + '模型失败：' + (resp && resp.error || '无响应'));
        return;
      }
      var ids = (resp.data || []).map(function (m) { return m.id || m.name; }).filter(Boolean);
      st.ids = ids;
      st.at = Date.now();
      modelSelects.forEach(function (m) {
        if (m.kind === kind) fillModelSelect(m.sel, S.settings[m.key], kind);
      });
      if (!silent) elog('✅ 拉到 ' + ids.length + ' 个模型：' + ids.join(' / '));
    });
  }

  function buildSettings() {
    var wrap = el('div', 'ms-settings');

    function group(title) {
      wrap.appendChild(el('div', 'ms-group-title', title));
    }

    function field(label, key, type, placeholder) {
      var row = el('div', 'ms-field');
      row.appendChild(el('label', null, label));
      var inp = document.createElement(type === 'textarea' ? 'textarea' : 'input');
      if (type !== 'textarea') inp.type = /key/i.test(key) ? 'password' : 'text';
      inp.value = S.settings[key] == null ? '' : S.settings[key];
      inp.placeholder = placeholder || '';
      inp.oninput = function () { S.settings[key] = inp.value; persist(); };
      row.appendChild(inp);
      wrap.appendChild(row);
      return inp;
    }

    function modelField(label, key, kind) {
      var row = el('div', 'ms-field');
      row.appendChild(el('label', null, label));
      var sel = document.createElement('select');
      sel.className = 'ms-model-select';
      fillModelSelect(sel, S.settings[key], kind);
      sel.onchange = function () {
        S.settings[key] = sel.value;
        S.settings.cfgVer = SETTINGS_VER;
        persist();
      };
      row.appendChild(sel);
      wrap.appendChild(row);
      modelSelects.push({ sel: sel, key: key, kind: kind });
      return sel;
    }

    function pullBtn(kind, baseKey, keyKey, label) {
      var row = el('div', 'ms-field');
      var pull = el('button', 'ms-mini wide', '🔄 ' + label);
      pull.onclick = function () {
        pull.disabled = true; pull.textContent = '拉取中…';
        refreshModels(kind, false);
        setTimeout(function () { pull.disabled = false; pull.textContent = '🔄 ' + label; }, 1600);
      };
      row.appendChild(pull);
      wrap.appendChild(row);
    }

    // 验证 API 接通：拉模型列表校验网络+Key，并检查当前配置的模型是否可用
    function testBtn(kind, label) {
      var row = el('div', 'ms-field');
      var btn = el('button', 'ms-mini wide', '🔌 验证' + label + '接通');
      var st = el('span', 'ms-hint', '');
      st.style.marginLeft = '8px';
      btn.onclick = function () {
        btn.disabled = true; btn.textContent = '验证中…'; st.textContent = '';
        var baseUrl = kind === 'text' ? S.settings.textBaseUrl : S.settings.imgBaseUrl;
        var apiKey = kind === 'text' ? S.settings.textApiKey : S.settings.imgApiKey;
        var curModel = kind === 'text' ? S.settings.textModel : S.settings.imgModel;
        if (!apiKey) {
          btn.disabled = false; btn.textContent = '🔌 验证' + label + '接通';
          st.textContent = '❌ 还没填 API Key';
          elog('❌ ' + label + ' API 验证失败：还没填 API Key（⚙ 设置里先填）');
          return;
        }
        chrome.runtime.sendMessage({ cmd: 'models', baseUrl: baseUrl, apiKey: apiKey }, function (resp) {
          btn.disabled = false; btn.textContent = '🔌 验证' + label + '接通';
          if (!resp || !resp.ok) {
            var err = (resp && resp.error) || '无响应（扩展刚重载过？刷新页面再试）';
            st.textContent = '❌ 接通失败';
            elog('❌ ' + label + ' API 接通失败：' + err + ' ← 检查接口地址和 Key');
            return;
          }
          var ids = (resp.data || []).map(function (m) { return m.id || m.name; }).filter(Boolean);
          if (curModel && ids.length && ids.indexOf(curModel) >= 0) {
            st.textContent = '✅ 接通成功 · ' + curModel + ' 可用';
            elog('✅ ' + label + ' API 接通成功：' + baseUrl + '，模型 ' + curModel + ' 可用（列表共 ' + ids.length + ' 个）');
          } else if (curModel && ids.length) {
            st.textContent = '⚠️ 网络通，但 ' + curModel + ' 不在列表';
            elog('⚠️ ' + label + ' API 网络可达，但配置的模型 ' + curModel + ' 不在模型列表：' + ids.slice(0, 10).join(' / ') + '（点「刷新模型列表」重新选）');
          } else {
            st.textContent = '✅ 网络接通（' + ids.length + ' 个模型）';
            elog('✅ ' + label + ' API 接通成功：' + baseUrl + '（' + ids.length + ' 个模型），请选择模型');
          }
        });
      };
      row.appendChild(btn);
      row.appendChild(st);
      wrap.appendChild(row);
    }

    var apiBtn = el('button', 'ms-mini wide', '🔑 连接 New API');
    apiBtn.type = 'button';
    apiBtn.onclick = function () { chrome.runtime.sendMessage({cmd:'xtNewApiOpen'}).catch(function () {}); };
    wrap.appendChild(apiBtn);

    // —— 行为参数 ——
    group('其他');
    var rowT = el('div', 'ms-field ms-inline');
    rowT.appendChild(el('label', null, '目标图片总数'));
    var inpT = document.createElement('input');
    inpT.type = 'number'; inpT.min = '5'; inpT.max = '10'; inpT.value = S.settings.targetCount;
    inpT.oninput = function () { S.settings.targetCount = Math.min(10, Math.max(5, parseInt(inpT.value, 10) || 10)); persist(); };
    rowT.appendChild(inpT);
    rowT.appendChild(el('span', 'ms-hint', '妙手上限 10 张'));
    wrap.appendChild(rowT);

    var row3 = el('div', 'ms-field ms-inline');
    row3.appendChild(el('label', null, '每分钟生图数'));
    var inpC = document.createElement('input');
    inpC.type = 'number'; inpC.min = '2'; inpC.max = '20'; inpC.value = S.settings.imgPerMin;
    inpC.oninput = function () { S.settings.imgPerMin = Math.min(20, Math.max(2, parseInt(inpC.value, 10) || 10)); persist(); };
    row3.appendChild(inpC);
    row3.appendChild(el('span', 'ms-hint', '按 New API 的账号与模型限额调节'));
    wrap.appendChild(row3);
    wrap.appendChild(el('div', 'ms-hint', '提示：每张图是独立提示词独立生成，10 张 10 并发约 1 分钟出齐；想更快就调小目标张数'));


    var rowE = el('div', 'ms-field ms-inline');
    rowE.appendChild(el('label', null, '思考强度'));
    var selE = document.createElement('select');
    selE.className = 'ms-model-select';
    ['low', 'high', 'max'].forEach(function (v) {
      var o = document.createElement('option');
      o.value = v;
      o.textContent = v + (v === 'low' ? '（最快）' : (v === 'max' ? '（最慢最细）' : ''));
      selE.appendChild(o);
    });
    selE.value = S.settings.reasoningEffort || 'low';
    selE.onchange = function () { S.settings.reasoningEffort = selE.value; persist(); };
    rowE.appendChild(selE);
    wrap.appendChild(rowE);

    field('标题提示词', 'titlePrompt', 'textarea');
    field('补图规划提示词', 'planPrompt', 'textarea');
    field('每张图通用约束（会拼到每张图提示词后面）', 'imagePrompt', 'textarea');

    // 首次打开自动拉一次（静默，失败不打扰）
    setTimeout(function () {
      if (S.settings.textApiKey) refreshModels('text', true);
      if (S.settings.imgApiKey) setTimeout(function () { refreshModels('img', true); }, 400);
    }, 600);

    return wrap;
  }

  /* ================= 装配 ================= */
  var root;

  function isEditorOpen() {
    if (findEditorOverlay()) return true;
    // 兜底：抽屉/弹层类名变化时，只要有可见的商品标题输入框就算编辑页
    var zh = document.querySelector('input[placeholder="请输入产品标题"]');
    if (zh) {
      var r = zh.getBoundingClientRect();
      if (r.width > 80 && r.height > 10) return true;
    }
    var pl = document.querySelector('.product-picture-list');
    if (pl && pl.getBoundingClientRect().width > 300) return true;
    return false;
  }

  function buildUI() {
    root = el('div', 'ms-ai-root');
    // v3.2.1 删除旧版紫色"AI"浮球：用户只认右下角的小猫咪球（collectbox.js 注入），
    // 编辑页单商品面板改为从洗图猫面板的"单商品编辑"入口唤起，避免两个球混淆。
    document.body.appendChild(root);
    buildEditPanel(root);

    // v3.2.1 编辑页面板改由洗图猫面板的「📝 编辑页」按钮唤起（旧紫球已删）
    window.addEventListener('ms-open-edit-panel', function () {
      if (!isEditorOpen()) {
        toast('先在采集箱里点「编辑」打开一个商品，再用 AI');
        return;
      }
      openEditPanel();
    });

    // 编辑页打开时给浮球加个角标提示；顺便自动识别商品切换（切换 SKU 时标题会变）
    setInterval(function () {
      var open = isEditorOpen();

      // 编辑页关掉了，面板自动收起，避免残留上一个商品的数据
      if (!open && !E.running && editPanel && editPanel.classList.contains('open')) {
        editPanel.classList.remove('open');
      }

      if (!open || E.running) return;
      if (E.newZh || E.newEn) return; // 已生成过结果，别自动清掉
      var ov = findEditorOverlay();
      if (!ov) return;
      var t = getEditorContext(ov).zh;
      t = t ? String(t.value || '').trim() : '';
      if (!t) return;
      if (!E.info) { E.info = { title: t, enTitle: '', imgUrls: [] }; renderEdit(); return; }
      if (E.info.title && t !== E.info.title) {
        refreshEditor();
        elog('👀 检测到商品已切换，自动刷新了');
      }
    }, 1500);
  }

  window.addEventListener('message', function (ev) {
    if (ev.source !== window) return;
    var d = ev.data;
    if (d && d.source === 'ms-ai-hook' && d.info) {
      E.detailId = d.detailId || '';
      E.info = d.info;
      if (isEditorOpen()) {
        renderEdit();
        elog('已识别到编辑页商品：' + (d.info.title || '').slice(0, 24));
      }
    }
  });

  // v2.3.0：把本文件已经过实测的 UI 自动化原语暴露给同页 collectbox.js。
  // 两个 content script 同处扩展 isolated world，共享 window；红色一键自动化按钮直接复用，不重写一套。
  window.__msRpaApi = {
    waitFor: waitFor,
    visTextEls: visTextEls,
    findBtn: findBtn,
    findBtnAll: findBtnAll,
    clickBtn: clickBtn,
    hoverBtn: hoverBtn,   // v3.2.6 悬停（导入菜单这类 hover 才弹出的按钮）
    realClickEl: realClickEl,
    realClickState: function () { return realClickState; },   // v3.5.6 通道状态（down=真实点击已失效）
    injectFile: injectFile,
    allRoots: allRoots,
    sleep: function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); },
    // v2.4.0：单品精修（最早那套编辑页 RPA）暴露给采集箱第三个圆圈调用
    edRun: function (mode) { return edRun(mode || 'all'); },
    isEditorOpen: function () { return isEditorOpen(); },
    openEditorPanel: function () { openEditPanel(); }
  };

  function boot() {
    if (!/91miaoshou\.com/.test(location.hostname)) return;
    buildUI();
    loadSettings(function () {
      // 设置面板重建（载入用户配置后）
      try {
        document.querySelectorAll('.ms-settings').forEach(function (s) { s.remove(); });
        modelSelects = [];
        if (editPanel) editPanel.appendChild(buildSettings());
      } catch (e) {}
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
