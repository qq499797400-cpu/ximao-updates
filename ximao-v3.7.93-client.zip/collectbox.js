// collectbox.js — 采集箱列表页一键洗图入口
// 作用：不用导出表格，直接在妙手采集箱页面抓当前列表 → 直接建成洗图台任务
(function () {
  if (!/91miaoshou\.com$/.test(location.hostname)) return;
  if (window.__mscbReady) return;
  window.__mscbReady = true;

  var CB = '/api/platform/pddkj/move/collect_box/';
  var items = new Map();                 // id -> { id, title, imgs: [] }
  var lastListUrl = '';                  // 页面自己发的列表接口，用于排查字段不匹配
  var lastGrabSig = '';                  // v3.7.26 最近一次主动抓取时看到的列表请求（用于翻页自动重采）
  var autoGrabbing = false;              // v3.7.26 自动重采进行中
  var passiveFillTimer = null;           // v3.7.26 被动新商品 → 去抖补详情
  // 底座地址/口令全部内置隐藏：客户界面不再出现任何服务器、域名、口令字样（防止暴露底座）
  // v3.7.4 洗图台整体搬上阿里云服务器（systemd 守护）：Mac 关机不影响跑单，同事共用一台
  var STUDIO_DEFAULT = '';
  var STUDIO_CODE_DEFAULT = '';
  var SHARE_DEFAULT = '';
  // 图床默认走自有分发节点（阿里云 200Mbps，成品图出图即推送上去）：妙手是云端服务，
  // 拉不到 127.0.0.1 —— 表格图链必须给公网节点域名（2026-11-17 客户拍板）
  // v3.5.6 图床默认切 https（sslip.io 真证书）：页面 <img> 可直接挂 https 图，
  // 不再依赖后台 fetchImg 代理 —— 代理在某些浏览器（ego 等）里会静默失败 → 缩略图白块
  var IMG_BASE_DEFAULT = '';
  function imgBaseNorm(b) {
    b = String(b || '').trim().replace(/\/+$/, '');
      return b;
  }
  var STUDIO_DEAD_RE = /^https?:\/\/wash\.geb\.de5\.net/i;

  /* ---------------- 模板设置：客户选改什么，固定值会被记住 ---------------- */
  // tpl 会随建单一并发给洗图台（服务端按模板决定改哪些字段）；固定值长期记忆在 chrome.storage
  var TPL_FIELDS = [
    { k: 'material', label: '材质', ph: '如：塑料 / 木质 / 毛绒' },
    { k: 'style',    label: '风格/工艺', ph: '如：圣诞风 / 3D 立体' },
    { k: 'size',     label: '尺寸', ph: '如：15cm / 一件装' },
    { k: 'scene',    label: '适用场景', ph: '如：家庭装饰 / 节日礼品' }
  ];
  // 内置大类目预设，可改可删。
  // 类目匹配由 catalog-draft.js 统一处理。
  var BUILTIN_PRESETS = [
    { name: '圣诞节日装饰', builtin: true, cats: ['圣诞', 'christmas', 'xmas'],
      tpl: { img: true, zh: true, en: true, attrs: true, fixed: { style: '圣诞节日风' },
        prompt: '商品确实是圣诞主题时才用节日氛围；保持原材质、原图文字与数量，不能默认变成木质' } },
    { name: '3C数码电子', builtin: true, cats: ['3c', '手机', '充电', '蓝牙', '耳机', '数据线', '电子', '数码', '智能', '电脑', '键盘', '鼠标', '摄像头', '音箱', '无线'],
      tpl: { img: true, zh: true, en: true, attrs: true, fixed: { style: '科技简约风' },
        prompt: '科技感、突出产品细节（接口/按键/材质）、冷色调点缀、白底简洁背景、构图干净' } },
    { name: '家居家具', builtin: true, cats: ['家具', '家居', '收纳', '置物', '椅子', '桌子', '灯具', '照明', '床品', '厨房', '浴室', '花瓶', '窗帘', '地毯'],
      tpl: { img: true, zh: true, en: true, attrs: true, fixed: { style: '温馨家居风' },
        prompt: '真实家居用途、柔和自然光、白底商品图；无原始尺寸不标尺寸' } },
    { name: '母婴玩具', builtin: true, cats: ['母婴', '婴儿', '儿童', '宝宝', '玩具', '奶瓶', '童', '积木', '玩偶', '益智'],
      tpl: { img: true, zh: true, en: true, attrs: true, fixed: { style: '明亮可爱风' },
        prompt: '明亮柔和色彩、安全温馨氛围、可爱风格、白底商品图、适合母婴人群审美' } },
    { name: '服装配饰', builtin: true, cats: ['服装', '衣服', '女装', '男装', '童装', '外套', '连衣裙', '帽', '围巾', '袜子', '鞋', '包', '饰品', '首饰', '腰带', '眼镜'],
      tpl: { img: true, zh: true, en: true, attrs: true, fixed: { style: '时尚简洁风' },
        prompt: '突出面料质感与版型、时尚简洁、白底商品图、细节清晰' } },
    { name: '户外运动', builtin: true, cats: ['户外', '运动', '健身', '露营', '骑行', '渔', '打猎', '瑜伽', '球', '水上'],
      tpl: { img: true, zh: true, en: true, attrs: true, fixed: { style: '活力动感风' },
        prompt: '真实户外使用场景、清晰细节和白底图；不编造性能、规格或耐用性' } }
  ];

  var cfg = {
    studio: STUDIO_DEFAULT,
    share: SHARE_DEFAULT,
    imgBase: '',
    code: STUDIO_CODE_DEFAULT,
    mode: 'auto',        // 全自动 auto / 半自动 semi（记住上次用的）
    copies: 1,
    imgN: 10,            // v3.7.23 本地直连每品出图数：1=仅主图，10=原版全套（主图+9分镜）
    fiss: 1,             // v3.7.24 单品裂变份数：1=不裂变，N=每品 AI 规划 N 个变体各出一条新链接
    limit: 100,
    exportN: 20,
    autoDetail: true,
    apiFirst: true,      // v3.5.8 导入默认走直连接口（秒级），RPA 只做兜底；面板可切
    imgDirect: true,     // v3.7.28 外链直写默认开：上游返回本站图链时直接入导入表，跳过图片空间（省配额省上传）；base64 回传自动回退上传
    imgSrc: 'auto',      // v3.7.75 图源模式：auto=外链优先 / url=要图链 / space=要图片（一律上传妙手空间）
    imgSize: 'auto',     // v3.7.75 体积档位：original/auto/small/tiny（tiny 同时缩边 1200px）
    tts: true,           // v3.6.0 TTS 语音提示默认开（开始采集/采集完成/开始洗图/洗图完成/开始上传/上传完成），面板可关
    onboarded: false,    // v3.7.74 新手引导：第一次安装后自动弹引导框，走完/跳过后不再弹
    tpl: { img: true, zh: true, en: true, attrs: true, fixed: {} }
  };

  /* ---------------- 解析：与 hook_main 同一套挖法 ---------------- */
  var ID_KEYS = ['commonCollectBoxDetailId', 'collectBoxDetailId', 'detailId', 'itemId', 'id'];   // v3.7.42 公用采集箱
  var STRONG_ID_KEYS = ['commonCollectBoxDetailId', 'collectBoxDetailId', 'detailId'];   // 列表行必有；字典/选项只有笼统的 id
  var TITLE_KEYS = ['title', 'itemTitle', 'productTitle', 'goodsTitle', 'name'];
  var IMG_KEYS = ['imgUrls', 'images', 'imageUrls', 'carouselImageUrls', 'carouselImgUrls',
    'mainImageUrls', 'mainImageList', 'picUrls', 'imgs', 'pictures', 'mainImg', 'picUrl', 'thumbnail', 'thumbnailUrl', 'coverImgUrl'];
  var LIST_OK_RE = /(search|list|page|query|items)/i;
  var LIST_BAD_RE = /(opt|option|attr|category|cate|dict|enum|tag|group|label|stat|count|template|remark)/i;
  function isListUrl(u) {
    u = String(u || '');
    if (!/collect_box/i.test(u)) return false;
    if (/getCollectItemInfo/i.test(u)) return false;
    if (LIST_BAD_RE.test(u)) return false;
    return LIST_OK_RE.test(u);
  }

  function pickFirst(o, keys) {
    for (var i = 0; i < keys.length; i++) {
      var v = o[keys[i]];
      if (v != null && v !== '' && !(Array.isArray(v) && !v.length)) return v;
    }
    return '';
  }
  function asUrlList(v) {
    var out = [];
    (function take(x, d) {
      if (!x || d > 3) return;
      if (typeof x === 'string') { if (/^https?:\/\//.test(x)) out.push(x); return; }
      if (Array.isArray(x)) { for (var i = 0; i < x.length; i++) take(x[i], d + 1); return; }
      if (typeof x === 'object') {
        ['url', 'imgUrl', 'imageUrl', 'src', 'picUrl', 'path'].forEach(function (k) { if (x[k]) take(x[k], d + 1); });
      }
    })(v, 0);
    return out;
  }
  function digItems(root) {
    var best = null;
    (function walk(v, d) {
      if (!v || d > 7) return;
      if (Array.isArray(v)) {
        if (v.length && v[0] && typeof v[0] === 'object') {
          var hasId = ID_KEYS.some(function (k) { return v[0][k] != null && v[0][k] !== ''; });
          if (hasId && (!best || v.length > best.length)) best = v;
        }
        for (var i = 0; i < Math.min(v.length, 3); i++) walk(v[i], d + 1);
        return;
      }
      if (typeof v === 'object') {
        for (var k in v) { if (Object.prototype.hasOwnProperty.call(v, k)) walk(v[k], d + 1); }
      }
    })(root, 0);
    return best || [];
  }
  function normalizeList(arr) {
    var out = [];
    for (var i = 0; i < arr.length; i++) {
      var o = arr[i];
      if (!o || typeof o !== 'object') continue;
      // 强 ID（collectBoxDetailId/detailId）= 真实列表行；只有笼统 id 时必须带图，否则当成字典/选项丢弃
      var id = String(pickFirst(o, STRONG_ID_KEYS) || '');
      var imgs = asUrlList(pickFirst(o, IMG_KEYS));
      if (!id) {
        id = String(pickFirst(o, ['itemId', 'id']) || '');
        if (!id || !imgs.length) continue;
      }
      var title = String(pickFirst(o, TITLE_KEYS) || '');
      if (!title && !imgs.length) continue;
      out.push({ id: id, title: title, imgs: imgs, row: o });   // v3.7.42 row=原始列表行（价格/来源/货号等全字段）
    }
    return out;
  }

  function ingest(arr) {
    var add = 0;
    (arr || []).forEach(function (it) {
      if (!it || !it.id) return;
      var id = String(it.id);
      var cur = items.get(id);
      if (cur) {
        var changed = false;
        if (!cur.title && it.title) { cur.title = it.title; changed = true; }
        if ((!cur.imgs || !cur.imgs.length) && it.imgs && it.imgs.length) { cur.imgs = it.imgs.slice(); changed = true; }
        if (!cur.raw && it && typeof it === 'object') { cur.raw = it.row || it; changed = true; }   // v3.7.42 补存列表整行
        if (changed) add++;
        return;
      }
      items.set(id, { id: id, title: it.title || '', imgs: (it.imgs || []).slice(), sel: true, raw: it.row || it });
      add++;
    });
    if (add) render();
    return add;
  }
  // v3.7.63 采集顺序修正：主动抓取时按接口返回顺序重排（之前 hook 早期捕获的旧行会插在前面，
  // 导致面板顺序和页面列表不一致，客户看到的第 1 个不是页面第 1 个）
  function ingestOrdered(arr) {
    var added = ingest(arr);
    (arr || []).forEach(function (it) {
      var id = it && it.id ? String(it.id) : '';
      if (id && items.has(id)) { var v = items.get(id); items.delete(id); items.set(id, v); }
    });
    return added;
  }

  /* ---------------- 妙手接口 ---------------- */
  function apiPost(path, obj) {
    var body = new URLSearchParams();
    Object.keys(obj || {}).forEach(function (k) { if (obj[k] != null) body.append(k, obj[k]); });
    // v3.7.42 支持 /api/ 开头全路径（公用采集箱接口不在 CB 前缀下）
    var full = (path.charAt(0) === '/' && path.indexOf('/api/') === 0) ? path : CB + path;
    return fetch(full, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString()
    }).then(function (r) { return r.text(); }).then(function (t) {
      try { return JSON.parse(t); } catch (e) { return null; }
    }).catch(function () { return null; });
  }

  // v3.7.45 数据源优先级修正：普通采集箱优先（有详情接口，导入不会全拒）；公用采集箱垫底（无详情数据源，2026-11-22 实测 40/40、10/10 导入全拒）
  var LIST_APIS = ['searchCollectBoxDetail', 'searchCollectItem', 'searchCollectItemList', 'getCollectItemList', 'getCollectItemPage', 'getCollectItemListV2', 'getList', '/api/move/common_collect_box/searchDetailList'];
  var PARAM_SETS = [
    { page: 1, pageSize: 100 },
    { pageNo: 1, pageSize: 100 },
    { current: 1, size: 100 },
    { page: 1, limit: 100 },
    { pageNum: 1, pageSize: 100 }
  ];
  /* 采集数量：v3.4.1 默认 500、上限 1000——页面每页显示多少就抓多少，不再被旧的 100 上限卡住。
     每页大小优先读页面自己最后一次列表请求的真实参数（页面显示 500/页 就按 500/页 发）。 */
  var LIMIT_MAX = 1000;
  // 从页面真实列表请求 URL 里解析 pageSize/size/limit（页面自己发过的请求最准）
  function pagePer() {
    try {
      var m = String(lastListUrl || '').match(/[?&](pageSize|size|limit|perPage)=([0-9]+)/i);
      if (m) return Math.max(1, Math.min(500, Number(m[2])));
    } catch (e) {}
    return 0;
  }
  function limitN() {
    var n = Number(cfg.limit) || 500;
    return Math.max(1, Math.min(LIMIT_MAX, Math.round(n)));
  }
  function perPage() { return pagePer() || Math.min(100, limitN()); }
  function paramSets() {
    var per = perPage();
    return PARAM_SETS.map(function (p) {
      var q = {};
      Object.keys(p).forEach(function (k) { q[k] = p[k]; });
      if (q.pageSize != null) q.pageSize = per;
      if (q.size != null) q.size = per;
      if (q.limit != null) q.limit = per;
      return q;
    });
  }
  // 超量的直接丢掉（保留先入库的），避免白抓详情、白占面板
  function trimToLimit(n) {
    if (items.size <= n) return 0;
    var keys = [];
    items.forEach(function (v, k) { keys.push(k); });
    keys.slice(n).forEach(function (k) { items.delete(k); });
    return keys.length - n;
  }

  // 客户面板日志：只显示在客户浏览器本地，绝不回传服务器/中转站（不 fetch、不 sendMessage）
  // v3.2.4 每行日志统一带 [HH:MM:SS] 时间戳（精确到秒）
  function tsNow() {
    var d = new Date(), pad = function (x) { return (x < 10 ? '0' : '') + x; };
    return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }
  // v3.7.63 运行日志环形缓冲：面板 DOM 只留 200 行，导出用缓冲保留最近 1200 行
  var logBuf = [];
  function logBufTs() {
    var d = new Date(), pad = function (x) { return (x < 10 ? '0' : '') + x; };
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + tsNow();
  }
  function log(t) {
    logBuf.push('[' + logBufTs() + '] ' + String(t));
    if (logBuf.length > 1200) logBuf.splice(0, logBuf.length - 1200);
    var box = document.querySelector('.mscb-log');
    if (!box) return;
    var line = document.createElement('div');
    // v3.3.0 日志分级着色：成功绿 / 警告橙 / 失败红加粗 / 执行蓝，扫一眼就知道状态
    var cls = 'mscb-line';
    if (/^✅|^👍|^🎉|^🩺|^🚀|^🐱/.test(t)) cls += ' ok';
    else if (/^⚠️|^⏸|^💳|^⚠/.test(t)) cls += ' warn';
    else if (/^❌|^😿/.test(t)) cls += ' err';
    else if (/^🖼️|^⏳|^▶|^⏱|^🔄|^🛰|^⑤|^④|^③|^②|^①|^⑥/.test(t)) cls += ' info';
    if (/^(?:✅|🎉).*完成/.test(t)) cls += ' complete';
    line.className = cls;
    var ts = document.createElement('span');
    ts.className = 'mscb-ts';
    ts.textContent = '[' + tsNow() + ']';
    line.appendChild(ts);
    line.appendChild(document.createTextNode(t));
    // v3.6.0 滚动停留：你往上翻着看的时候就停在原地，不再被新日志拽到底部；回到底部附近才恢复自动跟随
    var nearBottom = box.scrollTop + box.clientHeight >= box.scrollHeight - 40;
    box.appendChild(line);
    while (box.children.length > 200) box.removeChild(box.firstChild);   // 上限 200 行，防止面板越跑越重
    if (nearBottom) box.scrollTop = box.scrollHeight;
    // v3.4.4 迷你条镜像：面板收起后日志照样在左下角迷你条里滚动
    var mlog = document.querySelector('.mscb-mini-log');
    if (mlog) {
      var mNear = mlog.scrollTop + mlog.clientHeight >= mlog.scrollHeight - 40;
      mlog.appendChild(line.cloneNode(true));
      while (mlog.children.length > 200) mlog.removeChild(mlog.firstChild);
      if (mNear) mlog.scrollTop = mlog.scrollHeight;
    }
    // v3.6.0 出错/警告提示音；红色错误再弹一个不自动消失的提醒窗
    if (cls.indexOf(' err') >= 0) errAlert(t);
    else if (cls.indexOf(' warn') >= 0) warnBeep();
  }
  // v3.6.0 警告提示音（一声低短哔）/ 错误提示音（两声下行，更急）
  function beepTone(freqs, dur) {
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      var ac = new AC();
      var playTone = function () {
        freqs.forEach(function (f, i) {
          var o = ac.createOscillator(), g = ac.createGain();
          o.frequency.value = f; o.type = 'triangle';
          o.connect(g); g.connect(ac.destination);
          var t0 = ac.currentTime + i * (dur + 0.06);
          g.gain.setValueAtTime(0.001, t0);
          g.gain.exponentialRampToValueAtTime(0.16, t0 + 0.02);
          g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
          o.start(t0); o.stop(t0 + dur + 0.02);
        });
        setTimeout(function () { try { ac.close(); } catch (e) {} }, (freqs.length * (dur + 0.08) + 0.4) * 1000);
      };
      if (ac.state === 'suspended') {   // 自动播放策略下先恢复
        ac.resume().then(playTone).catch(function () { try { ac.close(); } catch (e2) {} });
      } else playTone();
    } catch (e) {}
  }
  function warnBeep() { beepTone([520], 0.12); }
  function errBeep() { beepTone([660, 440], 0.16); }
  // v3.7.28 自动刷新：跑单/接口测试建好链接后，自动刷新采集箱列表让新链接出现（倒计时可看，不用手动按 F5）
  function fmtDur(s) {
    s = Math.max(0, Math.round(s));
    if (s >= 3600) return Math.floor(s / 3600) + '时' + Math.round((s % 3600) / 60) + '分';
    if (s >= 60) return Math.floor(s / 60) + '分' + (s % 60) + '秒';
    return s + '秒';
  }
  function autoRefreshPage(reason, delaySec) {
    delaySec = Math.max(3, delaySec || 8);
    log('🔄 ' + reason + '，' + delaySec + ' 秒后自动刷新页面显示新链接（想先看结果区的话马上点面板，刷新不影响已生成的图和已建的链接）');
    var tick = setInterval(function () {
      delaySec -= 1;
      if (delaySec <= 0) { clearInterval(tick); window.location.reload(); }
      else log('🔄 自动刷新倒计时 ' + delaySec + ' 秒…');
    }, 1000);
  }

  // v3.6.0 红色错误弹窗：不自动消失，错误逐条累积，手动关闭；任务继续跑不受影响
  function errAlert(t) {
    errBeep();
    try {
      var mask = document.querySelector('.mscb-errmask');
      if (!mask) return;
      var list = mask.querySelector('.mscb-errlist');
      var row = document.createElement('div');
      row.className = 'mscb-errrow';
      row.textContent = '[' + tsNow() + '] ' + t;
      list.appendChild(row);
      while (list.children.length > 50) list.removeChild(list.firstChild);
      if (!mask.classList.contains('open')) mask.classList.add('open');
      list.scrollTop = list.scrollHeight;
      // 标题栏闪一下提示有新错误
      var h = mask.querySelector('h4');
      if (h) { h.classList.remove('flash'); void h.offsetWidth; h.classList.add('flash'); }
    } catch (e) {}
  }

  async function pull(auto) {
    if (!/collect_box/i.test(location.pathname)) {
      log('ℹ️ 当前不在采集箱页，请先到「产品采集 → 公用采集箱」再采集');
      return 0;
    }
    exportPos = 0;   // 新一轮采集：按数量导出的游标拨回第 1 个（按列表顺序往下采）
    if (auto) log('页面已加载完，正在读取采集箱列表…');
    // 页面自己发过的真实列表接口优先试（hook 捕获到的 URL），比盲猜准确
    var probe = LIST_APIS.slice();
    if (lastListUrl && lastListUrl.indexOf(CB) >= 0) {
      var real = lastListUrl.split(CB)[1].split('?')[0].replace(/[^A-Za-z0-9_]/g, '');
      if (real && isListUrl(lastListUrl) && probe.indexOf(real) < 0) {
        probe.unshift(real);
        log('🛰 优先使用页面真实接口：' + real);
      }
    }
    var setOf = paramSets();
    var want = limitN();
    log('🎯 主动抓取：上限 ' + want + ' 条（每页 ' + perPage() + '，翻页抓到够为止）');
    for (var i = 0; i < probe.length; i++) {
      for (var k = 0; k < setOf.length; k++) {
        var j = await apiPost(probe[i], setOf[k]);
        if (!j) continue;
        var arr = normalizeList(digItems(j));
        if (arr.length) {
          var api = probe[i];
          var ps = Object.assign({}, setOf[k]);
          var n = ingestOrdered(arr);   // v3.7.63 按接口顺序重排
          log('✅ ' + api + ' 返回 ' + arr.length + ' 个（新增 ' + n + '）');
          // 自动翻页：同一接口第 2、3… 页，直到返回空 / 全是重复 / 已够采集上限
          var pageKey = ps.page != null ? 'page' : (ps.pageNo != null ? 'pageNo' : (ps.current != null ? 'current' : 'pageNum'));
          var firstPage = Number(ps[pageKey]) || 1;
          var maxPage = firstPage + Math.ceil(want / perPage()) + 2;
          for (var pg = firstPage + 1; pg <= maxPage; pg++) {
            if (items.size >= want) break;
            var q = Object.assign({}, ps); q[pageKey] = pg;
            var jj = await apiPost(api, q);
            var a2 = normalizeList(digItems(jj || {}));
            if (!a2.length) break;
            var before = items.size;
            ingestOrdered(a2);   // v3.7.63 翻页也按页内顺序追加
            if (items.size === before) break;
            log('第 ' + pg + ' 页：+' + (items.size - before) + ' 个');
          }
          var dropped = trimToLimit(want);
          if (dropped) log('✂️ 超出上限，已裁掉 ' + dropped + ' 条（只留前 ' + want + ' 条）');
          log('共 ' + items.size + ' 个商品');
          lastGrabSig = lastListUrl;   // v3.7.26 记录本次抓取基准，翻页变化由此对比
          return items.size;
        }
      }
    }
    log('⚠️ 没抓到列表。请在页面上翻一次页或切换筛选，让页面自己发一次请求，再点「重新抓取」。');
    lastGrabSig = lastListUrl;   // v3.7.26 即使失败也记录基准，避免反复空转
    return 0;
  }

  async function fillDetails() {
    if (!/collect_box/i.test(location.pathname)) return;   // 非采集箱页不发补详情请求
    var need = [];
    items.forEach(function (v) {
      if (v.sel === false) return;   // 没勾选的不抓详情，省时间也省接口次数
      if ((!v.imgs || v.imgs.length < 3) || !v.title || !v.raw) need.push(v);
    });
    if (!need.length) return;
    log('正在补齐 ' + need.length + ' 个商品的详情（批量接口，每批 20 个）…');
    var got = 0;
    for (var i = 0; i < need.length; i += 20) {
      // v3.7.45 普通箱行必须用 collectBoxDetailId（v.id 可能是 common ID，查不到详情）
      var batch = need.slice(i, i + 20).map(function (v) {
        return { vid: v.id, did: (v.raw && v.raw.collectBoxDetailId) ? String(v.raw.collectBoxDetailId) : v.id };
      });
      var j = await infoPost(batch.map(function (p) { return p.did; }));
      ((j && j.collectItemInfoList) || []).forEach(function (info) {
        var hit = need.filter(function (v) { return (v.raw && v.raw.collectBoxDetailId ? String(v.raw.collectBoxDetailId) : v.id) === String(info.detailId); })[0];
        if (hit && applyInfo(hit.id, info)) got++;
      });
      setStat('正在补齐详情 ' + Math.min(i + 20, need.length) + '/' + need.length);
      if (i + 20 < need.length) await sleep(200);
    }
    render();
    log('✅ 详情补齐完成（' + got + ' 个）');
  }

  /* ---------------- 全字段直取 v2.1.0：一次接口拿全 ----------------
     妙手批量编辑抽屉里的每一栏，本质都是同一个接口 getCollectItemInfoList 带不同的 fields[]：
       fields=[title,cid]      → 标题栏
       fields=[imgUrls]        → 轮播图栏
       fields=[skuMap,saleAttributes] → 毛重/净重/尺寸/平台SKU/建议售价…
     所以完全不用全选、不用点批量编辑、不用逐栏点、更不用滚动虚拟列表：
     直接把 detailIds + 全部 fields 一次性 POST 过去，20 个商品的所有字段一次返回。 */
  var API_FIELDS = ['title', 'multiLanguageTitleMap', 'cid', 'attributes', 'itemNum', 'saleAttributes', 'skuMap',
    'generateDiySkuItemNumRuleFields', 'productOriginCountry', 'productOriginProvince', 'productOriginCertFiles',
    'personalizationSwitch', 'technologyType', 'firstType', 'twiceType', 'sizeCharts', 'currency', 'imgUrls',
    'goodsLayerDecorationReqs', 'productGuideFile', 'translateLanguages'];

  function infoPost(ids) {
    var body = new URLSearchParams();
    ids.forEach(function (id, i) {
      body.append('sites[' + i + ']', 'PDDKJ');
      body.append('detailIds[' + i + ']', id);
      body.append('platformItemIds[' + i + ']', '');
    });
    API_FIELDS.forEach(function (f, i) { body.append('fields[' + i + ']', f); });
    return fetch(CB + 'getCollectItemInfoList', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString()
    }).then(function (r) { return r.json(); }).catch(function () { return null; });
  }

  function applyInfo(info, vidOverride) {
    // v3.7.45 vidOverride：普通箱行 detailId 与条目 id 不一致时，按条目真实 id 落库
    var id = String((vidOverride != null && vidOverride !== '') ? vidOverride : (info.detailId || ''));
    if (!id) return null;
    var it = items.get(id);
    if (!it) { it = { id: id, title: '', imgs: [] }; items.set(id, it); }
    it.raw = info;                                     // 原始详情 → 导出时填 47 列
    if (info.title) it.title = String(info.title);
    if (Array.isArray(info.imgUrls) && info.imgUrls.length) it.imgs = info.imgUrls.map(xtAbsUrl);
    return it;
  }

  /* ---------------- F12 式全量抓取 v2.2.7 ----------------
     编辑页的数据源 getCollectItemInfo 一个请求就带全部字段（产品属性/品牌/材料/
     安装类型/工艺效果/语言类型/工艺类型…），比批量编辑接口 fields[] 齐得多。
     逐品调用（同源 fetch，带登录态），结果整包合并进 raw。 */
  function pagePost(path, obj) {
    var body = new URLSearchParams();
    Object.keys(obj).forEach(function (k) { if (obj[k] != null) body.append(k, obj[k]); });
    return fetch(CB + path, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString()
    }).then(function (r) { return r.text(); }).then(function (t) {
      try { return JSON.parse(t); } catch (e) { throw new Error('返回非JSON: ' + String(t).slice(0, 120)); }
    });
  }

  function applyDetail(id, info) {
    if (!id || !info || typeof info !== 'object') return false;
    var it = items.get(id);
    if (!it) { it = { id: id, title: '', imgs: [] }; items.set(id, it); }
    // 详情整包为主，已抓到的字段（批量编辑整段文本等）不被空值覆盖
    var merged = Object.assign({}, info);
    Object.keys(it.raw || {}).forEach(function (k) {
      var v = merged[k];
      if (v == null || v === '' || (Array.isArray(v) && !v.length)) merged[k] = it.raw[k];
    });
    it.raw = merged;
    it.rawFull = true;
    if (!it.title && info.title) it.title = String(info.title);
    if ((!it.imgs || !it.imgs.length) && Array.isArray(info.imgUrls) && info.imgUrls.length) it.imgs = info.imgUrls.map(xtAbsUrl);
    return true;
  }

  async function detailGrab() {
    var pairs = [];
    items.forEach(function (v) {
      if (v.sel !== false && !v.rawFull) {
        // v3.7.45 普通箱行同时带两个 ID：详情接口 getCollectItemInfo 只认 collectBoxDetailId（common ID 查不到 → 「没取到数据」）
        var did = (v.raw && v.raw.collectBoxDetailId) ? String(v.raw.collectBoxDetailId) : v.id;
        pairs.push({ vid: v.id, did: did });
      }
    });
    if (!pairs.length) return 0;
    log('🛰 全量抓取：' + pairs.length + ' 个商品逐个调编辑页数据源（getCollectItemInfo，一个请求带全部字段）…');
    var got = 0;
    for (var i = 0; i < pairs.length; i++) {
      try {
        var j = await pagePost('getCollectItemInfo', { detailId: pairs[i].did });
        /* v3.5.5 修复：接口真实返回体在 siteCollectItemInfo（部分账号才是 shopCollectItemInfo），
           旧版只认 shopCollectItemInfo → 全量抓取一直“成功 0 个”，商品编号/原始产地全丢 */
        var one = j && (j.siteCollectItemInfo || j.shopCollectItemInfo || j.collectItemInfo);
        if (one && applyDetail(pairs[i].vid, one)) got++;
        // 单品接口不给分类路径（只有 cateList 两级），补一次批量接口拿 breadcrumb
        var it0 = items.get(pairs[i].vid);
        if (it0 && !(it0.raw && it0.raw.breadcrumb)) {
          try {
            var bj = await infoPost([pairs[i].did]);
            var b1 = ((bj && bj.collectItemInfoList) || [])[0];
            if (b1 && b1.breadcrumb) {
              it0.raw = Object.assign({}, it0.raw, { breadcrumb: b1.breadcrumb, cid: (it0.raw && it0.raw.cid) || b1.cid });
            }
          } catch (e2) {}
        }
      } catch (e) {}
      if ((i % 5) === 0) setStat('🛰 全量抓取 ' + (i + 1) + '/' + pairs.length);
      await sleep(120);
    }
    render();
    if (got) log('✅ 全量抓取完成：' + got + '/' + pairs.length + ' 个商品（产品属性/品牌/材料/工艺等全部入 raw）');
    else log('⚠️ 全量抓取没取到数据（需在妙手站内且已登录，稍后重试）');
    return got;
  }

  async function apiGrab() {
    var ids = [];
    items.forEach(function (v) { if (v.sel !== false) ids.push(v.id); });
    if (!ids.length) {
      log('⚠️ 还没有商品。页面刷新后等列表加载完，点「重新抓取」再来');
      return 0;
    }
    log('🛰 直取接口：' + ids.length + ' 个商品 × ' + API_FIELDS.length + ' 个字段（不用点栏、不用滚动）…');
    var got = 0, withSku = 0, withImg = 0;
    for (var i = 0; i < ids.length; i += 20) {
      var chunk = ids.slice(i, i + 20);
      var j = await infoPost(chunk);
      var list = (j && j.collectItemInfoList) || [];
      if (!list.length && i === 0) {
        log('⚠️ 接口没返回数据' + (j && j.result ? '（' + j.result + '）' : '') + '，请刷新页面重试');
        break;
      }
      list.forEach(function (info) {
        var it = applyInfo(info);
        if (!it) return;
        got++;
        if (info.skuMap && Object.keys(info.skuMap).length) withSku++;
      });
      log('第 ' + (Math.floor(i / 20) + 1) + ' 批：+' + list.length + ' 个');
      if (i + 20 < ids.length) await sleep(250);
    }
    items.forEach(function (v) { if (v.imgs && v.imgs.length) withImg++; });
    render();
    if (got) {
      log('✅ 字段全部取回：' + got + '/' + ids.length + ' 个商品（' + withSku + ' 个带 SKU 明细，' + withImg + ' 个带轮播图）');
      log('🎉 全部就绪！点下面橙色「发送到洗图台」继续');
      try {
        var b = document.querySelector('.mscb-ball');
        if (b) { b.style.animation = 'mscb-pulse .5s ease-in-out 4'; setTimeout(function () { b.style.animation = ''; }, 2200); }
      } catch (e) {}
    }
    return got;
  }

  // 兼容旧入口：先走接口直取，接口完全失败才退回「点批量编辑逐栏抓」
  async function grabAll() {
    var n = await apiGrab();
    if (!n) {
      log('↩️ 改用界面抓取兜底（较慢，需要页面在采集箱列表页）…');
      await batchScrape();
    }
  }

  /* ---------------- 批量编辑抓取 v2.0.3：全自动 ----------------
     流程 = 自动全选当前页 → 点「批量编辑」→ 菜单选一栏进入抽屉 → 抽屉左侧逐栏点下去
     → 每栏在右侧表格 JS 滚动抓全（虚拟滚动池只有可见 8 行）→ 最后点「取消」关抽屉，绝不保存 */
  var BATCH_SECTIONS = ['标题', '英语标题', '类目属性', '主货号', '外包装', '产地', '制造地点', '品牌', '定制品', '详情文字', '规格名称', '敏感属性', '毛重', '净重', '尺寸', '平台SKU', 'SKU分类', '尺码表', '模特信息', '建议售价', '底板/套版', '轮播图', '颜色图', '预览图', '描述图优化', '素材图', '添加水印', '主图视频', '详情视频', '产品说明书', '商品主图', '详情图'];
  var IMG_SECTIONS = { '轮播图': 1, '颜色图': 1, '预览图': 1, '素材图': 1, '添加水印': 1, '描述图优化': 1, '商品主图': 1, '详情图': 1 };
  var PANEL_SEL = '.box-table-column-selection';
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  // v3.7.52 成品图上传妙手前客户端压缩：codekey 等上游会忽略 output_compression 参数，返回 1MB+ 大图，
  // 统一重编码 JPEG，质量 0.85→0.45 逐级下调，直到 ≤ capKB（默认 500KB）；不缩尺寸，保清晰度
  async function xtRecompress(blob, capKB, maxDim) {
    capKB = capKB || 500;
    try {
      if (!blob || !(blob.size > capKB * 1024) || !/^image\//.test(blob.type || '')) return blob;
      var bmp = await createImageBitmap(blob);
      var c = document.createElement('canvas');
      // v3.7.75 超小档：同时缩边（长边 ≤ maxDim），进一步压小体积
      var sc = (maxDim && Math.max(bmp.width, bmp.height) > maxDim) ? (maxDim / Math.max(bmp.width, bmp.height)) : 1;
      c.width = Math.max(1, Math.round(bmp.width * sc));
      c.height = Math.max(1, Math.round(bmp.height * sc));
      var ctx = c.getContext('2d');
      ctx.drawImage(bmp, 0, 0, c.width, c.height);
      var qs = [0.85, 0.75, 0.65, 0.55, 0.45], last = null;
      for (var qi = 0; qi < qs.length; qi++) {
        var out = await new Promise(function (rs) { c.toBlob(rs, 'image/jpeg', qs[qi]); });
        if (!out || !out.size) continue;
        last = out;
        if (out.size <= capKB * 1024) {
          try { if (typeof log === 'function') log('🗜 成品图压缩：' + Math.round(blob.size / 1024) + 'KB → ' + Math.round(out.size / 1024) + 'KB（质量 ' + qs[qi] + '）'); } catch (eL) {}
          return out;
        }
      }
      if (last) {   // 全档位仍超上限：接受最低档结果，避免死循环
        try { if (typeof log === 'function') log('🗜 成品图压缩（触底）：' + Math.round(blob.size / 1024) + 'KB → ' + Math.round(last.size / 1024) + 'KB'); } catch (eL2) {}
        return last;
      }
      return blob;
    } catch (e) { return blob; }
  }

  // v3.7.75 输出模式：图源（图链直写/上传图片空间）+ 体积档位（原样/标准/小体积/超小），按客户需求选
  function xtSrcDirect() {   // 是否允许用上游外链直写入表（false=一律上传妙手图片空间拿妙手图链）
    return cfg.imgSrc !== 'space' && cfg.imgDirect !== false;
  }
  function xtOutCap() {
    var s = cfg.imgSize || 'auto';
    if (s === 'original') return { cap: 0, maxDim: 0 };
    if (s === 'small') return { cap: 300, maxDim: 2000 };
    if (s === 'tiny') return { cap: 150, maxDim: 1200 };
    return { cap: 500, maxDim: 0 };   // auto：>500KB 才压，不缩边
  }

  function vis(el) {
    var r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && r.bottom > 0;
  }

  function selCount() {
    var m = (document.body.innerText || '').match(/已选\s*(\d+)\s*\/\s*\d+条/);
    return m ? Number(m[1]) : 0;
  }

  // 表头全选：需要完整事件序列，纯 click() 不触发
  function selectAllRows() {
    var inp = document.querySelector('.pro-virtual-table__header .pro-virtual-table__checkbox input');
    if (!inp || inp.checked) return;
    inp.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    inp.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
    inp.click();
    inp.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // 文本精确匹配的可见叶子元素（取文档序第一个，抽屉左侧栏在表格之前）
  function leafByName(root, name) {
    var els = root.querySelectorAll('span,li,div,a,p,button');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (el.children.length) continue;
      if ((el.textContent || '').trim() !== name) continue;
      if (!vis(el)) continue;
      return el;
    }
    return null;
  }

  function panelEl() {
    var p = document.querySelector(PANEL_SEL);
    return (p && vis(p)) ? p : null;
  }

  // 抽屉根：面板向上找 el-dialog（batch-edit-detail class 不稳定，不作依赖）
  function drawerRoot() {
    var p = panelEl();
    if (!p) return null;
    var d = p.closest('.el-dialog') || p.closest('[class*="dialog"]');
    return d || p.parentElement;
  }

  // 抽屉左侧栏位 = .menu-list 下的 menu-item（内含图标，不能按"无子元素"过滤；全局查，当前只有一个批量编辑抽屉）
  function sectionEl(root, name) {
    var items = document.querySelectorAll('.menu-list .menu-item, .menu-item');
    for (var i = 0; i < items.length; i++) {
      if ((items[i].textContent || '').trim() !== name) continue;
      if (!vis(items[i])) continue;
      return items[i];
    }
    var els = root.querySelectorAll('span,li,div,a,p,button');
    for (var j = 0; j < els.length; j++) {
      var el = els[j];
      if (el.children.length) continue;
      if ((el.textContent || '').trim() !== name) continue;
      if (!vis(el)) continue;
      return el;
    }
    return null;
  }

  function waitFor(fn, timeout, step) {
    return new Promise(function (res) {
      var t0 = Date.now();
      (function poll() {
        var r = fn();
        if (r) return res(r);
        if (Date.now() - t0 >= timeout) return res(null);
        setTimeout(poll, step || 300);
      })();
    });
  }

  // 打开抽屉（若未开）：自动全选 → 点批量编辑按钮 → 菜单点一个栏目进入
  async function openBatchDrawer() {
    if (panelEl()) return drawerRoot();
    if (selCount() === 0) {
      log('未勾选商品，先自动全选当前页…');
      selectAllRows();
      await sleep(1500);
    }
    var tryNames = ['标题', '英语标题', '毛重', '净重'];
    for (var t = 0; t < 3; t++) {
      var btn = null, bs = document.querySelectorAll('button');
      for (var i = 0; i < bs.length; i++) {
        if ((bs[i].innerText || '').trim() === '批量编辑' && vis(bs[i])) { btn = bs[i]; break; }
      }
      if (!btn) { log('❌ 页面上没有「批量编辑」按钮（当前不在采集箱列表页？）'); return null; }
      btn.click();
      var picked = await waitFor(function () {
        for (var j = 0; j < tryNames.length; j++) {
          var el = sectionEl(document, tryNames[j]) || leafByName(document, tryNames[j]);
          if (el) { el.click(); return el; }
        }
        return null;
      }, 4000, 400);
      if (!picked) { log('⚠️ 批量编辑菜单没弹出，重试 ' + (t + 1) + '/3…'); continue; }
      var d = await waitFor(panelEl, 6000, 300);
      if (d) return drawerRoot();
    }
    return null;
  }

  // 面板当前渲染的行（虚拟滚动池只有 ~8 行）
  function panelRowsOnce() {
    var p = panelEl();
    if (!p) return [];
    var rows = [], seen = new Set();
    var views = p.querySelectorAll('.vue-recycle-scroller__item-view, .jx-pro-virtual-table__row');
    for (var i = 0; i < views.length; i++) {
      var v = views[i];
      var text = String(v.innerText || '').trim();
      if (!text) continue;
      var thumb = '', imgs = [];
      var ims = v.querySelectorAll('img');
      for (var j = 0; j < ims.length; j++) {
        var s = ims[j].currentSrc || ims[j].src || '';
        if (!/^https?:\/\//.test(s)) continue;
        imgs.push(s);
        var r = ims[j].getBoundingClientRect();
        if (!thumb && r.width >= 25 && r.width <= 140 && r.height >= 25) thumb = s;
      }
      var key = (thumb || '') + '|' + text.replace(/\s+/g, '').slice(0, 60);
      if (seen.has(key)) continue;
      seen.add(key);
      rows.push({ text: text, imgs: imgs, thumb: thumb });
    }
    return rows;
  }

  function panelSig() {
    return panelRowsOnce().map(function (r) { return r.text.slice(0, 40); }).join('#').slice(0, 2000);
  }

  // 滚动抓全整栏（JS 设 scrollTop + 派发 scroll，到底/卡住即停）
  async function scrapePanel() {
    var uniq = new Map();
    var stuck = 0;
    for (var round = 0; round < 40; round++) {
      panelRowsOnce().forEach(function (r) {
        if (r.text) uniq.set(r.text.replace(/\s+/g, '').slice(0, 60), r);
      });
      var s = panelEl() && panelEl().querySelector('.vue-recycle-scroller');
      if (!s) break;
      var before = s.scrollTop;
      s.scrollTop += 380;
      s.dispatchEvent(new Event('scroll'));
      await sleep(400);
      if (s.scrollTop === before) { stuck++; if (stuck >= 3 && uniq.size) break; }
      else stuck = 0;
    }
    return [...uniq.values()];
  }

  async function closeDrawer() {
    function clickBtn(txt) {
      var btns = document.querySelectorAll('button');
      for (var i = btns.length - 1; i >= 0; i--) {
        var b = btns[i];
        if ((b.innerText || '').trim() === txt && vis(b) && b.closest('.el-dialog, .jx-pro-dialog, [class*="batch-edit"]')) { b.click(); return true; }
      }
      return false;
    }
    clickBtn('取消');
    await sleep(900);
    if (panelEl()) { clickBtn('确定'); await sleep(900); }
    if (panelEl()) {
      var x = document.querySelector('.el-dialog__headerbtn');
      if (x && vis(x)) { x.click(); await sleep(600); }
    }
  }

  function normUrl(u) {
    return String(u || '').split('?')[0].replace(/_(\d+x\d+|\d{2,4})\./g, '.');
  }

  // 把一栏的行合并进 items：缩略图/标题双重匹配，失败按顺序兜底
  function mergeRows(section, rows) {
    var order = [];
    items.forEach(function (v) { order.push(v); });
    var used = new Set(), matched = 0;
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i], it = null;
      var rn = normUrl(row.thumb);
      for (var k = 0; k < order.length; k++) {
        if (used.has(order[k].id)) continue;
        var imgs = order[k].imgs || [];
        for (var m = 0; m < imgs.length; m++) {
          if (normUrl(imgs[m]) === rn) { it = order[k]; break; }
        }
        if (it) break;
      }
      if (!it) {
        var head = row.text.replace(/\s+/g, '').slice(0, 14);
        for (var k2 = 0; k2 < order.length; k2++) {
          if (used.has(order[k2].id)) continue;
          var tt = String(order[k2].title || '').replace(/\s+/g, '');
          if (tt && head && tt.indexOf(head.slice(0, 8)) >= 0) { it = order[k2]; break; }
        }
      }
      if (!it && order[i] && !used.has(order[i].id)) it = order[i];
      if (!it) continue;
      used.add(it.id);
      it.batch = it.batch || {};
      it.batch[section] = IMG_SECTIONS[section] ? { imgs: row.imgs } : { text: row.text };
      matched++;
    }
    return matched;
  }

  async function batchScrape() {
    log('⚡ 开始自动抓取：全选 → 打开批量编辑 → 逐栏抓取…');
    var root = await openBatchDrawer();
    if (!root) {
      log('❌ 打不开批量编辑抽屉。可手动：勾选商品 → 点「批量编辑」→ 任选一栏进入抽屉，再点本按钮');
      return;
    }
    log('🔍 抽屉已打开，开始逐栏自动抓取（每栏滚动抓全再切下一栏）…');
    var batchSample = { url: location.href, at: new Date().toISOString(), sections: {} };
    var secDone = 0, matchedTotal = 0, failed = [];
    for (var i = 0; i < BATCH_SECTIONS.length; i++) {
      var name = BATCH_SECTIONS[i];
      var el = sectionEl(root, name);
      if (!el) continue;
      var before = panelSig();
      el.click();
      var switched = false;
      for (var w = 0; w < 12; w++) {
        await sleep(250);
        var sig = panelSig();
        if (sig && sig !== before) { switched = true; break; }
      }
      if (!switched && panelEl() && panelEl().parentElement) { panelEl().parentElement.click(); await sleep(500); }
      await sleep(400);
      var rows = await scrapePanel();
      if (!rows.length) { failed.push(name); continue; }
      var matched = mergeRows(name, rows);
      batchSample.sections[name] = rows;
      secDone++; matchedTotal += matched;
      log((matched >= rows.length ? '✅ ' : '⚠️ ') + name + '：' + rows.length + ' 行，匹配 ' + matched + ' 个商品');
    }
    window.__msBatchSample = batchSample;
    closeDrawer();
    if (!secDone) {
      log('❌ 一栏都没抓到。请在抽屉展开状态下再点一次本按钮；还不行就点「抓字段样本」把页面结构发我');
      return;
    }
    log('🎉 批量编辑抓取完成：' + secDone + ' 栏 / 匹配 ' + matchedTotal + ' 条字段数据' + (failed.length ? '（未读到：' + failed.join('、') + '）' : ''));
    log('这些字段会在「发送到洗图台」时随商品一起上传，导出表格时自动填进对应列');
  }

  /* ---------------- 发送到洗图台（走后台，绕开跨域） ---------------- */
  function relay(url, body) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage({ cmd: 'relayJson', url: url, body: body, timeoutMs: 90000 }, function (r) {
        if (!r) return reject(new Error('后台无响应，请到 chrome://extensions 重新加载扩展'));
        if (!r.ok) return reject(new Error(r.error || '请求失败'));
        resolve(r.data);
      });
    });
  }

  function relayText(url, method) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage({ cmd: 'relayText', url: url, method: method || 'GET', timeoutMs: 60000 }, function (r) {
        if (!r) return reject(new Error('后台无响应，请重新加载扩展'));
        if (!r.ok) return reject(new Error(r.error || '请求失败'));
        resolve(r.text);
      });
    });
  }

  // v3.6.1 抗断线：洗图台重启/网络抖一下不再让整条自动化报废。
  // 服务端任务照常跑，插件这边最多重连 5 分钟；恢复正常后无缝续上进度。
  async function statusSafe(url, body) {
    var deadline = Date.now() + 5 * 60 * 1000, lastErr = null, n = 0;
    while (Date.now() < deadline) {
      try { return await relay(url, body || {}); }
      catch (e) {
        lastErr = e; n++;
        if (n === 1 || n % 10 === 0) {
          log('🔌 洗图台连接断开（' + ((e && e.message) || '连接失败') + '）：任务在服务端照常跑，插件自动重连中（第 ' + n + ' 次，最多等 5 分钟）…');
        }
        await nap(3000);
      }
    }
    throw lastErr || new Error('洗图台长时间无响应');
  }

  function needSetup() {
    chrome.runtime.sendMessage({cmd:'xtNewApiOpen'}).catch(function () {});
    var panel = document.querySelector('.mscb-panel');
    if (panel) panel.classList.add('open');
  }

  async function send() {
    var list = [];
    items.forEach(function (v) {
      if (v.sel === false) return;   // 面板上取消勾选的不发
      if (v.title && v.imgs && v.imgs.length) {
        var raw = v.raw || {};
        if (v.batch && Object.keys(v.batch).length) raw.batch = v.batch;  // 批量编辑抓来的字段，导出表格时填列
        // 只有真的抓到原始详情/批量字段才带 raw，避免给服务端塞一堆空对象
        list.push({ id: v.id, title: v.title, urls: v.imgs, raw: (Object.keys(raw).length ? raw : null),
          tplKey: v.tplKey || '', note: noteByPid[String(v.id)] || '' });
      }
    });
    if (!list.length) {
      log(selCount() ? '没有可发送的商品（勾选的商品需要标题 + 至少 1 张图）' : '没有勾选任何商品，先在上面勾上要发的');
      return false;
    }
    var base = washBaseOf();
    var code = String(cfg.code || '').trim();
    if (!base) { log('❌ 请先在面板「洗图台」里填上新服务器地址（例如 http://服务器IP:8788 或 https://你的域名）'); needSetup(); return false; }
    if (!code) { log('❌ 请先填访问口令（管理员口令或客户口令），否则洗图台会拒绝'); needSetup(); return false; }
    // 原始规则：表格参数（供货价/毛重/尺寸/平台SKU/产地等全部列）必须跟标题图片一起采齐。
    // 列表接口只给标题+图，详情字段要靠 getCollectItemInfoList 直取，所以推单前自动补一轮。
    var noRaw = 0;
    list.forEach(function (x) { if (!x.raw) noRaw++; });
    if (noRaw) {
      log('📋 ' + noRaw + ' 个商品还没采集表格参数（原始规则：全参数直推），自动全字段直取…');
      try { await apiGrab(); } catch (eG) { log('⚠️ 全字段直取失败（' + String(eG.message || eG).slice(0, 60) + '），继续推送（表格参数列可能为空）'); }
      try { await detailGrab(); } catch (eD) {}   // 编辑页数据源兜底：产品属性等字段在这里
      list = [];
      items.forEach(function (v) {
        if (v.sel === false) return;
        if (v.title && v.imgs && v.imgs.length) {
          var raw2 = v.raw || {};
          if (v.batch && Object.keys(v.batch).length) raw2.batch = v.batch;
          list.push({ id: v.id, title: v.title, urls: v.imgs, raw: (Object.keys(raw2).length ? raw2 : null),
            tplKey: v.tplKey || '', note: noteByPid[String(v.id)] || '' });
        }
      });
    }
    var url = base + '/api/import-items?code=' + encodeURIComponent(code)
      + '&admin=' + encodeURIComponent(code)
      + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
    var btn = oneBtn || { disabled: false, textContent: '' };
    var btnOld = btn.textContent;
    btn.disabled = true;
    try {
      // 回填优先：洗图台当前任务如果已包含这些商品（图已生成完），只回填表格参数，不重建任务、不重新生图
      var withRaw = list.filter(function (x) { return x.raw; });
      if (withRaw.length) {
        try {
          var er = await relay(base + '/api/enrich-raw?code=' + encodeURIComponent(code)
            + '&admin=' + encodeURIComponent(code)
            + '&sharecode=' + encodeURIComponent(String(cfg.share || '')), { items: withRaw });
          if (er && er.ok && !er.noRun && er.enriched > 0) {
            log('✅ 当前任务已含 ' + er.enriched + '/' + withRaw.length + ' 个商品：表格参数已回填进现有任务（' + (er.runProducts || '?') + ' 个产品，图片不重新生成）');
            if (er.missing && er.missing.length) log('ℹ️ 有 ' + er.missing.length + ' 个商品不在当前任务里：' + er.missing.slice(0, 5).join('、'));
            if (er.mapped) log('📋 字段映射：' + er.mapped);
            if (er.enriched >= withRaw.length) {
              log('🎉 全部参数已就位。去洗图台点「生成导入表格」即可导出带全参数的 CSV');
              showOpen(base);
              return true;
            }
          }
        } catch (eE) { log('ℹ️ 参数回填跳过（' + String(eE.message || eE).slice(0, 60) + '），走正常建单流程'); }
      }
      log('📤 正在发送 ' + list.length + ' 个商品 → ' + base);
      var r = await relay(url, { items: list, copies: Number(cfg.copies) || 1, fileName: '采集箱直推_' + list.length + '个' });
      if (r.queued) {
        log('⏳ 洗图台正忙（' + (r.activeOwner || '其他任务') + ' 在跑），你的任务已排队第 ' + r.position + ' 位');
      } else {
        log('✅ 已建单：' + (r.imported || list.length) + ' 个商品 / ' + (r.products ? r.products.length : list.length) + ' 条链接（跳过 ' + (r.skipped || 0) + ' 个资料不全的）');
        if (r.mapped) log('📋 字段映射：' + r.mapped);
      }
      showOpen(base);
      return true;
    } catch (e) {
      var m = String(e.message || e);
      if (/403|口令/.test(m)) {
        log('❌ 洗图台拒绝了这次发送：口令不对。请在面板「访问口令」填对（当前填的是「' + (code.length ? code.slice(0, 2) + '***' : '空') + '」）后重试');
        needSetup();
      } else if (/Failed to fetch|net::|timeout|超时|ECONN|无法连接/i.test(m)) {
        log('❌ 连不上洗图台：' + base + '（' + m + '）—— 地址填错，或网络/隧道不通。可以先点「🔌 测连接」确认');
        needSetup();
      } else {
        log('❌ ' + m);
      }
      return false;
    } finally {
      btn.disabled = false; btn.textContent = btnOld;
    }
  }

  // 连通性自检：/api/ping 会回 { ok, admin, locked, me:{name,balance}, charge }
  async function ping() {
    var base = washBaseOf();
    var code = String(cfg.code || '').trim();
    if (!base) { log('❌ 先填洗图台地址'); needSetup(); return; }
    if (!code) { log('❌ 先填访问口令'); needSetup(); return; }
    log('🔌 正在测 ' + base + ' …');
    try {
      var url = base + '/api/ping?code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code);
      var r = await relay(url, {});
      if (r && r.locked) log('⛔ 地址通，但本机 IP 因口令错太多次被临时锁定（约 ' + (r.lockMin || 0) + ' 分钟后自动解）');
      else if (r && r.ok) log('✅ 全部正常：' + base + ' ｜ 身份 ' + (r.admin ? '管理员' : (r.me ? r.me.name : '?')) + (r.me && r.me.balance != null ? '（余额 ¥' + Number(r.me.balance).toFixed(2) + '）' : '') + ' ｜ ¥' + r.charge + '/张');
      else log('❌ 地址通，但口令不对（' + base + '）→ 改「访问口令」后重试');
    } catch (e) {
      log('❌ 不通：' + String(e.message || e));
    }
  }

  var envChecking = false;
  function diagnosticBase(value) {
    var u = new URL(value);
    if (!/^https?:$/.test(u.protocol) || u.username || u.password) throw new Error('检测地址必须是普通 HTTP/HTTPS 地址');
    var host = u.hostname.replace(/\.$/, '');
    if (!['api.jaykou.com','erp.91miaoshou.com','img.kwcdn.com','aimg.kwcdn.com'].includes(host)) throw new Error('这不是允许的检测地址');
    return value;
  }
  function checkPublishedImage(url) {
    diagnosticBase(url);
    return new Promise(function (resolve, reject) {
      var timer = setTimeout(function () { reject(new Error('图床图片读取超时')); }, 15000);
      function finish(error, value) { clearTimeout(timer); if (error) reject(error); else resolve(value); }
      try {
        chrome.runtime.sendMessage({ cmd: 'fetchImg', url: url }, function (r) {
          if (chrome.runtime.lastError || !r || !r.ok) { finish(new Error('图床图片读取失败，请检查地址或服务器')); return; }
          var im = new Image();
          im.onload = function () { if (!im.naturalWidth || !im.naturalHeight) finish(new Error('图床返回了空图片')); else finish(null, { width: im.naturalWidth, height: im.naturalHeight }); };
          im.onerror = function () { finish(new Error('图床返回内容不能解码为图片')); };
          im.src = r.dataUrl;
        });
      } catch (e) { finish(new Error('插件连接已失效，请重载插件并刷新页面')); }
    });
  }
  function environmentContextError(e) { return /Extension context invalidated|context.*invalid|(?:扩展|插件).*失效/i.test(String(e && e.message || e)); }
  function environmentExtensionStale() {
    try { return !chrome.runtime.id; } catch (e) { return true; }
  }
  function offerEnvironmentRefresh() {
    log('⚠️ 插件已更新，当前妙手页面的插件连接已失效。请刷新本页面后再点环境检测；不是标题或生图接口被拒绝。');
    if (window.confirm('插件已更新，这张旧页面的插件连接已失效。\n刷新页面后即可重新检测，不会重新上传或重新生图。\n\n现在刷新页面吗？')) window.location.reload();
  }
  async function environmentCheck() {
    if (envChecking || busy || rerunning || repairBusy) { log('⏳ 请等当前操作结束后再检测环境'); return; }
    if (environmentExtensionStale()) { offerEnvironmentRefresh(); return; }
    envChecking = true;
    var btn = document.querySelector('.mscb-envcheck');
    if (btn) { btn.disabled = true; btn.textContent = '检测中…'; }
    try {
      var r = await chrome.runtime.sendMessage({cmd:'xtNewApiDiagnose'});
      if (!r || !r.ok) throw new Error(r && r.error || '插件后台无响应');
      log(r.data.image.ok ? '✅ Jaykou 模型列表可读，生图模型可见' : '⚠️ Jaykou：' + r.data.image.error);
      log(r.data.title.ok ? '✅ 文本接口的模型列表可读，标题模型可见' : '⚠️ 改标题：' + r.data.title.error);
      log('🩺 此处只查连接和模型权限，不扣费、不上传。真实出图和改标题请到「连接 New API」分别测试。');
    } catch (e) {
      if (environmentContextError(e)) offerEnvironmentRefresh();
      else log('⚠️ 环境检测：' + String(e && e.message || e).slice(0, 160));
    } finally {
      envChecking = false;
      if (btn) { btn.disabled = false; btn.textContent = '🩺 环境检测'; }
    }
  }
  async function testImportInterface(event) {
    var btn=event.currentTarget;
    if (busy || paused || rerunning || repairBusy || envChecking) { log('⏳ 请等当前任务结束后再测试导入接口'); return; }
    if (!onCollectPage()) { log('⚠️ 请打开妙手 Temu 采集箱再测试直连接口。'); return; }
    if (!window.confirm('接口测试（完整版）将：\n1. 把内置「测试 1–5」图片上传到妙手图片空间\n2. 校验 5 条导入表\n3. 校验通过后真实提交导入 —— 在采集箱创建 5 条测试链接（草稿，不发布）\n\n不生成 AI 图片、不扣生图费；会创建 5 条名为「测试1~5」的商品条目。继续吗？')) return;
    btn.disabled=true;busy=true;
    try {
      var rows=[];
      for(var i=1;i<=5;i++){
        var sample=await fetch(chrome.runtime.getURL('qa/ceshi'+i+'.png'));
        if(!sample.ok)throw new Error('找不到内置「测试'+i+'」图片');
        var form=new FormData();
        form.append('uploadImgFile',new File([await sample.blob()],'xitumao-test-'+i+'.png',{type:'image/png'}));
        form.append('imageScene','previewImage'); form.append('uploadType','file'); form.append('scene','');
        var reply=await fetch('/api/picture/picture/uploadPictureFile',{
          method:'POST',credentials:'same-origin',redirect:'error',body:form,signal:AbortSignal.timeout(25000)
        });
        if(!reply.ok)throw new Error('测试'+i+'图片上传失败（HTTP '+reply.status+'）');
        var info=await reply.json();
        if(info.result!=='success'||!info.picturePath)throw new Error('测试'+i+'未返回可用图链');
        var u=new URL(info.picturePath);
        if(u.protocol!=='https:'||u.username||u.password||u.port||
         !['earth-rt.chengji-inc.com','erp.91miaoshou.com'].includes(u.hostname))
          throw new Error('测试'+i+'返回的图链不是已验证的妙手域名，停止校验。');
        // FIX 2026-11-21: 妙手导入要求 ①产品ID 纯数字（带字母整行被拒）②必填字段齐全
        // （缺 产品分类/规格/供货价/SKU数量/定制品 等行级失败）。以下取自实测成功批次的完整字段。
        rows.push({
          '产品ID': String(Date.now()).slice(-11) + i,
          '产品名称': '测试' + i,
          '英文标题': 'Xitumao API Test Product ' + i + ', 1 Piece, for Import Connectivity Verification Only',
          '产品分类': '家居、厨房用品>节日装饰品>装饰牌匾及摆件',
          '类目属性': '产品推荐用途:多用途;材料:人造木材;安装类型:其他安装类型;工艺效果:2D平面;语言类型:英语;产品类型:装饰型;工艺类型:印刷;风格:圣诞节日风',
          '产地': '中国大陆/江西省',
          '规格名称1': '型号',
          '规格属性值1': 'A',
          '供货价': '1.00',
          '是否敏感属性': '否',
          'SKU分类数量': '1',
          '是否定制品': '否',
          '产品轮播图链接': u.href, '产品素材图链接': u.href, '产品预览图链接': u.href
        });
        log('✅ 测试'+i+'图片上传通过');
      }
      var text='\ufeff'+[TPL_HDR.map(csvCell).join(',')].concat(rows.map(function(fields){
        return TPL_HDR.map(function(h){return csvCell(fields[h]||'');}).join(',');
      })).join('\r\n')+'\r\n';
      var count=await validateImportCsv(new File([text],'xitumao-test-1-5-validate-only.csv',{type:'text/csv;charset=utf-8'}));
      if(count!==5)throw new Error('预期校验 5 条，妙手实际识别 '+count+' 条，不算通过');
      log('✅ 测试 1–5：5 张上传、5 条表格校验通过');
      // v3.7.27 按用户要求：接口测试最后一步真实提交导入，在采集箱建出 5 条测试链接才算「真正通过」
      log('📤 第 6 步：真实提交导入，在采集箱创建 5 条测试链接…');
      var ir=await importSend(text,'xitumao-test-1-5.csv',90,function(step){ log('   · 导入步骤 '+step+' 完成'); });   // v3.7.63 走 importSend：setting 为空时自动 RPA 兑底，新账号也能过测
      if(ir && ir.ok){
        log('🎉 接口测试全部通过：5 条测试链接已建到采集箱（草稿，未发布）——马上自动刷新显示「测试1~5」');
        autoRefreshPage('接口测试 5 条链接已建好', 8);   // v3.7.28 自动刷新采集箱
        try { notify('🎉 接口测试通过','5 条测试链接已创建到妙手采集箱（草稿未发布），去列表核对'); } catch(eN){}
      } else {
        log('⚠️ 表格校验通过，但导入提交结果待确认 —— 请到妙手「导入记录」核对 xitumao-test-1-5 批次');
      }
    } catch (e) {
      log('⚠️ 接口测试未通过：'+String(e && e.message || e).slice(0,160));
    } finally { btn.disabled=false;busy=false; }
  }
  // 抓一个商品的完整详情样本，用来校准「采集字段 → 47 列导入表」的映射
  async function grabSample() {
    var first = null;
    items.forEach(function (v) { if (!first) first = v; });
    if (!first) { log('先抓取列表，再抓样本'); return; }
    var payload = { detailId: first.id, sample: first, batchSample: window.__msBatchSample || null };
    var blob = new Blob([JSON.stringify(payload, null, 1)], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'collect-sample.json';
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 5000);
    log('✅ 已下载 collect-sample.json（含商品详情 + 批量编辑抓取结构），发我即可校准列映射');
  }

  var oneBtn = null, autoBtn = null, busy = false;
  var zoomApi = null;   // v3.4.0 成品图灯箱（build 时接线）
  var compareApi = null; // v3.6.0 原图/洗后对比弹窗（build 时接线）
  var paused = false;          // 一键暂停：置位后流程停在下一步边界，点「继续」恢复
  var pauseBtn = null, startBtn = null, semiExtraRow = null;

  /* ---------------- 导出表格：洗图台出问题时的兜底（拖进洗图台即可上传） ---------------- */
  // 妙手导入模板 48 列，与洗图台 /api/download-csv 同一套表头
  var TPL_HDR = ['SKUID', '店铺ID', '店铺名称', '产品ID', '产品名称', '产品分类', '类目属性', '主货号', '产地', '制造地点',
    '站外产品链接', '产品轮播图链接', '产品素材图链接', '产品颜色图链接', '产品预览图链接', '规格名称1', '规格属性值1', '规格名称2', '规格属性值2',
    '供货价', '是否敏感属性', '敏感属性值', '储电容量', '刀具长度', '刀具尖度', '液体容量', '尺寸',
    'SKU分类类型', 'SKU分类数量', 'SKU分类单位', '共计内含件数', '共计内含件数单位', '毛重(g)', '净重(g)', '平台SKU', '包装信息',
    'SKCID', 'SKC产品状态', '生命周期', '是否定制品', '产品类型', 'JIT库存', '关联货源链接', '关联货源ID', '关联货源价格', '创建时间', '本地分组', '英文标题'];

  function csvCell(v) {
    var s = String(v == null ? '' : v);
    return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  /* ---------------- 原始详情 → 48 列映射（与服务端 fillRowFromRaw 同一套） ----------------
     raw 里存的是 getCollectItemInfoList 的英文键（skuMap/attributes/saleAttributes…），
     必须翻译成导入模板中文列名，否则导出表格除标题/图片外全空（v2.2.6 修复） */
  var MI_COUNTRY = { CN: '中国大陆', HK: '中国香港', MO: '中国澳门', TW: '中国台湾', US: '美国', JP: '日本', KR: '韩国', GB: '英国', DE: '德国', FR: '法国', IT: '意大利', ES: '西班牙', CA: '加拿大', AU: '澳大利亚', VN: '越南', TH: '泰国', IN: '印度', MX: '墨西哥', BR: '巴西', TR: '土耳其', ID: '印度尼西亚', MY: '马来西亚', PH: '菲律宾', SG: '新加坡', RU: '俄罗斯', PL: '波兰', NL: '荷兰', SE: '瑞典', AE: '阿联酋', SA: '沙特阿拉伯' };
  var DEFAULT_ORIGIN = '中国大陆/江西省';
  var RAW_ALIAS = {
    '产品分类': ['categoryName', 'categoryPath', 'categoryFullName', 'catName', 'categoryNamePath', 'category'],
    '类目属性': ['categoryAttributes', 'categoryAttr', 'attributes', 'props', 'propertyList', 'attrList', 'productAttributes', 'categoryProperty'],
    '主货号': ['outerGoodsSn', 'goodsSn', 'itemNo', 'articleNumber', 'supplierSku', 'productSn', 'skuSn', 'itemSku', 'itemNum'],
    '站外产品链接': ['sourceUrl', 'itemUrl', 'originalUrl', 'linkUrl', 'productUrl', 'goodsUrl', 'url'],
    '店铺名称': ['sourceShopName', 'shopName', 'supplierName', 'shopTitle'],   // v3.7.42 公用采集箱
    '创建时间': ['gmtCreate', 'createTime', 'createdAt', 'gmtModified'],   // v3.7.42 公用采集箱
    '产地': ['originName', 'origin', 'produceArea', 'madeIn', 'country', 'originCountry'],
    '制造地点': ['madePlace', 'manufacturePlace', 'producePlace', 'factoryPlace'],
    '供货价': ['supplyPrice', 'costPrice', 'purchasePrice', 'goodsPrice', 'lowPrice', 'price'],
    '尺寸': ['size', 'dimensions', 'packageSize', 'productSize', 'specSize'],
    '毛重(g)': ['grossWeight', 'grossWeightG', 'packageWeight', 'weight'],
    '净重(g)': ['netWeight', 'netWeightG', 'productWeight'],
    '包装信息': ['packageInfo', 'packInfo', 'packingInfo', 'packageList'],
    '是否敏感属性': ['isSensitive', 'sensitive'],
    '敏感属性值': ['sensitiveValue', 'sensitiveAttr'],
    '储电容量': ['batteryCapacity', 'electricCapacity'],
    '刀具长度': ['knifeLength', 'bladeLength'],
    '刀具尖度': ['knifeSharp', 'bladeSharp'],
    '液体容量': ['liquidCapacity', 'liquidVolume'],
    '产品类型': ['productType', 'goodsType', 'itemType'],
    '是否定制品': ['isCustomized', 'customMade', 'customized'],
    '本地分组': ['localGroup', 'groupName', 'group']
  };
  var BATCH_ALIAS = {
    '类目属性': '类目属性', '主货号': '主货号', '产地': '产地',
    '外包装': '包装信息', '毛重': '毛重(g)', '净重': '净重(g)', '尺寸': '尺寸',
    '平台SKU': '平台SKU', '定制品': '是否定制品', '建议售价': '供货价'
  };
  function cellOf(v) {
    if (v == null) return '';
    if (typeof v === 'string') return v.trim();
    if (typeof v === 'number' || typeof v === 'boolean') return String(v);
    if (Array.isArray(v)) {
      if (!v.length) return '';
      var parts = v.map(function (x) {
        if (x == null) return '';
        if (typeof x !== 'object') return String(x);
        var nm = x.name != null ? x.name : (x.attrName != null ? x.attrName : (x.propName != null ? x.propName : x.key));
        // 属性对象带 values 数组（详情接口形态）：材质:人造木材/密度板
        if (Array.isArray(x.values) && x.values.length) {
          var vs = x.values.map(function (y) {
            if (y == null) return '';
            if (typeof y !== 'object') return String(y);
            return String(y.name != null ? y.name : (y.value != null ? y.value : (y.val != null ? y.val : '')));
          }).filter(Boolean).join('/');
          return (nm != null ? nm + ':' : '') + vs;
        }
        var vl = x.value != null ? x.value : (x.attrValue != null ? x.attrValue : (x.propValue != null ? x.propValue : x.val));
        if (nm != null && vl != null && vl !== '') return nm + ':' + vl;
        return vl != null ? vl : (nm != null ? nm : (x.text != null ? x.text : JSON.stringify(x)));
      });
      return parts.filter(function (x) { return x !== ''; }).join(';');
    }
    if (typeof v === 'object') return JSON.stringify(v);
    return String(v);
  }
  function rawFind(o, keys, depth) {
    if (depth == null) depth = 2;
    if (!o || typeof o !== 'object' || depth < 0) return undefined;
    for (var i = 0; i < keys.length; i++) {
      var v = o[keys[i]];
      if (v !== undefined && v !== null && v !== '' && !(Array.isArray(v) && !v.length)) return v;
    }
    var ks = Object.keys(o);
    for (var j = 0; j < ks.length; j++) {
      var vv = o[ks[j]];
      if (vv && typeof vv === 'object' && !Array.isArray(vv)) {
        var r = rawFind(vv, keys, depth - 1);
        if (r !== undefined) return r;
      }
    }
    return undefined;
  }
  function fillCols(raw) {
    var o = {};
    if (!raw || typeof raw !== 'object') return o;
    var isMi = !!(raw.detailId || raw.skuMap || raw.attributes || raw.imgUrls || raw.collectItemInfoList);
    var put = function (col, val) {
      if (o[col]) return;
      var s = cellOf(val);
      if (s) o[col] = s;
    };
    if (isMi) {
      put('产品分类', raw.breadcrumb);
      if (Array.isArray(raw.attributes) && raw.attributes.length) {
        var txt = raw.attributes.map(function (a) {
          var vs = (a.values || []).map(function (v) { return typeof v === 'string' ? v : (v.name || v.value); }).filter(function (x) { return x != null && x !== ''; });
          if (!vs.length) return '';                       // 空属性（如未选的品牌名）不留「XX:」残段
          return a.name ? a.name + ':' + vs.join('/') : vs.join('/');
        }).filter(Boolean).join(';');
        put('类目属性', txt);
      }
      put('主货号', raw.itemNum || raw.oriItemNum);
      var cc0 = String(raw.productOriginCountry || '').toUpperCase();
      if (cc0 && cc0 !== 'CN') put('产地', MI_COUNTRY[cc0] || cc0);
      var skus = raw.skuMap && typeof raw.skuMap === 'object' ? Object.keys(raw.skuMap).map(function (k) { return raw.skuMap[k]; }) : [];
      var s0 = skus[0] || {};
      put('供货价', raw.maxSkuPrice != null ? raw.maxSkuPrice : s0.price);
      if ([s0.length, s0.width, s0.height].some(function (v) { return v != null && v !== ''; })) {
        put('尺寸', [s0.length, s0.width, s0.height].map(function (v) { return v == null ? '' : v; }).join('*'));
      }
      var w = skus.map(function (s) { return Number(s.weight); }).filter(function (n) { return n > 0; });
      if (w.length) put('毛重(g)', Math.max.apply(null, w));
      var nw = skus.map(function (s) { return Number(s.netWeight); }).filter(function (n) { return n > 0; });
      if (nw.length) put('净重(g)', Math.max.apply(null, nw));
      var psku = skus.map(function (s) { return s.itemNum; }).filter(Boolean);
      if (psku.length) put('平台SKU', psku.length === 1 ? psku[0] : psku.join(';'));
      var sale = Array.isArray(raw.saleAttributes) ? raw.saleAttributes : [];
      for (var k = 0; k < 2; k++) {
        var sp = sale[k];
        if (!sp || !sp.name) continue;
        put('规格名称' + (k + 1), sp.name);
        put('规格属性值' + (k + 1), (sp.values || []).map(function (v) { return v.name; }).filter(Boolean).join('/'));
      }
      if (s0.isSensitive != null && s0.isSensitive !== '') put('是否敏感属性', String(s0.isSensitive) === '1' ? '是' : '否');
      if (raw.personalizationSwitch != null && raw.personalizationSwitch !== '') {
        put('是否定制品', String(raw.personalizationSwitch) === '1' ? '是' : '否');
      }
      put('SKU分类数量', s0.numberOfPieces != null ? s0.numberOfPieces : s0.numberOfPiecesNew);
    }
    // 别名兜底（两层深搜）
    Object.keys(RAW_ALIAS).forEach(function (col) {
      if (o[col]) return;
      var cell = cellOf(rawFind(raw, RAW_ALIAS[col], 2));
      if (cell) o[col] = cell;
    });
    // v3.7.42 公用采集箱列表行兜底：站外商品链接（source=temu/1688 → 按来源构造）
    if (!o['站外产品链接'] && raw.sourceItemId) {
      var sid2 = String(raw.sourceItemId);
      var src2 = String(raw.source || raw.sourceSite || '').toLowerCase();
      var host2 = String(raw.hostname || '').toLowerCase();
      if (/temu/.test(src2) || /temu/.test(host2)) o['站外产品链接'] = 'https://www.temu.com/goods.html?goods_id=' + sid2;
      else if (/1688/.test(src2) || /1688/.test(host2)) o['站外产品链接'] = 'https://detail.1688.com/offer/' + sid2 + '.html';
      else if (sid2.length >= 10) o['站外产品链接'] = 'https://www.' + (/1688/.test(src2) ? '1688' : 'temu') + '.com/' + sid2;
    }
    // 批量编辑抓取字段兜底（raw.batch = { 栏目名: { text } }）
    var batch = raw.batch;
    if (batch && typeof batch === 'object') {
      var titleCompact = String(raw.title || '').replace(/\s+/g, '');
      Object.keys(batch).forEach(function (sec) {
        var col = BATCH_ALIAS[sec];
        if (!col || o[col]) return;
        var val = batch[sec];
        var cell = cellOf(val && (val.text !== undefined ? val.text : val));
        if (cell && titleCompact) {
          var cc = cell.replace(/\s+/g, '');
          if (cc.indexOf(titleCompact) === 0 && cc.length > titleCompact.length) {
            cell = cc.slice(titleCompact.length).trim() || cell.trim();
          }
        }
        if (cell && cell.length <= 500) o[col] = cell;
      });
    }
    // SKU 规格 1/2
    var sk2 = rawFind(raw, ['skus', 'skuList', 'skuInfos', 'productSkus', 'skuItems'], 2);
    if (Array.isArray(sk2) && sk2.length) {
      var ss0 = sk2[0] || {};
      var specs = ss0.specs || ss0.properties || ss0.attributes || ss0.specList || ss0.specifications;
      if (Array.isArray(specs)) {
        specs.slice(0, 2).forEach(function (sp, idx) {
          if (!sp) return;
          var nm = sp.name != null ? sp.name : (sp.specName != null ? sp.specName : (sp.propName != null ? sp.propName : (sp.key != null ? sp.key : (sp.attrName != null ? sp.attrName : sp.specKey))));
          var vl = sp.value != null ? sp.value : (sp.specValue != null ? sp.specValue : (sp.propValue != null ? sp.propValue : (sp.val != null ? sp.val : sp.attrValue)));
          var nc = '规格名称' + (idx + 1), vc = '规格属性值' + (idx + 1);
          if (!o[nc] && nm != null && nm !== '') o[nc] = String(nm);
          if (!o[vc] && vl != null && vl !== '') o[vc] = String(vl);
        });
      }
    }
    // 英文标题（多语言标题表）
    if (!o['英文标题'] && raw.multiLanguageTitleMap && typeof raw.multiLanguageTitleMap === 'object') {
      var m = raw.multiLanguageTitleMap;
      var en = m.en || m.EN || m.english || m.English || (Object.keys(m).length ? m[Object.keys(m)[0]] : '');
      if (en && typeof en === 'string') o['英文标题'] = en.trim();
    }
    // 产地归一：空值或「中国/China/CN」统一成 中国大陆/江西省
    var cur = String(o['产地'] || '').trim();
    if (!cur || /^(中国|中国大陆|中华人民共和国|china|cn|chn)$/i.test(cur)) o['产地'] = DEFAULT_ORIGIN;
    return o;
  }

  // 公共写出：把商品数组写成 48 列 CSV 并下载，返回导出数量（0=没导）
  function exportRows(list, label) {
    var lines = [TPL_HDR.map(csvCell).join(',')], n = 0, skipped = 0;
    list.forEach(function (v) {
      if (!v.title || !v.imgs || !v.imgs.length) { skipped++; return; }
      var o = {};
      var mapped = fillCols(v.raw || {});
      TPL_HDR.forEach(function (h) {
        if (mapped[h] != null && mapped[h] !== '') o[h] = mapped[h];
      });
      // 旧逻辑保留：raw/batch 里正好有同名列（整段文本抓取值）且映射没填上的，补进去
      var raw2 = v.raw || {};
      var batch = v.batch || {};
      TPL_HDR.forEach(function (h) {
        if (o[h]) return;
        var x = raw2[h];
        if (x == null || x === '') x = batch[h];
        if (x != null && String(x).trim() !== '' && typeof x !== 'object') o[h] = String(x).trim();
      });
      o['产品ID'] = v.id;
      o['产品名称'] = v.title;
      o['产品轮播图链接'] = v.imgs.join('\n');
      lines.push(TPL_HDR.map(function (h) { return csvCell(o[h] || ''); }).join(','));
      n++;
    });
    if (!n) {
      log(label + '：没有可导出的商品（需要标题 + 至少 1 张图）' + (skipped ? '，跳过 ' + skipped + ' 个资料不全的' : ''));
      return 0;
    }
    var d = new Date();
    var pad = function (x) { return (x < 10 ? '0' : '') + x; };
    var name = '采集箱导出_' + label + '_' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '_' + pad(d.getHours()) + pad(d.getMinutes()) + '.csv';
    // 带 BOM：Excel 直接双击不乱码；洗图台上传时服务端会自动剥掉 BOM
    var blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 8000);
    log('✅ 已导出 ' + name + '：' + n + ' 个商品' + (skipped ? '（跳过 ' + skipped + ' 个资料不全的）' : '') + ' —— 洗图台打不开时，把这张表拖进「选择 Excel / CSV」手动上传即可');
    return n;
  }

  // 按选中导出：只导面板上勾选的（原导出表格行为）
  function exportTable() {
    var list = [];
    items.forEach(function (v) { if (v.sel !== false) list.push(v); });
    if (!list.length) {
      log('❌ 没有勾选任何商品，先在上面勾上要导出的，或改用「按数量导出」');
      return;
    }
    exportRows(list, '按选中');
  }

  /* ---------------- 按数量导出 v2.2.8 ----------------
     不看勾选，按采集顺序从上往下取「导出数量」个；每导一批，游标往下走，
     再点一次就导出紧接着的下一批（采集也是按列表顺序往下采的）。 */
  var exportPos = 0;   // 已导到的位置（可导商品序列的下标）
  function exportByCount() {
    var nIn = document.querySelector('.mscb-expn');
    var n = Math.max(1, Math.min(500, Number(nIn && nIn.value) || 20));
    var eligible = [];
    items.forEach(function (v) { if (v.title && v.imgs && v.imgs.length) eligible.push(v); });
    if (!eligible.length) { log('❌ 还没有可导出的商品，先点「重新抓取」采集'); return; }
    if (exportPos >= eligible.length) {
      log('✅ 前 ' + eligible.length + ' 个已全部导完。重新采集一批后游标自动归零，或点「🔄 归零」从第 1 个重导');
      return;
    }
    var batch = eligible.slice(exportPos, exportPos + n);
    var got = exportRows(batch, '第' + (exportPos + 1) + '-' + (exportPos + batch.length) + '个');
    if (got) {
      exportPos += batch.length;
      log('📑 按数量导出：本批第 ' + (exportPos - batch.length + 1) + '~' + exportPos + ' 个 / 共 ' + eligible.length + ' 个可导' + (exportPos < eligible.length ? '，再点一次导出下一批 ' + (exportPos + 1) + '~' + Math.min(exportPos + n, eligible.length) + ' 个' : '（已到末尾）'));
    }
  }
  function resetExportPos() {
    exportPos = 0;
    log('↺ 游标已归零：下次「按数量导出」从第 1 个开始');
  }

  /* ---------------- 一键：采集 → 自动入表 → 自动导入洗图台 ---------------- */
  async function oneClick() {
    if (busy) return;
    // 地址为空时不再卡死（v2.2.6 兜底）；现在默认不预置地址 → 直接提示去填
    if (!String(cfg.studio || '').trim()) {
      log('❌ 请先在面板「洗图台」里填服务器地址，再点一键采集');
      needSetup(); return;
    }
    if (!String(cfg.code || '').trim()) { log('❌ 请先填访问口令，再点一键采集'); needSetup(); return; }
    busy = true;
    var old = oneBtn ? oneBtn.textContent : '';
    if (oneBtn) { oneBtn.disabled = true; oneBtn.textContent = '🛰 正在采集列表…'; }
    try {
      await waitResume();   // v2.6.0：半自动也支持一键暂停（每个步骤边界生效）
      await pull(true);
      if (!items.size) { log('❌ 没抓到商品：等采集箱列表加载完再点一次'); return; }
      await waitResume();
      if (oneBtn) oneBtn.textContent = '🛰 正在取全部字段…';
      var got = await apiGrab();
      if (!got) { log('⚠️ 接口没取到，改用界面逐栏抓取（较慢）…'); await grabAll(); }
      await waitResume();
      if (oneBtn) oneBtn.textContent = '🛰 正在全量抓取属性…';
      await detailGrab();   // F12 式全量：编辑页数据源补齐产品属性等批量接口没有的字段
      await waitResume();
      if (oneBtn) oneBtn.textContent = '📤 正在导入洗图台…';
      var ok = await send();
      if (ok) {
        log('🎉 采集成功：已自动入表，并已导入洗图台');
        var ball = document.querySelector('.mscb-ball');
        if (ball) { ball.style.animation = 'mscb-pulse 1s ease-in-out 2'; setTimeout(function(){ ball.style.animation=''; }, 2200); }
        startWashMonitor();   // v2.6.0：半自动也显示总/每链接进度条 + 预计/实际时间
      } else {
        log('⚠️ 采集已完成并留在本地，但没能送进洗图台 —— 按上面红字改配置后，再点一次「📥 一键采集并导入」即可（不会重复采集）');
      }
    } catch (e) {
      log('❌ ' + (e && e.message ? e.message : e));
    } finally {
      busy = false;
      if (oneBtn) { oneBtn.disabled = false; oneBtn.textContent = old; }
    }
  }

  /* ---------------- v2.3.0 红色按钮：勾选 → SOP 洗图 → 新表格 → RPA 建链接（零手动） ---------------- */
  var progEl = null, linksEl = null;
  // v2.6.0：结果区（每链接进度/预览/重跑/建议）+ 洗图运行状态
  var resEl = null, timeEl = null, resBtnsEl = null;
  var wash = { on: false, done: false, rpa: false, t0: 0, startedAt: 0, finishedAt: 0,
    target: 10, plan: 0, rate: 0, state: {}, products: [], selPids: {}, links: [],
    gen: 0, chargeRate: 0.06, balance: null, today: 0, todaySpent: 0, lowWarned: false };
  var noteByPid = {};   // srcPid -> 客户手填的修改建议
  var ratingsByPid = {};  // srcPid -> 1(满意)/0(不满意)：攒质检数据
  var rerunning = false;
  var repairBusy = false;
  var slowStreak = 0;   // v2.9.0 连续 0 产能轮数（限流提示用）
  // v2.7.0 列表筛选状态：搜索词 + 类目
  var filtQ = '', filtCat = '';
  function filteredItems() {
    var arr = [];
    items.forEach(function (v) { arr.push(v); });
    if (filtCat && filtCat !== '__all') arr = arr.filter(function (v) { return catOf(v) === filtCat; });
    if (filtQ) {
      var q = filtQ.toLowerCase();
      arr = arr.filter(function (v) {
        return (v.title || '').toLowerCase().indexOf(q) >= 0 || String(v.id).indexOf(q) >= 0;
      });
    }
    return arr;
  }
  function updateCatOptions() {
    var sel = document.querySelector('.mscb-cat');
    if (!sel) return;
    var cats = {};
    items.forEach(function (v) { cats[catOf(v)] = 1; });
    var names = Object.keys(cats).sort();
    var cur = filtCat || '__all';
    sel.innerHTML = '';
    var oAll = document.createElement('option');
    oAll.value = '__all';
    oAll.textContent = '全部类目' + (names.length ? '（' + names.length + '）' : '');
    sel.appendChild(oAll);
    names.forEach(function (nm) {
      var o = document.createElement('option');
      o.value = nm; o.textContent = nm;
      sel.appendChild(o);
    });
    if (names.indexOf(cur) < 0 && cur !== '__all') cur = '__all';
    sel.value = cur;
  }
  function nap(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  // 一键暂停：流程走到每个步骤/轮询边界都会先在这里等人，点「继续」才往下走
  async function waitResume(note) {
    if (!paused) return;
    if (note) setProg(null, note);
    if (!waitResume._spoke) { waitResume._spoke = true; speak('任务已暂停，回来点继续哦。'); }   // v3.7.25 暂停语音提醒（每轮一次）
    while (paused) await nap(700);
    log('▶️ 已继续');
    waitResume._spoke = false;
  }
  var miniT0 = 0;   // v3.4.4 迷你条计时起点（miniShow(true) 时置位）
  function setProg(pct, text, terminal) {
    wash.lastProgAt = Date.now();   // v3.4.8 标志自愈依据：进度还在动 = 任务活着
    if (progEl) {
      var bar = progEl.querySelector('.mscb-prog-bar i');
      var lab = progEl.querySelector('.mscb-prog-text');
      if (bar && pct != null) bar.style.width = Math.max(0, Math.min(100, pct)) + '%';
      if (lab) lab.textContent = text;
      if (pct != null || terminal) progEl.classList.toggle('done', !!terminal || pct >= 100);   // v3.3.0 完成后停止流动动画
    }
    // v3.4.4 迷你条同步：状态文字 + 进度条 + 已用/预计剩余时间
    var mini = document.querySelector('.mscb-mini');
    if (mini && mini.classList.contains('show')) {
      var mt = mini.querySelector('.mscb-mini-title');
      if (mt && text) mt.textContent = text;
      if (pct != null) {
        var mb = mini.querySelector('.mscb-mini-prog i');
        if (mb) mb.style.width = Math.max(0, Math.min(100, pct)) + '%';
        var mti = mini.querySelector('.mscb-mini-time');
        if (mti && miniT0) {
          var usedMs = Date.now() - miniT0;
          var etaMs = (pct > 0 && pct < 100) ? usedMs / pct * (100 - pct) : 0;
          mti.textContent = '已用 ' + fmtDur(usedMs) + (pct >= 100 ? ' · ✅ 完成' : (etaMs ? ' · 预计还需 ' + fmtDur(etaMs) : ''));
        }
      }
    }
    // v3.3.0 猫球实时进度：面板收起来也能从小猫身上看到跑了多少（橙色 badge）
    if (pct != null && pct > 0) {
      var bd = document.querySelector('.mscb-badge');
      if (bd) {
        bd.style.display = 'block';
        bd.style.background = pct >= 100 ? '#0f8a3d' : '#f5511e';
        bd.textContent = pct >= 100 ? '完' : Math.round(Math.min(100, pct)) + '%';
      }
    }
    // v3.4.6 注意：这里不再 log(text)——状态文字每 3 秒轮询一次，打进日志会刷屏；
    // 日志只记录事件（逐张出图/失败/阶段/完成），由 washSync 等处显式打
  }
  // v3.7.27c 本地直连正式接入「结果区」：跑本地单时每个商品在原有结果区占一行
  //（缩略图 + 每链接进度条 + 🔍预览 / 🔁重跑 / 💬修改建议），与洗图台模式同一板块，不再是另一套面板。
  var localShots = [], localRefs = {}, localRunMode = false, localPublishing = false;   // v3.7.87 localPublishing：发布当前进行中
  /* ---------- v3.7.33 断点续跑：本地任务快照（刷新页面/关浏览器/中断后都能接着跑，不重复扣费） ----------
     存 localStorage：商品清单（含采集原始参数）+ 每品已出图链 + 已组好的 48 列行 + 未完成状态。
     不存 base64 图（太大），续跑时缺失的图按原提示词重新生成；已出过的图直接用原图链，不再扣费。 */
  var JOB_KEY = 'xitumo_localjob_v1', JOB_META_KEY = 'xitumo_localjobs_meta_v1';
  var jobMeta = null, jobTimer = null;
  function jobRead() { try { return JSON.parse(localStorage.getItem(JOB_KEY) || 'null'); } catch (e) { return null; } }
  function jobReadMeta() { try { var a = JSON.parse(localStorage.getItem(JOB_META_KEY) || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
  function jobSnap() {
    var m = jobMeta || {};
    return {
      v: 1, at: m.at || Date.now(), savedAt: Date.now(), startedAt: m.startedAt || wash.startedAt || Date.now(),
      finished: !!wash.done, imgN: m.imgN, fiss: m.fiss,
      items: (m.items || []).map(function (v) {
        return { id: v.id, title: v.title, imgs: (v.imgs || []).slice(0, 12), raw: v.raw || null, tplKey: v.tplKey || '' };
      }),
      products: (wash.products || []).map(function (p) {
        return {
          srcPid: p.srcPid, title: p.title, total: p.total, done: (p.localUrls || []).filter(Boolean).length, status: p.status,
          localStage: p.localStage || '', localUrls: (p.localUrls || []).slice(),
          shots: (p.localShots || []).map(function (s) {
            return { idx: s.idx, item: s.item, varr: s.varr, img: s.img, url: s.url || '', prompt: s.prompt || '', title: s.title || '', failed: !!s.failed };
          }),
          row: p.rowCache || null
        };
      })
    };
  }
  function jobSave(now) {
    if (!jobMeta) return;
    var write = function () {
      jobTimer = null;
      try {
        var s = jobSnap(), txt = JSON.stringify(s);
        if (txt.length > 3.2e6) {   // 超限：丢掉采集原始数据再存一次（恢复时自动重新采集）
          s.items.forEach(function (it) { it.raw = null; }); s.rawDropped = true; txt = JSON.stringify(s);
        }
        localStorage.setItem(JOB_KEY, txt);
      } catch (e) {
        // 空间不足：丢掉提示词再试一次，仍失败就静默（绝不能打断出图）
        try {
          s.products.forEach(function (p) { (p.shots || []).forEach(function (x) { delete x.prompt; }); });
          localStorage.setItem(JOB_KEY, JSON.stringify(s));
        } catch (e2) {}
      }
    };
    if (now) { try { clearTimeout(jobTimer); } catch (e) {} return write(); }
    if (jobTimer) return;
    jobTimer = setTimeout(write, 1500);
  }
  function jobPushMeta(s) {
    try {
      var a = jobReadMeta().filter(function (x) { return x && Math.abs((x.at || 0) - (s.at || 0)) > 60000; });
      a.unshift({
        at: s.at, nProd: (s.products || []).length,
        nImg: (s.products || []).reduce(function (n, p) { return n + ((p.localUrls || []).filter(Boolean).length); }, 0),
        finished: !!s.finished,
        titles: (s.items || []).slice(0, 3).map(function (x) { return String(x.title || '').slice(0, 14); })
      });
      localStorage.setItem(JOB_META_KEY, JSON.stringify(a.slice(0, 10)));
    } catch (e) {}
  }
  // v3.7.37 链接模式（洗图台）跑完也记一条历史：没有本机快照（不能续跑），但可以预览成品图
  function histMetaPush(pids, titles, nImg, finished) {
    try {
      var a = jobReadMeta().filter(function (x) { return x && Math.abs((x.at || 0) - Date.now()) > 60000; });
      a.unshift({
        at: Date.now(), nProd: (pids || []).length, nImg: nImg || 0, finished: !!finished,
        titles: (titles || []).slice(0, 3).map(function (x) { return String(x || '').slice(0, 14); }),
        pids: (pids || []).slice(0, 40)
      });
      localStorage.setItem(JOB_META_KEY, JSON.stringify(a.slice(0, 10)));
      try { renderJobBar(); renderHistLocal(); } catch (e2) {}
    } catch (e) {}
  }
  function jobClear() {
    try { localStorage.removeItem(JOB_KEY); } catch (e) {}
    jobMeta = null;
    try {
      renderJobBar();
      var hw = document.querySelector('.mscb-histwrap');
      if (hw && !renderHistLocal()) {   // v3.7.37 框固定显示：清空后回到「暂无」占位，不再隐藏
        hw.classList.remove('open');
        var hl = hw.querySelector('.mscb-histlist'); if (hl) hl.innerHTML = '<div class="mscb-histmeta" style="padding:8px 12px;color:#98a2b3">暂无历史任务 · 本机跑完一单后会自动记录在这里（可预览/续跑）</div>';
        var hc = hw.querySelector('.mscb-histcount'); if (hc) hc.textContent = '暂无';
      }
    } catch (e2) {}
  }
  // 把快照还原成结果区（图片链已填好，可预览/导出/补图，不重新出图）
  function localStateRestore(job) {
    localRunMode = true;
    localShots = []; localRefs = {};
    var prods = (job && job.products) || [];
    wash.on = true; wash.done = !!job.finished; wash.rpa = false;
    wash.t0 = job.startedAt || Date.now(); wash.startedAt = wash.t0; wash.finishedAt = 0;
    wash.plan = prods.reduce(function (n, p) { return n + (Number(p.total) || 0); }, 0);
    wash.products = prods.map(function (p, i) {
      var urls = (p.localUrls || []).slice();
      var shots = (p.shots || []).map(function (s) {
        return { idx: s.idx, item: s.item, varr: s.varr, img: s.img, url: s.url || '', prompt: s.prompt || '', title: s.title || '', failed: !!s.failed, ref: '' };
      });
      shots.forEach(function (s) { if (s.url) localShots.push(s); });
      return {
        srcPid: p.srcPid, pid: 'local-' + p.srcPid + '-' + i, title: p.title, total: p.total || 10,
        done: urls.filter(Boolean).length, fail: 0, status: p.status || 'done', local: true,
        localStage: p.status === 'done' || urls.filter(Boolean).length >= (p.total || 1) ? (p.localStage || '✅ 已完成') : '⏸ 已恢复（可续跑）',
        localUrls: urls, localShots: shots, rowCache: p.row || null
      };
    });
    wash.state = {};
    wash.products.forEach(function (p) { wash.state[p.pid] = p; });
    washRender();
  }
  function localStateInit(list) {
    localRunMode = true;
    localShots = []; localRefs = {};
    var per = Math.max(1, Math.min(10, Number(cfg.imgN) || 10)) * Math.max(1, Math.min(10, Number(cfg.fiss) || 1));
    wash.on = true; wash.done = false; wash.rpa = false;
    wash.t0 = Date.now(); wash.startedAt = Date.now(); wash.finishedAt = 0; wash.plan = list.length * per;
    wash.products = list.map(function (v, i) {
      return { srcPid: v.id, pid: 'local-' + v.id + '-' + i, title: v.title, total: per,
        done: 0, fail: 0, status: 'running', local: true, localStage: '⏳ 排队中', localUrls: [], localShots: [] };
    });
    wash.state = {};
    wash.products.forEach(function (p) { wash.state[p.pid] = p; });
    washRender();
    try { washTimeLine(); } catch (eT) {}
  }
  // v3.7.32 生图消息断通道自动重试一次（MV3 SW 偶发被杀 → "message channel closed"）
  async function xtImgGen(dataUrl, prompt) {
    try { return await chrome.runtime.sendMessage({ cmd: 'imageBlob', dataUrl: dataUrl, prompt: prompt }); }
    catch (e) {
      if (!/message channel closed|Extension context invalidated/i.test(String(e && e.message || e))) throw e;
      await new Promise(function (r) { setTimeout(r, 2500); });
      return await chrome.runtime.sendMessage({ cmd: 'imageBlob', dataUrl: dataUrl, prompt: prompt });
    }
  }
  // v3.7.73 卡住跳过：面板「⏭ 跳过等待」一次性放行当前卡住的批次等待，
  // 未返回的图按「用户跳过」记入缺图（不进补图轮，可用补图按钮/补失败图稍后补），流程继续往下走
  var xtSkipFlag = false;
  // v3.7.78 全局出图闸门：所有链接的图统一进本地队列（排队零成本零等待感），同一时刻「在飞」张数封顶，
  // 完成一张立刻放行下一张（滚动窗口，没有“一波等齐才发下一波”的空转）。
  // AIMD 自适应：连续 15 张成功 → 并发 +4（上限 96）；一遇限流/超时/5xx → 并发减半（下限 8），不卡死上游。
  var xtGate = { cap: 48, run: 0, q: [], ok: 0, peak: 0 };
  var xtGateEpoch = 0;   // v3.7.78 每单开跑 +1：上一单异常中止后残留在队列里的任务作废，不再向上游下单白扣费
  function xtGateAcq() {
    return new Promise(function (res) {
      if (xtGate.run < xtGate.cap) { xtGate.run++; xtGate.peak = Math.max(xtGate.peak, xtGate.run); res(); }
      else xtGate.q.push(res);
    });
  }
  function xtGateRel() {
    xtGate.run--;
    var nxt = xtGate.q.shift();
    if (nxt) { xtGate.run++; xtGate.peak = Math.max(xtGate.peak, xtGate.run); nxt(); }
  }
  function xtGateOk() { if (++xtGate.ok >= 15 && xtGate.cap < 96) { xtGate.cap += 4; xtGate.ok = 0; } }
  function xtGateBad(e) {
    if (/429|rate|限流|too many|超时|timeout|HTTP 5|failed to fetch|networkerror/i.test(String(e || ''))) {
      xtGate.cap = Math.max(8, Math.floor(xtGate.cap / 2)); xtGate.ok = 0;
      log('🌡 上游有点堵，出图并发自动降到 ' + xtGate.cap + ' 张同时跑（会随成功率自动回升）');
    }
  }
  // 闸门版生图：先拿名额再发请求，结束必还名额；成功/失败各回喂 AIMD。
  // ctx = 批次取消标记（用户点「⏭ 跳过等待」时置 cancelled，队列里没开跑的图直接作废不再下单）；ep = 单次任务归属
  function xtGenGated(dataUrl, prompt, ctx) {
    var ep = xtGateEpoch;
    return xtGateAcq().then(function () {
      if (ep !== xtGateEpoch || (ctx && ctx.cancelled)) { xtGateRel(); return { skipped: true }; }
      var tG = Date.now();
      return xtImgGen(dataUrl, prompt).then(
        function (g) { xtGateRel(); if (g && g.ok) xtGateOk(); else xtGateBad(g && g.error); return g; },
        function (e) { xtGateRel(); xtGateBad(e && e.message || e); throw e; }
      );
    });
  }
  function xtWaitRace(p, ctx) {
    if (!xtSkipFlag) return p.then(function () { return true; }).catch(function () { return true; });   // 批内已逐个 catch，这里只兜底
    xtSkipFlag = false;
    if (ctx) ctx.cancelled = true;   // v3.7.78 队列里没开跑的图直接作废，不再向上游下单
    log('⏭ 已跳过当前批次的剩余等待：没返回的图按跳过处理，流程继续（稍后可用「补图」补齐）');
    p.catch(function () {});   // 后台继续跑完，拒绝不悬空
    return Promise.resolve(false);
  }
  function xtIsSkipErr(e) { return String(e && e.err || e || '').indexOf('用户跳过') >= 0; }
  function localMark(i, stage, status) {
    var p = wash.products && wash.products[i];
    if (!p) return;
    if (stage) p.localStage = stage;
    if (status) p.status = status;
    washRender();
  }
  function localShotAdd(i, shot) {
    var p = wash.products && wash.products[i];
    if (!p) return;
    p.localShots.push(shot);
    localShots.push(shot);
    if (shot.url) {
      // v3.7.34 串图检测：同品出现完全相同的图链，说明上游把多张返回成了同一张，提前告警（导入前可核对）
      var dupN = (p.localUrls || []).filter(function (x) { return x === shot.url; }).length;
      if (dupN > 0) log('⚠️ 「' + String(p.title || '').slice(0, 14) + '」第 ' + (shot.idx + 1) + ' 张与前一张图链完全相同（上游可能只返回了同一张图），导入前建议点 🔍 核对');
      p.localUrls[shot.idx] = shot.url;
      p.done = p.localUrls.filter(Boolean).length;
    }
    washRender();
    try { if (localRunMode) washTimeLine(); } catch (eTL2) {}   // v3.7.39 每出一张图刷新本单时间行
    jobSave();   // v3.7.33 每出一张图就落一次盘（节流 1.5s），刷新/断网后能接着跑
  }
  async function localRegenShot(shot) {
    // v3.7.34 恢复的任务快照里没有内存原图（base64 太大没存）：按商品原图重新取一次参考图
    if (!shot.ref) {
      var owner = null;
      (wash.products || []).some(function (x) {
        if ((x.localShots || []).indexOf(shot) >= 0) { owner = x; return true; }
        return false;
      });
      var src0 = '';
      try {
        var it2 = owner && items.get(String(owner.srcPid));
        src0 = (it2 && it2.imgs && it2.imgs[0]) || '';
      } catch (e0) {}
      if (src0) {
        var fr0 = await chrome.runtime.sendMessage({ cmd: 'fetchImg', url: src0 });
        if (fr0 && fr0.ok) shot.ref = fr0.dataUrl;
      }
      if (!shot.ref) throw new Error('参考图已丢失：这条是恢复出来的任务，先点「▶ 继续上次任务」再补图');
    }
    var gr = await xtImgGen(shot.ref, shot.prompt);
    if (!gr || !gr.ok) throw new Error('AI 生图失败：' + ((gr && gr.error) || '未知'));
    shot.dataUrl = gr.dataUrl;
    if (xtSrcDirect() && gr.srcUrl && /^https:\/\//.test(gr.srcUrl)) { shot.url = gr.srcUrl; return gr.srcUrl; }   // v3.7.28 外链直写
    var _op = xtOutCap();
    var blob = await xtRecompress(await (await fetch(shot.dataUrl)).blob(), _op.cap, _op.maxDim);   // v3.7.52 补图上传前压缩
    blob = await blob;
    var form = new FormData();
    form.append('uploadImgFile', new File([blob], 'wash-regen-' + shot.item + '-' + (shot.idx + 1) + '-' + Date.now() + '.jpg', { type: blob.type || 'image/jpeg' }));
    form.append('imageScene', 'previewImage'); form.append('uploadType', 'file'); form.append('scene', '');
    var up = await fetch('/api/picture/picture/uploadPictureFile', { method: 'POST', credentials: 'same-origin', redirect: 'error', body: form, signal: AbortSignal.timeout(60000) });
    if (!up.ok) throw new Error('上传妙手失败（HTTP ' + up.status + '）');
    var ui2 = await up.json();
    if (ui2.result !== 'success' || !ui2.picturePath) {
      if (ui2.code === 30013) throw new Error('图片空间容量不足（30013），先清理图片空间再重生成');
      throw new Error('妙手未返回可用图链：' + JSON.stringify(ui2).slice(0, 120));
    }
    var uu = new URL(ui2.picturePath);
    if (uu.protocol !== 'https:' || uu.username || uu.password || uu.port ||
      !['earth-rt.chengji-inc.com', 'erp.91miaoshou.com'].includes(uu.hostname))
      throw new Error('返回图链不是已验证的妙手域名，弃用');
    shot.url = uu.href;
    return uu.href;
  }
  // 本地单：单张重生成（对应预览里的 🔁），其他张不动；返回 true 表示已按本地逻辑处理
  async function localRegenIdx(pid, idx) {
    var p = wash.state[String(pid)];
    if (!p || !p.local) return false;
    var shot = (p.localShots || []).filter(function (s) { return s.idx === idx; })[0];
    if (!shot) { log('ℹ️ 这张图还没有生成记录（还没出到这张），等它出来再点重生成'); return true; }
    if (shot._busy) { log('⏳ 这张正在重生成，稍等'); return true; }
    shot._busy = true;   // 跑单中途也允许单张重生成，不打断主流程
    try {
      setProg(null, '🔁 第 ' + (idx + 1) + ' 张（' + pvImgType(idx) + '）重生成中…');
      var u = await localRegenShot(shot);
      p.localUrls[idx] = u; washRender();
      log('🔁 第 ' + (idx + 1) + ' 张已重生成并上传图片空间（该位置图链已替换；已导入的链接需重新导入或到妙手替换）');
    } catch (e) {
      log('⚠️ 重生成失败：' + String(e && e.message || e).slice(0, 160));
    } finally { shot._busy = false; }
    return true;
  }
  // v3.7.32 本地单补图：只重出缺失/失败的图，已有图不动（结果区 🩹 与「补失败图」大按钮共用）
  function localMissingPairs(onlyPid) {
    var out = [];
    (wash.products || []).forEach(function (p) {
      if (!p.local) return;
      if (onlyPid != null && String(p.srcPid) !== String(onlyPid)) return;
      (p.localShots || []).forEach(function (shot) {
        if (!(p.localUrls || [])[shot.idx]) out.push({ p: p, shot: shot });
      });
    });
    return out;
  }
  async function localRepairShots(pairs) {
    var miss = 0;
    for (var w = 0; w < pairs.length; w += 12) {
      await Promise.all(pairs.slice(w, w + 12).map(async function (it) {
        try {
          var u = await localRegenShot(it.shot);
          it.p.localUrls[it.shot.idx] = u;
          it.p.done = (it.p.localUrls || []).filter(Boolean).length;
          washRender();
        } catch (e) { miss++; log('⚠️ 第 ' + (it.shot.idx + 1) + ' 张补图失败：' + String(e && e.message || e).slice(0, 100)); }
      }));
    }
    return miss;
  }
  // v3.7.59 补图完成后重建导入行：给「当时整链接失败、没进导入表」的链接用（rowCache 缺失 = 没发布过）
  // v3.7.69 SKU 源图提取：源品 skuMap 里每个规格通常自带各自的图（Temu/1688 多颜色链接有好几张）。
  // 之前颜色图一律用主图第一张顶替 → 客户看到「SKU 图只抓到一张」。现在按规格值对号入座。
  // 返回与 skuVals 对齐的图链数组（找不到的规格为空串），一个都没有时返回 null。
  function xtSkuImgsOf(raw, skuVals) {
    var skus = raw && raw.skuMap && typeof raw.skuMap === 'object' ? Object.keys(raw.skuMap).map(function (k) { return raw.skuMap[k]; }) : [];
    if (!skus.length) return null;
    var out = (skuVals || []).map(function (sv) {
      var s = skus.filter(function (sk) { var j = ''; try { j = JSON.stringify(sk); } catch (eS) {} return j && j.indexOf(sv) >= 0; })[0] || null;
      if (!s) return '';
      var found = '';
      (function walk(v, d) {
        if (found || !v || d > 4) return;
        if (typeof v === 'string') { if (/^https?:\/\/\S+/i.test(v) && /\.(jpg|jpeg|png|webp|gif)(\?|$)/i.test(v)) found = v; return; }
        if (Array.isArray(v)) { for (var i2 = 0; i2 < v.length && !found; i2++) walk(v[i2], d + 1); return; }
        if (typeof v === 'object') {
          Object.keys(v).forEach(function (k2) { if (!found && /img|pic|image|photo|thumb/i.test(k2)) walk(v[k2], d + 1); });
          Object.keys(v).forEach(function (k3) { if (!found) walk(v[k3], d + 1); });
        }
      })(s, 0);
      return found;
    });
    return out.some(Boolean) ? out : null;
  }
  function localRowForSrcPid(srcPid) {
    var p = (wash.products || []).filter(function (x) { return x.local && String(x.srcPid) === String(srcPid); })[0];
    if (!p) return null;
    var fixed = (p.localUrls || []).filter(Boolean);
    if (!fixed.length) return null;
    var it = items.get(String(srcPid)) || items.get(Number(srcPid)) || items.get(srcPid) || {};
    var mapped = fillCols(it.raw || {});
    var row = {};
    TPL_HDR.forEach(function (h) { if (mapped[h] != null && mapped[h] !== '') row[h] = mapped[h]; });
    row['产品ID'] = newPid12();
    row['产品名称'] = String(it.title || p.title || srcPid).slice(0, 60);
    var carUrls = fixed.slice();
    var srcImgs = (Array.isArray(it.imgs) ? it.imgs : []).concat(Array.isArray(it.raw && it.raw.imgUrls) ? it.raw.imgUrls.map(xtAbsUrl) : []);
    srcImgs.forEach(function (su) { if (carUrls.length < 5 && su && carUrls.indexOf(su) < 0) carUrls.push(su); });
    if (carUrls.length < 5) return { row: null, need: 5 - carUrls.length };   // 妙手校验轮播最少 5 张
    row['产品轮播图链接'] = carUrls.join('\n');
    row['产品素材图链接'] = fixed[0];
    row['产品预览图链接'] = fixed[0];
    row['商品详情图'] = fixed.join('\n');
    var skuVals = String(mapped['规格属性值1'] || '').split('/').filter(function (x) { return String(x).trim(); });
    var nSku = Math.max(1, skuVals.length);
    // v3.7.91 改：补图重建同样要求 SKU 图与洗后主图同步，一律用洗后主图 fixed[0] 顶替，不再用源品旧图
    var colCells = [];
    for (var si2 = 0; si2 < nSku; si2++) colCells.push(fixed[0]);
    row['产品颜色图链接'] = colCells.join('\n');
    ['SKUID', '店铺ID', '店铺名称', '创建时间', 'SKCID'].forEach(function (h) { delete row[h]; });
    return { row: row, title: row['产品名称'] };
  }
  /* ---------------- v3.7.35 属性/外包装接口回填 ----------------
     妙手采集箱 CSV 导入的「类目属性」「包装信息」列会被解析器直接忽略（实测对照导入已证实），
     所以导入成功后走编辑页保存接口 saveSiteCollectItemInfo 逐条回填：
     · 类目属性：原始采集品的属性 → 目标类目规则（getCategoryAttributeRules）名称/取值模糊匹配 → 只写能命中的
     · 外包装：形状/类型/图片 原样带过去
     保存契约：POST siteCollectItemInfo=<整包JSON>&site=PDDKJ（与编辑页「保存修改」同一请求） */
  var xtRulesCache = {};
  async function xtRulesOf(cid) {
    if (xtRulesCache[cid]) return xtRulesCache[cid];
    var CB = '/api/platform/pddkj/move/collect_box/';
    var r = null;
    try {
      r = await fetch(CB + 'getCategoryAttributeRules?cid=' + cid, { method: 'GET', credentials: 'include' }).then(function (x) { return x.text(); }).then(function (t) { try { return JSON.parse(t); } catch (e) { return null; } });
      if (!r || !r.productAttributeRules) {
        var body = new URLSearchParams(); body.append('cid', cid);
        r = await fetch(CB + 'getCategoryAttributeRules', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: body.toString() }).then(function (x) { return x.text(); }).then(function (t) { try { return JSON.parse(t); } catch (e2) { return null; } });
      }
    } catch (e) { r = null; }
    var rules = (r && r.productAttributeRules) || [];
    xtRulesCache[cid] = rules;
    return rules;
  }
  function xtMatchAttrs(srcAttrs, rules, title) {
    var attrs = [], missed = [];
    (srcAttrs || []).forEach(function (a) {
      var an = String(a && a.name || '').trim();
      if (!an) return;
      var rule = rules.filter(function (f) { return f.name === an; })[0] ||
                 rules.filter(function (f) { return (f.name || '').indexOf(an) >= 0 || an.indexOf(f.name || '') >= 0; })[0];
      if (!rule) { missed.push(an); return; }
      var opts = rule.values || [];
      var vals = [];
      ((a && a.values) || []).forEach(function (v) {
        var vn = typeof v === 'string' ? v : (v && (v.name || v.value));
        if (vn == null || vn === '') return;
        var hit = opts.filter(function (o) { return o.name === vn; })[0] ||
                  opts.filter(function (o) { return (o.name || '').indexOf(vn) >= 0 || vn.indexOf(o.name || '') >= 0; })[0];
        if (hit) vals.push({ vid: hit.vid, name: hit.name });
      });
      if (vals.length) attrs.push({ pid: rule.pid != null ? rule.pid : rule.templatePid, name: rule.name, values: vals });   // v3.7.40 pid 必须用规则自身 pid（templatePid 会被校验判为「未设置」，材料必填报错的真凶）
    });
    // v3.7.40 必填缺口兜底：类目必填属性没从原始数据命中时，用标题/属性文本关键词选值；
    // 电气类（电池/电压/插头）原始数据完全没有时按「无电池」组合兜底（ego 探针 241/247 实测通过保存校验）
    try {
      var text = String(title || '') + ' ' + (srcAttrs || []).map(function (a) {
        return String(a && a.name || '') + ' ' + ((a && a.values) || []).map(function (v) { return typeof v === 'string' ? v : ((v && (v.name || v.value)) || ''); }).join(' ');
      }).join(' ');
      var haveNames = {}; attrs.forEach(function (x) { haveNames[x.name] = 1; });
      var hasElec = /电压|电池|供电|插头|充电|太阳能/.test((srcAttrs || []).map(function (a) { return String(a && a.name || ''); }).join(' '));
      var defMap = { '是否带电池': '否', '包含电池': '无电池', '供电方式': '干电池供电', '电池类型': '其他（不可充电电池）' };
      rules.filter(function (r) { return r.required && !haveNames[r.name]; }).forEach(function (rule) {
        var opts = rule.values || rule.options || [];
        if (!opts.length) {
          // v3.7.48 无选项的必填属性（自由文本，如「产品推荐用途」0752 实测漏报）：直接给中性文本值，不再漏
          attrs.push({ pid: rule.pid != null ? rule.pid : rule.templatePid, name: rule.name, values: [{ name: '多用途' }] });
          return;
        }
        var pick = null;
        for (var oi = 0; oi < opts.length && !pick; oi++) {
          var on = String(opts[oi].name || '');
          if (on.length >= 2 && text.indexOf(on) >= 0) pick = opts[oi];
        }
        if (!pick && rule.name === '附着方法') pick = opts.filter(function (o) { return /挂/.test(text); })[0] || opts.filter(function (o) { return o.name === '挂'; })[0] || null;
        if (!pick && !hasElec) {
          var dn = defMap[rule.name];
          if (dn) pick = opts.filter(function (o) { return o.name === dn; })[0] || null;
        }
        if (!pick && rule.name === '节假日') pick = opts.filter(function (o) { return o.name === '通用' || o.name === '其他'; })[0] || null;
        // v3.7.46 中性兜底：标题关键词/电气组合都没命中时，用中性选项（多用途/通用/其他/家庭），必填属性不再落空（2026-11-22 「产品推荐用途」必填报错实测）
        if (!pick) pick = opts.filter(function (o) { return /多用途|通用|其他|家庭/.test(String(o.name || '')); })[0] || null;
        if (pick) attrs.push({ pid: rule.pid != null ? rule.pid : rule.templatePid, name: rule.name, values: [{ vid: pick.vid != null ? pick.vid : pick.templateOptionId, name: pick.name }] });
        else missed.push(rule.name);
      });
    } catch (eGap) {}
    return { attrs: attrs, missed: missed };
  }
  async function xtFindNewItems(startTs, wantTitles) {
    var map = {};
    var want = {}; wantTitles.forEach(function (t) { if (t) want[t] = true; });
    for (var pg = 1; pg <= 4; pg++) {
      var body = new URLSearchParams();
      body.append('claimPublishShopStatus', 'published'); body.append('titleType', 'multi'); body.append('remarkType', 'multi');
      body.append('status', 'notPublished'); body.append('pageNo', String(pg)); body.append('pageSize', '50');
      var j = await fetch('/api/platform/pddkj/move/collect_box/searchCollectBoxDetail', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: body.toString() }).then(function (x) { return x.text(); }).then(function (t) { try { return JSON.parse(t); } catch (e) { return null; } });
      var arr = (j && j.detailList) || [];
      if (!arr.length) break;
      arr.forEach(function (one) {
        var t = String(one.title || '').trim();
        if (want[t] && !map[t] && String(one.gmtCreate || '') >= startTs) map[t] = String(one.collectBoxDetailId || one.detailId || '');
      });
      var gotN = Object.keys(map).length;
      if (gotN >= wantTitles.length) break;
      await new Promise(function (r2) { setTimeout(r2, 250); });
    }
    return map;
  }
  async function xtBackfillOne(detailId, srcAttrs, pack, descUrls, titles) {
    var CB = '/api/platform/pddkj/move/collect_box/';
    var body0 = new URLSearchParams(); body0.append('detailId', detailId);
    var j0 = await fetch(CB + 'getCollectItemInfo', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: body0.toString() }).then(function (x) { return x.text(); }).then(function (t) { try { return JSON.parse(t); } catch (e) { return null; } });
    var item = j0 && (j0.siteCollectItemInfo || j0.shopCollectItemInfo || j0.collectItemInfo);
    if (!item) return { ok: false, reason: '读不到商品数据' };
    // v3.7.59 英文标题回填：CSV 导入的「英文标题」列被妙手解析器忽略（多单实测），
    // 与属性回填同路：编辑页接口把 multiLanguageTitleMap.en 直接写进商品
    var tEn = String((titles && titles.en) || '').trim();
    if (tEn) {
      var ml0 = (item.multiLanguageTitleMap && typeof item.multiLanguageTitleMap === 'object') ? item.multiLanguageTitleMap : {};
      item.multiLanguageTitleMap = Object.assign({}, ml0, { en: tEn });
    }
    var rules = await xtRulesOf(item.cid);
    var m = xtMatchAttrs(srcAttrs, rules, item.productName || item.title || '');
    item.attributes = m.attrs;
    // v3.7.41 电气归一化（ego 探针 247/259/262 实测组合）：装饰品源数据里的插头/电压信息是噪声，
    // 统一「干电池供电+无电池」组合，删除冲突的电气子属性；属性数组里父属性（供电方式）必须排最前，
    // 否则保存必报「属性【电池类型】选择…父属性【供电方式】必须选择【干电池供电】」（262 实测排序即过）
    var xtByName = {};
    rules.forEach(function (x) { xtByName[x.name] = x; });
    var xtRemove = ['插头规格', '工作电压', '可充电电池', '太阳能电池', '电池容量（mAh）', '电池数量', '电源方式', '电池类型', '是否带电池', '包含电池', '供电方式', '不可充电电池'];
    item.attributes = item.attributes.filter(function (a) { return xtRemove.indexOf(a.name) < 0; });
    var xtForce = { '供电方式': '干电池供电', '电池类型': '其他（不可充电电池）', '是否带电池': '否', '包含电池': '无电池', '电池属性': '不可充电电池', '不可充电电池': '其他电池' };
    var xtParents = [];
    Object.keys(xtForce).forEach(function (nm) {
      var rule = xtByName[nm]; if (!rule) return;
      // v3.7.47 容错取值：精确匹配 → 「其他」模糊匹配（不可充电电池）→ 首个选项
      var opts = rule.values || [];
      var v = opts.filter(function (o) { return o.name === xtForce[nm]; })[0] ||
             (nm === '不可充电电池' ? opts.filter(function (o) { return /其他/.test(String(o.name || '')); })[0] : null) || opts[0];
      if (!v) return;
      var el = { pid: rule.pid != null ? rule.pid : rule.templatePid, name: nm, values: [{ vid: v.vid != null ? v.vid : v.templateOptionId, name: v.name }] };
      if (nm === '供电方式' || nm === '电源方式' || nm === '电池属性') xtParents.push(el); else item.attributes.push(el);
    });
    item.attributes = xtParents.concat(item.attributes);
    var xtSeen = {};
    item.attributes = item.attributes.filter(function (a) { var k = a.name; if (xtSeen[k]) return false; xtSeen[k] = 1; return true; });
    // v3.7.40 外包装：无效 → 数字枚举 1 + 用首图当外包装图（探针 244/246/247 实测：空串/删除都报「外包装类型有误」，该字段类目必填且必须带图）
    var opOK = function (v) { return v != null && v !== '' && !isNaN(Number(v)); };
    if (!opOK(item.outerPackageType) || !(item.outerPackageImgUrls || []).length) {
      item.outerPackageType = 1; item.outerPackageShape = 1;
      item.outerPackageImgUrls = [(item.imgUrls || [])[0] || ''].filter(Boolean);
    }
    if (!opOK(item.outerPackageShape)) item.outerPackageShape = 1;
    // v3.7.36 产品描述图：富文本图层 {type:'image',content:{imgUrl}} → 商品描述区（实测落库）；
    // 描述图 = 全部生成图（含主图），满足「描述图也要把主图放进去」
    if (Array.isArray(descUrls) && descUrls.length) {
      item.goodsLayerDecorationReqs = descUrls.map(function (u) { return { type: 'image', content: { imgUrl: u } }; });
    }
    // v3.7.40 保存校验兜底（探针 242/243 实测）：毛重>净重>0、长宽高/包装尺寸>0、SKU 尺寸兜底
    if (!(Number(item.weight) > 0)) item.weight = 150;
    if (!(Number(item.netWeight) > 0) || Number(item.netWeight) >= Number(item.weight)) item.netWeight = Math.max(1, Math.floor(Number(item.weight) * 0.8));
    if (!(Number(item.length) > 0)) item.length = 20;
    if (!(Number(item.width) > 0)) item.width = 15;
    if (!(Number(item.height) > 0)) item.height = 5;
    if (!(Number(item.packageLength) > 0)) item.packageLength = 20;
    if (!(Number(item.packageWidth) > 0)) item.packageWidth = 15;
    if (!(Number(item.packageHeight) > 0)) item.packageHeight = 5;
    Object.keys(item.skuMap || {}).forEach(function (k) {
      var sk = item.skuMap[k];
      if (!Number(sk.weight)) sk.weight = '150';
      if (!Number(sk.netWeight) || Number(sk.netWeight) >= Number(sk.weight)) sk.netWeight = String(Math.max(1, Math.floor(Number(sk.weight) * 0.8)));
      if (!Number(sk.length)) sk.length = '20';
      if (!Number(sk.width)) sk.width = '15';
      if (!Number(sk.height)) sk.height = '5';
    });
    var payload = 'siteCollectItemInfo=' + encodeURIComponent(JSON.stringify(item)) + '&site=PDDKJ';
    var j2 = await fetch(CB + 'saveSiteCollectItemInfo', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: payload }).then(function (x) { return x.text(); }).then(function (t) { try { return JSON.parse(t); } catch (e) { return { result: 'fail', reason: '返回异常' }; } });
    if (j2 && j2.result === 'success') return { ok: true, attrN: m.attrs.length, missed: m.missed, en: !!tEn };
    // 英文标题导致保存被拒（如店铺未开多语言）：退回不带多语言标题再存一次，保住属性/外包装
    if (tEn && /标题|语言|multi/i.test(String(j2 && j2.reason || ''))) {
      delete item.multiLanguageTitleMap;
      var payloadT = 'siteCollectItemInfo=' + encodeURIComponent(JSON.stringify(item)) + '&site=PDDKJ';
      var jT = await fetch(CB + 'saveSiteCollectItemInfo', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: payloadT }).then(function (x) { return x.text(); }).then(function (t) { try { return JSON.parse(t); } catch (e) { return { result: 'fail', reason: '返回异常' }; } });
      if (jT && jT.result === 'success') return { ok: true, attrN: m.attrs.length, missed: m.missed.concat(['英文标题被拒：' + String(j2.reason).slice(0, 30)]) };
      return { ok: false, reason: String(jT && jT.reason || j2.reason || '').slice(0, 60) };
    }
    // 属性缺必填导致失败：退回不带属性再存一次，保住外包装
    if (m.attrs.length && /必填/.test(String(j2 && j2.reason || ''))) {
      item.attributes = [];
      var payload2 = 'siteCollectItemInfo=' + encodeURIComponent(JSON.stringify(item)) + '&site=PDDKJ';
      var j3 = await fetch(CB + 'saveSiteCollectItemInfo', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: payload2 }).then(function (x) { return x.text(); }).then(function (t) { try { return JSON.parse(t); } catch (e) { return { result: 'fail', reason: '返回异常' }; } });
      if (j3 && j3.result === 'success') return { ok: true, attrN: 0, missed: m.missed.concat(['必填缺：' + String(j2.reason).slice(0, 40)]) };
      return { ok: false, reason: String(j3 && j3.reason || j2.reason || '').slice(0, 60) };
    }
    return { ok: false, reason: String(j2 && j2.reason || '').slice(0, 60) };
  }
  async function localAttrBackfill(pairs, importStartTs) {
    // pairs: [{title, srcAttrs, pack}]；importStartTs: 本单开始时间（ 'YYYY-MM-DD hh:mm:ss' 下限）
    var titles = pairs.map(function (p) { return p.title; });
    log('🧩 属性/外包装/描述图回填：' + pairs.length + ' 条（CSV 导入不带这些，走编辑页接口补）…');
    var found = await xtFindNewItems(importStartTs, titles);
    var okN = 0, warn = [], enN = 0;
    for (var i = 0; i < pairs.length; i += 3) {
      await Promise.all(pairs.slice(i, i + 3).map(async function (p) {
        var did = found[p.title];
        if (!did) { warn.push(p.title.slice(0, 14) + '：没找到新链接'); return; }
        try {
          var r = await xtBackfillOne(did, p.srcAttrs, p.pack, p.desc, { en: p.en });
          if (r.ok) { okN++; if (r.en) enN++; if (r.missed && r.missed.length) warn.push(p.title.slice(0, 14) + '：属性缺 ' + r.missed.join('/').slice(0, 60)); }
          else warn.push(p.title.slice(0, 14) + '：' + (r.reason || '保存失败'));
        } catch (e) { warn.push(p.title.slice(0, 14) + '：' + String(e && e.message || e).slice(0, 60)); }
      }));
      try { setProg(94 + Math.round((Math.min(i + 3, pairs.length) / pairs.length) * 5), '⑧ 属性回填 ' + Math.min(i + 3, pairs.length) + '/' + pairs.length + '…'); } catch (eP) {}
    }
    log('🧩 属性回填完成：成功 ' + okN + '/' + pairs.length + '，英文标题写入 ' + enN + ' 条' + (warn.length ? '；注意：' + warn.slice(0, 6).join('；') : ''));
    return okN;
  }
  async function localRepairAll(onlyPid) {
    for (var round = 1; round <= 2; round++) {
      var pairs = localMissingPairs(onlyPid);
      if (!pairs.length) break;
      log('🩹 补图第 ' + round + ' 轮：' + pairs.length + ' 张，已有图不重跑');
      setProg(null, '🩹 补图中：剩 ' + pairs.length + ' 张…');
      var left = await localRepairShots(pairs);
      if (!left) break;
      await nap(4000);
    }
    return localMissingPairs(onlyPid).length;
  }
  // 本地单：整链接重跑（对应结果区的 🔁），按原提示词逐张重出
  async function localRerunProd(pid) {
    var p = wash.state[String(pid)];
    if (!p || !p.local) return false;
    if (busy) { log('⏳ 当前有任务在跑，等它结束再重跑'); return true; }
    if (!p.localShots || !p.localShots.length) { log('ℹ️ 这个商品还没有生成记录'); return true; }
    busy = true; p.status = 'running'; p.done = 0; p.localUrls = []; washRender();
    try {
      var shots = p.localShots.slice().sort(function (a, b) { return a.idx - b.idx; });
      for (var i = 0; i < shots.length; i++) {
        setProg(null, '🔁 重跑 ' + (i + 1) + '/' + shots.length + ' 张…');
        try {
          var u = await localRegenShot(shots[i]);
          p.localUrls[shots[i].idx] = u; p.done = p.localUrls.filter(Boolean).length; washRender();
        } catch (eR) { log('⚠️ 第 ' + (shots[i].idx + 1) + ' 张重跑失败：' + String(eR.message || eR).slice(0, 120)); }
      }
      p.status = 'done'; washRender();
      log('🔁 整链接重跑完成：' + String(p.title || p.srcPid).slice(0, 18) + '（新图链已更新；已导入的链接需重新导入或到妙手替换）');
    } finally { busy = false; }
    return true;
  }
  function showLinks(links, note) {
    if (!linksEl) return;
    wash.links = (links || []).slice();   // v2.7.0：存起来供复制/导出留底
    var lb = document.querySelector('.mscb-linkbtns');
    if (lb) lb.style.display = wash.links.length ? '' : 'none';
    linksEl.innerHTML = '';
    var d = document.createElement('div');
    d.className = 'mscb-links-title';
    d.textContent = note || ('✅ 已创建 ' + links.length + ' 条产品链接');
    linksEl.appendChild(d);
    links.slice(0, 30).forEach(function (u) {
      var a = document.createElement('a');
      a.href = u; a.target = '_blank'; a.rel = 'noopener'; a.className = 'mscb-link';
      a.textContent = u;
      linksEl.appendChild(a);
    });
  }
  function R() { return window.__msRpaApi || null; }

  /* ---------------- v2.6.0 结果区：每链接进度条 / 预览 / 重跑 / 修改建议 / 时间估算 ---------------- */
  function imgBaseOf() {
    var b = imgBaseNorm(cfg.imgBase);
    return b || IMG_BASE_DEFAULT;   // 默认自有分发节点（妙手拉不到 127.0.0.1）
  }
  // v3.4.6 关键修复：洗图台 API 地址与图床地址分离。imgBaseOf 现在默认指向分发节点
  // 之前十几处 API 调用误用 imgBaseOf 打到节点 nginx 全 404（体检报「返回非 JSON 404」）
  function washBaseOf() {
    var b = String(cfg.studio || '').trim().replace(/\/+$/, '');
    // v3.7.4 洗图台上服务器：老记录里存过本机 127.0.0.1:8788 的自动升级成服务器地址
    if (/^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?(?:\/|$)/i.test(b)) b = '';
    return b || STUDIO_DEFAULT;
  }
  // 成品图地址与洗图台 /view 规则一致：{图床}/view/{pid}/{pid}-{i}.jpg
  function washImgUrl(pid, i) {
    var lp = wash.state[String(pid)];   // v3.7.27c 本地直连：直接用已上传妙手的图链，不再走洗图台图床
    if (lp && lp.local && lp.localUrls && lp.localUrls[i]) return lp.localUrls[i];
    var s = String(cfg.share || '');
    return imgBaseOf() + '/view/' + pid + '/' + pid + '-' + i + '.jpg' + (s ? '?sharecode=' + encodeURIComponent(s) : '');
  }
  // v3.7.34 预览取图：本地直连优先用内存里这张图本身（dataURL）。
  // 之前只用图链，若上游几张图返回了同一个图链，点哪张都会显示成同一张（表现为「一直跳到第一张」）。
  function shotImgSrc(pid, idx) {
    var p = wash.state[String(pid)];
    if (p && p.local && p.localShots) {
      for (var i = 0; i < p.localShots.length; i++) {
        var s = p.localShots[i];
        if (s.idx === idx && s.dataUrl) return s.dataUrl;
      }
    }
    return washImgUrl(pid, idx);
  }
  // v3.4.7 https 页面不能直接挂 http 图床的 <img>（Chrome 混合内容拦截 → 永远显示「生成中/未生成」，
  // 而下载/新标签打开不受限）。预览图统一走 background 拉回来转 dataURL 再挂；带缓存防渲染循环重复拉取
  // v3.7.1 修复「预览白块」：图床上某张图曾因未推送/瞬断失败过，浏览器会把这次失败结果缓存住（实测 <img> 3ms 就报错），
  //        之后无论刷新多少次都只认那份失败缓存 —— 必须换一个带时间戳的地址才会重新请求。
  //        现在：失败自动带戳重试 3 次（400ms/800ms 退避），仍失败才出占位，占位可点重试；失败过的地址以后一律带戳。
  var imgDlCache = {};
  var imgBad = {};
  function bustUrl(u) {
    return u + (u.indexOf('?') >= 0 ? '&' : '?') + 't=' + Date.now() + '_' + Math.floor(Math.random() * 1e4);
  }
  // v3.7.87 相对路径补全：妙手本地上传的图片（/view/local-xxx.jpg）只有相对路径，
  // 不补域名会导致对比图显示失败、生图参考图抓取失败、导入 CSV 里链接打不开三个问题
  function xtAbsUrl(u) {
    var s = String(u || '').trim();
    if (!s || /^(https?:|data:)/i.test(s)) return s;
    if (s.charAt(0) === '/') { try { return location.origin + s; } catch (eA) { return s; } }
    return s;
  }
  function loadImgViaBg(im, u, missEl, forceBg) {
    u = xtAbsUrl(u);   // v3.7.87 妙手本地上传图是相对路径（/view/local-...jpg），先补全域名，否则直挂/代理全 404
    if (!u) { miss(im, null); return; }
    if (imgDlCache[u]) { im.src = imgDlCache[u]; return; }
    var tries = 0;
    im.onerror = function () {
      if (tries < 4) { imgBad[u] = 1; setTimeout(function () { tryLoad(); }, 400 * tries); return; }
      imgBad[u] = 1;
      miss(im, missEl);
    };
    function miss(el, box) {
      el.style.display = 'none';
      if (!box) return;
      box.style.display = 'flex';
      box.classList.add('mscb-pvmiss-retry');
      box.innerHTML = '⏳ 图未加载<br><b>点击重试</b>';
      box.onclick = function () {
        box.style.display = 'none'; el.style.display = ''; delete imgBad[u]; tries = 0;
        tryLoad();
      };
    }
    function tryLoad() {
      tries++;
      var url = (tries > 1 || imgBad[u]) ? bustUrl(u) : u;
      if (!/^https?:/i.test(url)) { im.src = url; return; }
      // v3.7.68 forceBg 改成多级回退：先无 Referer 直挂（多数防盗链只拦带外站 Referer 的请求，无 Referer 反而放行），
      // 第 1/2 次失败再走后台代理（第 3/4 次）。之前直接走代理，而 MV3 后台 fetch 带 chrome-extension Origin 会被 kwcdn 等 CDN 拒。
      if (forceBg && tries <= 2) {
        try { im.referrerPolicy = 'no-referrer'; } catch (eR) {}
        im.src = url;
        return;
      }
      if ((forceBg && tries > 2) || /^http:/i.test(url)) {   // http：https 页面挂不动，走后台取回 dataURL；forceBg 兜底也走后台代理
        chrome.runtime.sendMessage({ cmd: 'fetchImg', url: url }, function (r) {
          if (chrome.runtime.lastError || !r || !r.ok) { if (im.onerror) im.onerror(); return; }
          if (imgDlCache[u] === undefined) {
            var keys = Object.keys(imgDlCache);
            if (keys.length > 60) delete imgDlCache[keys[0]];   // 简单 FIFO，防内存涨
            imgDlCache[u] = r.dataUrl;
          }
          im.src = r.dataUrl;
        });
        return;
      }
      // v3.7.90 非同源图先试一次无 Referer 直挂（多数防盗链只拦带外站 Referer 的请求）
      im.src = url;
    }
    // v3.7.90 页面同源直取兜底：妙手本地上传图（/view/local-xxx.jpg）要登录会话，
    // 内容脚本在妙手页面里 fetch 同源 URL 自带 Cookie+Referer，比后台代理更可靠。
    // 在最终报错前插一道：把「无Referer直挂+后台代理都试过」改成三重兜底。
    var _oldMiss = miss;
    miss = function (el, box) {   // 包装 miss：先试同源 fetch，成功则续命
      if (/^https?:/i.test(u)) {
        var pageOrigin = '';
        try { pageOrigin = location.origin; } catch (eO) {}
        if (pageOrigin && u.indexOf(pageOrigin) === 0) {
          fetch(u, { credentials: 'include', cache: 'no-store', signal: AbortSignal.timeout(30000) })
            .then(function (rp) {
              if (!rp.ok) throw new Error('HTTP ' + rp.status);
              return rp.blob();
            })
            .then(function (bl) {
              if (!/^image\//i.test(String(bl.type || ''))) throw new Error('非图片');
              var fr = new FileReader();
              fr.onload = function () {
                try {
                  if (imgDlCache[u] === undefined) {
                    var ks = Object.keys(imgDlCache);
                    if (ks.length > 60) delete imgDlCache[ks[0]];
                    imgDlCache[u] = fr.result;
                  }
                  el.style.display = ''; if (box) box.style.display = 'none';
                  el.src = fr.result;   // 成功：直接续挂，不再 miss
                } catch (eS) { _oldMiss(el, box); }
              };
              fr.readAsDataURL(bl);
            })
            .catch(function () {
              try { log('⚠️ 图片加载失败（直挂+后台代理(免/带Cookie)+页面直取都试过）：' + String(u).slice(0, 110)); } catch (eL) {}
              _oldMiss(el, box);
            });
          return;
        }
      }
      try { log('⚠️ 图片加载失败（直挂+后台代理都试过）：' + String(u).slice(0, 110)); } catch (eL) {}
      _oldMiss(el, box);
    };
    tryLoad();
  }
  // v3.0.0 单链接下载：该产品的成品图逐张下载到本地（先验货再上架）
  function dlProduct(s) {
    var n = s.total || 10;
    var tag = String(s.srcPid || s.pid || 'product').replace(/[\\/:*?"<>|]/g, '_').slice(0, 40);
    for (var i = 0; i < n; i++) {
      (function (idx) {
        try {
          chrome.runtime.sendMessage({ cmd: 'download', url: washImgUrl(s.pid, idx),
            filename: '洗图猫_' + tag + '_' + (idx + 1) + '.jpg' }, function () { void chrome.runtime.lastError; });
        } catch (e) {}
      })(i);
    }
    log('⬇️ 已开始下载「' + (s.srcPid || s.pid) + '」的 ' + n + ' 张成品图（浏览器下载栏查看）');
  }
  function fmtDur(ms) {
    if (ms == null || !isFinite(ms)) return '未记录';
    ms = Math.max(0, ms || 0);
    var s = Math.round(ms / 1000);
    if (s < 60) return s + '秒';
    var m = Math.floor(s / 60);
    if (m < 60) return m + '分' + (s % 60 ? (s % 60) + '秒' : '');
    return Math.floor(m / 60) + '时' + (m % 60 ? (m % 60) + '分' : '');
  }
  function generationSummaryText(timing, etaMs, done) {
    var text = '⏱ 本单总生成历时：';
    if (timing && typeof timing.elapsedMs === 'number' && isFinite(timing.elapsedMs)) text += fmtDur(timing.elapsedMs) + '（首次派发至首次齐套，含上游等待/重试/暂停）';
    else if (timing && timing.status === 'running' && typeof timing.elapsedSoFarMs === 'number') text += '进行中，已历时 ' + fmtDur(timing.elapsedSoFarMs) + '（含等待/暂停）';
    else text += '未完整记录，不能用本次补跑替代';
    var attempt = timing && timing.latestAttempt;
    if (attempt && attempt.kind !== 'generate') {
      text += ' · 本次' + (attempt.kind === 'regenerate' ? '重做' : attempt.kind === 'resume' ? '恢复补跑' : '补跑') + '：';
      text += typeof attempt.elapsedMs === 'number' ? fmtDur(attempt.elapsedMs) : attempt.status === 'pending' ? '等待派发' : attempt.status === 'running' ? '进行中' : '完成时间未记录';
      text += '（不覆盖整单）';
    }
    if (!done) text += ' · 预计剩余 ' + fmtDur(etaMs) + '（估计）';
    return text + ' · 非纯模型推理时间';
  }
  function presetOf(key) {
    if (key === xtCatalog.generic.name) return xtCatalog.generic;
    return (cfg.tplPresets || []).find(function (p) { return p && p.name === key; }) || null;
  }
  /* ---------------- v2.7.0 人性化套件 ---------------- */
  // 商品类目：从原始详情里挖类目名，供一键筛选（不同类目配不同模板）
  function fullCategory(v) {
    var raw = v && v.raw || {};
    var bc = [raw.breadcrumb, raw.categoryPath, raw.categoryFullName].find(function (x) { return typeof x === 'string' && x.trim(); });
    var label = bc || rawFind(raw, ['categoryName', 'catName', 'category'], 2);
    return typeof label === 'string' ? label.trim() : '';
  }
  function catOf(v) {
    return fullCategory(v).split(/[\/>＞]/).pop().trim().slice(0, 14) || '未分类';
  }
  function catalogRow(v) {
    var raw = v.raw || {};
    var candidates = [raw.publishShopId, raw.shopId, raw.storeId].concat(Array.isArray(raw.shopIds) ? raw.shopIds : []);
    var shops = new Set(candidates.filter(function (id) { return id != null && /^\d{1,32}$/.test(String(id)); }).map(String));
    return { title: v.title, category: fullCategory(v), shop: shops.size === 1 ? shops.values().next().value : '', manual: v.tplManual };
  }
  // v2.9.0 小猫咪气泡弹消息：主动说话 + 跳一下，客户不打开面板也能看见
  var catTimer = null;
  function catSay(html, ms) {
    try {
      var b = document.querySelector('.mscb-bubble');
      var ball = document.querySelector('.mscb-ball');
      if (ball) {   // 说话时跳一下
        ball.classList.remove('jump');
        void ball.offsetWidth;   // 重启动画
        ball.classList.add('jump');
        setTimeout(function () { ball.classList.remove('jump'); }, 900);
      }
      if (!b) return;
      b.classList.remove('bye');
      b.classList.remove('show');
      void b.offsetWidth;
      b.innerHTML = html;
      b.classList.add('show');
      if (catTimer) clearTimeout(catTimer);
      catTimer = setTimeout(function () {
        b.classList.add('bye');
        setTimeout(function () { b.classList.remove('show', 'bye'); }, 320);
      }, ms || 6500);
    } catch (e) {}
  }
  // 系统通知（走后台 chrome.notifications，客户切走也能收到）+ 本地提示音
  function notify(title, msg) {
    try {
      chrome.runtime.sendMessage({ cmd: 'notify', title: title, message: msg }, function () { void chrome.runtime.lastError; });
    } catch (e) {}
    try {   // 提示音：两声短哔（需要页面有过交互，正常点过启动就有）
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      var ac = new AC();
      var playBeep = function () {
        [0, 0.18].forEach(function (dt) {
          var o = ac.createOscillator(), g = ac.createGain();
          o.frequency.value = 880; o.type = 'sine';
          o.connect(g); g.connect(ac.destination);
          g.gain.setValueAtTime(0.001, ac.currentTime + dt);
          g.gain.exponentialRampToValueAtTime(0.12, ac.currentTime + dt + 0.02);
          g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + dt + 0.14);
          o.start(ac.currentTime + dt); o.stop(ac.currentTime + dt + 0.16);
        });
        setTimeout(function () { try { ac.close(); } catch (e) {} }, 800);
      };
      if (ac.state === 'suspended') {   // 自动播放策略下先恢复（点过启动即有激活资格）
        ac.resume().then(playBeep).catch(function () { try { ac.close(); } catch (e2) {} });
      } else playBeep();
    } catch (e) {}
  }
  // ---------- v3.6.0 TTS 语音提示（浏览器原生 speechSynthesis，零成本零依赖） ----------
  // 声音选择：优先中文女声（macOS 婷婷 / Windows 晓晓·慧慧 / Chrome Google 女声），
  // 找不到就用任意中文语音并略抬音调。面板「🔊 语音提示」可关。
  var ttsVoice = null, ttsUtterance = null;
  function ttsPick() {
    try {
      var vs = window.speechSynthesis ? speechSynthesis.getVoices() : [];
      var zh = vs.filter(function (v) { return /^zh|cmn/i.test(v.lang || ''); });
      ttsVoice = zh.filter(function (v) { return /ting|婷婷|xiaoxiao|晓晓|xiaoyi|小艺|hui|慧|meijia|美佳|yao|瑶|female|女/i.test(v.name || ''); })[0]
        || zh[0] || null;
    } catch (e) {}
  }
  try {
    if ('speechSynthesis' in window) {
      ttsPick();
      speechSynthesis.onvoiceschanged = ttsPick;   // Chrome 语音列表异步加载，就绪后再挑一次
      // v3.7.37 Chrome 自动播放策略：页面没有用户手势时 speechSynthesis 报 not-allowed（实测 2026-11-21）。
      // 首次手势（点击/按键）时静默解锁一次，之后正常播报；手势监听全程保留，兼容刷新后无人交互的场景。
      var ttsPrimed = false;
      var ttsPrime = function () {
        try { speechSynthesis.resume(); } catch (e0) {}
        if (ttsPrimed) return;
        ttsPrimed = true;
        try {
          var x = new SpeechSynthesisUtterance(' ');
          x.volume = 0; x.lang = 'zh-CN';
          speechSynthesis.speak(x);
        } catch (e1) {}
      };
      document.addEventListener('pointerdown', ttsPrime, true);
      document.addEventListener('keydown', ttsPrime, true);
      document.addEventListener('touchstart', ttsPrime, true);
    }
  } catch (e) {}
  // BEGIN_COMPLETION_VOICE_QUEUE
  var ttsQueue = [], ttsStartTimer = null, ttsEndTimer = null;
  var ttsAudio = null, ttsAudioTimer = null;
  var ttsBlocked = false;   // v3.7.37 自动播放策略拦截中
  function ttsRetryOnGesture() {
    var done = false;
    var go = function () {
      if (done) return; done = true;
      document.removeEventListener('pointerdown', go, true);
      document.removeEventListener('keydown', go, true);
      ttsBlocked = false;
      try { speechSynthesis.resume(); } catch (e0) {}
      try {
        var x = new SpeechSynthesisUtterance(' ');
        x.volume = 0; x.lang = 'zh-CN';
        speechSynthesis.speak(x);
      } catch (e1) {}
      setTimeout(function () { if (ttsQueue.length) pumpSpeech(); }, 150);
    };
    document.addEventListener('pointerdown', go, true);
    document.addEventListener('keydown', go, true);
    log('🔇 语音被浏览器拦了（页面刷新后没点过任何地方）：随便点一下页面，我会自动补播刚才那句');
  }
  function localVoiceClip(text) {
    if (text === '洗图完成，所有链接图片已齐全。') return 'wash-complete';
    if (text === '上传完成，请刷新页面查看链接。') return 'upload-complete';
    return '';
  }
  function playLocalVoice(text, clip) {
    if (typeof Audio !== 'function' || !clip) return false;
    try {
      var audio = new Audio(chrome.runtime.getURL('audio/' + clip + '.wav'));
      ttsAudio = audio;
      function finish(error) {
        if (ttsAudio !== audio) return;
        // v3.7.74 播放失败先用全新 Audio 元素重试一次（旧元素进入错误态后 replay 永远失败，是“偶尔失灵”的主因），
        // 同一句 5 秒内只重试一次防死循环，仍失败才切回浏览器语音
        if (error) {
          if (!playLocalVoice.__failAt || Date.now() - playLocalVoice.__failAt > 5000) {
            playLocalVoice.__failAt = Date.now();
            if (ttsAudio === audio) { audio.onended = null; audio.onerror = null; audio.pause(); ttsAudio = null; clearTimeout(ttsAudioTimer); ttsAudioTimer = null; }
            ttsQueue.unshift({ text: text, nativeOnly: false });   // v3.7.74 修复真凶：entry 是 pumpSpeech 局部变量，这里引用会 ReferenceError 使整条语音队列卡死；录音兜底目标就是原生语音，固定 false
            log('🔄 婷婷女声播放中断，用新音频实例重试一次…');
            setTimeout(pumpSpeech, 200);
            return;
          }
          log('⚠️ 婷婷女声录音两次未能播放，切回浏览器语音。');
        }
        if (ttsAudio !== audio) return;
        ttsAudio = null;
        clearTimeout(ttsAudioTimer); ttsAudioTimer = null;
        audio.pause();
        if (!error) log('🔊 婷婷女声播放结束');
        pumpSpeech();
      }
      audio.onplaying = function () { if (ttsAudio === audio) log('🔊 婷婷女声：' + text); };
      audio.onended = function () { finish(false); };
      audio.onerror = function () { finish(true); };
      ttsAudioTimer = setTimeout(function () { finish(true); }, 8000);
      Promise.resolve(audio.play()).catch(function () { finish(true); });
      return true;
    } catch (e) {
      ttsAudio = null;
      clearTimeout(ttsAudioTimer); ttsAudioTimer = null;
      return false;
    }
  }
  function clearSpeechWatchdogs() {
    if (ttsStartTimer !== null) clearTimeout(ttsStartTimer);
    if (ttsEndTimer !== null) clearTimeout(ttsEndTimer);
    ttsStartTimer = null; ttsEndTimer = null;
  }
  function stopSpeech() {
    clearSpeechWatchdogs();
    if (ttsAudio) { var audio = ttsAudio; ttsAudio = null; audio.pause(); }
    clearTimeout(ttsAudioTimer); ttsAudioTimer = null;
    ttsQueue.length = 0;
    ttsUtterance = null;
    try { speechSynthesis.cancel(); } catch (e) {}
  }
  function pumpSpeech() {
    if (ttsUtterance || ttsAudio || !ttsQueue.length || cfg.tts === false) return;
    var entry = ttsQueue.shift();
    var text = typeof entry === 'string' ? entry : entry.text;
    if (!entry.nativeOnly && playLocalVoice(text, localVoiceClip(text))) return;
    try {
      ttsPick();
      var u = new SpeechSynthesisUtterance(String(text));
      ttsUtterance = u;
      u.lang = 'zh-CN'; u.rate = 1; u.pitch = ttsVoice ? 1 : 1.2; u.volume = 0.95;
      if (ttsVoice) u.voice = ttsVoice;
      var started = false;
      function finish(stalled) {
        if (ttsUtterance !== u) return;
        clearSpeechWatchdogs();
        ttsUtterance = null; // invalidate before cancel: synchronous/late callbacks cannot affect next item
        if (stalled === true) {
          u.onstart = null; u.onend = null; u.onerror = null;
          try { speechSynthesis.cancel(); } catch (e) {}
          log('⚠️ 语音未能正常完成，已释放语音队列；请点「语音试播」检查声音设置（不影响业务结果）');
        }
        pumpSpeech();
      }
      u.onstart = function () {
        if (ttsUtterance !== u) return;
        started = true;
        if (ttsStartTimer !== null) clearTimeout(ttsStartTimer);
        ttsStartTimer = null;
        log('🔊 正在播报：' + text);
        // Bounded recovery for an engine that starts but never emits end/error.
        var maxSpeechMs = Math.max(45000, Math.min(180000, String(text).length * 600 + 10000));
        ttsEndTimer = setTimeout(function () { if (ttsUtterance === u) finish(true); }, maxSpeechMs);
      };
      u.onend = finish;
      u.onerror = function (e) {
        // v3.7.37 not-allowed = 自动播放拦截：不要丢弃这句话，等用户下一次点击页面任意位置自动补播
        if (e.error === 'not-allowed' && !ttsBlocked) {
          clearSpeechWatchdogs();
          ttsUtterance = null;
          ttsBlocked = true;
          ttsQueue.unshift({ text: text, nativeOnly: !!entry.nativeOnly });
          ttsRetryOnGesture();
          return;
        }
        if (e.error !== 'canceled' && e.error !== 'interrupted') {
          log('⚠️ 语音未播出（' + (e.error || '未知原因') + '），请点「语音试播」检查声音设置');
          // v3.7.74 引擎偶发 synthesis-failed / audio-busy：同一句自动重试一次（1.2s 后），不再直接丢句
          if (!entry.retried && /synthesis-failed|audio-busy|network/i.test(String(e.error || ''))) {
            ttsUtterance = null;
            clearSpeechWatchdogs();
            ttsQueue.unshift({ text: text, nativeOnly: true, retried: true });
            setTimeout(pumpSpeech, 1200);
            return;
          }
        }
        finish();
      };
      // Only recovery/explicit off cancels; normal queued announcements remain FIFO.
      ttsStartTimer = setTimeout(function () { if (!started && ttsUtterance === u) finish(true); }, 3000);
      speechSynthesis.resume();
      speechSynthesis.speak(u);
    } catch (e) {
      clearSpeechWatchdogs();
      ttsUtterance = null;
      log('⚠️ 语音调用失败，请点「语音试播」检查声音设置');
      if (ttsQueue.length) setTimeout(pumpSpeech, 0);
    }
  }
  function speak(text) {
    if (cfg.tts === false) return false;
    if (!('speechSynthesis' in window) && !localVoiceClip(String(text))) { log('⚠️ 当前浏览器不支持语音，完成提醒仍会弹窗显示'); return false; }
    ttsQueue.push(String(text));
    pumpSpeech();
    return true;
  }
  // END_COMPLETION_VOICE_QUEUE
  // 提醒失败不能进入导入重试分支，避免重复提交。
  function showImportComplete(result) {
    if (!result || result.ok !== true) return;
    try {
      var n = result.okN != null ? result.okN : result.links ? result.links.length : null;
      var fail = result.failN != null ? result.failN : 0;
      var summary = (n == null ? '请到导入记录核对数量' : '成功 ' + n + ' 个，失败 ' + fail + ' 个');
      var message = '上传完成：' + summary + '。请刷新页面查看新链接。';
      log('🎉 ' + message);
      speak((fail > 0 ? '导入已结束，有失败项，请查看日志。' : '上传完成，') + '请刷新页面查看链接。');
      var mask = document.querySelector('.mscb-donemask');
      if (!mask) return;
      mask.querySelector('.mscb-donetext').textContent = message + ' 刷新不会再次上传。';
      mask.classList.add('open');
      mask.querySelector('.mscb-done-refresh').focus();
    } catch (e) { /* 不重试业务请求，页面日志和原结果仍保留。 */ }
  }
  // 预计时间自学习：记录最近 5 单的每张平均耗时，估算越用越准
  function learnedSecPerImg() {
    var arr = cfg.speedLog || [];
    if (!arr.length) return 20;
    var s = 0; arr.forEach(function (x) { s += x; });
    return Math.max(3, Math.round(s / arr.length));
  }
  function saveSpeedSample() {
    var used = wash.generationTiming && wash.generationTiming.elapsedMs;
    if (typeof used !== 'number' || !isFinite(used)) return;
    var done = Math.max(1, washDoneSum());
    var perImg = Math.round(used / 1000 / done);
    if (!(perImg > 0 && perImg < 600)) return;
    cfg.speedLog = (cfg.speedLog || []);
    cfg.speedLog.push(perImg);
    while (cfg.speedLog.length > 5) cfg.speedLog.shift();
    saveCfg();
  }
  var pauseNeedsAck = false;
  async function setServerPause(base, auth, on, startedAt) {
    var result = await relay(base + '/api/pause?' + auth, { on: on, scope: 'all', expectStartedAt: startedAt });
    if (!result || !result.ok || result.paused !== on) throw new Error((result && result.error) || '服务器未确认暂停状态');
  }
  async function pauseAtBoundary(base, auth, st) {
    if (paused && pauseNeedsAck && wash.serverActive && !st.paused) {
      pauseNeedsAck = false;
      try {
        await setServerPause(base, auth, true, wash.batchAt);
        log('⏸ 已停止派新图；已发出的请求会自然结束。');
      } catch (e) { log('⚠️ 本地已暂停，服务器暂停未确认。'); }
    }
    await waitResume('⏸ 已暂停，点击顶部「继续」恢复。');
  }
  function settledWash(st) {
    return !!st && (st.status === 'done' || st.status === 'error' ||
      (st.status === 'ready' && Number(st.startedAt) > 0 &&
        (st.products || []).some(function (p) { return Number(p.done) > 0; })));
  }
  function missingWashProducts() {
    return washMine().filter(function (s) { return s.status !== 'paused' && s.done < s.total; });
  }
  function washTerminalText() {
    var n = missingWashProducts().reduce(function (sum, p) { return sum + p.total - p.done; }, 0);
    return '⚠️ 本轮结束：已保存 ' + washDoneSum() + '/' + wash.plan + ' 张，缺 ' + n + ' 张。已有图保留，可点「补失败图」。';
  }
  // 一次提交全部缺图：单条补图一发就会置 running，随后同批的逐条请求会被拒绝。
  async function washRepair(base, auth) {
    if (repairBusy) return missingWashProducts().length;
    var bad = missingWashProducts();
    if (!bad.length) return 0;
    if (!wash.done || !wash.batchAt) return bad.length;
    repairBusy = true;
    var original = wash.batchAt;
    try {
      await waitResume();
      var only = washMine().filter(function (s) { return s.status !== 'paused'; }).map(function (s) { return s.pid; });
      log('🩹 自动补图：只补缺失的 ' + bad.reduce(function (sum, p) { return sum + p.total - p.done; }, 0) + ' 张，已有图片不重跑。');
      var r = await relay(base + '/api/fill-all?' + auth, { only: only, expectStartedAt: original });
      if (!r || !r.ok) throw new Error((r && r.error) || '补图提交失败');
      wash.done = false;
      var end = Date.now() + 15 * 60 * 1000;
      while (Date.now() < end) {
        var pauseAt = Date.now();
        var st = await statusSafe(base + '/api/status?' + auth, {});
        if (!matchesWash(st, only)) throw new Error('洗图单已切换，停止跟踪补图');
        washSync(st); washRender(); washTimeLine();
        if (settledWash(st)) {
          var left = missingWashProducts().length;
          log(left ? washTerminalText() : '✅ 补图完成：所有链接图已齐全');
          return left;
        }
        await pauseAtBoundary(base, auth, st);
        end += Date.now() - pauseAt;
        setProg(null, '🩹 补图中：' + washDoneSum() + '/' + wash.plan + ' 张…');
        await nap(3500);
      }
      throw new Error('补图仍在服务器运行，稍后点「续跑」查看，不会重复提交');
    } finally { repairBusy = false; }
  }
  function matchesWash(st, only) {
    return !!(st && st.mine !== false && only.length && only.every(function (pid) {
      return (st.products || []).some(function (p) { return String(p.pid) === pid; });
    }));
  }
  // 链接清单：复制 / 导出 CSV 留底（产品名称 + 产品ID + 最终链接）
  function linkListRows() {
    var rows = [];
    var seen = {};
    (wash.links || []).forEach(function (u) { if (!seen[u]) { seen[u] = 1; rows.push({ title: '', id: '', url: u }); } });
    return rows;
  }
  function copyLinks() {
    var urls = (wash.links || []);
    if (!urls.length) { log('ℹ️ 还没有建好的链接'); return; }
    var text = urls.join('\n');
    var done = function () { log('📋 已复制 ' + urls.length + ' 条链接到剪贴板'); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done, function () { fallbackCopy(text, done); });
    } else fallbackCopy(text, done);
  }
  function fallbackCopy(text, done) {
    var ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); done(); } catch (e) { log('❌ 复制失败，请手动选择链接复制'); }
    document.body.removeChild(ta);
  }
  function exportLinksCsv() {
    var urls = (wash.links || []);
    if (!urls.length) { log('ℹ️ 还没有建好的链接'); return; }
    var lines = ['产品ID,产品名称,产品链接'];
    var seen = {};
    urls.forEach(function (u) {
      if (seen[u]) return; seen[u] = 1;
      var pid = (String(u).match(/(\d{6,})/) || [])[1] || '';
      var it = null;
      items.forEach(function (v) { if (!it && String(v.id) === pid) it = v; });
      lines.push([pid, (it && it.title) || '', u].map(csvCell).join(','));
    });
    var d = new Date();
    var pad = function (x) { return (x < 10 ? '0' : '') + x; };
    var name = '产品链接清单_' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '_' + pad(d.getHours()) + pad(d.getMinutes()) + '.csv';
    var blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 8000);
    log('📄 已导出链接清单 ' + name + '（' + (lines.length - 1) + ' 条，客户留底用）');
  }
  function tplForItem(key) {
    var p = presetOf(key);
    var t = p ? JSON.parse(JSON.stringify(p.tpl)) : (cfg.tpl ? JSON.parse(JSON.stringify(cfg.tpl)) : null);
    // v2.9.0 类目化提示词：预设里配的「提示词补充」随模板带给服务端生图
    if (t && p && p.prompt) t.prompt = p.prompt;
    // v3.7.28 生图模式继承：旧预设没存 imgMode 时跟随全局设置（否则选了 POD 也只对未配模板的商品生效）
    if (t && !t.imgMode && cfg.tpl && cfg.tpl.imgMode) t.imgMode = cfg.tpl.imgMode;
    if (t && !t.podLevel && cfg.tpl && cfg.tpl.podLevel) t.podLevel = cfg.tpl.podLevel;   // v3.7.69 改造幅度同样跟随
    return t;
  }
  // Re-evaluate automatically matched rows after detail collection adds a usable category.
  var autoTplLogAt = 0;
  function autoTplAssign() {
    if (cfg.autoTpl === false) return 0;
    var ps = cfg.tplPresets || [], n = 0;
    items.forEach(function (v) {
      var next = xtCatalog.template(catalogRow(v), ps, cfg.catalogPreferences);
      if (v.tplKey !== next) { v.tplKey = next; n++; }
    });
    if (n && Date.now() - autoTplLogAt > 30000) {
      autoTplLogAt = Date.now();
      log('🧩 已按类目逐商品配模板 ' + n + ' 个；不确定的使用通用保真。');
    }
    return n;
  }
  function washReset(selIds) {
    wash.on = true; wash.done = false; wash.rpa = false;
    wash.state = {}; wash.products = [];
    wash.t0 = Date.now(); wash.startedAt = 0; wash.finishedAt = 0; wash.generationTiming = null; wash.serverNow = 0;
    wash.target = 10; wash.plan = 0; wash.rate = 0;
    wash.selPids = selIds || {};
    wash.lastMile = 0;   // v3.2.4 阶段进度日志游标复位
    wash.misLogged = false;   // v3.6.2 结果区"与勾选不一致"的说明只打一次
  }
  /* Pure, browser-compatible formatter. Only observed dispatches justify “已切换”. */
  function washRetryMessage(product, serverLog) {
    var p = product || {};
    var pid = String(p.pid || '');
    var name = String(p.title || p.name || ('链接 ' + pid)).slice(0, 24);
    var prefix = '⚠️ 链接《' + name + '》：';
    var done = Math.max(0, Number(p.done) || 0);
    var total = Math.max(0, Number(p.total) || 0);
    if (total > 0 && done >= total) return '✅ 链接《' + name + '》：图片已齐全（' + done + '/' + total + '）；先前重试计数不代表缺图';
    var events = [], lines = Array.isArray(serverLog) ? serverLog : [];
    lines.forEach(function (line, order) {
      if (typeof line !== 'string') return;
      var m = /▶\s*渠道(\d+)·([^：]+)：(\S+)/.exec(line);
      if (m && pid && m[3].indexOf(pid + '-') === 0 && /^\d+$/.test(m[3].slice(pid.length + 1))) {
        events.push({ kind: 'dispatch', order: order, channel: m[1], station: m[2].trim(), image: m[3] });
        return;
      }
      m = /↻\s*(\S+)(?:\s+.*?)?\s+@([^:：]+)[:：]\s*(.*)/.exec(line);
      if (m && pid && m[1].indexOf(pid + '-') === 0 && /^\d+$/.test(m[1].slice(pid.length + 1))) {
        events.push({ kind: 'retry', order: order, station: m[2].trim(), image: m[1], reason: m[3] });
      }
    });
    var retries = events.filter(function (e) { return e.kind === 'retry'; });
    var failedImage = /第(\d+)张/.exec(String(p.lastErr || ''));
    if (failedImage) retries = retries.filter(function (e) { return e.image === pid + '-' + (Number(failedImage[1]) - 1); });
    var last = retries[retries.length - 1];
    var reason = String(p.lastErr || (last && last.reason) || '');
    var remaining = total > 0 ? '，仍缺 ' + Math.max(0, total - done) + ' 张' : '';
    if (/poolMicro\s*无图链|未返回有效图片/i.test(reason)) {
      return prefix + '渠道未返回有效图片，正在核对并重试' + remaining + '；将按真实结果确认';
    }
    if (/(?:所有|全部).*(?:不可用|耗尽|失败)|重试.*耗尽|all.*(?:failed|exhausted)/i.test(reason)) {
      return prefix + '可用渠道已耗尽，本次尚未完成' + remaining + '；请稍后重试或联系管理员排查';
    }
    if (/\b429\b|限流|rate.?limit|too many requests/i.test(reason)) {
      // Never attach a different image's subsequent dispatch to this retry.
      var rateLast = last && /\b429\b|限流|rate.?limit|too many requests/i.test(last.reason) ? last : null;
      var source = null, next = null;
      if (rateLast) {
        events.forEach(function (e) {
          if (e.kind !== 'dispatch' || e.image !== rateLast.image) return;
          if (e.order < rateLast.order && e.station === rateLast.station) source = e;
          if (!next && e.order > rateLast.order && e.station !== rateLast.station) next = e;
        });
      }
      var from = source ? '渠道' + source.channel : '当前渠道';
      return prefix + from + '繁忙/限流（429）' + (next ? '，已切换到渠道' + next.channel + '继续生成' : '，正在等待调度可用渠道') + remaining + '；尚未完成';
    }
    return prefix + '生成尚未完成' + remaining + (reason ? '（原因：' + reason.slice(0, 120) + '）' : '') + '；正在重试或等待排查';
  }
  function washCompletionSuffix(product) {
    var p = product || {}, total = Math.max(0, Number(p.total) || 0), done = Math.max(0, Number(p.done) || 0);
    return total > 0 && done >= total ? ' · 图片全部齐全' : total > 0 ? ' · 仍缺 ' + Math.max(0, total - done) + ' 张待补' : ' · 目标张数待确认';
  }
  // 把 /api/status 的产品数组合并进 wash（记录每链接完成时刻，用于实际用时）
  // BEGIN_COMPLETION_VOICE_TRACKER
  function voiceTaskIdentity(st) {
    if (!st || !Array.isArray(st.products) || !st.products.length) return '';
    var pids = st.products.map(function (p) { return String(p.pid || ''); }).sort();
    if (pids.some(function (id) { return !id; })) return '';
    var scope = String(washBaseOf() || '') + '|';
    if (st.jobId) return scope + 'job:' + String(st.jobId);
    var started = st.generationTiming && st.generationTiming.startedAt || st.startedAt;
    if (!(Number(started) > 0)) return '';
    return scope + 'started:' + String(started) + '|products:' + JSON.stringify(pids);
  }
  function voiceTaskComplete(st) {
    if (!st || st.status !== 'done' || !Array.isArray(st.products) || !st.products.length) return false;
    var target = Number(st.settings && st.settings.target);
    if (!(target > 0)) return false;
    var products = st.products.filter(function (p) { return !p.paused; });
    return products.length > 0 && products.every(function (p) {
      var done = Number(p.done);
      return Number.isFinite(done) && done >= target;
    });
  }
  function completionVoiceObserve(st, silentComplete) {
    if (!voiceTaskComplete(st)) return false;
    var key = voiceTaskIdentity(st);
    if (!key) return false; // no invented identity: cannot safely deduplicate unknown legacy tasks
    var seen = Array.isArray(cfg.completionVoiceSeen) ? cfg.completionVoiceSeen : [];
    if (seen.indexOf(key) >= 0) return false;
    cfg.completionVoiceSeen = seen.concat([key]).slice(-128);
    saveCfg();
    if (silentComplete) return false; // an already-complete restore is not a fresh completion
    notify('🎨 洗图完成', '全部 ' + st.products.length + ' 个链接图片已齐全，可以预览或上传');
    speak('洗图完成，所有链接图片已齐全。');
    return true;
  }
  // END_COMPLETION_VOICE_TRACKER
  function washSync(st, voiceOptions) {
    if (!st) return;
    wash.generationTiming = st.generationTiming || null; wash.serverNow = st.serverNow || 0;
    wash.startedAt = wash.generationTiming && wash.generationTiming.startedAt || NaN;
    wash.finishedAt = wash.generationTiming && wash.generationTiming.finishedAt || NaN;
    wash.t0 = wash.startedAt;
    var target = (st.settings && st.settings.target) || 10;
    var arr = (st.products || []).map(function (p) {
      var pid = String(p.pid || '');
      var s = wash.state[pid] || {};
      s.generationTiming = p.generationTiming || null;
      s.doneAt = s.generationTiming && typeof s.generationTiming.elapsedMs === 'number' ? s.generationTiming.elapsedMs : null;
      var prevDone = s.done || 0, prevFail = s.fail || 0;
      s.pid = pid; s.srcPid = String(p.srcPid || p.pid); s.copyIdx = p.copyIdx || 0;
      s.title = p.title || ''; s.done = p.done || 0; s.fail = p.fail || 0;
      s.lastErr = p.lastErr || '';   // v3.6.1 服务端下发的失败原因
      s.total = target; s.status = p.paused ? 'paused' : (p.status || 'wait');
      // v3.2.4 每链接日志：链接名+张数+耗时+状态（时间戳由 log() 统一加，精确到秒）
      var name = (s.title || ('链接 ' + s.srcPid)).slice(0, 24);
      // v3.4.6 逐张日志：每出一张就打一条（用户要求一张一张提示）
      // 一次轮询出多张时逐条补齐；接回任务首次同步猛涨（>3 张）时只打一条汇总，避免刷屏
      if (s.done > prevDone && s.status !== 'done') {
        var el = fmtDur(Date.now() - (wash.startedAt || wash.t0));
        var delta = s.done - prevDone;
        if (delta > 3) {
          log('🖼️ 《' + name + '》已出 ' + s.done + '/' + s.total + ' 张（本轮 +'
            + delta + '）· 累计 ' + el + ' · 进行中');
        } else {
          for (var di = prevDone + 1; di <= s.done; di++) {
            log('🖼️ 《' + name + '》第 ' + di + '/' + s.total + ' 张已出 · 累计 ' + el + ' · 成功');
          }
        }
      }
      if (s.done < s.total && (s.fail > prevFail || s.retryNotice)) {
        var retryMessage = washRetryMessage(s, st.log);
        if (retryMessage !== s.retryNotice) log(retryMessage);
        s.retryNotice = retryMessage;
      } else if (s.done >= s.total) s.retryNotice = '';
      if (s.status === 'done' && !s.linkLogged) {
        s.linkLogged = true;
        log((s.done >= s.total ? '✅' : '⚠️') + ' 链接《' + name + '》'
          + (s.done >= s.total ? '洗图完成：' : '首轮结束：') + s.done + '/' + s.total + ' 张'
          + (s.doneAt != null ? ' · 耗时 ' + fmtDur(s.doneAt) : '')
          + washCompletionSuffix(s));
      }
      wash.state[pid] = s;
      return s;
    });
    wash.products = arr;
    // v3.6.2 结果区显示的是「洗图台上现有的单」，和当前勾选无关：第一次发现不一致就说明一句
    if (!wash.misLogged && arr.length) {
      var selN = 0; for (var sk in wash.selPids) { selN++; break; }
      var unsel = arr.filter(function (s) { return selN && !wash.selPids[s.pid] && !wash.selPids[s.srcPid]; });
      if (unsel.length) {
        wash.misLogged = true;
        log('ℹ️ 结果区显示的是洗图台上现有的任务（' + arr.length + ' 个链接），与当前勾选无关；点「启动」会新建一单替换它，旧图仍在洗图台磁盘上');
      }
    }
    wash.target = target;
    wash.plan = st.planImgs || (arr.length * target);
    // v3.2.4 阶段性进度日志（每 25% 一条，不刷屏）：总张数+已用时间+产能+扣费
    if (st.status === 'running' && wash.plan) {
      var ds = washDoneSum(), mile = Math.floor(ds * 4 / wash.plan);
      if (mile > (wash.lastMile || 0) && ds < wash.plan) {
        wash.lastMile = mile;
        log('⏳ 洗图进度 ' + ds + '/' + wash.plan + ' 张（' + Math.round(ds * 100 / wash.plan) + '%）· 已用 '
          + fmtDur(Date.now() - (wash.startedAt || wash.t0)) + (wash.rate ? ' · 产能 ' + wash.rate + '张/分' : '') + ' · 💳 ' + billLine());
      }
    }
    // Legacy batch startedAt/finishedAt can be reset by repair; never use them as total generation time.
    wash.rate = st.throughput || 0;
    // v2.9.0 限流降速提示：连续 ~15 秒 0 出图时说明上游拥挤，安抚客户（每段只说一次）
    if (st.status === 'running' && !wash.rate) {
      slowStreak++;
      if (slowStreak === 4) {
        log('🐢 上游拥挤：洗图站已自动降速，出图会慢一些（服务器在自动重试，不用管）');
        catSay('🐢 喵～上游有点挤，已自动降速慢慢跑，<b>不会影响已完成的部分</b>，耐心等一下下');
        speak('上游有点挤，已自动降速，不会影响已完成的部分。');   // v3.7.25 限流降速语音
      }
    } else slowStreak = 0;
    wash.done = settledWash(st);
    wash.batchAt = Number(st.startedAt) || 0;
    wash.serverActive = st.mine !== false && !wash.done && st.status === 'running' && wash.batchAt > 0;
    // v2.8.0 扣费统计：gen=实际生成张数（生成即扣费），chargeRate=单价，me=余额/当日用量
    if (st.stats && st.stats.gen != null) wash.gen = st.stats.gen;
    if (st.settings && st.settings.charge) wash.chargeRate = st.settings.charge;
    if (st.me) {
      wash.balance = (st.me.balance != null) ? st.me.balance : wash.balance;
      wash.today = st.me.today || 0;
      wash.todaySpent = st.me.todaySpent || 0;
    }
    // 余额预警：低于阈值只提醒一次（阈值可在 cfg.lowBal 配，默认 ¥10）
    if (wash.balance != null && wash.balance <= (cfg.lowBal || 10) && !wash.lowWarned) {
      wash.lowWarned = true;
      notify('⚠️ 余额偏低', '当前余额 ¥' + Number(wash.balance).toFixed(2) + '，快不够跑了，请及时充值');
      speak('余额不多了，记得充值，不然跑到一半要停了。');   // v3.7.25 余额预警语音
      log('⚠️ 余额预警：当前余额 ¥' + Number(wash.balance).toFixed(2) + '，请及时充值，避免跑到一半停');
      catSay('⚠️ 喝…喵，余额只剩 <b>¥' + Number(wash.balance).toFixed(2) + '</b> 了，记得充值呀，不然跑到一半我要断粮啦');   // v2.9.0
    }
    // 顶栏额度/余额实时刷新
    try {
      var qn = document.querySelector('.mscb-quota-n');
      if (qn && wash.balance != null)
        qn.textContent = '余额 ¥' + Number(wash.balance).toFixed(2) + ' · 今日已出 ' + (wash.today || 0) + ' 张';
    } catch (e) {}
    try { completionVoiceObserve(st, voiceOptions && voiceOptions.silentComplete); } catch (e) { log('⚠️ 完成提醒未执行，请检查语音设置；业务结果不受影响'); }
  }
  function washMine() {
    // v3.6.2：服务端只下发「本单」产品，结果区就全显示。
    // 勾选只决定「这一批要跑谁」，不该决定「结果区显示谁」——
    // 否则刷新页面后勾选一变，上一单的成品图就凭空消失了（其实图和单都还在服务端）。
    return wash.products || [];
  }
  function washDoneSum() {
    var n = 0; washMine().forEach(function (s) { n += s.done; });
    return n;
  }
  // 总时间行：预计剩余 + 实际已用 + 产能
  // v2.8.0 扣费统计文案：实际扣费张数 × 单价（生成即扣费，暂停/重试失败不扣）
  function billLine() {
    var n = wash.gen || washDoneSum();
    var amt = n * (wash.chargeRate || 0.06);
    return '已扣费 ' + n + ' 张 · 约 ¥' + amt.toFixed(2)
      + (wash.balance != null ? '（余额 ¥' + Number(wash.balance).toFixed(2) + '）' : '');
  }
  function washTimeLine() {
    if (!timeEl) return;
    if (!wash.on) { timeEl.textContent = ''; return; }
    if (wash.done && missingWashProducts().length) {
      timeEl.textContent = '本轮已结束 · 已保存 ' + washDoneSum() + '/' + wash.plan + ' 张 · 等待补齐';
      return;
    }
    if (localRunMode) {
      // v3.7.39 本地直连专用时间行：之前错套洗图台 generationTiming 文案，显示「未完整记录/已扣费 0 张」假数据。
      // 现在全部用本地真实数据：已用时长 + 剩余估算（按本单实际出图速度）+ 已扣费张数×单价。
      var doneSum = washDoneSum();
      var remN = Math.max(0, (wash.plan || 0) - doneSum);
      var el = Date.now() - (wash.startedAt || wash.t0 || Date.now());
      var eta = doneSum >= 3 ? Math.round(remN * (el / doneSum) + 20000) : remN * learnedSecPerImg() * 1000;
      timeEl.textContent = '⏱ 已用 ' + fmtDur(el) + (remN > 0 ? ' · 剩约 ' + fmtDur(eta) : ' · ✅')
        + ' · 💳 已扣费 ' + doneSum + ' 张 · 约 ¥' + (doneSum * (wash.chargeRate || 0.06)).toFixed(2)
        + (wash.balance != null ? '（余额 ¥' + Number(wash.balance).toFixed(2) + '）' : '');
      return;
    }
    var mine = washMine();
    var doneSum = washDoneSum();
    var remaining = Math.max(0, wash.plan - doneSum);
    var etaMs = wash.rate > 0 ? remaining / wash.rate * 60000 : remaining * learnedSecPerImg() * 1000;   // 无实时产能时用历史平均
    timeEl.textContent = generationSummaryText(wash.generationTiming, etaMs, wash.done)
      + (wash.rate ? ' · 产能 ' + wash.rate + '张/分' : '')
      + ' · 💳 ' + billLine();

  }
  // v2.8.0 经营小看板：今日单量/出图/花费 + 差评率（本地统计，老板一屏看完）
  function pushRunLog(extra) {
    try {
      var d = new Date(), pad = function (x) { return (x < 10 ? '0' : '') + x; };
      var rec = { day: d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()), at: Date.now(),
        links: (extra && extra.links) || washMine().length,
        imgs: (extra && extra.imgs) || (wash.gen || washDoneSum()),
        charge: +(((extra && extra.imgs) || (wash.gen || washDoneSum())) * (wash.chargeRate || 0.06)).toFixed(2),
        durSec: wash.generationTiming && typeof wash.generationTiming.elapsedMs === 'number' ? Math.round(wash.generationTiming.elapsedMs / 1000) : null,
        fail: (extra && extra.fail) != null ? extra.fail : washMine().reduce(function (a, s) { return a + (s.fail || 0); }, 0) };
      cfg.runLog = (cfg.runLog || []).concat([rec]).slice(-60);
      saveCfg(); dashRender();
      // v2.9.0 单据小结：每单跑完日志里一条，方便日结
      log('🧾 本单小结：' + rec.links + ' 链接 · ' + rec.imgs + ' 张 · 💳 ¥' + rec.charge.toFixed(2)
        + ' · 用时 ' + fmtDur(rec.durSec == null ? null : rec.durSec * 1000) + (rec.fail ? ' · 失败 ' + rec.fail + ' 张' : ' · 全部成功'));
    } catch (e) {}
  }
  function dashRender() {
    var el = document.querySelector('.mscb-dash');
    if (!el) return;
    var d = new Date(), pad = function (x) { return (x < 10 ? '0' : '') + x; };
    var today = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
    var runs = (cfg.runLog || []).filter(function (r) { return r.day === today; });
    var imgs = 0, charge = 0, dur = 0, links = 0;
    runs.forEach(function (r) { imgs += r.imgs; charge += r.charge; dur += r.durSec; links += r.links; });
    var good = 0, bad = 0;
    for (var k in cfg.ratings) { if (cfg.ratings[k] === 1) good++; else if (cfg.ratings[k] === 0) bad++; }
    var badRate = (good + bad) ? Math.round(bad * 100 / (good + bad)) : null;
    el.innerHTML = '';
    var mk = function (t) {
      var s = document.createElement('span'); s.textContent = t; el.appendChild(s);
    };
    mk('📊 今日：' + runs.length + ' 单 / ' + links + ' 链接');
    mk('🖼️ ' + imgs + ' 张');
    mk('💳 ¥' + charge.toFixed(2));
    if (runs.length) mk('⏱ 均 ' + fmtDur(Math.round(dur / runs.length)) + '/单');
    if (badRate != null) mk(badRate <= 10 ? '👍 差评率 ' + badRate + '%' : '⚠️ 差评率 ' + badRate + '%');
    if (!runs.length) mk('今天还没跑单，按「启动」开第一单');
    // v2.9.0 看板导出：近 60 单记录导 CSV，给老板做周报
    var exp = document.createElement('span');
    exp.textContent = '📄 导出';
    exp.title = '导出最近 60 单记录（日期/链接/张数/扣费/耗时/失败）';
    exp.className = 'mscb-dashexp';   // v3.7.0 改用主题变量，不再写死橙色
    exp.onclick = function () { exportRunLog(); };
    el.appendChild(exp);
  }
  // v2.9.0 看板记录导出 CSV
  function exportRunLog() {
    var logs = cfg.runLog || [];
    if (!logs.length) {
      // v3.7.63 没跑单记录时不再“看起来没反应”：自动改为导出当前已抓取的商品表格
      log('ℹ️ 还没有跑单记录——已自动改为导出「当前已抓取的商品表格」');
      var b = document.querySelector('.mscb-expall');
      if (b) { b.click(); }
      else { log('❌ 面板上没找到「一键导出已抓取数据」按钮，请直接点那个按钮'); }
      return;
    }
    var lines = ['日期,时间,链接数,出图张数,扣费¥,用时秒,失败张数'];
    logs.forEach(function (r) { lines.push([r.day, new Date(r.at).toTimeString().slice(0, 8), r.links, r.imgs, r.charge, r.durSec, r.fail].map(csvCell).join(',')); });
    var blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = '经营看板_' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 8000);
    log('📄 已导出经营看板 ' + (logs.length) + ' 条记录（含今日之前的，最近 60 单）');
    catSay('📄 喵！看板记录导好了，给老板的周报素材这不就有了～');
  }
  // v3.7.63 本机直连手动导入兑底：把本单已生成的 48 列导入行（wash.products[].rowCache）直接下载成 CSV
  function exportLocalRows() {
    var rows = [];
    (wash.products || []).forEach(function (p) { if (p && p.rowCache) rows.push(p.rowCache); });
    if (!rows.length) { log('❌ 本单还没有已生成的导入行：先跑完/续跑恢复任务，再点本按钮'); return; }
    var csv = '\ufeff' + [TPL_HDR.map(csvCell).join(',')].concat(rows.map(function (f) {
      return TPL_HDR.map(function (h) { return csvCell(f[h] || ''); }).join(',');
    })).join('\r\n') + '\r\n';
    var d = new Date(), pad = function (x) { return (x < 10 ? '0' : '') + x; };
    var name = '洗图导入表_' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '_' + pad(d.getHours()) + pad(d.getMinutes()) + '_' + rows.length + '品.csv';
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 8000);
    log('✅ 已导出 ' + name + '：' + rows.length + ' 个商品（48 列，图链已换成本机洗好的图）。手动导入：妙手采集箱 → 导入 → 导出妙手产品再导入 页签 → 拖入这张表 → 店铺全选 → 确定');
    catSay('📄 喵！导入表导好了，' + rows.length + ' 个商品，拖进妙手「导出妙手产品再导入」就能手动导入～');
  }
  // v3.7.87 发布当前（本地直连）：暂停/卡图时客户不想干等，把已完成商品的图先导入妙手。
  // 已发布的行打 __published 标记，本单跑完后的自动导入会跳过它们，不产生重复链接
  async function localPublishNow() {
    if (localPublishing) { log('⏳ 发布当前正在进行中，稍等'); return; }
    var doneRows = (wash.products || []).map(function (p2) { return p2 && p2.rowCache; }).filter(Boolean);
    var pubRows = doneRows.filter(function (r2) { return !r2.__published; });
    if (!pubRows.length) { log(doneRows.length ? 'ℹ️ 已完成的 ' + doneRows.length + ' 个商品都发布过了，没有新增可发' : 'ℹ️ 还没有已完成的商品可发布（每个商品跑完才能发）'); return; }
    if (!window.confirm('把当前已完成的 ' + pubRows.length + ' 个商品先导入妙手？\n\n· 只发已完成的部分，没跑完的商品不受影响\n· 这些商品跑完后不会再重复自动导入\n· 建议先点「⏸ 暂停」再发布，避免边跑边发')) { log('↩️ 已取消发布当前'); return; }
    localPublishing = true;
    try {
      var csvText2 = '\ufeff' + [TPL_HDR.map(csvCell).join(',')].concat(pubRows.map(function (f2) { return TPL_HDR.map(function (h2) { return csvCell(f2[h2] || ''); }).join(','); })).join('\r\n') + '\r\n';
      log('📤 发布当前：正在导入 ' + pubRows.length + ' 个已完成商品…');
      var r2 = await importSend(csvText2, 'wash-local-publish-' + pubRows.length + '品.csv', 90, function (s2) { log('   · ' + s2); });
      if (r2 && r2.ok) {
        pubRows.forEach(function (rr2) { rr2.__published = true; });
        wash.rpa = true;
        log('🎉 发布当前完成：成功 ' + (r2.okN || 0) + ' 失败 ' + (r2.failN || 0) + ' 条 —— 妙手「导入记录」查看；剩余商品跑完后照常自动导入');
        catSay('🚀 已把当前完成的 ' + (r2.okN || 0) + ' 条先发到妙手了～');
      } else log('❌ 发布当前失败：' + String((r2 && r2.error) || '未知').slice(0, 140));
    } catch (ePub) { log('❌ 发布当前异常：' + String(ePub.message || ePub).slice(0, 140)); }
    finally { localPublishing = false; washRender(); }
  }
  function washStatusText(s) {
    if (s.localStage) return s.localStage;   // v3.7.27c 本地直连：用本地实时阶段文案（排队/出图 x-y/n/改标题/完成/失败）
    if (s.status === 'done') return '✅ 完成';
    if (s.status === 'running' || s.status === 'master') return '🎨 洗图中';
    if (s.fail > 0) return '⚠️ ' + s.fail + ' 张失败';
    if (s.status === 'paused') return '⏸ 排队外';
    return '⏳ 排队';
  }
  function washRender() {
    if (!resEl) return;
    if (resBtnsEl) {
      var bad = missingWashProducts().length;
      resBtnsEl.style.display = '';
      var rrpa = resBtnsEl.querySelector('.mscb-rrpa');
      if (rrpa) {
        // v3.7.87 本地直连模式下恢复「发布当前」按钮：跑单中（暂停/卡图）只要有已完成商品就能先发妙手；
        // 之前 v3.7.27c 在本地模式整个隐藏了它，客户暂停/卡图时没有任何手动发布入口
        var doneRowsN = localRunMode ? (wash.products || []).filter(function (p2) { return p2 && p2.rowCache && !p2.rowCache.__published; }).length : 0;
        rrpa.style.display = (!localRunMode || (!wash.done && doneRowsN > 0)) ? '' : 'none';
        rrpa.disabled = localRunMode ? localPublishing : (!wash.done || busy || rerunning || repairBusy);
        if (localRunMode) {
          rrpa.textContent = '📤 发布当前（已完成 ' + doneRowsN + ' 品先发妙手）';
          rrpa.title = localPublishing ? '正在发布中…' : '把已完成的商品先导入妙手；建议先点「⏸ 暂停」再发布；这些商品跑完后不会重复自动导入';
        } else {
          rrpa.title = !wash.done ? '生成完成后可上传并导入' : (busy || rerunning || repairBusy) ? '当前任务处理中，请等待完成' : wash.rpa ? '已导入过，再次导入可能产生重复链接，将先询问确认' : '使用现有流程生成表格并导入妙手';
          var apiFirstNow = cfg.apiFirst !== false;
          rrpa.textContent = apiFirstNow
            ? (wash.rpa ? '🚀 再次上传并导入（直连·秒级）' : '🚀 一键上传并导入（直连·秒级）')
            : (wash.rpa ? '🚀 再次上传并导入（RPA）' : '🚀 一键上传并导入（RPA）');
        }
      }
      var rprev = resBtnsEl.querySelector('.mscb-rprev');
      if (rprev) rprev.style.display = wash.done ? '' : 'none';
      var rcsv = resBtnsEl.querySelector('.mscb-rcsv');   // v3.4.6 全自动也能导出已转换表格核对
      if (rcsv) { rcsv.style.display = (!localRunMode && wash.done) ? '' : 'none'; rcsv.disabled = false; }   // v3.7.27c
      var lexp = resBtnsEl.querySelector('.mscb-lcsv');   // v3.7.63 本机直连：导出本单已生成的 48 列导入表（手动导入兑底）
      if (lexp) { lexp.style.display = (localRunMode && wash.done) ? '' : 'none'; lexp.disabled = false; }
      var rrep = resBtnsEl.querySelector('.mscb-rrepair');
      if (rrep) { rrep.style.display = (!localRunMode && wash.done && bad) ? '' : 'none'; rrep.disabled = false; }   // v3.7.27c
      var rrfail = resBtnsEl.querySelector('.mscb-rrfail');
      if (rrfail) { rrfail.style.display = (!localRunMode && wash.done && bad) ? '' : 'none'; rrfail.disabled = false; }   // v3.7.27c
    }
    if (!wash.on || !wash.products.length) { resEl.classList.remove('show'); resEl.innerHTML = ''; return; }
    resEl.classList.add('show');
    resEl.innerHTML = '';
    var mine = washMine();
    if (!mine.length) { resEl.classList.remove('show'); return; }
    mine.forEach(function (s) {
      var it = items.get(s.srcPid);
      var row = document.createElement('div');
      row.className = 'mscb-resrow';
      var th = document.createElement('div');
      th.className = 'mscb-resthumb';
      th.title = '点开看成品图';
      th.onclick = function () { openPreview([s]); };
      var im = document.createElement('img');
      im.loading = 'lazy';
      im.onerror = function () { im.style.display = 'none'; };
      im.onload = function () { im.style.display = ''; };
      var u0 = s.done > 0 ? shotImgSrc(s.pid, 0) : ((it && it.imgs && it.imgs[0]) || '');
      if (!u0) im.style.display = 'none';
      else loadImgViaBg(im, u0);   // v3.4.7 http 图走后台转 dataURL，绕过 https 页面混合内容拦截
      th.appendChild(im);
      row.appendChild(th);
      var mid = document.createElement('div');
      mid.className = 'mscb-resmid';
      var t1 = document.createElement('div');
      t1.className = 'mscb-rest1';
      var nm = (it && it.title) || s.title || ('产品 ' + s.srcPid);
      if (s.copyIdx > 0) nm += '（副本' + (s.copyIdx + 1) + '）';
      if (noteByPid[s.srcPid]) nm += ' 💬';
      var nmEl = document.createElement('span');
      nmEl.className = 'mscb-resname'; nmEl.textContent = nm; nmEl.title = nm;
      var cnt = document.createElement('span');
      cnt.className = 'mscb-rescnt' + (s.done >= s.total ? ' ok' : '');
      cnt.textContent = s.done + '/' + s.total + ' 张';   // v3.7.34 进度按张数显示（不是按链接）
      cnt.title = '已出 ' + s.done + ' 张 / 共 ' + s.total + ' 张';
      t1.appendChild(nmEl); t1.appendChild(cnt);
      var t2 = document.createElement('div');
      t2.className = 'mscb-rest2';
      var perEta = s.status === 'done' || wash.done ? '' : (' · 预计 ' + fmtDur(localRunMode ? Math.max(0, s.total - s.done) * learnedSecPerImg() * 1000 : (s.total - s.done) / (wash.rate > 0 ? wash.rate : 3) * 60000));
      var perAct = s.status === 'done' ? (typeof s.doneAt === 'number' ? ' · 用时 ' + fmtDur(s.doneAt) : ' · 用时未记录')
        : (localRunMode && s.linkT0 ? ' · 已跑 ' + fmtDur(Date.now() - s.linkT0) : '');   // v3.7.39 每链接计时：跑的时候实时「已跑」，完成显示「用时」
      t2.textContent = washStatusText(s) + (s.done < s.total && s.status !== 'done' ? (' · 还差 ' + (s.total - s.done) + ' 张') : '') + perEta + perAct;
      var bar = document.createElement('div');
      bar.className = 'mscb-resbar';
      var bi = document.createElement('i');
      bi.style.width = Math.min(100, Math.round(100 * s.done / Math.max(1, s.total))) + '%';
      bar.appendChild(bi);
      mid.appendChild(t1); mid.appendChild(t2); mid.appendChild(bar);
      row.appendChild(mid);
      var acts = document.createElement('div');
      acts.className = 'mscb-resacts';
      var mk = function (label, tip, fn, dis) {
        var b = document.createElement('button');
        b.textContent = label;
        if (tip) b.title = tip;   // v3.6.0 鼠标悬浮说明
        b.disabled = !!dis;
        b.onclick = fn;
        acts.appendChild(b);
      };
      mk('🔍', '预览：查看这个链接已生成的全部成品图（1:1，可对比原图/放大）', function () { openPreview([s]); });
      mk('⬇️', '下载：把这个链接的全部成品图打包保存到电脑（洗完后可用）', function () { dlProduct(s); }, s.status !== 'done');
      mk('🩹', '补图：只重出这个链接缺失/失败的图，已生成的图片不动（不重复花冤枉钱）；补完自动把没发布过的链接重新导入妙手', async function () {
        if (busy) { log('⏳ 当前有任务在跑，等它结束再补图'); return; }
        if (!(wash.products || []).some(function (x) { return x.local; })) { log('ℹ️ 服务端洗图单请用上面的「🩹 补失败图」大按钮'); return; }
        busy = true;
        try {
          var before = localMissingPairs(s.srcPid).length;
          log('🩹 开始补图「' + String(s.title || s.srcPid).slice(0, 20) + '」：本地登记缺 ' + before + ' 张…');
          if (!before) log('ℹ️ 该链接没有登记缺图记录（可能当时失败在传图等其他环节）。');
          var left = await localRepairAll(s.srcPid);
          // v3.7.59 补完图后：没发布过的链接（rowCache 缺失）自动重建导入行并提交妙手
          if (!left && !s.rowCache) {
            var built = localRowForSrcPid(s.srcPid);
            if (built && built.row) {
              log('📤 该链接此前未发布（当时失败），补图已齐，正在重新导入妙手…');
              var csvOne = '\ufeff' + [TPL_HDR.map(csvCell).join(',')].concat([TPL_HDR.map(function (h) { return csvCell(built.row[h] || ''); }).join(',')]).join('\r\n') + '\r\n';
              var rOne = await apiImport(csvOne, 'wash-repair-' + s.srcPid + '.csv', 92, function (st2) { log('   · ' + st2); });
              if (rOne && rOne.ok) { s.rowCache = built.row; log('🎉 补图链接已重新导入妙手（' + (rOne.okN || 1) + ' 条）——到「导入记录」查看'); }
              else log('⚠️ 重新导入未确认成功，请到妙手「导入记录」核对后手动重试');
            } else if (built && built.need) {
              log('⚠️ 补完后仅 ' + (5 - built.need) + ' 张生成图，不足妙手轮播图最低 5 张（补原图也不够）；建议对该链接 🔁 重跑');
            } else {
              log('⚠️ 该链接缺原始采集资料，无法自动重建导入行；请对该链接 🔁 重跑');
            }
          }
          setProg(100, left ? ('⚠️ 该链接仍缺 ' + left + ' 张，可 🔁 重跑或到预览里单张重生成') : '✅ 该链接补图完成' + (s.rowCache ? '' : '（已重新导入妙手）'));
        } catch (eRp) { log('❌ 补图出错：' + String(eRp && eRp.message || eRp).slice(0, 160)); setProg(null, '❌ 补图出错：' + String(eRp && eRp.message || eRp).slice(0, 80)); }
        finally { busy = false; washRender(); }
      }, busy);
      mk('🔁', '重跑：这个链接的图全部重新生成', function () { rerunOne(s.pid); }, rerunning || busy);
      // v3.7.83 按用户要求移除「💬 修改建议」按钮：容易误点弹出弹窗造成困惑，且客户几乎不用（面板顶部的修改建议框已够用）
      row.appendChild(acts);
      resEl.appendChild(row);
    });

  }
  // v3.2.6 图片类型：第 1 张=卖点主图，第 2~10 张=服务端分镜 SLOTS（名称缓存自 /api/rules-get，拉不到用内置同名清单）
  var PV_SLOT_NAMES = ['场景图', '细节材质图', '使用说明图', '卖点图解', '注意事项图', '模特图', '竞品对比图', '尺寸标注图', '实物尺寸比对图'];
  var pvSlotsCache = null;
  function pvImgType(i) {
    if (i === 0) return '卖点主图';
    var nm = (pvSlotsCache && pvSlotsCache[i - 1]) || PV_SLOT_NAMES[i - 1];
    return nm || ('分镜 ' + i);
  }
  // 预览弹窗：4 列卡片网格（序号+图片类型+重生成/看提示词按钮），点图开原图
  function openPreview(prods) {
    var mask = document.querySelector('.mscb-pvmask');
    if (!mask) return;
    var list = (prods && prods.length ? prods : washMine()).filter(function (s) { return s.done > 0; });
    var grid = mask.querySelector('.mscb-pvgrid');
    var ttl = mask.querySelector('.mscb-pvtitle');
    var h = mask.querySelector('.mscb-pv-h');
    grid.innerHTML = '';
    if (!list.length) { log('ℹ️ 还没有生成好的图可预览（每张图完成后会出现在这里）'); return; }
    var total = 0;
    var pvSeq = [];   // v3.7.34 整组图序列：点第几张就放大第几张，可左右切换
    list.forEach(function (s) {
      var it = items.get(s.srcPid);
      var cap = document.createElement('div');
      cap.className = 'mscb-pvtitle';
      cap.textContent = ((it && it.title) || s.title || s.srcPid) + (s.copyIdx > 0 ? '（副本' + (s.copyIdx + 1) + '）' : '');
      grid.appendChild(cap);
      for (var i = 0; i < s.total; i++) {
        (function (pid, srcPid, idx, copyIdx, sRow) {
          var card = document.createElement('div');
          card.className = 'mscb-pvcard';
          // 序号 + 图片类型 + 每张图自己的按钮（🔁 重生成 / 💬 看提示词）
          var bar = document.createElement('div');
          bar.className = 'mscb-pvbar';
          var no = document.createElement('span'); no.textContent = '#' + (idx + 1);
          var typ = document.createElement('span'); typ.className = 'mscb-pvtyp';
          typ.textContent = pvImgType(idx); typ.title = pvImgType(idx);
          var btns = document.createElement('span'); btns.className = 'mscb-pvbtns';
          var bCmp = document.createElement('button'); bCmp.textContent = '🆚';
          bCmp.title = '整单对比：左边这个链接的全部采集原图（未修改），右边全部洗后成品图，按张数对齐（点图可放大）';
          bCmp.onclick = function () {
            var it2 = items.get(srcPid) || items.get(String(srcPid)) || items.get(Number(srcPid));
            // v3.7.68 对比图原图修复：列表行 imgs 只有缩略图（1张），完整原图集在详情抓取后的 raw.imgUrls 里——
            // 之前只取 it2.imgs 所以只显示 1 张（和 4624 行补位源图逻辑保持一致），两个来源合并去重
            var origs = (Array.isArray(it2 && it2.imgs) ? it2.imgs : []).slice();
            var rawImgs = (it2 && it2.raw && Array.isArray(it2.raw.imgUrls)) ? it2.raw.imgUrls : [];
            rawImgs.forEach(function (u2) { if (u2 && origs.indexOf(u2) < 0) origs.push(u2); });
            if (!origs.length && it2 && Array.isArray(it2.raw && it2.raw.images)) it2.raw.images.forEach(function (u2) { if (typeof u2 === 'string' && /^https?:/.test(u2) && origs.indexOf(u2) < 0) origs.push(u2); });
            var totalN = (wash.state[pid] && wash.state[pid].total) || sRow.total || 10;
            var washes = [];
            for (var k = 0; k < totalN; k++) washes.push(washImgUrl(pid, k));
            var tf = sRow.titleFinal || (sRow.rowCache ? { orig: ((it2 && it2.title) || sRow.title || ''), zh: String(sRow.rowCache['产品名称'] || ''), en: String(sRow.rowCache['英文标题'] || '') } : null);   // v3.7.82 标题对比
            if (compareApi) compareApi.open(origs, washes, ((it2 && it2.title) || sRow.title || ('链接 ' + srcPid)) + (sRow.copyIdx > 0 ? '（副本' + (sRow.copyIdx + 1) + '）' : ''), tf);
          };
          var bRe = document.createElement('button'); bRe.textContent = '🔁';
          bRe.title = '重新生成这张图（删旧图按当前规则重出，其他 9 张不动，单独计 1 张）';
          bRe.onclick = function () { regenImg(pid, idx); };
          var bPr = document.createElement('button'); bPr.textContent = '💬';
          bPr.title = '查看这张图的完整提示词（全局规则+系列约束+分镜+类目补充+固定参数+修改建议）';
          bPr.onclick = function () { showImgPrompt(srcPid, idx); };
          btns.appendChild(bCmp); btns.appendChild(bRe); btns.appendChild(bPr);
          bar.appendChild(no); bar.appendChild(typ); bar.appendChild(btns);
          card.appendChild(bar);
          var im = document.createElement('img');
          im.loading = 'lazy';
          im.setAttribute('data-pid', pid); im.setAttribute('data-idx', idx);
          var srcNow = shotImgSrc(pid, idx);
          var myPos = pvSeq.length;
          pvSeq.push({ u: srcNow, cap: ((it && it.title) || s.title || '') + ' · #' + (idx + 1) + ' ' + pvImgType(idx) });
          im.title = '#' + (idx + 1) + ' ' + pvImgType(idx) + '（点开放大，← → 可切换）';
          im.onclick = function () { if (zoomApi) zoomApi.openSeq(pvSeq, myPos); };
          var missEl = document.createElement('div');
          missEl.className = 'mscb-pvmiss'; missEl.style.display = 'none';
          missEl.textContent = '⏳ 生成中/未生成';
          loadImgViaBg(im, srcNow, missEl);   // v3.7.1 带失败自动重试
          card.appendChild(im); card.appendChild(missEl);
          grid.appendChild(card);
          total++;
        })(s.pid, s.srcPid, i, s.copyIdx, s);
      }
    });
    h.textContent = '🖼️ 成品图预览（' + list.length + ' 个链接 · ' + total + ' 张 · 1:1 展示；🆚=整单原图对比 🔁=重生成该张 💬=看该张提示词，点图放大）';
    ttl.textContent = '';
    mask.classList.add('open');
    // v3.7.27c 本地直连：预览开着时每 4 秒自动补齐新出的图（本地单不走 /api/status 轮询）
    if (localRunMode && !wash.done && !mask._lpvTimer) {
      mask._lpvTimer = setInterval(function () {
        if (!mask.classList.contains('open') || wash.done) { clearInterval(mask._lpvTimer); mask._lpvTimer = null; return; }
        openPreview(washMine());
      }, 4000);
    }
    // v3.5.1 预览自动刷新：任务没跑完时每 6 秒轮询，生成好的格子自动补上（不再一直「生成中/未生成」），全部完成自动停
    if (!wash.done && washBaseOf() && String(cfg.code || '').trim()) {
      var pvTimer = setInterval(async function () {
        if (!mask.classList.contains('open')) { clearInterval(pvTimer); return; }
        try {
          var ca = 'code=' + encodeURIComponent(cfg.code || '') + '&admin=' + encodeURIComponent(cfg.code || '');
          var st = await relay(washBaseOf() + '/api/status?' + ca, {});
          if (!st) return;
          washSync(st);
          var allDone = true;
          list.forEach(function (s) {
            var cur = wash.state[s.pid] || {};
            if ((cur.done || 0) < s.total || (cur.fail || 0) > 0) allDone = false;
            for (var i = 0; i < s.total; i++) {
              if (i >= (cur.done || 0)) continue;          // 还没出的不刷
              var im2 = grid.querySelector('img[data-pid="' + s.pid + '"][data-idx="' + i + '"]');
              if (!im2 || im2.style.display !== 'none') continue;   // 已经显示的跳过（防重复拉取）
              var miss2 = im2.parentNode.querySelector('.mscb-pvmiss');
              if (miss2) miss2.style.display = 'none';
              im2.style.display = '';
              var u2 = washImgUrl(s.pid, i);
              loadImgViaBg(im2, u2 + (u2.indexOf('?') >= 0 ? '&' : '?') + 'r=' + Date.now());
            }
          });
          if (st.status === 'done' || allDone) {
            clearInterval(pvTimer);
            log('🖼️ 预览已自动刷新：所有图片生成完毕');
          }
        } catch (e) { /* 服务暂不可达，下一轮再试 */ }
      }, 6000);
    }
  }
  // v3.2.6 单张重生成：走服务端 /api/regen-img（只删并重出这一张，其他图原样保留，按 1 张计费）
  async function regenImg(pid, idx) {
    if (wash.state[String(pid)] && wash.state[String(pid)].local) { await localRegenIdx(pid, idx); return; }   // v3.7.27c 本地直连单张重生成
    if (busy || rerunning) { log('⏳ 当前有任务在跑，等它结束再重生成单张'); return; }
    var base = washBaseOf(), code = String(cfg.code || '').trim();
    if (!base || !code) { log('❌ 先在面板里填好洗图台地址和口令'); needSetup(); return; }
    var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
      + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
    busy = true; rerunning = true;
    progEl.classList.add('show');
    try {
      setProg(5, '🔁 第 ' + (idx + 1) + ' 张（' + pvImgType(idx) + '）重生成中：删旧图重出…');
      var r = await relay(base + '/api/regen-img?' + auth, { pid: String(pid), idx: idx });
      if (!r || !r.ok) throw new Error((r && r.error) || '重生成请求失败');
      var end = Date.now() + 15 * 60 * 1000, st = null;
      while (Date.now() < end) {
        await nap(3000);
        st = await statusSafe(base + '/api/status?' + auth, {});
        washSync(st); washRender();
        if (st.status === 'error') throw new Error('重生成失败：' + ((st.log || []).slice(-1)[0] || '未知'));
        if (st.status === 'done') break;
      }
      if (!st || st.status !== 'done') throw new Error('重生成超时（15 分钟），请稍后在洗图台查看');
      setProg(100, '✅ 第 ' + (idx + 1) + ' 张（' + pvImgType(idx) + '）已重新生成');
      log('🔁 单张重生成完成：第 ' + (idx + 1) + ' 张（' + pvImgType(idx) + '），预览里的图已刷新');
    } catch (e) {
      setProg(null, '❌ 单张重生成失败：' + (e && e.message ? e.message : e));
      log('❌ 单张重生成失败：' + (e && e.message ? e.message : e));
    } finally {
      busy = false; rerunning = false;
      washRender();
    }
    refreshPreviewImg(pid, idx);
  }
  // 重生成完成后只刷新对应那一格（加时间戳防缓存）
  function refreshPreviewImg(pid, idx) {
    var im = document.querySelector('.mscb-pvcard img[data-pid="' + pid + '"][data-idx="' + idx + '"]');
    if (!im) return;
    var u = washImgUrl(pid, idx);
    im.style.display = '';
    var card = im.closest ? im.closest('.mscb-pvcard') : null;
    var miss = card && card.querySelector('.mscb-pvmiss');
    if (miss) miss.style.display = 'none';
    loadImgViaBg(im, u + (u.indexOf('?') >= 0 ? '&' : '?') + 't=' + Date.now());   // v3.4.7 后台代理 + 时间戳防缓存
  }
  // v3.2.6 单张提示词查看：全局规则/系列约束/分镜要求 + 类目补充 + 固定参数 + 修改建议
  async function showImgPrompt(srcPid, idx) {
    var s = washMine().filter(function (x) { return x.srcPid === String(srcPid); })[0] || {};
    var L = ['【图片】' + (s.title || srcPid) + ' · 第 ' + (idx + 1) + ' 张 · ' + pvImgType(idx)];
    var base = washBaseOf(), code = String(cfg.code || '').trim();
    if (base && code) {
      try {
        var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
          + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
        var rr = await relay(base + '/api/rules-get?' + auth, {});
        if (rr && rr.rules) {
          if (Array.isArray(rr.rules.slots)) pvSlotsCache = rr.rules.slots.map(function (x) { return x.name; });
          if (idx === 0 && rr.rules.master) {
            L.push('【全局规则 · 主图提示词】\n' + String(rr.rules.master).trim());
          } else {
            if (rr.rules.series) L.push('【系列一致性约束（与主图同款同风格）】\n' + String(rr.rules.series).trim());
            var slots = rr.rules.slots || [];
            var slot = slots.length ? slots[(idx - 1) % slots.length] : null;
            if (slot && slot.text) L.push('【分镜要求 · ' + slot.name + '】\n' + String(slot.text).trim());
          }
        } else {
          L.push('（暂时拉不到服务端规则明细；实际生图使用服务端 rules.json）');
        }
      } catch (e) { L.push('（暂时拉不到服务端规则明细；实际生图使用服务端 rules.json）'); }
    }
    var tpl = tplForItem(s.tplKey || '') || {};
    var fx = (tpl.fixed && typeof tpl.fixed === 'object') ? Object.keys(tpl.fixed).map(function (k) {
      var v = String(tpl.fixed[k] || '').trim();
      return v ? ((TPL_FIXED_LABELS[k] || k) + '：' + v) : '';
    }).filter(Boolean).join('；') : '';
    L.push('【类目/模板补充' + (s.tplKey ? ' · ' + s.tplKey : '') + '】\n' + (String(tpl.prompt || '').trim() || '（未填，沿用全局默认）'));
    L.push('【固定参数（必须遵守）】\n' + (fx || '（未填固定值）'));
    L.push('【修改建议（最高优先级，冲突以此为准）】\n' + (noteByPid[String(srcPid)] || '（该链接没有修改建议）'));
    var text = L.join('\n\n');
    var mask = document.createElement('div');
    mask.className = 'mscb-mask open mscb-glass-overlay';
    mask.setAttribute('data-theme', (document.querySelector('.mscb-root') || {}).getAttribute ? document.querySelector('.mscb-root').getAttribute('data-theme') || 'classic' : 'classic');
    mask.innerHTML = '<div class="mscb-dialog" style="max-width:640px"><h4>💬 第 ' + (idx + 1) + ' 张（' + pvImgType(idx) + '）的完整提示词</h4>'
      + '<p class="mscb-hint" style="margin:0 0 8px">服务端按：修改建议 &gt; 类目补充 &gt; 固定参数 &gt; 全局规则/分镜 拼接后生成本张图：</p>'
      + '<textarea class="mscb-note-ta" style="min-height:200px" readonly></textarea>'
      + '<div class="mscb-dialog-btns"><button class="mscb-pv-x">关闭</button><button class="mscb-pv-copy">📋 复制</button></div></div>';
    document.body.appendChild(mask);
    var ta = mask.querySelector('textarea');
    ta.value = text;
    mask.querySelector('.mscb-pv-x').onclick = function () { mask.remove(); };
    mask.querySelector('.mscb-pv-copy').onclick = function () {
      ta.select();
      try { document.execCommand('copy'); log('📋 第 ' + (idx + 1) + ' 张（' + pvImgType(idx) + '）的提示词已复制'); } catch (e) {}
    };
    mask.addEventListener('click', function (ev) { if (ev.target === mask) mask.remove(); });
  }
  // 单链接重跑：走服务端 /api/rerun-product（只重生成这一个，别的链接不动）
  async function rerunOne(pid, opts) {
    opts = opts || {};
    if (wash.state[String(pid)] && wash.state[String(pid)].local) { await localRerunProd(pid); return true; }   // v3.7.27c 本地直连：按原提示词逐张重出
    if (busy || rerunning) { if (!opts.silent) log('⏳ 当前有任务在跑，等它结束再重跑'); return false; }
    var base = washBaseOf();
    var code = String(cfg.code || '').trim();
    if (!base || !code) { log('❌ 先在面板里填好洗图台地址和口令'); needSetup(); return false; }
    var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
      + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
    busy = true; rerunning = true;
    progEl.classList.add('show');
    var s = wash.state[pid];
    try {
      setProg(5, '🔁 重跑 ' + (s && s.srcPid ? s.srcPid : pid) + '：删除旧图，重新生成…');
      // v3.0.0：重跑带上最新修改建议 + 当前模板（服务端会更新产品上的 note/tpl 再生成）
      var note = noteByPid[String(s && s.srcPid || pid)] || '';
      var tpl = s ? tplForItem(s.tplKey || '') : null;
      var body = { pid: String(pid), note: note };
      if (tpl && (tpl.prompt || (tpl.fixed && Object.keys(tpl.fixed).length))) body.tpl = tpl;
      var r = await relay(base + '/api/rerun-product?' + auth, body);
      if (!r || !r.ok) throw new Error((r && r.error) || '重跑请求失败');
      if (s) { s.done = 0; s.fail = 0; s.doneAt = 0; s.status = 'master'; }
      var end = Date.now() + 30 * 60 * 1000, st = null;
      while (Date.now() < end) {
        await nap(3000);
        st = await statusSafe(base + '/api/status?' + auth, {});
        washSync(st);
        setProg(10 + Math.round(80 * washDoneSum() / Math.max(1, wash.plan)),
          '🔁 重跑中：' + washDoneSum() + '/' + wash.plan + ' 张…');
        var cur = wash.state[pid];
        if (st.status === 'error') throw new Error('重跑失败：' + ((st.log || []).slice(-1)[0] || '未知'));
        if ((cur && cur.status === 'done') || st.status === 'done') break;
      }
      if (!st || st.status !== 'done') { if (!(wash.state[pid] && wash.state[pid].status === 'done')) throw new Error('重跑超时，请稍后在洗图台查看'); }
      setProg(100, '✅ 重跑完成：' + pid + ' 的图已重新生成，可重新预览');
      log('🔁 重跑完成：' + pid + '（洗图台已作废旧表格，确认满意后点「🚀 一键上传并跑 RPA」会自动重新生成表格）');
      return true;
    } catch (e) {
      setProg(null, '❌ 重跑失败：' + (e && e.message ? e.message : e));
      return false;
    } finally {
      busy = false; rerunning = false;
      washRender();
    }
  }
  // v3.0.0 一键全部重跑失败项：补图后仍失败/缺图的链接逐个重跑（带各自修改建议），一个完成再下一个
  async function rerunFailed() {
    if (busy || rerunning) { log('⏳ 当前有任务在跑，等它结束再点'); return; }
    var bad = washMine().filter(function (s) { return s.done < s.total || s.fail > 0; });
    if (!bad.length) { log('✅ 当前勾选/全部链接的图都齐全，没有需要重跑的'); return; }
    log('🔁 准备重跑 ' + bad.length + ' 个失败/缺图链接（逐个跑，带各自修改建议）…');
    catSay('🔁 喵！我来挨个重跑失败的 <b>' + bad.length + '</b> 个，别急哦');
    var okN = 0, failN = 0;
    for (var i = 0; i < bad.length; i++) {
      var r = await rerunOne(bad[i].pid, { silent: true });
      if (r) okN++; else failN++;
      if (i < bad.length - 1) await nap(1200);
    }
    log('🔁 批量重跑结束：成功 ' + okN + ' 个' + (failN ? '，失败 ' + failN + ' 个（可再点一次重试）' : ''));
    catSay(failN ? '😿 有 ' + failN + ' 个还是没跑成，看看日志里啥原因' : '🎉 喵呜～失败的全补齐了！');
    notify(failN ? '🔁 重跑部分完成' : '🔁 失败项全部重跑完成', '成功 ' + okN + ' 个' + (failN ? '，失败 ' + failN + ' 个' : '') + '，去结果区预览验收');
  }
  // v3.7.84 「修改建议」弹窗已随 DOM 一并移除；noteByPid 数据层保留（cfg.notes 持久化、提示词预览仍会展示）
  // v3.0.0 提示词试算预览：全局规则+类目补充+固定参数+修改建议四层拼好给客户看一眼再启动
  var TPL_FIXED_LABELS = { material: '材质', style: '风格', size: '尺寸', scene: '适用场景' };
  // v3.7.26 画面风格 / 模特设置选项（模特设置只作用于「模特图」分镜，防止部分类目 AI 面部失真等问题）
  var TPL_STYLE_LABELS = { minimal: '极简北欧风', warm: '温馨居家风', studio: '影棚高级质感', natural: '清新自然光', festival: '节日氛围感', retro: '复古怀旧', urban: '时尚都市', outdoor: '户外阳光', cute: '童趣活泼', luxury: '轻奢质感', morandi: '莫兰迪色系', bright: '明亮通透' };
  var TPL_MODEL_LABELS = {
    race: { asian: '亚裔', european: '欧美白人', african: '非裔', latino: '拉丁裔', middleeast: '中东面孔', indian: '印度裔', multi: '多族裔' },
    face: { show: '露脸（自然正面）', hide: '不露脸（侧脸/背影，防面部失真）' },
    shot: { full: '全身', half: '半身', closeup: '面部特写', hand: '手部/手持特写' }
  };
  async function promptPreview() {
    // 用哪个模板：第一个勾选且分配了模板的商品 → 该预设；否则默认模板
    var firstTpl = null, presetName = '默认模板';
    items.forEach(function (v) { if (!firstTpl && v.sel !== false && v.title && v.tplKey) firstTpl = v; });
    var tpl = firstTpl ? tplForItem(firstTpl.tplKey) : JSON.parse(JSON.stringify(cfg.tpl || {}));
    if (firstTpl) presetName = firstTpl.tplKey;
    tpl = tpl || {};
    // 第 1 层：全局规则（服务端 rules.json，管理员口令可拉；拉不到给占位说明）
    var master = '';
    var base = washBaseOf(), code = String(cfg.code || '').trim();
    if (base && code) {
      try {
        var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
          + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
        var rr = await relay(base + '/api/rules-get?' + auth, {});
        if (rr && rr.rules && rr.rules.master) master = String(rr.rules.master).trim();
        if (rr && rr.rules && Array.isArray(rr.rules.slots)) pvSlotsCache = rr.rules.slots.map(function (x) { return x.name; });   // v3.2.6 缓存分镜名给预览标签
      } catch (e) { /* 拉不到就占位 */ }
    }
    var L = [];
    L.push('【第1层 · 全局规则（服务端统一规则：白底/无水印/禁词等）】\n' + (master || '（暂时拉不到服务端全局规则；实际生图会使用服务端 rules.json 里的规则）'));
    L.push('【第2层 · 类目/模板补充（预设：' + presetName + '）】\n' + (String(tpl.prompt || '').trim() || '（未填提示词补充，沿用全局默认）'));
    var fx = (tpl.fixed && typeof tpl.fixed === 'object') ? Object.keys(tpl.fixed).map(function (k) {
      var v = String(tpl.fixed[k] || '').trim();
      return v ? ((TPL_FIXED_LABELS[k] || k) + '：' + v) : '';
    }).filter(Boolean).join('；') : '';
    L.push('【第3层 · 固定参数（必须遵守）】\n' + (fx || '（未填固定值，不额外约束）'));
    var notes = [];
    items.forEach(function (v) {
      if (v.sel === false) return;
      var n = noteByPid[String(v.id)];
      if (n) notes.push(v.id + '：' + n);
    });
    L.push('【第4层 · 修改建议（最高优先级，冲突以此为准）】\n' + (notes.length ? notes.slice(0, 10).join('\n') + (notes.length > 10 ? '\n…共 ' + notes.length + ' 条' : '') : '（没有单链接修改建议）'));
    var text = L.join('\n\n');
    // 动态弹窗（复用对话框样式，关闭即移除）
    var mask = document.createElement('div');
    mask.className = 'mscb-mask open mscb-glass-overlay';
    mask.setAttribute('data-theme', (document.querySelector('.mscb-root') || {}).getAttribute ? document.querySelector('.mscb-root').getAttribute('data-theme') || 'classic' : 'classic');
    mask.innerHTML = '<div class="mscb-dialog" style="max-width:640px"><h4>👁 最终提示词预览（启动前试算）</h4>'
      + '<p class="mscb-hint" style="margin:0 0 8px">服务端生图时会按这个结构拼接：修改建议 &gt; 类目补充 &gt; 固定参数 &gt; 全局规则。下面是当前配置下会生效的内容：</p>'
      + '<textarea class="mscb-note-ta" style="min-height:180px" readonly></textarea>'
      + '<div class="mscb-dialog-btns"><button class="mscb-pv-x">关闭</button><button class="mscb-pv-copy">📋 复制</button></div></div>';
    document.body.appendChild(mask);
    var ta = mask.querySelector('textarea');
    ta.value = text;
    mask.querySelector('.mscb-pv-x').onclick = function () { mask.remove(); };
    mask.querySelector('.mscb-pv-copy').onclick = function () {
      ta.select();
      try { document.execCommand('copy'); log('📋 最终提示词已复制到剪贴板'); } catch (e) {}
    };
    mask.addEventListener('click', function (ev) { if (ev.target === mask) mask.remove(); });
    log('👁 已生成最终提示词预览（模板「' + presetName + '」，修改建议 ' + notes.length + ' 条）');
  }
  // v3.0.0 跑单前体检：余额够不够 / 洗图台通不通 / 勾选的商品齐不齐，有问题先报不启动
  async function preflight(mode) {
    var problems = [];
    // ① 勾选与素材
    var sel = [], noImg = 0, noTitle = 0;
    items.forEach(function (v) {
      if (v.sel === false) return;
      if (!v.title) { noTitle++; return; }
      if (!v.imgs || !v.imgs.length) { noImg++; return; }
      sel.push(v);
    });
    if (!sel.length) problems.push('没有可跑的商品（勾选的商品需要标题 + 至少 1 张图）');
    else {
      if (noTitle) problems.push(noTitle + ' 个勾选商品缺标题');
      if (noImg) problems.push(noImg + ' 个勾选商品缺图片（点 🔄 补采集试试）');
    }
    // ② 洗图台连通 + 余额；v3.7.22 本地直连模式（地址留空）改为体检 New API 令牌
    var base = washBaseOf(), code = String(cfg.code || '').trim();
    if (!base) {
      try {
        var tk = await chrome.runtime.sendMessage({ cmd: 'xtNewApiStatus' });
        if (!tk || !tk.ok || !tk.data || !tk.data.connected) problems.push('本地直连模式：生图还没保存生效——站点池要在「接口设置→站点池」保存后才算数（导入 JSON 会自动保存），或填生图网关二选一');
      } catch (eT) {
        problems.push('令牌状态检查失败：' + String(eT && eT.message || eT).slice(0, 60));
      }
    } else if (!code) {
      problems.push('洗图台口令没填');
    } else {
      try {
        var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
          + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
        var st = await statusSafe(base + '/api/status?' + auth, {});
        var bal = st && st.me && typeof st.me.balance === 'number' ? st.me.balance : null;
        var rate = (st && st.settings && st.settings.charge) || 0.06;
        var target = (st && st.settings && st.settings.target) || 10;
        var est = sel.length * target * rate;
        if (bal != null) {
          if (bal <= 0) problems.push('余额已用完（¥0.00），先充值再跑');
          else if (bal < est) problems.push('余额不足：预计本单需约 ¥' + est.toFixed(2) + '（' + sel.length + ' 商品 × ' + target + ' 张 × ¥' + rate + '），当前余额 ¥' + bal.toFixed(2));
        }
        if (st && st.status === 'running') problems.push('洗图台有任务正在跑（' + ((st.stats && st.stats.done) || 0) + '/' + (st.planImgs || '?') + ' 张），等它跑完或先暂停那边');
      } catch (e) {
        problems.push('洗图台连不上：' + String(e && e.message || e).slice(0, 60));
      }
    }
    return { ok: !problems.length, problems: problems, sel: sel.length, est: (sel.length * 10 * 0.06) };
  }

  // 复用 content.js 里已经实测过的 clickBtn/realClick（chrome.debugger 真实点击）
  // v3.2.6 支持悬停模式：妙手「导入」等按钮必须鼠标移上去才弹下拉菜单（合成 click 无效）
  // v3.4.4 按录屏定位根因：工具栏容器文字「一键搬运产品导入创建产品」会误命中 /导入创建产品/，
  // 点到大容器中心=点到工具栏空白处，弹窗根本不开。改为：命中多个候选时选面积最小的（最内层真实按钮）
  var stepNote = null;   // v3.4.4 rpaImport 期间把「重做」消息写进日志
  function rpaFind(patterns) {
    var A = R();
    if (!A) return null;
    for (var j = 0; j < patterns.length; j++) {
      var all = A.findBtnAll ? A.findBtnAll(patterns[j]) : null;
      if (!all || !all.length) continue;
      var best = all[0], bestArea = Infinity;
      for (var q = 0; q < all.length; q++) {
        var r = all[q].getBoundingClientRect();
        var a = r.width * r.height;
        if (a < bestArea) { bestArea = a; best = all[q]; }
      }
      return best;
    }
    return null;
  }

  async function rpaStep(name, patterns, waitMs, attempts, opts) {
    var A = R();
    if (!A) throw new Error('页面自动化组件没加载：刷新一下妙手页面再点红色按钮');
    var hoverMode = !!(opts && opts.hover && A.hoverBtn);
    var act = hoverMode ? A.hoverBtn : A.clickBtn;
    var tries = 0;   // v3.4.4 二重验证：动作未生效的重试次数（单独计数，找按钮的重试另算）
    for (var i = 0; i < (attempts || 12); i++) {
      while (paused) await A.sleep(800);   // 暂停期间不消耗重试次数
      var el = rpaFind(patterns);
      if (el) {
        setProg(null, 'RPA：' + name + ' ✓');
        await act(el);
        await A.sleep(waitMs || 1200);
        // v3.4.4 二重验证：操作后必须找到效果证据（opts.verify 出现 / opts.verifyGone 消失），
        // 没验证到就视为没点到，自动重做本步（宁慢勿错，不带着失效动作往下走）
        var ok = true;
        if (opts && opts.verify) {
          ok = false;
          for (var v = 0; v < 8 && !ok; v++) { if (rpaFind([].concat(opts.verify))) ok = true; else await A.sleep(300); }
        }
        if (ok && opts && opts.verifyGone) {
          for (var g = 0; g < 8 && ok; g++) { if (rpaFind([].concat(opts.verifyGone))) { ok = false; await A.sleep(400); } }
        }
        if (ok) return el;
        // v3.5.6 通道体检：真实点击不可用（debugger 挂不上/被占用，ego 等自动化浏览器必现）时，
        // 合成点击对妙手的下拉弹层无效，继续重做纯属空转——立即抛错让 importSend 走直连兜底
        var rcState = A.realClickState && A.realClickState();
        if (rcState && rcState.down) {
          throw new Error('真实点击通道不可用（' + (rcState.err || '调试协议被占用') + '）：本浏览器自动化点击失效，自动改走直连接口');
        }
        tries++;
        setProg(null, 'RPA：' + name + ' 动作未生效，回退重做（第 ' + tries + ' 次）…');
        if (stepNote) stepNote('↻ ' + name + ' 未生效，重做');
        // v3.5.6 修复：原来这里 i-- 抵消了循环自增，重试上限永远到不了 = 无限重做。
        // 现在重做也消耗 attempts，确保失败有界、能落到直连兜底
        continue;
      }
      // 目标迟迟没出现时重新点击锚点按钮（v3.4.5：「导入」是点击触发；点完菜单若被收起就再点一次）
      if (opts && opts.reHover) {
        var anchor = rpaFind(opts.reHover);
        if (anchor) await A.clickBtn(anchor);
      }
      await A.sleep(600);
    }
    throw new Error('RPA 卡在「' + name + '」：页面上没找到对应按钮' + diagHint(patterns));
  }

  // v3.4.4 失败诊断：把页面上可见的相关按钮文字列出来，日志一眼看出页面上到底有什么
  function diagHint(patterns) {
    try {
      var A = R();
      var seen = [];
      A.allRoots().forEach(function (doc) {
        Array.prototype.slice.call(doc.querySelectorAll('button,a,span,div,li,td,p,label')).forEach(function (x) {
          var t = (x.textContent || '').replace(/\s+/g, '');
          if (!t || t.length > 16 || seen.indexOf(t) >= 0) return;
          var r = x.getBoundingClientRect();
          if (r.width < 5 || r.height < 5) return;
          if (/导入|模板|再导入|店铺|确定|上传|全选/.test(t)) seen.push(t);
        });
      });
      if (seen.length) return '。页面上可见的相关元素：' + seen.slice(0, 18).join(' / ');
    } catch (e) {}
    return '';
  }

  function findImportFileInput() {
    var out = [];
    var A = R();
    if (!A) return null;
    A.allRoots().forEach(function (doc) {
      Array.prototype.slice.call(doc.querySelectorAll('input[type=file]')).forEach(function (inp) {
        if (/image/i.test(inp.accept || '')) return;   // 排除图片上传框
        out.push(inp);
      });
    });
    return out.length ? out[out.length - 1] : null;
  }

  function pickUpProductLinks() {
    var A = R(); var out = [];
    if (!A) return out;
    A.allRoots().forEach(function (doc) {
      Array.prototype.slice.call(doc.querySelectorAll('a[href]')).forEach(function (a) {
        var h = String(a.href || '');
        if (!/^https?:/i.test(h)) return;
        if (/(product|goods|item|detail|offer)/i.test(h) && !/\.(js|css|png|jpg|jpeg|gif|svg)(\?|$)/i.test(h)) out.push(h);
      });
    });
    return Array.from ? Array.from(new Set(out)) : out.filter(function (x, i) { return out.indexOf(x) === i; });
  }

  // v3.4.5 直连接口导入：绕过整个 RPA 点击链路，直接 POST 妙手导入接口（同源 fetch 自动带登录态）
  // 实测抓包：① getLastCollectBoxImportItemTask 拿上次 setting（含 shopIds）
  //           ② getCollectBoxImportFileItemCount 校验 CSV
  //           ③ createCollectBoxImportItemTask 提交（file + setting）
  //           ④ 轮询 getLastCollectBoxImportItemTask 等 status=finish，读 成功/失败 数
  async function validateImportCsv(file) {
    try {
      var form=new FormData();form.append('file',file);
      var reply=await fetch(location.origin+'/api/platform/pddkj/move/collect_box_import/getCollectBoxImportFileItemCount',
        {method:'POST',credentials:'same-origin',redirect:'error',body:form,signal:AbortSignal.timeout(15000)});
      if (!reply.ok) throw new Error('HTTP '+reply.status);
      var result=await reply.json();
      if (result.result!=='success'||!Number.isSafeInteger(result.itemNum)||result.itemNum<1) throw new Error('校验未确认有可导入商品');
      return result.itemNum;
    } catch (e) {
      var blocked=new Error('妙手未通过表格校验，本次未提交、不转 RPA。请检查表格后重试。');
      blocked.code='IMPORT_VALIDATION';
      throw blocked;
    }
  }
  async function apiImport(csvText, fileName, basePct, stepLog) {
    var t0 = Date.now();
    var name = (fileName || 'wash-import.csv').replace(/\.[a-z]+$/i, '');
    function done(n) { if (stepLog) stepLog(n, Math.round((Date.now() - t0) / 100) / 10); t0 = Date.now(); }
    var origin = location.origin;
    var LAST = origin + '/api/platform/pddkj/move/collect_box_import/getLastCollectBoxImportItemTask';
    var CREATE = origin + '/api/platform/pddkj/move/collect_box_import/createCollectBoxImportItemTask';
    function jpost(url, body) {
      return fetch(url, { method: 'POST', credentials: 'include', body: body || '' }).then(function (r) {
        return r.text().then(function (t) { try { return JSON.parse(t); } catch (e) { throw new Error(url.split('/').pop() + ' 返回异常：' + t.slice(0, 120)); } });
      });
    }
    setProg(basePct + 2, '直连 1/4：读取上次导入配置（店铺清单）…');
    var j1 = await jpost(LAST);
    var lastTask = j1 && j1.collectBoxImportItemTask;
    if (lastTask && lastTask.status && !/^(finish|fail|failed|error|cancel|canceled|cancelled|stop)$/i.test(lastTask.status)) {
      var busyError = new Error('妙手已有导入任务尚未完成，请等待结束后重试；本次未提交，不会转 RPA');
      busyError.code = 'IMPORT_BUSY'; throw busyError;
    }
    var setting = lastTask && lastTask.setting;
    var oldTaskId = lastTask && lastTask.collectBoxImportItemTaskId;
    // v3.7.65 导入配置自学习：读到一次真实 setting 就永久存档（chrome.storage），以后不再依赖手动导入
    var settingBuilt = false;
    if (setting) { try { chrome.storage.local.set({ xtSettingTpl: setting }); } catch (eS) {} }
    if (!setting) {
      var stTpl = await new Promise(function (res) { try { chrome.storage.local.get('xtSettingTpl', function (o) { res((o && o.xtSettingTpl) || ''); }); } catch (eG) { res(''); } });
      if (stTpl) { setting = String(stTpl); log('ℹ️ 妙手没有历史导入记录，改用本机存档的导入配置（上次成功导入自动存档）'); }
    }
    if (!setting) {
      // v3.7.65 全新账号：从已抓商品行自动识别店铺 ID，构造最简导入配置直连提交（不走 RPA）
      var shopIds = [];
      items.forEach(function (v) {
        var r = v.raw || {};
        [r.publishShopId, r.shopId, r.storeId].concat(Array.isArray(r.shopIds) ? r.shopIds : []).forEach(function (x) {
          var n = Number(x); if (n && shopIds.indexOf(n) < 0) shopIds.push(n);
        });
      });
      if (shopIds.length) {
        setting = JSON.stringify({ shopIds: shopIds });
        settingBuilt = true;
        log('ℹ️ 全新账号：已从采集箱数据自动识别 ' + shopIds.length + ' 个店铺，构造导入配置直连提交（不用手动导入，不走 RPA）');
      }
    }
    if (!setting) { var noSet = new Error('读不到导入配置，且采集箱数据里没识别到店铺 ID：点面板右上角「📤 导出导入表」导出一份空白模板 → 到妙手采集箱「导入 → 导出妙手产品再导入」页签拖入（不用等导入成功）→ 回采集页刷新 → 面板点「新任务开始」即可全链路跑通（之后本机永久存档，全自动）'); noSet.code = 'NO_SETTING'; throw noSet; }
    done('1.读取导入配置（' + ((setting.match(/shopIds/) && '含店铺清单') || '无店铺') + '）');

    setProg(basePct + 10, '直连 2/4：上传表格校验…');
    var mkFile = function () { return new File([csvText], fileName || 'wash-import.csv', { type: 'text/csv;charset=utf-8' }); };
    var verifiedCount = await validateImportCsv(mkFile());
    done('2.表格校验通过（识别 ' + verifiedCount + ' 条 · ' + Math.round(csvText.length / 1024) + 'KB）');

    setProg(basePct + 25, '直连 3/4：提交导入任务…');
    var fd3 = new FormData(); fd3.append('file', mkFile()); fd3.append('setting', setting);
    await waitResume('⏸ 已暂停，尚未向妙手提交。');
    var j3;
    try { j3 = await jpost(CREATE, fd3); }
    catch (e) { var unknown = new Error('提交结果未知，请先查看妙手导入记录；不会自动再次提交或转 RPA'); unknown.code = 'IMPORT_PENDING'; throw unknown; }
    if (!j3 || !j3.result) { var pending = new Error('提交结果待确认，请先查看妙手导入记录；不会自动再次提交或转 RPA'); pending.code = 'IMPORT_PENDING'; throw pending; }
    if (j3.result !== 'success') {
      var rejected = new Error((settingBuilt ? '自动构造的导入配置被拒：' : '提交导入被拒：') + String(j3.reason || j3.code || j3.result));
      if (settingBuilt) rejected.code = 'NO_SETTING';   // v3.7.65 构造配置被拒时不走 RPA，直接报原因
      else if (/存在导入任务未完成|等待任务结束|导入.*(?:进行中|未完成)/.test(String(j3.reason || ''))) rejected.code = 'IMPORT_BUSY';
      throw rejected;
    }
    done('3.提交导入任务');

    setProg(basePct + 35, '直连 4/4：盯导入结果…');
    var end = Date.now() + 180000;
    var tPoll = Date.now();
    while (Date.now() < end) {
      await new Promise(function (s) { setTimeout(s, 1500); });
      try {
        var j = await jpost(LAST);
        var task = j && j.collectBoxImportItemTask;
        if (!task) continue;
        var isNew = oldTaskId == null || String(task.collectBoxImportItemTaskId) !== String(oldTaskId);
        var mine = isNew && (!task.fileName || String(task.fileName).indexOf(name) >= 0);
        if (task.status === 'finish' && mine) {
          var okN = Number(task.successCount) || 0, failN = Number(task.failCount) || 0;
          return { ok: okN > 0, okN: okN, failN: failN, links: [] };
        }
        // v3.4.6 实测：服务器处理期间 processPercent 一直报 0（finish 才跳结果），
        // 别拿 0% 刷屏——只有真>0 才显示百分比，否则显示已盯秒数
        if (task.processPercent != null && task.status !== 'finish') {
          var pp = Number(task.processPercent) || 0;
          if (pp > 0) setProg(basePct + 35 + Math.round(pp * 0.3), '直连 4/4：导入进度 ' + pp + '%…');
          else setProg(basePct + 35, '直连 4/4：提交导入中（已盯 ' + Math.round((Date.now() - tPoll) / 1000) + ' 秒）…');
        }
      } catch (e) {}
    }
    var waiting = new Error('导入已提交，180 秒内尚未确认完成，请查看妙手导入记录；不会自动再次提交或转 RPA');
    waiting.code = 'IMPORT_PENDING'; throw waiting;
  }

  // v3.4.5 统一入口：直连接口优先（秒级、不弹窗、不点按钮），失败自动回退 RPA 点按钮
  async function importSend(csvText, fileName, basePct, stepLog) {
    // v3.5.8 顺序可切：默认「直连优先」（妙手导入接口，2~5 秒完成，任何浏览器都能跑），
    // RPA 只做兜底。理由：v3.5.4 切的 RPA 优先在有浏览器限制的环境里每次都要先撞墙再降级，白等十几秒。
    // 面板「⚡ 直连导入优先」取消勾选 → 回到 RPA 优先（真实人工流程，看得见摸得着）。
    var apiFirst = cfg.apiFirst !== false;
    if (apiFirst) {
      try {
        setProg(basePct + 2, '⚡ 直连导入：提交表格到妙手…');
        var r1 = await apiImport(csvText, fileName, basePct, stepLog);
        if (r1.ok) log('✅ 直连导入完成：成功 ' + (r1.okN != null ? r1.okN : '见导入记录') + ' 失败 ' + (r1.failN != null ? r1.failN : '0'));
        else log('⚠️ 直连已提交，结果待确认，请查看导入记录');
        showImportComplete(r1);
        return r1;
      } catch (eApi) {
        if (eApi && (eApi.code === 'IMPORT_BUSY' || eApi.code === 'IMPORT_PENDING' || eApi.code === 'IMPORT_VALIDATION')) { log('⚠️ ' + eApi.message); throw eApi; }
        if (eApi && eApi.code === 'NO_SETTING') { log('❌ 直连导入：' + eApi.message + '（v3.7.65 起不再走 RPA）'); throw eApi; }   // v3.7.65 配置问题不走 RPA，报清楚原因
        log('⚠️ 直连接口失败（' + String(eApi && eApi.message || eApi).slice(0, 80) + '），自动回退 RPA 点按钮…');
        try { miniShow(true); } catch (eM) {}
        var fallbackRpa = await rpaImport(csvText, fileName, basePct, stepLog);
        showImportComplete(fallbackRpa);
        return fallbackRpa;
      }
    }
    try {
      try { miniShow(true); } catch (eM) {}
      var res = await rpaImport(csvText, fileName, basePct, stepLog);
      if (res.ok) log('✅ RPA 导入完成：成功 ' + (res.okN != null ? res.okN : '见导入记录') + ' 失败 ' + (res.failN != null ? res.failN : '?'));
      else log('⚠️ RPA 已提交，结果待确认，请查看导入记录');
      showImportComplete(res);
      return res;
    } catch (eRpa) {
      log('⚠️ RPA 通道失败（' + String(eRpa && eRpa.message || eRpa).slice(0, 80) + '），自动回退直连接口兜底…');
      var fallbackApi = await apiImport(csvText, fileName, basePct, stepLog);
      showImportComplete(fallbackApi);
      return fallbackApi;
    }
  }

  // 真正的 RPA：导入 → 导入创建产品 → 「导出妙手产品再导入」标签 → 注入 CSV → 店铺全选 → 确定
  // v3.4.4 按客户实测纠正：妙手表必须走「导出妙手产品再导入」页签（按模板导入解析不了）；
  // 店铺下拉实际是「请选择或输入搜索」，点开后直接点「全选」；最后点绿色「确定」
  async function rpaImport(csvText, fileName, basePct, stepLog) {
    var A = R();
    if (!A) throw new Error('页面自动化组件没加载');
    stepNote = stepLog || null;   // v3.4.4 重做消息也进日志
    var tStep = Date.now();
    function done(name) {
      if (stepLog) stepLog(name, Math.round((Date.now() - tStep) / 100) / 10);
      tStep = Date.now();
    }
    setProg(basePct + 2, 'RPA 1/6：点「导入」，等下拉菜单…');
    // v3.4.5 实地验证（浏览器实测）：「导入」是点击触发，悬停根本弹不出菜单（此前误诊为必须悬停）
    // 二重验证：点完菜单项「导入创建产品」必须可见（=菜单真的弹开了），否则重做
    await rpaStep('打开导入菜单', [/^导入$/, /^导入产品$/], 350, 10, { verify: /^导入创建产品$/ });
    done('1.悬停导入按钮+菜单弹开');

    setProg(basePct + 8, 'RPA 2/6：点「导入创建产品」…');
    // v3.4.4 录屏确认：下拉菜单项文字就是「导入创建产品」，精确匹配避免命中工具栏容器
    // v3.4.4 二重验证：点击后弹窗必须出现（页签可见），否则回退重做（重做时先重新悬停开菜单）
    await rpaStep('导入创建产品', [/^导入创建产品$/, /导入创建产品/, /^创建产品$/], 600, 15, { reHover: [/^导入$/, /^导入产品$/], verify: [/按模板导入/, /导出妙手产品再导入/] });
    done('2.点导入创建产品+弹窗打开');

    setProg(basePct + 16, 'RPA 3/6：切「导出妙手产品再导入」标签…');
    // v3.4.4 客户纠正：必须走这个页签（我们的表是妙手导出格式），按模板导入解析不了
    // v3.4.4 二重验证：切完页签后必须出现该页签专属说明文字「…导出Temu产品Excel表格后，重新导入至妙手采集箱」
    await rpaStep('导出妙手产品再导入', [/^导出妙手产品再导入$/, /导出妙手产品再导入/], 450, 20,
      { verify: [/重新导入至妙手采集箱/, /产品管理导出/] });
    done('3.切导出妙手产品再导入+页签已生效');

    setProg(basePct + 26, 'RPA 4/6：注入表格 ' + fileName);
    // v3.4.4 注入后验证弹窗里出现文件名（=表格真的被识别），没识别就点上传入口重注入，最多 2 轮
    var injected = false;
    var baseName = (fileName || 'wash-import.csv').replace(/\.[a-z]+$/i, '');
    var nameRe = new RegExp(baseName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    for (var round = 0; round < 2 && !injected; round++) {
      var input = findImportFileInput();
      if (!input && !round) {
        try { await rpaStep('上传入口', [/点击或拖拽文件导入/, /上传文件/, /选择文件/, /^上传$/], 700, 5); } catch (e) {}
        input = findImportFileInput();
      }
      if (!input) throw new Error('没找到导入弹窗的文件输入框（弹窗可能被风控拦截）');
      var file = new File([csvText], fileName || 'wash-import.csv', { type: 'text/csv;charset=utf-8' });
      A.injectFile(input, file);
      for (var fv = 0; fv < 8 && !injected; fv++) {
        await A.sleep(400);
        if (rpaFind([nameRe])) injected = true;
      }
      if (!injected && round === 0) {
        if (stepNote) stepNote('↻ 表格注入未被识别，回退重新走上传入口');
        setProg(null, 'RPA 4/6：表格没被识别，回退重试…');
      }
    }
    if (!injected) throw new Error('表格注入后弹窗未显示「' + baseName + '」（识别失败）' + diagHint([nameRe]));
    done('4.注入表格（' + Math.round(csvText.length / 1024) + 'KB，已识别）');
    // v3.4.2：注入后不傻等——轮询等店铺下拉出现，一般 1s 内就绪
    // v3.4.4 二重验证：点开下拉→点全选后，占位符必须消失（=店铺真的选上了），否则整轮重做
    var shopDone = false;
    for (var wi = 0; wi < 12 && !shopDone; wi++) {
      await A.sleep(400);
      try {
        var shop = rpaFind([/^请选择或输入搜索$/, /^请选择店铺$/, /请选择或输入搜索/, /请选择店铺/]);
        if (shop && !shopDone) {
          setProg(basePct + 32, 'RPA 5/6：点开店铺下拉 → 全选…');
          await A.clickBtn(shop); await A.sleep(450);
          // v3.4.4 客户纠正：下拉展开后有很多店铺，直接点「全选」（最小面积优先，避免命中「全选反选752条」）
          var all = rpaFind([/^全选$/, /^全\s*选$/]);
          if (all) { await A.clickBtn(all); }
          else {
            var first = rpaFind([/^全部门店$/, /^主店$/, /^默认店铺$/]);
            if (first) await A.clickBtn(first);
          }
          // 二重验证：占位符消失 = 店铺已选上；还在 = 没点中，整轮重做（不往下走）
          var picked = false;
          for (var pv = 0; pv < 6 && !picked; pv++) {
            await A.sleep(450);
            if (!rpaFind([/^请选择或输入搜索$/, /^请选择店铺$/])) picked = true;
          }
          if (picked) { shopDone = true; done('5.店铺全选+已选上'); }
          else if (stepNote) stepNote('↻ 店铺没选上（下拉可能没点开），整轮重做');
        }
      } catch (e) {}
    }
    if (!shopDone) throw new Error('店铺选择未生效（点了全选但下拉框还是空的）' + diagHint([/店铺/]));

    await waitResume('⏸ 已暂停，尚未向妙手提交。');
    setProg(basePct + 38, 'RPA 6/6：点「确定」提交导入…');
    await rpaStep('确定导入', [/^确\s*定$/, /^确定$/, /^开始导入$/], 800, 12);
    done('6.点确定提交');
    // v3.4.4 确定后的验证只观察不重按（重复点确定可能造成重复导入）：8 秒内弹窗关掉=成功提交
    var dlgClosed = false;
    for (var cv = 0; cv < 16 && !dlgClosed; cv++) {
      await A.sleep(500);
      if (!rpaFind([/^确\s*定$/])) dlgClosed = true;
    }
    if (!dlgClosed && stepNote) stepNote('⚠ 确定后弹窗还在（可能带进度条），以导入记录结果为准，不重复点击');

    // 等导入结果（成功提示 / 导入记录里出现新行）——轮询间隔 2s→1.2s，提前 1~4 秒发现完成
    var ok = false, end = Date.now() + 120000;
    while (Date.now() < end) {
      var body = '';
      try { body = (document.body.innerText || '').slice(0, 200000); } catch (e) {}
      if (/导入成功|创建成功|导入完成|导入任务已提交/.test(body)) { ok = true; break; }
      await A.sleep(1200);
    }
    var links = pickUpProductLinks();
    return { ok: ok, links: links };
  }

  /* ---------------- v2.4.0 模式2：采集全字段 → 导出48列表格（去洗图猫网站洗图后手动导回） ---------------- */
  async function tableMode() {
    setProg(5, '① 读取当前页列表…');
    await pull(true);
    if (!items.size) { setProg(null, '❌ 没抓到商品，等采集箱列表加载完再点'); return; }
    setProg(25, '② 补采接口原始参数（标题/图/表格字段）…');
    try { await apiGrab(); } catch (e) {}
    try { await detailGrab(); } catch (e) {}
    var list = [];
    items.forEach(function (v) { if (v.sel !== false && v.title && v.imgs && v.imgs.length) list.push(v); });
    if (!list.length) { setProg(null, '❌ 没有可导出的商品（需勾选标题+至少1张图）'); return; }
    setProg(60, '③ 生成 ' + list.length + ' 行的完整字段表格（48列）…');
    var n = exportRows(list, '采集表格');
    if (n) {
      setProg(100, '✅ 表格已导出：下载目录里的 CSV（' + n + ' 行）。下一步：到洗图猫网站上传这张表 → 洗图 → 下载新表 → 在妙手手动导入。');
    } else {
      setProg(null, '❌ 导出失败，请重试');
    }
  }

  /* ---------------- v2.4.0 模式3：编辑页单品精修（最早那套 RPA：AI 改标题+洗图，写进编辑页自己保存） ---------------- */
  async function singleMode() {
    var A = window.__msRpaApi;
    if (!A || typeof A.edRun !== 'function') {
      setProg(null, '❌ 单品助手组件没加载：刷新一下妙手页面再点这个圆圈');
      return;
    }
    if (typeof A.isEditorOpen !== 'function' || !A.isEditorOpen()) {
      setProg(null, 'ℹ️ 单个自动要先有「编辑」上下文：在采集箱点开某个商品的编辑抽屉，再按「启动」跑单品精修');
      try { A.openEditorPanel && A.openEditorPanel(); } catch (e) {}
      return;
    }
    setProg(10, '✨ 单品精修：AI 改标题 + 智能洗图，结果写进编辑页…');
    try {
      var r = A.edRun('all');
      if (r && typeof r.then === 'function') await r;
      setProg(100, '✅ 已下发单品精修任务：新标题与新图已写入编辑页，核对后点妙手「保存修改」');
    } catch (e) {
      setProg(null, '❌ ' + (e && e.message ? e.message : String(e)));
      catSay('😿 喵！出岔子了：<b>' + String((e && e.message) || e).slice(0, 60) + '</b>，点开面板看日志详情');
    }
  }

  // 一键自动化的主流程：只处理面板上勾选的商品，SOP 与 RPA 连成一条，不等人
  async function autoOne() {
    var base = washBaseOf();
    var code = String(cfg.code || '').trim();
    var imgBase = imgBaseNorm(cfg.imgBase) || IMG_BASE_DEFAULT;
    // v3.7.22 本地直连：洗图台地址为空时不再报错，自动转「本地直连全自动」
    //（生图/改标题走客户 New API 令牌，成品图传妙手图片空间，本地组表直连导入，全程不经服务器）
    if (!base) return localAutoOne();
    if (!code) { log('❌ 先填访问口令'); needSetup(); return; }
    if (/127\.0\.0\.1|localhost|192\.168\./i.test(imgBase)) {
      log('⚠️ 图床域名是本地地址，妙手服务器拉不到这些图；正式建链接前请填公网域名');
    }
    busy = true;
    monToken++;   // 全自动有自己的轮询，打断半自动遗留的监控循环
    if (progEl) progEl.classList.add('show');
    if (oneBtn) oneBtn.disabled = true;
    if (autoBtn) autoBtn.disabled = true;
    if (linksEl) linksEl.innerHTML = '';
    var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
      + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
    try {
      await waitResume();
      setProg(2, '① 读取勾选…');
      var list0 = [];
      items.forEach(function (v) { if (v.sel !== false && v.title && v.imgs && v.imgs.length) list0.push(v); });
      if (!list0.length) throw new Error('没有勾选可洗的商品（需标题 + 至少 1 张图），先全选或勾几条');

      // v3.6.3 覆盖预警：洗图台上还有别的单时先说清楚（防误覆盖上一单的成品图/表格）
      try {
        var oldSt = await relay(base + '/api/status?' + auth, {});
        var oldProds = (oldSt && oldSt.products) || [];
        if (oldProds.length) {
          var selSet = {}; list0.forEach(function (v) { selSet[String(v.id)] = true; });
          var sameJob = oldProds.every(function (p) { return selSet[String(p.srcPid)] || selSet[String(p.pid)]; });
          if (!sameJob) {
            var od = oldProds.reduce(function (a, p) { return a + (p.done || 0); }, 0);
            var ot = oldProds.reduce(function (a, p) { return a + ((oldSt.settings && oldSt.settings.target) || 10); }, 0);
            if (!window.confirm(
              '⚠️ 洗图台上还有一单：' + oldProds.length + ' 个链接（已完成 ' + od + '/' + ot + ' 张）。\n\n'
              + '现在启动会【新建一单并替换它】：旧图还在服务器磁盘上（可在面板「🕘 历史单」里找回预览/下载），但结果区、导出表格、一键上传都指向新单。\n\n'
              + '【确定】继续新建（替换上一单）\n【取消】回去先把上一单导出/上传完')) {
              log('↩️ 已取消启动：洗图台上还有一单（' + oldProds.length + ' 个链接 · 已完成 ' + od + '/' + ot + ' 张），先把它的表格导出/链接建完再来');
              catSay('⏸ 喵～上一单还没收尾，我没敢动它；先去结果区把表格导出来吧');
              return;
            }
            log('⚠️ 已确认覆盖：上一单（' + oldProds.length + ' 个链接）将在建单时被替换，旧图仍在洗图台磁盘，可从「🕘 历史单」找回');
          }
        }
      } catch (e0) { /* 洗图台连不上不挡路 */ }

      await waitResume();
      setProg(8, '② 补采接口原始参数（' + list0.length + ' 个商品）…');
      if (autoBtn) autoBtn.textContent = '⚡ 自动化进行中…';
      speak('开始采集');
      try { await apiGrab(); } catch (e) {}
      try { await detailGrab(); } catch (e) {}
      speak('采集完成');
      var list = [];
      items.forEach(function (v) {
        if (v.sel === false || !v.title || !v.imgs || !v.imgs.length) return;
        var raw = v.raw || {};
        if (v.batch && Object.keys(v.batch).length) raw.batch = v.batch;
        list.push({ id: v.id, title: v.title, urls: v.imgs, raw: Object.keys(raw).length ? raw : null,
          tplKey: v.tplKey || '', note: noteByPid[String(v.id)] || '' });
      });
      var selIds = {}; list.forEach(function (x) { selIds[String(x.id)] = 1; });

      // 按模板分组建单：不同类目用不同模板，一组一单（模板随单带给服务端）
      var groups = {};
      list.forEach(function (x) { var k = x.tplKey || ''; (groups[k] = groups[k] || []).push(x); });
      var gKeys = Object.keys(groups);
      for (var gi = 0; gi < gKeys.length; gi++) {
        await waitResume();
        var gk = gKeys[gi];
        setProg(16, '③ 建单（第 ' + (gi + 1) + '/' + gKeys.length + ' 组模板「' + (gk || '默认') + '」，' + groups[gk].length + ' 个）…');
        var imp = await relay(base + '/api/import-items?' + auth,
          { items: groups[gk], copies: Number(cfg.copies) || 1,
            fileName: '一键自动化_' + groups[gk].length + '个' + (gk ? '_' + gk : ''),
            tpl: tplForItem(gk) });   // 模板设置：改图/标题/属性 + 固定值，随单带给服务端
        if (!imp || !imp.ok) throw new Error('建单失败：' + ((imp && imp.error) || '未知错误'));
        if (gi < gKeys.length - 1) await nap(800);
      }

      setProg(22, '④ 确认任务归属…');
      var st = null, waitEnd = Date.now() + 10 * 60 * 1000;
      while (Date.now() < waitEnd) {
        if (paused) { waitEnd += 1000; await nap(1000); continue; }   // 暂停期间不占用等待窗口
        st = await statusSafe(base + '/api/status?' + auth, {});
        if (imp.queued && (!st.mine || st.status === 'running' || !(st.products || []).length)) {
          setProg(22, '④ 洗图台忙，前面还有 ' + (st.queuedTotal || '?') + ' 单，自动等待…');
          await nap(6000); continue;
        }
        break;
      }
      var pids = (st && st.products || []).filter(function (p) {
        return selIds[String(p.srcPid)] || selIds[String(p.pid)];
      }).map(function (p) { return String(p.pid); });
      if (!pids.length) throw new Error('没找到勾选商品对应的洗图台产品 ID');

      await waitResume();
      washReset(selIds);
      setProg(28, '⑤ 启动洗图（只跑这 ' + pids.length + ' 个产品）…');
      var launch = await relay(base + '/api/start?' + auth, { only: pids, catAttrs: cfg.catAttrs || '' });
      if (!launch || !launch.ok) throw new Error((launch && launch.error) || '洗图启动失败');
      speak('开始洗图');
      // v3.2.5 给客户的预期说明：单张最快约 25 秒，任务越多并行越多整体越快
      log('⏱ 温馨提示：每张图最快也要约 25 秒生成（AI 逐张精修），勾的任务越多并行越多、整体越快；进度条下方会实时显示预计剩余时间，不用盯着等。');
      catSay('⏱ 喵～单张图最快也要 <b>25 秒</b> 左右，这是满速上限啦；不过<b>任务越多我跑得越欢</b>（多链接并行出图），这单 ' + pids.length + ' 个链接我会一起开的～');

      setProg(0, '⑥ SOP 洗图中：0/' + ((st && st.planImgs) || pids.length * 10) + ' 张…');
      var sEnd = Date.now() + 90 * 60 * 1000, lastPct = -1;
      while (Date.now() < sEnd) {
        var pausedAt = Date.now();
        st = await statusSafe(base + '/api/status?' + auth, {});
        if (!matchesWash(st, pids)) throw new Error('洗图单已切换，已停止自动处理，未提交妙手。');
        if (settledWash(st)) break;
        if (st.status === 'running') {
          washSync(st);
          washRender();
          washTimeLine();
          await pauseAtBoundary(base, auth, st);
          sEnd += Date.now() - pausedAt;
          var done = washDoneSum();
          var plan = wash.plan || st.planImgs || pids.length * 10;
          // v3.5.1 进度条直接按张数比例走（0/10=空条 → 10/10=满条），不再带前置阶段基数导致「0 张却 1/3 条」
          var pct = Math.round(100 * (plan ? done / plan : 0));
          if (pct >= lastPct || done > 0) { if (pct !== lastPct) { lastPct = pct; setProg(pct, '⑥ SOP 洗图中：' + done + '/' + plan + ' 张（' + pct + '%）…'); } }
        }
        await nap(3500);
      }
      if (!settledWash(st)) throw new Error('洗图超时，请点「续跑」查看服务器进度。');
      washSync(st); washRender(); washTimeLine();
      await waitResume();
      var left;
      try { left = await washRepair(base, auth); }
      catch (e) {
        if (!wash.done) throw e;
        log('⚠️ 本轮缺图，自动补图未受理：' + (e && e.message || e));
        left = missingWashProducts().length;
      }
      if (left) { setProg(Math.round(100 * washDoneSum() / Math.max(1, wash.plan)), washTerminalText(), true); return; }
      if (st.status === 'error' && !washDoneSum()) throw new Error('本轮未生成图片，请查看日志。');
      saveSpeedSample();

      // 检查模式：洗完不马上建链接，先让客户预览/重跑/填建议，满意再点「一键上传并跑 RPA」
      if (cfg.check) {
        var usedMs = (wash.finishedAt || Date.now()) - (wash.startedAt || wash.t0);
        setProg(100, '🔍 检查模式：洗图完成（' + fmtDur(usedMs) + '，' + washMine().length + ' 个链接）。预览满意就点「🚀 一键上传并跑 RPA」；不满意的单个链接可「🔁 重跑」。');
        log('🔍 检查模式：结果已列在下方，每个链接可预览 / 重跑 / 填修改建议。');
        return;   // finally 会复位按钮；大按钮由 rpaFromCheck 接力
      }

      await waitResume();
      await rpaRun(base, auth, imgBase);
    } catch (e) {
      setProg(null, '❌ ' + (e && e.message ? e.message : String(e)));
      catSay('😿 喵！出岔子了：<b>' + String((e && e.message) || e).slice(0, 60) + '</b>，点开面板看日志详情');
    } finally {
      busy = false;
      paused = false;
      if (pauseBtn) { pauseBtn.textContent = '⏸ 暂停'; pauseBtn.disabled = true; }
      if (startBtn) { startBtn.disabled = false; applyModeSafe(); }
      washRender();
    }
  }

  // 检查模式下的大按钮：生成新表格 → 读取 → RPA 建链接（autoOne 洗完后的接力棒）
  async function rpaFromCheck() {
    if (busy || rerunning) { log('⏳ 当前有任务在跑，稍等一下'); return; }
    if (!wash.done) { log('ℹ️ 还没洗完图，等结果区全部 ✅ 再点'); return; }
    // v3.4.8 本单已建过链接时允许「再次上传」（补图/重跑后的正常需求），但要确认防误触
    if (wash.rpa && !window.confirm('本单已经建过一次链接。\n再点会用当前表格再导入一遍（可能产生重复链接）。\n\n确定要再次上传吗？')) { log('↩️ 已取消再次上传'); return; }
    // v3.4.8 有缺图也放行（客户要求出错后仍可一键上架），但先说清楚后果
    var badN = missingWashProducts().length;
    if (badN && !window.confirm('还有 ' + badN + ' 个链接的图没齐。\n点「确定」照常上传（这几个链接图会少几张）；\n点「取消」先去补图再上传。')) { log('↩️ 已取消，先补图'); return; }
    var base = washBaseOf();
    var code = String(cfg.code || '').trim();
    if (!base || !code) { log('❌ 先在面板里填好洗图台地址和口令'); needSetup(); return; }
    var imgBase = imgBaseNorm(cfg.imgBase) || IMG_BASE_DEFAULT;
    var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
      + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
    busy = true;
    progEl.classList.add('show');
    try {
      await rpaRun(base, auth, imgBase);
    } catch (e) {
      setProg(null, '❌ ' + (e && e.message ? e.message : String(e)));
      catSay('😿 喵！出岔子了：<b>' + String((e && e.message) || e).slice(0, 60) + '</b>，点开面板看日志详情');
    } finally {
      busy = false; paused = false;
      if (pauseBtn) { pauseBtn.textContent = '⏸ 暂停'; pauseBtn.disabled = true; }
      if (startBtn) { startBtn.disabled = false; applyModeSafe(); }
      washRender();
    }
  }

  /* ---------------- v3.7.22 本地直连全自动：不经洗图台服务端 ----------------
     以前的成功版本靠洗图台服务器出图+图床；本版把出图搬进浏览器：
     · 生图/改标题走客户自己的 New API 令牌（background 已有 chat / imageBlob 通道）
     · 成品图直接传妙手图片空间（uploadPictureFile）拿妙手自己的 https 图链
       —— 妙手导入必然拉得到，不再依赖自建图床（接口测试已验证该上传/图链契约）
     · 本地组 48 列 CSV（fillCols 与服务端 fillRowFromRaw 同一套映射）
       → collect_box_import 直连导入（apiImport 四步抓包链路）
     洗图台地址留空时 autoOne 自动转本模式；填了地址仍走服务器链路。 */
  function newPid12() {
    var s = String(Math.floor(Math.random() * 9) + 1);
    for (var i = 0; i < 11; i++) s += String(Math.floor(Math.random() * 10));
    return s;
  }
  // v3.7.23 本地直连完整提示词框架（客户端内置，替代洗图台服务端 rules.json）。
  // 层级与原版一致：修改建议 > 类目补充 > 固定参数 > 全局规则/分镜
  var LOCAL_RULES = {
    master: '商品主图规则：以参考图中的商品为准，保持原样（形状/颜色/材质/图案文字/数量不得改动）；【商品主体硬性锁定】商品的外形轮廓、长宽比例、结构、款式、造型、图案排布、零件数量必须与参考图逐一对齐，严禁改变商品形状、严禁拉伸压扁、严禁增减少数零件、严禁替换成相似但不同的款式——只换背景与拍摄呈现，商品本体一个像素都不要 redesign；背景与构图跟随【主图构图】要求，若同时指定了「整体画面风格」则风格优先（未指定风格时背景由构图决定：棚拍/斜置用浅色棚拍背景，平铺顶拍用与商品协调的纯色或纹理平面，场景摆拍用真实环境背景，不要一律白底）；商品主体突出；商业级产品摄影，光线明亮均匀；无水印、无 LOGO、不添加任何额外文字；不添加参考图中不存在的物体。',
    series: '系列一致性约束：本张与主图必须是同一款商品（同形状/同颜色/同材质/同细节），风格与主图统一，禁止替换成其他商品或加入无关商品。',
    slots: [
      { name: '场景图', text: '把商品放入真实使用场景（家居/桌面/节庆布置等），突出用途与氛围，商品保持原样且为画面主体。' },
      { name: '细节材质图', text: '近距离特写商品的材质纹理与工艺细节，浅景深，突出质感。' },
      { name: '使用说明图', text: '以分步骤说明的方式展示商品的安装或使用方法（像产品说明书：把 2-3 个步骤画面组织在同一画面里，有先后主次顺序），让人一眼看懂怎么装、怎么用；步骤不用文字标注，全靠画面表达。' },
      { name: '卖点图解', text: '聚焦商品最大卖点（如多功能/易收纳/耐用），画面直观体现该优势。' },
      { name: '注意事项图', text: '用画面呈现使用注意事项（如远离火源、儿童使用需看护），简洁明确，不添加文字。' },
      { name: '模特图', text: '真人模特自然展示商品的使用/佩戴效果，光线柔和，商品为视觉焦点。' },
      { name: '竞品对比图', text: '左右并排对比：一侧是本商品（清晰突出优势与细节），另一侧是普通同类产品作为参照；画面里必须有一处醒目的大写英文「VS」作为对比标识（除 VS 外不加其他文字），画面整洁，不出现品牌名、不出现中文。' },
      { name: '尺寸标注图', text: '多角度展示商品整体与局部比例，画面上用厘米（cm）和英寸（inch）双单位标注尺寸（标注文字只用英文与数字，不得出现中文）；无真实尺寸数据时按同类商品常见合理尺寸标注，数值不夸张不编造精确到毫米的假精度。' },
      { name: '实物尺寸比对图', text: '商品与常见物品（手/硬币/书本等）同框摆放，直观体现真实大小；画面附 cm 与 inch 双单位尺寸标注（标注只用英文与数字，不得出现中文）。' }
    ],
    // v3.7.26 POD 改造模式：允许把采集品改造成新品（换图案/配色/造型/场景）
    // v3.7.69 POD 改造幅度分三档：light=只换呈现（商品原样）/ mid=标准（原 podMaster）/ strong=强改造（图案主题可重设）
    podMasterLight: 'POD 轻改造主图规则：商品本身保持原样——图案/印花/配色/造型/细节均不得改动，只允许更换背景、场景与拍摄呈现方式（如搭配道具、换环境、换拍摄角度），把原商品包装得更有质感与卖点感；商品品类与主体结构必须保持可识别；【2D 平面图保留】如果参考图是 2D 平面设计（平面印花稿、矢量图案、2D 插画、平铺图案稿），生成图必须保留这套 2D 平面元素与图案本身（图形内容、配色、排布原样不动），呈现为平面/印花效果，不得把图案改成 3D 写实或改动图案内容；【2D 角标保留】如果参考图带有「2D」字样的标注/角标（通常在左上角、右上角或右下角），生成的图必须在相同的角落保留同样的「2D」文字标注；参考图没有 2D 角标时则不要自行添加；背景与构图跟随【主图构图】要求，若同时指定了「整体画面风格」则风格优先（未指定风格时不要一律白底，按构图选：棚拍/斜置浅色棚拍背景，平铺用协调纯色/纹理平面，场景摆拍用真实环境）；商业级产品摄影，光线明亮均匀；无水印、无 LOGO、除「2D」角标外不添加任何文字；不得出现真实品牌与知名 IP 元素。',
    podMaster: 'POD 创意商品主图规则：以参考图中的商品为品类与结构基础，允许并鼓励创意改造——可更换图案/印花/配色/纹理/造型/装饰元素，把它设计成一款有卖点的新品；但商品品类与主体结构必须保持可识别，不得变成另一种产品；【2D 平面图保留】如果参考图是 2D 平面设计（平面印花稿、矢量图案、2D 插画、平铺图案稿），生成图必须保留这套 2D 平面元素与图案本身（图形内容、配色、排布原样不动），呈现为平面/印花效果，不得把图案改成 3D 写实或改动图案内容；【2D 角标保留】如果参考图带有「2D」字样的标注/角标（通常在左上角、右上角或右下角），生成的图必须在相同的角落保留同样的「2D」文字标注，让客户一眼识别这是 2D 平面款、不会误解为立体实物；参考图没有 2D 角标时则不要自行添加；背景与构图跟随【主图构图】要求，若同时指定了「整体画面风格」则风格优先（未指定风格时不要一律白底，按构图选：棚拍/斜置浅色棚拍背景，平铺用协调纯色/纹理平面，场景摆拍用真实环境）；商品主体突出；商业级产品摄影，光线明亮均匀；无水印、无 LOGO、除「2D」角标外不添加任何文字；不得出现真实品牌与知名 IP 元素。',
    podMasterStrong: 'POD 强改造主图规则：对参考图商品做大幅度创意改版——【图案主题必须重做】把原图案/印花/装饰主题替换成与原图明显不同的全新主题（从这些方向任选：卡通动物、花卉植物、几何抽象、海洋生物、星空宇宙、复古花纹、美食水果、节日元素等，要求与原图主题完全不同），配色可以大改，装饰元素可以增删替换；目标是产出一张与参考图并排摆放时一眼就能看出「这是两个不同设计」的图；仅要求保持：商品品类相同、外形结构可识别（不得把立体商品改成另一种产品，木质拼块/摆件类保留其立体造型与块面结构，只重做块面上的图案）；【2D 角标】如果参考图带有「2D」字样角标，在相同角落保留「2D」文字标注；背景与构图跟随【主图构图】要求，若同时指定了「整体画面风格」则风格优先（未指定风格时不要一律白底，按构图选背景：棚拍/斜置浅色棚拍背景，平铺用协调纯色/纹理平面，场景摆拍用真实环境）；商业级产品摄影，光线明亮均匀；无水印、无 LOGO、除「2D」角标外不添加任何文字；不得出现真实品牌与知名 IP 元素。',
    podSeries: '系列一致性约束：本张与主图必须是同一款改造后的新品（同图案/同配色/同造型/同细节），风格统一，禁止变回原样或混入其他商品。'
  };
  function tplFixedStr(tpl) {
    var f = tpl && tpl.fixed && typeof tpl.fixed === 'object' ? tpl.fixed : null;
    if (!f) return '';
    return Object.keys(TPL_FIXED_LABELS).map(function (k) {
      var v = String(f[k] || '').trim();
      return v ? (TPL_FIXED_LABELS[k] + '：' + v) : '';
    }).filter(Boolean).join('；');
  }
  function buildImgPrompt(idx, tpl, note, pIdx) {
    var L = [];
    var pod = tpl && tpl.imgMode === 'pod';   // v3.7.26 生图模式：pod=允许改造
    var podLv = pod ? ((tpl && tpl.podLevel) || 'mid') : 'mid';   // v3.7.69 改造幅度
    if (idx === 0) {
      L.push(pod ? (podLv === 'strong' ? LOCAL_RULES.podMasterStrong : (podLv === 'light' ? LOCAL_RULES.podMasterLight : LOCAL_RULES.podMaster)) : LOCAL_RULES.master);
      // v3.7.69 主图构图轮换：相邻商品用不同摆拍方式，避免每个品的主图都是同一种居中构图
      var COMPS = [
        '居中棚拍：干净浅色背景，商品正面居中',
        '45° 斜置展示：商品斜放摆拍，体现厚度与立体层次',
        '平铺顶拍：垂直俯拍平铺构图，画面饱满有设计感',
        '生活场景摆拍：搭配 1-2 件协调道具的场景化摆拍，营造使用氛围'
      ];
      L.push('【主图构图】' + COMPS[Math.abs(pIdx || 0) % COMPS.length] + '；背景按此构图选择（未指定画面风格时不要一律用白底/浅底，场景摆拍就用真实环境背景），同类商品各品的主图构图要有区分，不要千篇一律。');
    } else {
      L.push(pod ? LOCAL_RULES.podSeries : LOCAL_RULES.series);
      var slot = LOCAL_RULES.slots[(idx - 1) % LOCAL_RULES.slots.length];
      if (slot) {
        // v3.7.87 POD 模式分镜一致性：slot 文案里的「商品保持原样」会与改造后的新品冲突，
        // 模型看着原图就把旧图案画回去了（客户实测「只有主图改了，其他图没变化」）——POD 时统一改写并追加锁主题句
        var slotText = pod
          ? slot.text.replace(/商品保持原样且为画面主体/g, '已改造后的新品为画面主体（图案用主图的新设计）')
            .replace(/商品保持原样/g, '已改造后的新品保持主图的新设计')
          : slot.text;
        var st = '【分镜 · ' + slot.name + '】' + slotText + (pod ? '（POD 模式：画面围绕改造后的新品主题自由设计）' : '');
        if (pod) st += ' 【POD 一致性】本张商品必须是主图那款改造后的新品：图案主题/配色/细节与主图完全一致；参考图里的原始图案只是改前底稿，严禁照抄回画面。';
        // v3.7.26 模特设置只作用于「模特图」分镜（防止部分类目 AI 面部失真等问题）
        if (slot.name === '模特图' && tpl && tpl.model) {
          var mv = [];
          if (tpl.model.race && TPL_MODEL_LABELS.race[tpl.model.race]) mv.push('模特人种：' + TPL_MODEL_LABELS.race[tpl.model.race]);
          if (tpl.model.face === 'hide') mv.push('不露脸：避免正脸，用侧脸/背影/发丝/道具遮挡面部（防止 AI 面部失真）');
          else if (tpl.model.face === 'show') mv.push('露脸自然，五官无畸变');
          if (tpl.model.shot && TPL_MODEL_LABELS.shot[tpl.model.shot]) mv.push('景别：' + TPL_MODEL_LABELS.shot[tpl.model.shot]);
          if (mv.length) st += ' 【模特要求】' + mv.join('；');
        }
        L.push(st);
      }
    }
    if (tpl && tpl.style && TPL_STYLE_LABELS[tpl.style]) L.push('整体画面风格：' + TPL_STYLE_LABELS[tpl.style] + '，贯穿所有画面。');
    if (tpl && tpl.prompt) L.push(String(tpl.prompt).trim());
    var fx = tplFixedStr(tpl);
    if (fx) L.push('固定参数（必须遵守）：' + fx);
    // v3.7.34 全图硬性约束（所有分镜通用）：画面内不要中文，标注一律英文
    // v3.7.69 2D 图案保留约束跟随改造幅度：强改造模式允许重设图案主题
    L.push('【硬性约束】画面中不得出现任何中文/汉字、不得出现中文品牌词；除尺寸图的 cm/inch 数字标注与竞品对比图的「VS」外，不添加其他文字；不得出现水印、LOGO、真实品牌；不得复刻参考图中的知名 IP 角色、影视/动漫/游戏形象、品牌吉祥物等受版权保护的元素（POD 模式下图案必须为原创设计风格）；' + (pod && podLv === 'strong' ? 'POD 强改造模式下除「2D」角标外的图案内容可重新设计。' : 'POD 模式的 2D 平面图案必须原样保留、不得改写图案内容。'));
    if (note) L.push('修改建议（最高优先级，冲突以此为准）：' + note);
    return L.join(' ');
  }
  async function localAutoOne(resumeJob) {
    busy = true; monToken++;
    if (progEl) progEl.classList.add('show');
    if (oneBtn) oneBtn.disabled = true;
    if (autoBtn) autoBtn.disabled = true;
    if (linksEl) linksEl.innerHTML = '';
    try { var jb0 = document.querySelector('.mscb-jobbar'); if (jb0) jb0.style.display = 'none'; } catch (eJ0) {}   // v3.7.33 跑单时不显示「上次任务」横幅
    var t0 = Date.now();
    try {
      await waitResume();
      setProg(2, '① 本地直连：读取勾选…');
      var list = [];
      if (resumeJob && Array.isArray(resumeJob.items) && resumeJob.items.length) {
        // v3.7.33 续跑：商品清单直接用上次快照（页面刷新/关浏览器后原勾选已丢，靠快照接上）
        list = resumeJob.items.slice();
        log('♻️ 恢复上次任务：' + list.length + ' 个商品，已完成的不重复出图');
      } else {
        items.forEach(function (v) { if (v.sel !== false && v.title && v.imgs && v.imgs.length) list.push(v); });
      }
      if (!list.length) throw new Error('没有勾选可洗的商品（需标题 + 至少 1 张图），先全选或勾几条');
      setProg(4, '② 检查 New API 令牌…');
      var st = null;
      try { st = await chrome.runtime.sendMessage({ cmd: 'xtNewApiStatus' }); } catch (eS) {}
      if (!st || !st.ok || !st.data || !st.data.connected)
        throw new Error('生图还没保存生效：站点池要在「接口设置→站点池」保存后才算数（导入 JSON 会自动保存），或填生图网关二选一；填了改标题模型也要点「验证并保存连接」');
      log('🔌 令牌就绪：生图 ' + ((st.data.pool && st.data.pool.length)
        ? ('站点池 ' + st.data.pool.map(function (pp) { return pp.name + '×' + pp.weight; }).join(' / '))
        : (st.data.image || 'gpt-image')) + ' ｜ 改标题 ' + (st.data.title || '默认'));
      var poolOnN = (st.data.pool && st.data.pool.length) ? st.data.pool.filter(function (pp) { return pp.on !== false; }).length : 0;   // v3.7.43 环境测试播报
      speak('环境检查通过' + (poolOnN ? ('，站点池 ' + poolOnN + ' 个站点可用') : '') + '。开始跑单了，共 ' + list.length + ' 个商品，请稍等。');   // v3.7.43 环境测试+启动播报
      setProg(8, '③ 补采接口原始参数…');
      var noRaw = 0, noDetailRaw = 0;
      list.forEach(function (x) {
        if (!x.raw) { noRaw++; return; }
        // v3.7.45 列表级行（自带标题/图）但缺详情字段 → SKU/规格/类目属性/毛净重列全空 → 导入全拒（2026-11-22 普通箱 12/12 实测）
        var rw = x.raw;
        if (!rw.detailId && !rw.skuMap && !(Array.isArray(rw.attributes) && rw.attributes.length) && !rw.itemNum && !rw.saleAttributes) noDetailRaw++;
      });
      if (noRaw) {
        log('📋 ' + noRaw + ' 个商品还没采集表格参数，自动全字段直取…');
        try { await apiGrab(); } catch (eG) { log('⚠️ 全字段直取失败（' + String(eG.message || eG).slice(0, 60) + '），继续（部分列可能为空）'); }
        try { await detailGrab(); } catch (eD) {}
        if (resumeJob) {
          // 续跑：保留快照清单与顺序，只把页面里重新采到的原始参数补回去
          var rawById = {};
          items.forEach(function (v) { if (v && v.title) rawById[String(v.id)] = v; });
          list.forEach(function (x) {
            var hit = rawById[String(x.id)];
            if (hit && hit.raw && !x.raw) x.raw = hit.raw;
            if (hit && hit.tplKey && !x.tplKey) x.tplKey = hit.tplKey;
          });
        } else {
          list = [];
          items.forEach(function (v) { if (v.sel !== false && v.title && v.imgs && v.imgs.length) list.push(v); });
        }
      } else if (noDetailRaw) {
        // v3.7.45 详情字段补齐：列表行 raw 缺 skuMap/attributes 等 → 逐个 getCollectItemInfo 全量抓取
        log('📋 ' + noDetailRaw + ' 个商品只有列表级参数，缺 SKU/规格/类目属性等详情字段，自动全量抓取…');
        try { await detailGrab(); } catch (eD) { log('⚠️ 全量抓取失败（' + String(eD.message || eD).slice(0, 60) + '），继续（部分列可能为空）'); }
        var rawById2 = {};
        items.forEach(function (v) { if (v && v.title) rawById2[String(v.id)] = v; });
        list = list.map(function (x) { return rawById2[String(x.id)] || x; }).filter(function (x) { return x && x.title && x.imgs && x.imgs.length; });
        log('✅ 详情字段补齐后确认 ' + list.length + ' 个商品待跑');
      }
      var imgN0 = Math.max(1, Math.min(10, Number((resumeJob && resumeJob.imgN) || cfg.imgN) || 10));
      var fiss0 = Math.max(1, Math.min(10, Number((resumeJob && resumeJob.fiss) || cfg.fiss) || 1));
      // v3.7.33 续跑：先算清楚「还缺多少张」——已组好导入行的商品完全跳过，已出过的图复用原图链
      var willGen = list.length * fiss0 * imgN0;
      if (resumeJob) {
        var snapByPid = {};
        ((resumeJob.products) || []).forEach(function (p) { snapByPid[String(p.srcPid)] = p; });
        willGen = 0;
        list.forEach(function (v) {
          var pp = snapByPid[String(v.id)];
          if (!pp || pp.row) return;
          var have = (pp.localUrls || []).filter(Boolean).length;
          willGen += Math.max(0, fiss0 * imgN0 - have);
        });
      }
      // v3.7.43 启动前体检②：详情参数缺失检测（公用采集箱来源无详情接口 → 必填列全空 → 导入被全拒，2026-11-22 40/40 实测）
      var noDetailN = 0;
      list.forEach(function (x) { var rw = x && x.raw; if (!rw || (!rw.detailId && !rw.skuMap && !(Array.isArray(rw.attributes) && rw.attributes.length))) noDetailN++; });
      var noDetailAll = noDetailN === list.length && list.length > 0;
      if (noDetailN) {
        var detWarn = noDetailAll
          ? ('⚠️ 体检警告：' + noDetailN + '/' + list.length + ' 个商品没有详情参数（SKU/规格/类目属性等必填列会是空的），导入大概率被妙手全部拒绝。建议到普通「采集箱」勾选商品再跑全自动；只想要图不导入的话可以继续。')
          : ('⚠️ 体检提示：' + noDetailN + '/' + list.length + ' 个商品缺详情参数，这部分导入可能被拒（其余正常）。');
        log(detWarn);
        speak(noDetailAll ? ('注意：这批 ' + list.length + ' 个商品缺详情参数，导入会被全拒。建议改用普通采集箱的商品。只想要图可以继续。') : (noDetailN + ' 个商品缺详情参数，这部分导入可能失败，请留意。'));
      }
      var okGo = resumeJob
        ? window.confirm('♻️ 继续上次任务，共 ' + list.length + ' 个商品：\n· 已完成的商品直接复用原图链，不再扣费\n· 已出过的图不重出，只补缺的（约 ' + willGen + ' 张）\n· 生成完自动组表并导入妙手\n\n确定继续吗？')
        : window.confirm('本地直连全自动，共 ' + list.length + ' 个商品：\n· 每品裂变 ' + fiss0 + ' 份（1=不裂变）× 每份出图 ' + imgN0 + ' 张 = 合计约 ' + (list.length * fiss0 * imgN0) + ' 张图\n· AI 改标题按模板开关（中文/英文）+ 固定值入表（参数一律按采集原始数据，只有模板手填固定值才改）\n· 提示词按原版五层框架：全局规则/分镜 + 类目补充 + 固定参数 + 修改建议\n· 成品图上传妙手图片空间，自动组 48 列表并提交导入\n· 导入会在妙手采集箱新建商品条目（走你自己的 New API 令牌，真实扣费）\n\n确定开始吗？');
      if (!okGo) throw new Error('用户取消');
      var rows = [], okN = 0, failN = 0, failVoiceDone = false, rowByProd = {};
      jobMeta = {
        at: (resumeJob && resumeJob.at) || Date.now(),
        startedAt: (resumeJob && resumeJob.startedAt) || Date.now(),
        items: list, imgN: imgN0, fiss: fiss0, resume: !!resumeJob
      };
      if (resumeJob) localStateRestore(resumeJob);   // 结果区先显示上次已出的图，缺的再补
      else localStateInit(list);                     // v3.7.27c 接入原结果区：每品一行（缩略图+进度条+预览/重跑/建议）
      jobSave(true);
      var quotaFull = false;   // v3.7.27 妙手图片空间容量不足（code 30013）→ 立即停单，避免后续商品白白扣生图费
      var imgN = imgN0;
      var fiss = fiss0;
      // v3.7.28 进度条同步：已用时长 + 剩余时间估算（按已完成出图单元的平均速度推算）
      var runStat = { ok: 0, fail: 0, bySt: {}, bytes: 0 };   // v3.7.76 本单出图统计（完成时打印小结，bySt 仅内部用，不展示给客户）
      xtGateEpoch++;   // v3.7.78 新单开跑：作废上一单残留在闸门队列里的任务（防异常中止后继续下单白扣费）
      function runStatOk(station, dataUrl) {
        runStat.ok++;
        runStat.bytes += String(dataUrl || '').length * 0.75;
        if (station) runStat.bySt[String(station)] = (runStat.bySt[String(station)] || 0) + 1;
      }
      // v3.7.76 站点脱敏：客户可见日志只出现「通道1/通道2…」，绝不出现站点名/域名（客户不该知道背后有几个站）
      var xtStAliasMap = {};
      function xtStAlias(station) {
        if (!station) return '';
        var k = String(station);
        if (!xtStAliasMap[k]) xtStAliasMap[k] = '通道' + (Object.keys(xtStAliasMap).length + 1);
        return xtStAliasMap[k];
      }
      function xtMaskErr(s) { return String(s || '').replace(/https?:\/\/[^\s'"）)]+/gi, '⟨地址⟩'); }   // v3.7.76 上游报错里万一带 URL 也打码
      var imgUnitsTotal = resumeJob
        ? (wash.products || []).reduce(function (n, p) { return n + (Number(p.total) || 0); }, 0) || (list.length * fiss0 * imgN0)
        : list.length * fiss0 * imgN0;
      // v3.7.33 续跑：已出的图先计入进度，进度条不会从 0 开始
      var doneUnits = 0;
      if (resumeJob) (wash.products || []).forEach(function (p) { doneUnits += (p.localUrls || []).filter(Boolean).length; });
      function progTail() {
        // v3.7.67 去重：本机直连模式下「已用/剩约」只显示在下方专用时间行（washTimeLine，含已扣费），
        // 顶部进度文本不再重复拼接两栏时间
        if (localRunMode) return '';
        var el = (Date.now() - t0) / 1000;
        if (imgUnitsTotal && doneUnits >= 3) {
          var rem = Math.max(0, imgUnitsTotal - doneUnits) * (el / doneUnits) + 20;   // +20s ≈ 每品改标题+上传写回开销
          return ' · 已用 ' + fmtDur(el) + ' · 剩约 ' + fmtDur(rem);
        }
        return ' · 已用 ' + fmtDur(el);
      }
      // v3.7.28 计时持续走：批次生成/上传期间也每 3 秒刷新「已用/剩约」，不再冻结在阶段切换瞬间
      // v3.7.67 进度跟随修复：①出图计数/百分比每 3s 用实时 doneUnits 重算（原来只在下一链接开跑时才动）
      // ②旧 run 的计时器自动自杀（monToken 守卫，防两次启动互相覆写进度文本）
      // ③本机直连模式下顶部不再拼「已用/剩约」——下方专用时间行已有，去掉重复的两栏时间
      var progBase = '';
      var myMon = monToken;
      var progTimer = setInterval(function () {
        if (monToken !== myMon) { clearInterval(progTimer); return; }
        if (progBase && busy) {
          var txt = progBase.replace(/出图 \d+\/\d+ 张/, '出图 ' + doneUnits + '/' + imgUnitsTotal + ' 张');
          var pct2 = /出图 /.test(progBase) ? Math.max(10, Math.min(82, 10 + Math.round(doneUnits / Math.max(1, imgUnitsTotal) * 72))) : null;
          setProg(pct2, txt + progTail());
        }
        try { var sk2 = document.querySelector('.mscb-skip'); if (sk2) sk2.style.display = busy ? '' : 'none'; } catch (eSk) {}   // v3.7.73 跑单时才显示跳过按钮
        try { if (localRunMode) washTimeLine(); } catch (eTL) {}
      }, 3000);   // v3.7.39 本地时间行也 3s 刷新
      function localSetProg(pct, base) { progBase = base; setProg(pct, base + progTail()); }
      // v3.7.32 多品并发：所有商品同时开跑（v3.7.78 图级流量由全局闸门 xtGate 统一限流，商品级不再需要压并发）
      // 1000 张 = 瞬时全部入本地队列，在飞封顶（默认 48，cfg.gateCap 可改，8~96 自适应），完成一张放行一张
      // v3.7.39 全部链接同时开跑（用户拍板：不排队）：默认并发 = 链接总数，cfg.prodPar 只作为可选压低开关；
      var PROD_PAR = Math.max(1, Math.min(Number(cfg.prodPar) || list.length, list.length));
      if (Number(cfg.gateCap) > 0) xtGate.cap = Math.min(96, Math.max(8, Number(cfg.gateCap)));   // v3.7.78 闸门初值可配
      var nextIdx = 0, doneProd = 0;
      async function washOne(i) {
        var v = list[i];
        var pCur = wash.products && wash.products[i];
        // v3.7.33 续跑：这个商品上次已经组好导入行 → 直接复用，不重出图/不重复改标题/不重复扣费
        if (resumeJob && pCur && pCur.rowCache) {
          rows.push(pCur.rowCache); okN++;
          pCur.status = 'done'; pCur.localStage = '✅ 已完成（续跑复用，未重复扣费）';
          localMark(i, pCur.localStage, 'done');
          log('♻️ ' + (i + 1) + '/' + list.length + ' 「' + String(pCur.title || v.title).slice(0, 18) + '」上次已完成，直接复用');
          return;
        }
        // 已出过的图按 idx 复用（只补缺的），fiss>1 时 idx 会重叠，整体重跑更安全
        var preUrls = (resumeJob && pCur && fiss === 1) ? (pCur.localUrls || []) : null;
        localMark(i, fiss > 1 ? '🌿 裂变规划中…' : '🎨 出图中…', 'running');   // v3.7.27c
        if (pCur && !pCur.linkT0) pCur.linkT0 = Date.now();   // v3.7.39 每链接单独计时（结果区行内实时显示「已跑」）
        var tpl = tplForItem(v.tplKey) || cfg.tpl || {};
        var note = String(noteByPid[v.id] || '').trim();
        // 参数原则（按用户要求 v3.7.24 收敛）：一律以采集原始数据为准（fillCols 透传）；
        // 只有客户手动在模板里填了固定值（tpl.fixed）才改参数，不做任何 AI 自动推断。
        var effFixed = (tpl.fixed && typeof tpl.fixed === 'object') ? JSON.parse(JSON.stringify(tpl.fixed)) : {};
        var effTpl = JSON.parse(JSON.stringify(tpl));
        effTpl.fixed = effFixed;
        var fxStr = tplFixedStr(effTpl);
        // v3.7.69 每条链接开跑时播报模板配置：中/英标题、生图模式、改造幅度一目了然（英文标题空着先看这行）
        log('🧩 链接' + (i + 1) + '模板：' + (effTpl.zh === false ? '中文标题不改' : '改中文标题') + ' · ' + (effTpl.en ? '生成英文标题' : '【未勾】英文标题（勾了才会生成）') + ' · 生图' + (effTpl.img === false ? '关闭' : (effTpl.imgMode === 'pod' ? 'POD-' + ({ light: '轻', mid: '标准', strong: '强' }[effTpl.podLevel || 'mid']) + '改造' : '原样复刻')) + (effTpl.prompt ? ' · 有补充提示词' : ''));
        // 单品裂变（v3.7.24）：fiss>1 时 AI 规划 N 个差异化变体（方向+中英标题），每个变体独立出一条新链接
        var variants = [];
        if (fiss > 1) {
          try {
            var vr = await chrome.runtime.sendMessage({ cmd: 'chat', messages: [
              { role: 'system', content: '你是电商选品裂变助手。把这个商品裂成 ' + fiss + ' 个差异化变体（不同的风格/场景/目标人群/节日主题，彼此明显不同，且都符合商品事实，不编造材质与功能）。每个变体输出：theme=变体方向（不超过10字中文）、titleZh=该变体的中文商品标题（不超过200字符，保留品类/材质/数量/尺寸）、titleEn=该变体的英文Temu标题（不超过200字符）。只输出 JSON 数组（形如 [{"theme":"...","titleZh":"...","titleEn":"..."}]），不要任何解释。' },
              { role: 'user', content: '商品：' + v.title + (fxStr ? '；固定值：' + fxStr : '') }
            ] });
            if (vr && vr.ok) {
              var varr = null;
              try { varr = JSON.parse(String(vr.data).replace(/```json|```/g, '').trim()); } catch (eV) {}
              if (Array.isArray(varr)) variants = varr.slice(0, fiss).map(function (x) {
                return { theme: String((x && x.theme) || '').slice(0, 20), titleZh: String((x && x.titleZh) || '').slice(0, 200), titleEn: String((x && x.titleEn) || '').slice(0, 200) };
              });
            }
          } catch (eV2) {}
          while (variants.length < fiss) variants.push({ theme: '变体' + (variants.length + 1), titleZh: '', titleEn: '' });
          log('🌿 裂变规划：' + variants.map(function (x) { return x.theme || '?'; }).join(' / '));
        } else {
          variants.push({ theme: '', titleZh: '', titleEn: '' });
        }
        localSetProg(10 + Math.round(doneUnits / Math.max(1, imgUnitsTotal) * 72),
          '④ 出图 ' + doneUnits + '/' + imgUnitsTotal + ' 张 · 链接 ' + (i + 1) + '/' + list.length + '：' + String(v.title).slice(0, 18) + '…');
        try {
          var fr = null;
          if (effTpl.img !== false) {
            fr = await chrome.runtime.sendMessage({ cmd: 'fetchImg', url: v.imgs[0] });
            if (!fr || !fr.ok) throw new Error('参考图读取失败：' + ((fr && fr.error) || v.imgs[0]));
          }
          var made = 0;
          for (var kx = 0; kx < variants.length; kx++) {
            var va = variants[kx];
            var urls = [];
            // v3.7.89 POD 强改造参考图接力：先出主图（新设计），再用主图当其余分镜的参考图。
            // 之前只靠提示词压不住 images/edits 模型对原始参考图的复读倾向，客户实测「只有主图变，其他不变」
            var podStrong = effTpl.imgMode === 'pod' && (effTpl.podLevel || 'mid') === 'strong';
            var slotRef = fr ? fr.dataUrl : '';
            if (effTpl.img !== false) {
              var prompts = [], pMiss = 0;
              for (var pi = 0; pi < imgN; pi++) {
                var pp = buildImgPrompt(pi, effTpl, note, i);   // v3.7.69 传商品序号，主图构图按品轮换
                if (va.theme) pp += ' 【本条变体方向：' + va.theme + '】';
                prompts.push(pp);
              }
              // v3.7.78 不再按 10 张一波：整品全部图一次性进全局闸门队列，完成一张放行一张，上游只承受闸门值
              for (var g0 = 0; g0 < prompts.length; g0 += (prompts.length || 1)) {
                var chunk = prompts.slice(g0, g0 + prompts.length);
                localSetProg(10 + Math.round(doneUnits / Math.max(1, imgUnitsTotal) * 72),
                  '④ 出图 ' + doneUnits + '/' + imgUnitsTotal + ' 张 · 本链接第 ' + (g0 + 1) + '-' + Math.min(g0 + chunk.length, prompts.length) + '/' + prompts.length + ' 张' + (variants.length > 1 ? '（变体' + (kx + 1) + '/' + variants.length + '）' : ''));
                localMark(i, '🎨 出图 ' + (g0 + 1) + '-' + Math.min(g0 + chunk.length, prompts.length) + '/' + prompts.length + (variants.length > 1 ? '（变体' + (kx + 1) + '/' + variants.length + '）' : ''), 'running');   // v3.7.27c
                // v3.7.32 单张失败不再整单失败：先记下缺的，立刻补 3 轮（每轮 4s），补不回来就跳过继续出后面的图
                // v3.7.33 续跑：这一批里上次已出过的图直接复用原图链，只对缺的下单（不重复扣费）
                var haveMap = {};
                if (preUrls) for (var qi = 0; qi < chunk.length; qi++) {
                  if (preUrls[g0 + qi]) { haveMap[qi] = 1; doneUnits++; }
                }
                var part = chunk.map(function (pp2, ci) { return haveMap[ci] ? { pre: preUrls[g0 + ci] } : null; });
                var todo = [];
                for (var ti = 0; ti < chunk.length; ti++) if (!haveMap[ti]) todo.push(ti);
                if (todo.length < chunk.length) log('♻️ 第 ' + (g0 + 1) + '-' + (g0 + chunk.length) + ' 张：' + (chunk.length - todo.length) + ' 张上次已出，复用原图链，只补 ' + todo.length + ' 张');
                // v3.7.78 bctx = 本批次取消标记：用户点「⏭ 跳过等待」时，队列里没开跑的图直接作废不再下单（防白扣费）
                var bctx = { cancelled: false };
                // v3.7.68 卡住播报 + 逐张日志；v3.7.78 降频（60s 首报，之后每 120s 一报），大单不刷屏
                var tBatch = Date.now();
                var linkTag = '链接' + (i + 1) + '「' + String(v.title).slice(0, 12) + '」';
                // v3.7.89 强改造主图先行：单独先出第 1 张，成功后拿它当参考图出其余分镜；
                // 主图上次已出过（续跑复用）就拉原图回来当参考图，保证分镜与主图同款
                if (podStrong && chunk.length > 1 && todo.indexOf(0) >= 0) {
                  localMark(i, '🎨 强改造主图先行（新设计打底）…', 'running');
                  var tG0 = Date.now();
                  try {
                    var gr0 = await xtGenGated(fr.dataUrl, chunk[0], bctx);
                    var secs0 = Math.round((Date.now() - tG0) / 100) / 10;
                    if (gr0 && gr0.skipped) { part[0] = { err: '⏭ 用户跳过等待' }; }
                    else if (!gr0 || !gr0.ok) {
                      part[0] = { err: 'AI 生图失败：' + ((gr0 && gr0.error) || '未知') };
                      runStat.fail++;
                      log('❌ ' + linkTag + '第 1 张（主图）失败：' + xtMaskErr((gr0 && gr0.error) || '未知').slice(0, 90) + '（等了 ' + secs0 + 's）');
                    } else {
                      part[0] = { dataUrl: gr0.data.dataUrl, srcUrl: (gr0.data.srcUrl || '') };
                      runStatOk(gr0.data.station, gr0.data.dataUrl);
                      log('✅ ' + linkTag + '第 1/' + prompts.length + ' 张（主图）：' + (gr0.data.station ? xtStAlias(gr0.data.station) + ' · ' : '') + secs0 + 's · ' + Math.round((gr0.data.dataUrl || '').length * 0.75 / 1024) + 'KB');
                    }
                  } catch (e0b) {
                    part[0] = { err: String(e0b && e0b.message || e0b) };
                    log('❌ ' + linkTag + '第 1 张（主图）异常：' + String(e0b && e0b.message || e0b).slice(0, 90));
                  }
                  if (part[0] && part[0].dataUrl) slotRef = part[0].dataUrl;
                  var tIdx0 = todo.indexOf(0); if (tIdx0 >= 0) todo.splice(tIdx0, 1);
                } else if (podStrong && haveMap[0] && preUrls && preUrls[g0]) {
                  // 主图复用上次已出的：拉回 dataURL 当分镜参考图
                  try { var f0r = await chrome.runtime.sendMessage({ cmd: 'fetchImg', url: preUrls[g0] }); if (f0r && f0r.ok && f0r.dataUrl) slotRef = f0r.dataUrl; } catch (eF0) {}
                }
                var batchWd = setInterval(function () {
                  var s2 = Math.round((Date.now() - tBatch) / 1000);
                  if (s2 === 60 || (s2 >= 120 && s2 % 120 === 0)) log('⏳ ' + linkTag + '第 ' + (g0 + 1) + '-' + (g0 + chunk.length) + ' 张已等 ' + s2 + 's 还没全部返回（含排队；单张上游超时 420s）；不想等可点日志区上方「⏭ 跳过等待」立即继续');
                }, 30000);
                var wrMain = await xtWaitRace(Promise.all(todo.map(function (ci) {
                  var tG = Date.now();
                  return xtGenGated(slotRef, chunk[ci], bctx).then(function (gr) {
                    var secs = Math.round((Date.now() - tG) / 100) / 10;
                    if (gr && gr.skipped) { part[ci] = { err: '⏭ 用户跳过等待' }; return; }   // v3.7.78 队列中被取消，不算失败
                    if (!gr || !gr.ok) {
                      part[ci] = { err: 'AI 生图失败：' + ((gr && gr.error) || '未知') };
                      runStat.fail++;   // v3.7.75 本单统计
                      log('❌ ' + linkTag + '第 ' + (g0 + ci + 1) + ' 张（' + pvImgType(g0 + ci) + '）失败：' + xtMaskErr((gr && gr.error) || '未知').slice(0, 90) + '（等了 ' + secs + 's）');
                      return;
                    }
                    part[ci] = { dataUrl: gr.data.dataUrl, srcUrl: (gr.data.srcUrl || '') };   // v3.7.28 srcUrl=上游本站图链（base64 回传时为空）
                    runStatOk(gr.data.station, gr.data.dataUrl);   // v3.7.75 本单统计
                    log('✅ ' + linkTag + '第 ' + (g0 + ci + 1) + '/' + prompts.length + ' 张（' + pvImgType(g0 + ci) + '）：' + (gr.data.station ? xtStAlias(gr.data.station) + ' · ' : '') + secs + 's · ' + Math.round((gr.data.dataUrl || '').length * 0.75 / 1024) + 'KB');
                  }).catch(function (e1) {
                    part[ci] = { err: String(e1 && e1.message || e1) };
                    log('❌ ' + linkTag + '第 ' + (g0 + ci + 1) + ' 张（' + pvImgType(g0 + ci) + '）异常：' + String(e1 && e1.message || e1).slice(0, 90) + '（等了 ' + Math.round((Date.now() - tG) / 100) / 10 + 's）');
                  });
                })));
                if (!wrMain) todo.forEach(function (ci) { if (!part[ci]) part[ci] = { err: '⏭ 用户跳过等待（图未返回，稍后可补图）' }; });
                clearInterval(batchWd);
                for (var rTry = 0; rTry < 3; rTry++) {
                  var bads = [];
                  for (var bi = 0; bi < part.length; bi++) if ((!part[bi] || (part[bi].err && !xtIsSkipErr(part[bi].err))) && !xtIsSkipErr(part[bi])) bads.push(bi);   // v3.7.73 用户跳过的槽位不进补图轮
                  if (!bads.length) break;
                  localMark(i, '🩹 第 ' + (rTry + 1) + ' 轮补图：' + bads.length + ' 张…', 'running');
                  log('🩹 第 ' + (rTry + 1) + ' 轮补图：第 ' + bads.map(function (x) { return g0 + x + 1; }).join('/') + ' 张重试中（已出的图不动）');
                  await nap(4000);
                  var wrRetry = await xtWaitRace(Promise.all(bads.map(function (bx) {
                    var tG2 = Date.now();
                    return xtGenGated(bx === 0 ? fr.dataUrl : slotRef, chunk[bx], bctx).then(function (gr) {
                      if (gr && gr.skipped) { part[bx] = { err: '⏭ 用户跳过等待' }; return; }   // v3.7.78
                      if (!gr || !gr.ok) {
                        part[bx] = { err: 'AI 生图失败（补图）：' + ((gr && gr.error) || '未知') };
                        runStat.fail++;   // v3.7.75 本单统计
                        log('❌ ' + linkTag + '第 ' + (g0 + bx + 1) + ' 张补图仍失败：' + xtMaskErr((gr && gr.error) || '未知').slice(0, 90) + '（等了 ' + Math.round((Date.now() - tG2) / 100) / 10 + 's）');
                        return;
                      }
                      part[bx] = { dataUrl: gr.data.dataUrl, srcUrl: (gr.data.srcUrl || '') };
                      runStat.fail--;   // v3.7.78 补图成功，把主轮记的失败抵回来，统计才准
                      runStatOk(gr.data.station, gr.data.dataUrl);   // v3.7.75 本单统计
                      log('✅ ' + linkTag + '第 ' + (g0 + bx + 1) + ' 张补图成功：' + (gr.data.station ? xtStAlias(gr.data.station) + ' · ' : '') + Math.round((Date.now() - tG2) / 100) / 10 + 's · ' + Math.round((gr.data.dataUrl || '').length * 0.75 / 1024) + 'KB');
                    }).catch(function (e2) {
                      part[bx] = { err: String(e2 && e2.message || e2) };
                      log('❌ ' + linkTag + '第 ' + (g0 + bx + 1) + ' 张补图异常：' + String(e2 && e2.message || e2).slice(0, 90) + '（等了 ' + Math.round((Date.now() - tG2) / 100) / 10 + 's）');
                    });
                  })));
                  if (!wrRetry) bads.forEach(function (bx) { if (!part[bx] || !part[bx].dataUrl) part[bx] = { err: '⏭ 用户跳过等待（图未返回，稍后可补图）' }; });
                }
                for (var u0 = 0; u0 < part.length; u0++) {
                  var gen = part[u0];
                  if (gen && gen.pre) { urls.push(gen.pre); continue; }   // v3.7.33 续跑复用上次的图链
                  if (!gen || gen.err) {   // 补不回来：跳过这张，整单继续，结尾统一提示可 🩹 补图
                    pMiss = (pMiss || 0) + 1;
                    try {   // 登记占位记录，稍后「🩹 补图」按原提示词只补这一张
                      localShotAdd(i, { item: i + 1, varr: kx + 1, img: g0 + u0 + 1, idx: g0 + u0, dataUrl: '', prompt: prompts[g0 + u0], url: '', ref: fr.dataUrl, title: String(v.title).slice(0, 18), failed: true });
                    } catch (eSh) {}
                    log('⚠️ 第 ' + (g0 + u0 + 1) + ' 张（' + pvImgType(g0 + u0) + '）补图 3 轮仍失败，先跳过：' + xtMaskErr(gen && gen.err || '').slice(0, 80));
                    continue;
                  }
                  var shot = { item: i + 1, varr: kx + 1, img: g0 + u0 + 1, idx: g0 + u0, dataUrl: gen.dataUrl, prompt: prompts[g0 + u0], url: '', ref: fr.dataUrl, title: String(v.title).slice(0, 18) };   // v3.7.27c 记录每张图，供结果区预览/单张重生成
                  var finalUrl = '';
                  if (xtSrcDirect() && gen.srcUrl && /^https:\/\//.test(gen.srcUrl)) {
                    finalUrl = gen.srcUrl;   // v3.7.28 外链直写：上游本站图链直接入表，跳过图片空间
                  } else {
                  var _op = xtOutCap();
                  var blob = await xtRecompress(await (await fetch(gen.dataUrl)).blob(), _op.cap, _op.maxDim);   // v3.7.75 按体积档位压缩
                  blob = await blob;
                  var form = new FormData();
                  form.append('uploadImgFile', new File([blob], 'wash-' + v.id + '-' + (kx + 1) + '-' + (g0 + u0 + 1) + '.jpg', { type: blob.type || 'image/jpeg' }));
                  form.append('imageScene', 'previewImage'); form.append('uploadType', 'file'); form.append('scene', '');
                  var up = await fetch('/api/picture/picture/uploadPictureFile', {
                    method: 'POST', credentials: 'same-origin', redirect: 'error', body: form, signal: AbortSignal.timeout(60000)
                  });
                  if (!up.ok) throw new Error('成品图上传妙手失败（HTTP ' + up.status + '）');
                  var ui2 = await up.json();
                  if (ui2.result !== 'success' || !ui2.picturePath) {
                    if (ui2.code === 30013 || /容量不足/.test(String(ui2.reason || ''))) {
                      quotaFull = true;
                      throw new Error('🛑 妙手图片空间容量不足（code 30013）。请到妙手「图片空间/素材库」清理旧图或扩容后重试；本单已自动停止，后续商品不再生图（避免白扣生图费）。');
                    }
                    throw new Error('妙手未返回可用图链（HTTP ' + up.status + '，blob ' + Math.round(blob.size / 1024) + 'KB，响应 ' + JSON.stringify(ui2).slice(0, 160) + '）');
                  }
                  var uu = new URL(ui2.picturePath);
                  if (uu.protocol !== 'https:' || uu.username || uu.password || uu.port ||
                    !['earth-rt.chengji-inc.com', 'erp.91miaoshou.com'].includes(uu.hostname))
                    throw new Error('返回图链不是已验证的妙手域名，弃用');
                  finalUrl = uu.href;
                  }
                  urls.push(finalUrl);
                  shot.url = finalUrl; localShotAdd(i, shot); doneUnits++;   // v3.7.27c 出图即入结果区 + 单元计数（算剩余时间）
                }
              }
              if (pMiss) log('⚠️ 「' + String(v.title).slice(0, 16) + '」缺 ' + pMiss + ' 张（补图 3 轮仍失败），已先继续；稍后可点 🩹 补图，或对该链接 🔁 重跑');
            } else {
              urls = (v.imgs || []).slice(0, 10);   // 模板未勾「改图」：保留原图链
            }
            // 标题：裂变变体自带优先，缺失时按模板开关 AI 补改写
            var req = [];
            if (effTpl.prompt) req.push('场景/风格要求：' + String(effTpl.prompt).trim());
            if (va.theme) req.push('变体方向：' + va.theme);
            if (fxStr) req.push('必须体现：' + fxStr);
            var newZh = va.titleZh, newEn = va.titleEn;
            if (effTpl.zh !== false && !newZh) {
              localMark(i, '✍️ 改标题中…', 'running');   // v3.7.27c
              try {
                var cr = await chrome.runtime.sendMessage({ cmd: 'chat', messages: [
                  { role: 'system', content: '你是跨境电商（Temu / 妙手 / Amazon）标题优化专家。优化中文商品标题：\n1. 保留核心品类词、材质、图案主题、使用场景；删除极限词与运营堆叠词（包邮/爆款/热卖/最/第一/100%/正品保证/清仓/促销/年份数字）\n2. 按语义段（逗号/顿号/竖线分隔）去重，重复只留一次；用中文逗号分隔；不超过 60 个汉字\n3. 不翻译、不新增原文没有的功能，不编造材质与尺寸\n4. 【2D 硬性规则 — 优先级最高】：原文出现 2D / 2D平面 / 平面 / 单面 / 板片 / 贴片 / flat panel 等表述时判定为 2D 商品，中文标题必须原样带「2D」（推荐「2D平面…」开头），绝不能删掉或改写成 3D / 立体 / 浮雕；原文明确写 NOT 3D / 不是3D / 非3D 的，标题里不许出现 3D；原文不是 2D 的不要凭空加 2D\n只输出标题本身，不要任何解释。' + (req.length ? '\n改写要求：' + req.join('；') : '') },
                  { role: 'user', content: '原标题：' + v.title }
                ] });
                if (cr && cr.ok && typeof cr.data === 'string') newZh = cr.data.trim();
              } catch (eT) { log('⚠️ 中文标题改写失败（' + String(eT.message || eT).slice(0, 50) + '），保留原标题'); }
            }
            if (effTpl.en && !newEn) {
              var enSys = '你是跨境电商（Temu / 妙手 / Amazon）英文标题优化专家。基于中文标题产出一条英文电商标题：\n1. Amazon/Temu 规范：删除 free shipping / hot sale / best / best seller / 100% / perfect / guarantee / cheapest / no.1 等极限词与促销词\n2. 语义段去重（逗号分隔的段重复只留一次）；节日补 Christmas / Halloween / Easter / Thanksgiving / Valentine\'s Day，人群补 for Kids / for Adults / for Family；原文已有则不重复\n3. 不超过 120 字符，半角逗号加空格分隔，保留原文品牌/专有名词\n4. 保留品类词、材质、数量、尺寸与关键参数，不翻译原文没有的功能，不编造材质与尺寸\n5. 【2D 硬性规则 — 优先级最高】：原文含 2D / 2D Flat / 2D平面 / 平面 / 单面 / 板片 / 贴片 / flat panel 时判定为 2D 商品，英文标题必须带「2D」（推荐「2D Flat …」开头），绝不能改写成 3D / 立体 / embossed；原文写 NOT 3D / 不是3D 的标题里不许出现 3D；原文不是 2D 的不要凭空加 2D\n只输出英文标题本身，不要任何解释。';
              // v3.7.67 英文标题：采集源没有时也必须生成（AI 直接从中文标题翻译/改写），失败自动重试一次
              for (var enTry = 0; enTry < 2 && !newEn; enTry++) {
                if (enTry) await nap(1500);
                try {
                  var cr2 = await chrome.runtime.sendMessage({ cmd: 'chat', messages: [
                    { role: 'system', content: enSys + (req.length ? '\n改写要求：' + req.join('；') : '') },
                    { role: 'user', content: '中文标题：' + (newZh || v.title) }
                  ] });
                  if (cr2 && cr2.ok && typeof cr2.data === 'string') newEn = cr2.data.trim();
                } catch (eT2) {
                  if (enTry) log('⚠️ 英文标题生成失败（' + String(eT2.message || eT2).slice(0, 60) + '），保留原标题；若每单都这样，请到「接口设置」确认已连接改标题模型（DeepSeek）');
                }
              }
              // v3.7.69 英文标题生成失败不再静默：写明原因（改标题模型没配/没返回），让客户一眼知道去哪修
              if (!newEn) log('⚠️ 「' + String(v.title).slice(0, 14) + '」英文标题没生成出来：改标题模型两次都没返回正文——到「接口设置」确认①已连接改标题模型（DeepSeek 等对话模型）②点「测试」能返回文字。本条链接仍会导入，只是英文标题空着。');
            }
            var mapped = fillCols(v.raw || {});
            // v3.7.28 SKU 图（颜色图）：单 SKU 直接用主图第一张；多 SKU 时 AI 识别每个规格值的颜色/款式，
            // 逐个生成对应外观的 SKU 图并上传图片空间（外观无差异的 SKU 沿用主图第一张，不白扣费）
            var skuVals = String(mapped['规格属性值1'] || '').split('/').filter(function (x) { return String(x).trim(); });
            var skuUrls = null;
            if (effTpl.img !== false && skuVals.length > 1) {
              localMark(i, '🎨 SKU 图生成中（' + skuVals.length + ' 个 SKU）…', 'running');
              try {
                var plan = null;
                try {
                  var spr = await chrome.runtime.sendMessage({ cmd: 'chat', messages: [
                    { role: 'system', content: '你是电商 SKU 图规划助手。输入商品标题和 SKU 规格值列表，逐个判断该规格值对外观的影响（颜色/图案/款式差异）。\n【硬规则】规格值里的颜色词必须严格按字面执行（「酒红色」就是酒红色、「奶油白」就是奶油白，不得自由发挥）；款式词（长袖/短袖/款A/款B/带灯/不带灯等）要写明具体款式差异点。\n只输出 JSON 数组，形如 [{"sku":"规格值","imgDesc":"给生图模型的一句话外观说明，例如：整体配色改为酒红色，图案与造型保持不变"}]；若该规格值不影响外观（如数量/尺寸/型号），imgDesc 填「与主图相同」。不要任何解释。' },
                    { role: 'user', content: '商品：' + (newZh || v.title) + '\nSKU 规格值：' + skuVals.join('、') }
                  ] });
                  if (spr && spr.ok) { try { plan = JSON.parse(String(spr.data).replace(/```json|```/g, '').trim()); } catch (eP) {} }
                } catch (eP2) {}
                if (!Array.isArray(plan) || !plan.length) plan = skuVals.map(function (s) { return { sku: s, imgDesc: '' }; });
                skuUrls = [];
                // v3.7.92 商品主体一致性（客户拍板）：全部 SKU 图一律以「洗后主图」当参考图，不再用源品原图/源品规格图——
                // 源品图没洗过，商品主体/风格与洗后主图必然不一致，正是「SKU 图与主图商品主体不同」的根因。
                // 提示词硬性锁定：商品主体（形状/结构/版型/图案/数量）与参考图一模一样，只按规格改字面颜色/款式。
                var washedMainRef = urls[0] || '';   // 已上传的洗后主图链接（公网可达），作为所有 SKU 图的统一参考
                var skuPlan = skuVals.map(function (sv, svi) {
                  var hit = plan.filter(function (p) { var ps = String(p && p.sku || ''); return ps.indexOf(sv) >= 0 || sv.indexOf(ps) >= 0; })[0];
                  var desc = String((hit && hit.imgDesc) || '').trim();
                  var ask = !!(desc && desc.indexOf('与主图相同') < 0);
                  var prompt = ask ? (LOCAL_RULES.master + ' 【SKU 变体图 · 商品主体硬性锁定】这张图与参考图（洗后主图）必须是同一件商品：商品的形状、结构、版型、图案、文字、数量、拍摄角度、构图一律与参考图一模一样，严禁改动商品主体，严禁换成别的款式或造型；只允许按规格「' + sv + '」改变：' + desc + '（且只改这一项，其他一律不动）；不得出现任何文字标注。') : '';
                  return { sv: sv, ask: ask, ref: washedMainRef, refTag: '洗后主图', prompt: prompt };
                });
                var skuCtx = { cancelled: false };   // v3.7.78 SKU 批次取消标记
                var wrSku = await xtWaitRace(Promise.all(skuPlan.filter(function (x) { return x.ask; }).map(function (x) {
                  var run = async function (prompt, refUrl) {
                    var refD = refUrl;
                    if (/^https?:\/\//i.test(refUrl || '')) {   // 规格源图是图链，先取回 dataURL 再当参考图
                      try { var bl = await (await fetch(refUrl, { credentials: 'omit', referrerPolicy: 'no-referrer' })).blob(); refD = await new Promise(function (rs) { var fr2 = new FileReader(); fr2.onload = function () { rs(fr2.result); }; fr2.onerror = function () { rs(''); }; fr2.readAsDataURL(bl); }); } catch (eR) { refD = ''; }
                      if (!refD) { try { var bg = await new Promise(function (res) { chrome.runtime.sendMessage({ cmd: 'fetchImg', url: refUrl }, function (rr) { res(chrome.runtime.lastError ? null : rr); }); }); if (bg && bg.ok) refD = bg.dataUrl; } catch (eB) {} }
                    }
                    return xtGenGated(refD || washedMainRef || (podStrong ? slotRef : fr.dataUrl), prompt, skuCtx);
                  };
                  return run(x.prompt, x.ref).then(function (g) {
                    if (g && g.skipped) { x.gen = { ok: false, error: '⏭ 用户跳过等待' }; return; }   // v3.7.78 跳过不算失败，走主图兜底
                    if (!g || !g.ok) throw new Error('SKU 图生成失败（' + x.sv + '）：' + xtMaskErr((g && g.error) || '未知'));
                    x.gen = g;
                    runStatOk(g && g.data && g.data.station, g && g.data && g.data.dataUrl);   // v3.7.75 本单统计
                    log('✅ SKU 图「' + x.sv + '」生成（参考：' + x.refTag + ' · ' + String(x.prompt.match(/外观特点：([^；]+)/) ? x.prompt.match(/外观特点：([^；]+)/)[1] : '').slice(0, 40) + '）');
                  }).catch(function (e0) {
                    // v3.7.39 SKU 图失败自动补试一次（等 4s 让上游缓一缓），仍失败才走主图兜底
                    return new Promise(function (rs) { setTimeout(rs, 4000); }).then(function () { return run(x.prompt, ''); }).then(function (g2) {
                      if (g2 && g2.skipped) { x.gen = { ok: false, error: '⏭ 用户跳过等待' }; return; }   // v3.7.78
                      if (!g2 || !g2.ok) throw e0;
                      x.gen = g2;
                      runStatOk(g2 && g2.data && g2.data.station, g2 && g2.data && g2.data.dataUrl);   // v3.7.75 本单统计
                      log('✅ SKU 图「' + x.sv + '」补试成功（参考：主图）');
                    });
                  });
                })));
                if (!wrSku) skuPlan.forEach(function (x) { if (x.ask && (!x.gen || !x.gen.ok)) x.gen = { ok: false, error: '⏭ 用户跳过等待' }; });   // v3.7.78 跳过的 SKU 走主图兜底而不是整品报错
                for (var si = 0; si < skuPlan.length; si++) {
                  var skuT = skuPlan[si], sv = skuT.sv;
                  if (!skuT.ask) { skuUrls.push(urls[0]); continue; }
                  var gr = skuT.gen;
                  if (!gr || !gr.ok) {
                    // v3.7.78 用户跳过的 SKU 沿用主图（之前是整品报错丢弃 SKU 图，不合理）；真失败才抛
                    if (/用户跳过/.test(String(gr && gr.error || ''))) { log('⏭ SKU「' + sv + '」等待被跳过，沿用主图'); skuUrls.push(urls[0]); continue; }
                    throw new Error('SKU 图生成失败（' + sv + '）：' + String(gr && gr.error || '无返回'));
                  }
                  if (xtSrcDirect() && gr.srcUrl && /^https:\/\//.test(gr.srcUrl)) { skuUrls.push(gr.srcUrl); continue; }   // v3.7.28 外链直写
                  var _opS = xtOutCap();
                  var sblob = await xtRecompress(await (await fetch(gr.dataUrl)).blob(), _opS.cap, _opS.maxDim);   // v3.7.75 SKU 图按体积档位压缩
                  sblob = await sblob;
                  var sform = new FormData();
                  sform.append('uploadImgFile', new File([sblob], 'wash-sku-' + v.id + '-' + (kx + 1) + '-' + (si + 1) + '.jpg', { type: sblob.type || 'image/jpeg' }));
                  sform.append('imageScene', 'previewImage'); sform.append('uploadType', 'file'); sform.append('scene', '');
                  var sui = null;
                  for (var satt = 0; satt < 2; satt++) {   // v3.7.51 SKU 上传失败自动重试 1 次（主图上传同接口成功过，多为瞬时拦截）
                    var sup = await fetch('/api/picture/picture/uploadPictureFile', { method: 'POST', credentials: 'same-origin', redirect: 'error', body: sform, signal: AbortSignal.timeout(60000) });
                    if (!sup.ok) { if (satt === 0) { await sleep(3000); continue; } throw new Error('SKU 图上传妙手失败（HTTP ' + sup.status + '）'); }
                    sui = await sup.json();
                    if (sui.result === 'success' && sui.picturePath) break;
                    if (sui.code === 30013) { quotaFull = true; throw new Error('🛑 妙手图片空间容量不足（code 30013），SKU 图上传被拦'); }
                    if (satt === 0) { await sleep(3000); continue; }
                    throw new Error('SKU 图未返回可用图链（' + sv + '，响应 ' + JSON.stringify(sui).slice(0, 160) + '）');
                  }
                  var su2 = new URL(sui.picturePath);
                  if (su2.protocol !== 'https:' || su2.username || su2.password || su2.port ||
                    !['earth-rt.chengji-inc.com', 'erp.91miaoshou.com'].includes(su2.hostname))
                    throw new Error('SKU 图图链不是已验证的妙手域名，弃用');
                  skuUrls.push(su2.href);
                }
                log('🎨 SKU 图：' + skuVals.length + ' 个 SKU 已按各自颜色/款式生成并上传（' + skuPlan.filter(function (x) { return x.ask; }).length + ' 张定制图 + ' + skuPlan.filter(function (x) { return !x.ask; }).length + ' 张沿用主图）');
                doneUnits += skuVals.length;   // v3.7.28 SKU 图也计入单元（剩余时间估算更准）
              } catch (eSku) {
                skuUrls = null;
                log('⚠️ SKU 变体图没生成成功（' + String(eSku.message || eSku).slice(0, 80) + '）：已自动补试仍失败，本变体全部 SKU 暂用主图第一张顶替——不影响导入和上架，客户点颜色/款式时看到的图与主图相同；想要区分色图可在跑完后对该链接点「补失败图」重试');   // v3.7.39 说清后果与补救
              }
              if (quotaFull) throw new Error('🛑 图片空间容量不足（30013），本单已停止，避免白扣生图费');
            }
            var row = {};
            TPL_HDR.forEach(function (h) { if (mapped[h] != null && mapped[h] !== '') row[h] = mapped[h]; });
            row['产品ID'] = newPid12();
            row['产品名称'] = (effTpl.zh !== false && newZh) ? newZh : (newEn || v.title);
            if (newEn) row['英文标题'] = newEn;
            if (pCur) pCur.titleFinal = { orig: String(v.title || ''), zh: String(row['产品名称'] || ''), en: String(row['英文标题'] || '') };   // v3.7.82 标题对比用（🆚 弹窗展示原/新标题）
            if (effTpl.img !== false && urls.length) {
              // v3.7.49 妙手校验轮播图最少 5 张（08:04 实测：2 张图导入成功但属性回填报「轮播图最少为5张」）：
              // 生成图不足 5 张时用源品原图补位（原图排在生成图后面，客户可自行删减）
              var carUrls = urls.slice();
              if (carUrls.length < 5) {
                // v3.7.52 补位源图：列表行 imgs 只有缩略图（1张），详情全量抓取后的 raw.imgUrls 才是完整原图集
                var srcImgs = (Array.isArray(v.imgs) ? v.imgs : []).concat(Array.isArray(v.raw && v.raw.imgUrls) ? v.raw.imgUrls.map(xtAbsUrl) : []);
                srcImgs.forEach(function (su) { if (carUrls.length < 5 && su && carUrls.indexOf(su) < 0) carUrls.push(su); });
                if (carUrls.length > urls.length) log('🖼 生成图 ' + urls.length + ' 张不足妙手最低 5 张，已用源品原图补 ' + (carUrls.length - urls.length) + ' 张');
              }
              row['产品轮播图链接'] = carUrls.join('\n');   // 多图按妙手导入格式换行分隔
              row['产品素材图链接'] = urls[0];
              row['产品预览图链接'] = urls[0];
              // v3.7.28 详情图：全部生成图写进商品描述（已用导入探针实测验证妙手支持「商品详情图」列）
              row['商品详情图'] = urls.join('\n');
              // v3.7.28 SKU 图：多 SKU 用 AI 生成的对应颜色/款式图；生成失败或单 SKU 用主图第一张
              // v3.7.91 改：SKU 预览图必须跟洗后主图同步。AI 生成失败时不再退回源品旧图（没洗过、风格与主图不一致），
              // 一律用洗后主图 urls[0] 顶替，保证客户点颜色/款式看到的图与洗后主图一致。
              var nSku = Math.max(1, skuVals.length);
              var colCells = [];
              for (var si3 = 0; si3 < nSku; si3++) {
                colCells.push(skuUrls && skuUrls.length === nSku ? skuUrls[si3] : urls[0]);
              }
              row['产品颜色图链接'] = colCells.join('\n');
              if (!skuUrls || skuUrls.length !== nSku) {
                log('🖼 SKU 图：AI 按规格生成未成功，已用洗后主图顶替全部 ' + nSku + ' 个 SKU（与洗后主图保持一致）');
              }
            }
            // 固定值入表（其他参数勾选时）：材质/风格/场景并入类目属性，尺寸单独列；裂变变体把方向并入风格
            if (effTpl.attrs !== false) {
              var attrAdds = [];
              if (String(effFixed.material || '').trim()) attrAdds.push('材质:' + effFixed.material);
              var styleV = [String(effFixed.style || '').trim(), va.theme].filter(Boolean).join('/');
              if (styleV) attrAdds.push('风格:' + styleV);
              if (String(effFixed.scene || '').trim()) attrAdds.push('适用场景:' + effFixed.scene);
              if (attrAdds.length) row['类目属性'] = (row['类目属性'] ? row['类目属性'] + ';' : '') + attrAdds.join(';');
              if (String(effFixed.size || '').trim() && !row['尺寸']) row['尺寸'] = effFixed.size;
            }
            ['SKUID', '店铺ID', '店铺名称', '创建时间', 'SKCID'].forEach(function (h) { delete row[h]; });
            rows.push(row); okN++;
            if (variants.length === 1) { rowByProd[i] = { row: row, srcAttrs: (v.raw && Array.isArray(v.raw.attributes)) ? v.raw.attributes : [], pack: v.raw ? { shape: String(v.raw.outerPackageShape || ''), type: v.raw.outerPackageType != null ? String(v.raw.outerPackageType) : '', imgs: Array.isArray(v.raw.outerPackageImgUrls) ? v.raw.outerPackageImgUrls.slice(0, 6) : [] } : null }; if (pCur) pCur.rowCache = row; }   // v3.7.32 补图回填 / v3.7.33 续跑复用 / v3.7.35 属性回填
            jobSave();   // v3.7.33 每完成一个商品落盘一次（已组好的导入行也存进快照）
            if (pCur) pCur.doneAt = Date.now() - (pCur.linkT0 || (Date.now() - 1000));   // v3.7.39 每链接实际用时，结果区行内显示
            var linkDur = fmtDur(pCur ? pCur.doneAt : 0);
            localMark(i, '✅ 完成：' + (effTpl.img !== false ? '出图 ' + urls.length + ' 张' : '原图保留') + (newZh ? '·中文标题' : '') + (newEn ? '·英文标题' : '') + ' · 用时 ' + linkDur, 'done');   // v3.7.27c
            log('✅ ' + (i + 1) + '/' + list.length + (variants.length > 1 ? ' 裂变' + (kx + 1) + '/' + variants.length : '') + ' 「' + String(newZh || v.title).slice(0, 18) + '」' + (effTpl.img !== false ? ('出图 ' + urls.length + ' 张') : '保留原图') + (newZh ? ' +中文标题' : '') + (newEn ? ' +英文标题' : '') + ' + 传妙手完成 · ⏱ 用时 ' + linkDur);
            speak('第 ' + okN + ' 条完成，用时 ' + linkDur + '。');   // v3.7.43 每条链接完成语音播报
            made++;
          }
        } catch (eOne) {
          failN++;
          localMark(i, '⚠️ 失败：' + String(eOne.message || eOne).slice(0, 30), 'done');   // v3.7.27c
          var pFail = wash.products && wash.products[i]; if (pFail) { pFail.fail = (pFail.fail || 0) + 1; if (pFail.linkT0) pFail.doneAt = Date.now() - pFail.linkT0; }   // v3.7.28 失败计数 / v3.7.39 失败也记用时
          log('⚠️ ' + (i + 1) + '/' + list.length + ' 「' + String(v.title).slice(0, 20) + '」失败：' + String(eOne.message || eOne).slice(0, 200));
          if (!failVoiceDone) { failVoiceDone = true; speak('有商品出错了，请看一眼日志。'); }   // v3.7.25 首个失败即时语音（每单只提醒一次，避免吵）
        }
        if (quotaFull) { log('🛑 图片空间已满，剩余 ' + (list.length - i - 1) + ' 个商品不再处理；清理妙手图片空间后重新勾选即可续跑。'); jobSave(); return; }
        jobSave();   // v3.7.33 每个商品跑完落盘一次

      }
      var prodRuns = [];
      for (var wi = 0; wi < PROD_PAR; wi++) {
        prodRuns.push((async function worker() {
          while (true) {
            if (quotaFull) return;
            var my = nextIdx++;
            if (my >= list.length) return;
            await washOne(my);
            doneProd++;
          }
        })());
      }
      await Promise.all(prodRuns);
      // v3.7.32 自动补图：全部品出完后再统一补 2 轮（只补缺的，已有图不重跑），补到的图回填到导入表
      try {
        var missPairs0 = localMissingPairs();
        if (missPairs0.length) {
          log('🩹 全部出图结束，自动补图开始：缺 ' + missPairs0.length + ' 张（已有图不重跑）');
          var leftN0 = await localRepairAll();
          var patched = 0;
          Object.keys(rowByProd).forEach(function (k) {
            var pRow = wash.products[Number(k)], entryX = rowByProd[k];
            if (!pRow || !entryX) return;
            var rowX = entryX.row;
            var fixed = (pRow.localUrls || []).filter(Boolean);
            var had = String(rowX['产品轮播图链接'] || '').split('\n').filter(Boolean).length;
            if (fixed.length > had) {
              var joined = fixed.join('\n');
              rowX['产品轮播图链接'] = joined; rowX['商品详情图'] = joined;
              rowX['产品素材图链接'] = fixed[0]; rowX['产品预览图链接'] = fixed[0];
              patched++;
            }
          });
          log(leftN0 ? ('⚠️ 自动补图后仍缺 ' + leftN0 + ' 张（导入按实际张数走；可再点 🩹 补图）')
                     : ('✅ 自动补图完成：全部齐全' + (patched ? '，已回填 ' + patched + ' 个商品的图链' : '')));
        }
      } catch (eRep) { log('⚠️ 自动补图异常（不影响导入）：' + String(eRep && eRep.message || eRep).slice(0, 120)); }
      if (!rows.length) throw new Error('全部商品处理失败（' + failN + ' 个），没有可导入的行');
      var autoRows = rows.filter(function (rA) { return !rA.__published; });   // v3.7.87 发布当前已发过的不再重复导入
      if (!autoRows.length) { log('✅ 所有商品都已用「发布当前」发过，无需再自动导入'); wash.done = true; wash.finishedAt = Date.now(); washRender(); jobSave(); return; }
      localSetProg(86, '⑥ 组装 48 列导入表…');
      var csvText = '\ufeff' + [TPL_HDR.map(csvCell).join(',')].concat(autoRows.map(function (fields) {
        return TPL_HDR.map(function (h) { return csvCell(fields[h] || ''); }).join(',');
      })).join('\r\n') + '\r\n';
      localSetProg(90, '⑦ 提交妙手导入…');
      await waitResume('⏸ 已暂停，尚未向妙手提交。');
      var r = await importSend(csvText, 'wash-local-' + okN + '品.csv', 90, function (step) { log('   · ' + step); });   // v3.763 setting 为空自动 RPA 兑底
      if (r.ok) {
        // v3.7.35 属性/外包装接口回填（CSV 导入解析器忽略「类目属性」「包装信息」列）
        try {
          var pairs35 = [];
          Object.keys(rowByProd).forEach(function (k) {
            var en = rowByProd[k];
            if (!en || !en.row || en.row.__published) return;   // v3.7.87 发布当前已发过的不再回填
            if (en.row && en.row['产品名称']) pairs35.push({ title: String(en.row['产品名称']).trim(), en: String(en.row['英文标题'] || '').trim(), srcAttrs: en.srcAttrs || [], pack: en.pack, desc: String(en.row['商品详情图'] || '').split('\n').filter(function (u) { return /^https:\/\//.test(u); }) });
          });
          if (pairs35.length) {
            localSetProg(93, '⑧ 属性/外包装回填…');
            var importStart = new Date(Date.now() - 15 * 60000);
            var pad2 = function (x) { return (x < 10 ? '0' : '') + x; };
            var tsStr = importStart.getFullYear() + '-' + pad2(importStart.getMonth() + 1) + '-' + pad2(importStart.getDate()) + ' ' + pad2(importStart.getHours()) + ':' + pad2(importStart.getMinutes()) + ':' + pad2(importStart.getSeconds());
            await localAttrBackfill(pairs35, tsStr);
          }
        } catch (eBf) { log('⚠️ 属性回填异常（不影响已导入的链接）：' + String(eBf && eBf.message || eBf).slice(0, 140)); }
        wash.done = true; wash.finishedAt = Date.now(); washRender(); log('🎉 导入完成：成功 ' + (r.okN || 0) + ' 失败 ' + (r.failN || 0) + ' 条链接 —— 到妙手「导入记录」查看');   // v3.7.27c
        setProg(100, '🎉 完成：导入成功 ' + (r.okN || 0) + ' 失败 ' + (r.failN || 0) + '（链接在妙手「导入记录」）');
        pushRunLog({ links: r.okN || 0 });
        notify('🎉 本地直连全自动完成', '成功 ' + (r.okN || 0) + ' 失败 ' + (r.failN || 0) + '，产品链接到妙手「导入记录」查看');
        catSay((r.failN || 0) > 0 ? '😿 喵！这单有 ' + (r.failN || 0) + ' 个失败项，点开面板看日志啥原因' : '🚀 喵！<b>' + (r.okN || 0) + ' 条链接建好了</b>，产品链接到妙手「导入记录」查看～这单干得漂亮吧');   // v3.7.25 喵吉祥物补接本地直连完成
        speak((r.failN || 0) > 0 ? ('全部结束，成功 ' + (r.okN || 0) + ' 条，失败 ' + (r.failN || 0) + ' 条，用时 ' + fmtDur(Date.now() - t0) + '，请查看日志。') : '洗图完成，所有链接图片已齐全。');   // v3.7.43 完成播报带汇总
        log('✅ 全自动完成：' + okN + ' 个商品生图/改标题成功（失败 ' + failN + '），导入成功 ' + (r.okN || 0) + ' 失败 ' + (r.failN || 0) + '；用时 ' + Math.round((Date.now() - t0) / 1000) + ' 秒');
        // v3.7.76 本单出图统计小结：只报成功/失败张数与原图数据量，站点信息对客户完全隐藏
        log('📊 本单出图统计：成功 ' + runStat.ok + ' 张 · 失败 ' + runStat.fail + ' 张' + (runStat.bytes ? ' · 原图约 ' + (Math.round(runStat.bytes / 1024 / 1024 * 10) / 10) + 'MB' : '') + '。想省费可把「每品出图」调小或换「体积：小体积」档。');
        // v3.7.34 跑完不再自动刷新页面：用户要在结果区核对/微调，刷新会丢掉现场。
        // 结果区与图片都留在这里；需要看妙手新链接时手动刷新即可（刷新后可在「🕘 历史任务」里恢复本单）。
        log('✅ 本单已结束，页面保持不刷新（方便你在结果区核对/微调）。要看妙手里的新链接时，手动刷新页面即可。');
      } else {
        wash.done = true; washRender();   // v3.7.27c 结果区收尾：不再显示「进行中」
        // v3.7.43 导入结果分明的失败播报：全失败/部分失败/待确认 三种说法，不再一律「待确认」
        var failImp = Number(r.failN) || 0, okImp = Number(r.okN) || 0;
        if (failImp > 0 && okImp === 0) {
          setProg(96, '❌ 导入失败：' + failImp + ' 条全部被妙手拒绝（生图已完成，表格在结果区可核对）');
          log('❌ 导入失败：' + failImp + ' 条全部被拒。生图/传图已完成；常见原因：公用采集箱来源缺必填列（分类/规格/SKU/净重/包装）。请到妙手「导入记录」看明细，或改用普通采集箱数据源跑全自动。');
          speak('注意：' + failImp + ' 条链接导入全部被拒，图已经洗好在结果区。请查看日志。');   // v3.7.43 失败语音
        } else if (failImp > 0) {
          setProg(96, '⚠️ 导入部分失败：成功 ' + okImp + ' 失败 ' + failImp + '；到妙手「导入记录」核对');
          speak('导入结束，成功 ' + okImp + ' 条，失败 ' + failImp + ' 条，请查看日志。');   // v3.7.43 部分失败语音
        } else {
          setProg(96, '⚠️ 表格已提交，结果待确认；请到妙手「导入记录」核对');
          speak('表格已提交妙手，结果还没确认，请稍后到导入记录查看。');   // v3.7.43 待确认语音
        }
      }
    } catch (e) {
      var m = String(e.message || e);
      if (m.indexOf('用户取消') === 0) { log('↩️ 已取消'); setProg(0, ''); }
      else { log('❌ 本地直连失败：' + m.slice(0, 200)); setProg(0, '❌ ' + m.slice(0, 120), true); }
    } finally {
      busy = false; paused = false;
      try { clearInterval(progTimer); } catch (eT2) {}   // v3.7.28 停掉进度计时刷新
      if (pauseBtn) { pauseBtn.textContent = '⏸ 暂停'; pauseBtn.disabled = true; }
      if (oneBtn) oneBtn.disabled = false;
      if (autoBtn) autoBtn.disabled = false;
      try { window.__mscbApplyMode && window.__mscbApplyMode(); } catch (eA) {}
      // v3.7.27c 结果区收尾：没轮到的商品标「未处理」，别一直显示「进行中」
      try {
        (wash.products || []).forEach(function (p) {
          if (p.local && p.status === 'running' && !(p.done >= p.total)) { p.localStage = '⏸ 未处理（任务提前结束）'; p.status = 'done'; }
        });
        washRender();
      } catch (eF) {}
      // v3.7.33 断点续跑：收尾落盘 + 记入历史，下次打开面板可「继续上次任务」
      try {
        if (jobMeta) {
          jobSave(true);
          var snapEnd = jobRead();
          if (snapEnd) jobPushMeta(snapEnd);
        }
        renderJobBar(); renderHistLocal();
      } catch (eJ) {}
    }
  }

  /* ---------- v3.7.33 断点续跑 UI：顶部横幅 + 历史任务框（本机快照，可恢复） ---------- */
  function jobSummary(job) {
    var ps = (job && job.products) || [];
    var total = 0, got = 0, doneProd = 0;
    ps.forEach(function (p) {
      total += Number(p.total) || 0;
      var g = (p.localUrls || []).filter(Boolean).length;
      got += g;
      if (p.row || g >= (Number(p.total) || 1)) doneProd++;
    });
    return { nProd: ps.length, total: total, got: got, doneProd: doneProd, finished: !!job.finished, at: (job && (job.at || job.savedAt)) || 0 };
  }
  function fmtAgo(ts) {
    var d = Math.max(0, Date.now() - (ts || 0));
    if (d < 60000) return '刚刚';
    if (d < 3600000) return Math.round(d / 60000) + ' 分钟前';
    if (d < 86400000) return Math.round(d / 3600000) + ' 小时前';
    return Math.round(d / 86400000) + ' 天前';
  }
  function resumeJobGo() {
    if (busy || rerunning || repairBusy) { log('⏳ 当前有任务在跑，等它结束再继续上次任务'); return; }
    var job = jobRead();
    if (!job) { log('ℹ️ 没有可恢复的任务记录'); return; }
    log('♻️ 继续上次任务：' + (job.products || []).length + ' 个商品，已完成的不重出');
    localAutoOne(job).catch(function (e) { log('⚠️ 续跑失败：' + String(e && e.message || e).slice(0, 160)); });
  }
  function jobViewOnly() {
    var job = jobRead();
    if (!job) { log('ℹ️ 没有可恢复的任务记录'); return; }
    localStateRestore(job);
    log('👁 已恢复上次任务的结果区（图链都在，可预览/导出/补图；要接着出图点「▶ 继续」）');
  }
  function renderJobBar() {
    var bar = document.querySelector('.mscb-jobbar');
    if (!bar) return;
    var job = jobRead();
    if (!job || !((job.products || []).length)) { bar.style.display = 'none'; bar.innerHTML = ''; return; }
    var s = jobSummary(job);
    if (s.finished && Date.now() - (job.savedAt || s.at) > 7 * 86400000) { bar.style.display = 'none'; bar.innerHTML = ''; return; }
    bar.style.display = '';
    bar.className = 'mscb-jobbar' + (s.finished ? ' done' : '');
    bar.innerHTML = '';
    var tx = document.createElement('span');
    tx.innerHTML = (s.finished ? '✅ 上次任务已完成：' : '⏸ 上次任务<b>没跑完</b>：')
      + '<b>' + s.doneProd + '/' + s.nProd + '</b> 品 · <b>' + s.got + '/' + s.total + '</b> 张 · ' + fmtAgo(s.at)
      + (s.finished ? '' : '　（刷新/关机都不丢，点继续只补缺的，已出的图不重复扣费）');
    var bts = document.createElement('span'); bts.className = 'mscb-jbtns';
    if (!s.finished) {
      var bGo = document.createElement('button'); bGo.textContent = '▶ 继续上次任务';
      bGo.onclick = function () { resumeJobGo(); };
      bts.appendChild(bGo);
    }
    var bV = document.createElement('button'); bV.textContent = '👁 看结果';
    bV.onclick = function () { jobViewOnly(); };
    var bX = document.createElement('button'); bX.textContent = '🗑 清除';
    bX.title = '清掉这条本机记录（只删恢复数据，不影响已导入妙手的链接）';
    bX.onclick = function () { if (window.confirm('清除上次任务的恢复记录？\n（已生成的图链仍在妙手，不影响已导入的链接；只是以后不能再一键续跑）')) { jobClear(); log('🗑 已清除上次任务记录'); } };
    bts.appendChild(bV); bts.appendChild(bX);
    bar.appendChild(tx); bar.appendChild(bts);
  }
  // 历史任务框：本机快照（可恢复）+ 历史元数据；没有本机记录时交给洗图台磁盘历史
  // v3.7.37 框固定显示：无记录时保留「暂无」占位，不再隐藏整个框
  function renderHistLocal() {
    var histWrap = document.querySelector('.mscb-histwrap');
    if (!histWrap) return;
    histWrap.style.display = '';
    var job = jobRead(), metas = jobReadMeta();
    if (!job && !metas.length) {
      var c0 = histWrap.querySelector('.mscb-histcount');
      if (c0) c0.textContent = '暂无';
      return false;
    }
    var nameEl = histWrap.querySelector('.mscb-histname');
    var listEl = histWrap.querySelector('.mscb-histlist');
    var cntEl = histWrap.querySelector('.mscb-histcount');
    if (nameEl) nameEl.textContent = '🕘 历史任务（本机 · 可恢复）';
    listEl.innerHTML = '';
    var rows = 0;
    if (job) {
      rows++;
      var s = jobSummary(job);
      var row = document.createElement('div'); row.className = 'mscb-histrow';
      var t = document.createElement('div'); t.className = 'mscb-histt';
      t.textContent = (s.finished ? '✅ ' : '⏸ ') + ((job.items || []).slice(0, 2).map(function (x) { return String(x.title || '').slice(0, 12); }).join(' / ') || '上次任务') + (s.nProd > 2 ? ' 等 ' + s.nProd + ' 品' : '');
      t.title = t.textContent;
      var meta = document.createElement('div'); meta.className = 'mscb-histmeta';
      meta.textContent = s.got + '/' + s.total + ' 张 · ' + fmtAgo(s.at);
      var btns = document.createElement('div'); btns.className = 'mscb-histbtns';
      if (!s.finished) {
        var bGo = document.createElement('button'); bGo.textContent = '▶'; bGo.title = '继续这个任务（只补缺的图）';
        bGo.onclick = function () { resumeJobGo(); };
        btns.appendChild(bGo);
      }
      var bV = document.createElement('button'); bV.textContent = '🔍'; bV.title = '把这单已出的图放回结果区（可预览/导出）';
      bV.onclick = function () { jobViewOnly(); };
      btns.appendChild(bV);
      row.appendChild(t); row.appendChild(meta); row.appendChild(btns);
      listEl.appendChild(row);
    }
    metas.forEach(function (m) {
      if (job && Math.abs((m.at || 0) - (job.at || 0)) < 60000) return;   // 当前快照已单列
      rows++;
      var row = document.createElement('div'); row.className = 'mscb-histrow';
      var t = document.createElement('div'); t.className = 'mscb-histt';
      t.textContent = (m.finished ? '✅ ' : '⏸ ') + ((m.titles || []).join(' / ') || '历史任务');
      var meta = document.createElement('div'); meta.className = 'mscb-histmeta';
      meta.textContent = m.nProd + ' 品 · ' + m.nImg + ' 张 · ' + fmtAgo(m.at);
      row.appendChild(t); row.appendChild(meta);
      // v3.7.37 链接模式的历史单：给 🔍 预览按钮（洗图台图床图链，不依赖本机快照）
      if (Array.isArray(m.pids) && m.pids.length) {
        var btns = document.createElement('div'); btns.className = 'mscb-histbtns';
        var bV = document.createElement('button'); bV.textContent = '🔍';
        bV.title = '预览这单的 ' + m.nImg + ' 张成品图';
        bV.onclick = function () {
          var per = Math.max(1, Math.round((m.nImg || m.pids.length * 10) / m.pids.length));
          openPreview(m.pids.map(function (pid, ix) {
            return { pid: String(pid), srcPid: String(pid), title: (m.titles || [])[ix] || ('链接 ' + pid), total: per, done: per, fail: 0, status: 'done', lastErr: '' };
          }));
        };
        btns.appendChild(bV);
        row.appendChild(btns);
      }
      listEl.appendChild(row);
    });
    if (cntEl) cntEl.textContent = rows + ' 条';
    return true;
  }

  // 生成表格 → 读取 → RPA 导入（autoOne 尾段与检查模式大按钮共用）
  async function rpaRun(base, auth, imgBase) {
    await waitResume();
    speak('开始自动化上传');
    setProg(72, '⑦ 生成新表格（48 列）…');
    var info = await relay(base + '/api/csv?' + auth, { base: imgBase, share: String(cfg.share || ''), catAttrs: cfg.catAttrs || '', partial: true });   // v3.5.9 允许部分缺图也出表上传（只带已生成的图）
    if (!info || !info.ok) throw new Error('生成表格失败：' + ((info && info.error) || '未知'));

    setProg(76, '⑧ 读取新表格内容…');
    var csvText = await relayText(base + '/api/download-csv?' + auth, 'GET');
    if (!csvText || csvText.indexOf(',') < 0) throw new Error('新表格内容为空');

    // v3.5.1 重复导入防护：同一份表格 10 分钟内导入过，先确认再放行（防止误点多条导入任务）
    var importSig = String(csvText.length) + ':' + String(csvText).slice(120, 240);
    if (cfg.lastImportSig === importSig && Date.now() - (cfg.lastImportAt || 0) < 10 * 60 * 1000) {
      if (!window.confirm('这份表格 10 分钟内刚导入过（防止重复建链接）。\n确定要再导入一遍吗？')) { log('↩️ 已取消重复导入'); throw new Error('用户取消：10 分钟内已导入过同一份表格'); }
    }

    await waitResume('⏸ 已暂停，尚未向妙手提交。');
    var r = await importSend(csvText, info.name || 'wash-import.csv', 78);
    cfg.lastImportSig = importSig; cfg.lastImportAt = Date.now(); saveCfg();   // v3.5.1 记住最近一次导入指纹
    wash.rpa = true; washRender();
    if (r.links && r.links.length) {
      setProg(100, '🎉 完成：已自动建链接 ' + r.links.length + ' 条，💳 ' + billLine() + (r.ok ? '' : '（提交结果待确认）'));
      pushRunLog({ links: r.links.length });   // v2.8.0：写入经营小看板
      showLinks(r.links);
      notify('🎉 链接建好了', '已自动建 ' + r.links.length + ' 条产品链接，💳 ' + billLine() + '，可复制/导出清单留底');
      catSay('🚀 喵！<b>' + r.links.length + ' 条链接建好了</b>，可以复制留底啦，我这单干得漂亮吧～');   // v2.9.0
    } else if (r.ok) {
      // v3.4.6 直连接口导入：链接不出现在页面上，用导入数量明确报成功（之前文案像失败，客户误判）
      setProg(100, '🎉 完成：直连导入成功 ' + (r.okN || 0) + ' 个 失败 ' + (r.failN || 0) + '（链接在妙手「导入记录」里）');
      log('✅ 导入提交成功：成功 ' + (r.okN || 0) + ' 失败 ' + (r.failN || 0) + '——产品链接稍后出现在采集箱/导入记录，不影响导入本身');
      pushRunLog({ links: r.okN || 0 });
      notify('✅ 导入成功', '成功 ' + (r.okN || 0) + ' 失败 ' + (r.failN || 0) + '，产品链接请到妙手「导入记录」查看');
    } else {
      setProg(96, '⚠️ 表格已生成并注入导入弹窗，未捕获成功提示；请到「导入记录」核对');
    }
  }

  /* ---------------- v2.6.0 半自动进度监控：入台后轮询 /api/status ----------------
     不自动启动洗图，只展示：总进度条 + 每链接进度条 + 预计/实际时间 + 结果区
     （预览 / 重跑 / 修改建议与全自动共用同一套 UI）。 */
  var monToken = 0;
  async function startWashMonitor(monitorOptions) {
    var base = washBaseOf();
    var code = String(cfg.code || '').trim();
    if (!base || !code) return;
    var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
      + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
    var my = ++monToken;
    wash.on = true; wash.done = false;
    wash.gen = 0; wash.lowWarned = false;   // v2.8.0：新任务扣费从零计
    if (!wash.t0) wash.t0 = Date.now();
    if (progEl) progEl.classList.add('show');
    var end = Date.now() + 120 * 60 * 1000;
    while (Date.now() < end && monToken === my) {
      try {
        var st = await statusSafe(base + '/api/status?' + auth, {});
        if (monToken !== my) return;
        if (st.status === 'empty') {
          setProg(10, '⏳ 已导入工作台，等你在网站上传/启动洗图后，这里会实时显示进度…');
          await nap(5000); continue;
        }
        washSync(st);
        washRender(); washTimeLine();
        if (settledWash(st)) {
          var left = missingWashProducts().length;
          if (left && !(monitorOptions && monitorOptions.readOnly)) {
            try { left = await washRepair(base, auth); } catch (e) { log('⚠️ 补图未完成：' + (e && e.message || e)); }
          }
          if (left) { setProg(Math.round(100 * washDoneSum() / Math.max(1, wash.plan)), washTerminalText(), true); return; }
          saveSpeedSample();
          if (!(monitorOptions && monitorOptions.readOnly)) pushRunLog();
          setProg(100, '🎉 洗图完成，可预览或一键上传并导入。');
          // v3.7.37 链接模式跑完也进「历史任务」框（可预览；本机无快照所以没有续跑按钮）
          try {
            var hp = [], ht = [], hn = 0;
            (wash.products || Object.keys(wash.state || {}).map(function (k) { return wash.state[k]; })).forEach(function (p) {
              if (!p) return;
              hp.push(String(p.pid || p.srcPid)); ht.push(p.title); hn += Number(p.done) || 0;
            });
            if (hp.length) histMetaPush(hp, ht, hn, true);
          } catch (eHm) {}
          return;
        }
        if (st.status === 'running') {
          var done = washDoneSum(), plan = Math.max(1, wash.plan || 1);
          setProg(30 + Math.round(40 * done / plan), '🎨 洗图中：' + done + '/' + plan + ' 张…');
        } else {
          setProg(20, '⏳ 洗图台排队 / 待启动中…');
        }
      } catch (e) { /* 网络抖动：下一轮继续 */ }
      await nap(5000);
    }
  }

  /* ---------------- v2.7.1 一键续跑（断点恢复）----------------
     页面刷新 / 浏览器重开 / 换电脑后，任务状态都在服务器上：
     running → 重新接上实时监控；done → 恢复结果区（预览/重跑/建议/建链接）。 */
  async function resumeWash() {
    var base = washBaseOf();
    var code = String(cfg.code || '').trim();
    if (!base || !code) { log('⚠️ 还没有洗图台地址/激活码，无法续跑'); return; }
    if (busy) { log('⏳ 当前有任务进行中，无需续跑'); return; }
    var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
      + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
    log('🔄 续跑：正在从服务器读取上次任务…');
    try {
      var st = await statusSafe(base + '/api/status?' + auth, {});
      if (!st || st.status === 'empty' || !(st.products || []).length) {
        log('ℹ️ 服务器上没有可续跑的任务；重新开始请按「启动」或先在网站导入'); return;
      }
      washSync(st, { silentComplete: st.status === 'done' });
      wash.on = true;
      wash.done = settledWash(st);
      wash.rpa = false;   // 保守处理：RPA 是否建过链接无法确定，结果区保留「一键上传并跑 RPA」由人决定
      if (!wash.t0 && st.generationTiming && st.generationTiming.startedAt) wash.t0 = st.generationTiming.startedAt;
      if (progEl) progEl.classList.add('show');
      washRender(); washTimeLine();
      // v3.2.7 续跑补抓：客户重启后当前页可能只剩一页（20/50/100…），按任务需要的量自动翻页补齐缺失数据。
      // 客户点过下一页、或把每页条数调到 50/100/200/500，都能把没抓到的商品数据补回来（标题/图片/全字段）。
      try {
        var taskIds = washMine().map(function (x) { return String(x.srcPid); });
        var lack = taskIds.filter(function (id) { var it = items.get(id); return !it || !it.title || !it.raw; });
        if (lack.length) {
          log('🔄 续跑补抓：本机还缺 ' + lack.length + ' 个商品的数据，按任务量自动翻页补齐（每页条数不够会自动加大）…');
          var oldLimit = limitN();
          cfg.limit = Math.min(LIMIT_MAX, Math.max(oldLimit, washMine().length + 10));
          try { await pull(false); } catch (e) {}
          try { await fillDetails(); } catch (e) {}
          cfg.limit = oldLimit; saveCfg();
          var still = taskIds.filter(function (id) { var it = items.get(id); return !it || !it.title || !it.raw; }).length;
          if (still) {
            log('🩺 续跑补抓：还差 ' + still + ' 个——翻到对应页或调大每页条数后点「🔄 补采集」即可补上（不影响已洗好的图，只补导出用的数据）');
          } else {
            log('✅ 续跑补抓完成：任务所需 ' + taskIds.length + ' 个商品的数据已全部就位');
          }
        }
      } catch (e) {}
      if (settledWash(st)) {
        if (missingWashProducts().length) {
          busy = true;
          try {
            var left = await washRepair(base, auth);
            setProg(left ? null : 100, left ? washTerminalText() : '✅ 已补齐，可预览或一键上传并导入');
          } finally { busy = false; washRender(); }
          return;
        }
        setProg(100, '✅ 已接回：上次任务已完成（' + washMine().length + ' 个链接）。可预览/重跑/填建议，或点「一键上传并跑 RPA」');
        log('✅ 续跑成功：任务已完成，结果区已恢复（补失败图 + 通知也执行一次）');
        notify('🔄 续跑成功', '上次洗图任务已完成，共 ' + washMine().length + ' 个链接，结果区已恢复');
        catSay('🔄 喵！接回上次任务了（已完成 ' + washMine().length + ' 个链接），结果都在下面～');   // v2.9.0
      } else {
        log('🔄 已接回任务：服务器' + (st.status === 'running' ? '洗图中，继续实时监控' : '排队/待启动，会持续盯进度'));
        startWashMonitor();
      }
    } catch (e) {
      log('❌ 续跑失败：' + (e && e.message ? e.message : e));
    }
  }

  function showOpen(base) {
    // 采集导入后自动打开/切到洗图台。
    // 注意：异步请求之后再 window.open 会被 Chrome 弹窗拦截（这正是「采集完不跳转」的原因），
    // 所以改由后台用 chrome.tabs 打开，并且优先复用已经开着的洗图台标签页。
    var url = base + '/' + (cfg.share ? '?sharecode=' + encodeURIComponent(cfg.share) : '');
    try {
      chrome.runtime.sendMessage({ cmd: 'openStudio', url: url }, function (r) {
        if (chrome.runtime.lastError || !r || !r.ok) {
          try { window.open(url, 'mscb_studio'); } catch (e) { log('⚠️ 没能自动打开洗图台，请手动访问 ' + url); }
          return;
        }
        log(r.reused ? '🔎 已切到洗图台标签页' : '🪟 已打开洗图台标签页');
      });
    } catch (e) {
      try { window.open(url, 'mscb_studio'); } catch (e2) { log('⚠️ 没能自动打开洗图台，请手动访问 ' + url); }
    }
  }

  /* ---------------- 旧配置迁移：把失效的旧地址换掉 ---------------- */
  function migrateCfg() {
    // Do not reuse local workbench credentials on the customer gateway.
    if (cfg.studio || cfg.code || cfg.imgBase || cfg.share) {
      cfg.studio = cfg.code = cfg.imgBase = cfg.share = '';
      saveCfg(); syncInputs();
    }
  }

  // v3.7.4 安全入口：applyMode 定义在面板闭包内，闭包外统一走这里（裸调会抛错并中断 finally 后续逻辑）
  function applyModeSafe() {
    try { if (typeof window.__mscbApplyMode === 'function') window.__mscbApplyMode(); } catch (e) { /* ignore */ }
  }

  // cfg 校准后刷新可见 UI（模式按钮文字 / 暂停态）
  function syncInputs() {
    applyModeSafe();
  }

  /* ---------------- 设置持久化 ---------------- */
  function saveCfg() {
    try { chrome.storage.local.set({ mscb: cfg }); } catch (e) {}
  }
  function loadCfg(cb) {
    try {
      chrome.storage.local.get('mscb', function (v) {
        if (v && v.mscb) {
          Object.keys(v.mscb).forEach(function (k) { if (v.mscb[k] != null) cfg[k] = v.mscb[k]; });
        }
        cb && cb();
      });
    } catch (e) { cb && cb(); }
  }

  /* ---------------- UI ---------------- */
  var statEl, listEl;

  function setStat(t) { if (statEl) statEl.textContent = t; }

  function selCount() {
    var sel = 0;
    items.forEach(function (v) { if (v.sel !== false) sel++; });
    return sel;
  }
  function syncSelBar() {
    var total = items.size, sel = selCount();
    var info = document.querySelector('.mscb-selinfo');
    if (info) info.textContent = total ? ('已选 ' + sel + ' / ' + total) : '未采集';
    // v3.5.2 一键导出按钮实时显示可导数量（抓到多少导多少）
    var expAll = document.querySelector('.mscb-expall');
    if (expAll) {
      var ready = 0;
      items.forEach(function (v) { if (v.title && v.imgs && v.imgs.length) ready++; });
      expAll.textContent = ready ? ('📤 一键导出已抓取数据（' + ready + ' 个 · 全字段）')
        : '📤 一键导出已抓取数据（全部字段）';
    }
    // v3.4.1 按数量模式开着时，数字框实时跟当前勾选数联动（手动取消勾选也会变）
    var cnt = document.querySelector('.mscb-count');
    if (cnt && document.querySelector('.mscb-bycount') && document.querySelector('.mscb-bycount').checked && document.activeElement !== cnt) {
      cnt.value = sel;
    }
    var badge = document.querySelector('.mscb-badge');
    if (badge) {
      if (busy) return;   // v3.3.0 跑单中 badge 显示实时进度，不要被商品数覆盖
      badge.style.display = total ? 'block' : 'none';
      badge.style.background = '#1f2d3d';
      badge.textContent = total > 99 ? '99+' : String(total);
    }
    var allBox = document.querySelector('.mscb-all');
    if (allBox) {
      allBox.checked = total > 0 && sel === total;
      allBox.indeterminate = sel > 0 && sel < total;   // 部分勾选显示成横杠
    }
  }

  function render() {
    autoTplAssign();
    var all = [];
    items.forEach(function (v) { all.push(v); });
    var ok = all.filter(function (v) { return v.title && v.imgs && v.imgs.length; }).length;
    var sel = selCount();
    setStat('已捕获 ' + all.length + ' 个商品（可用 ' + ok + ' 个，已选 ' + sel + ' 个）'
      + ((filtQ || (filtCat && filtCat !== '__all')) ? ' · 筛选显示 ' + filteredItems().length + ' 个' : ''));
    updateCatOptions();
    if (!listEl) return;
    listEl.innerHTML = '';
    var arr = filteredItems();
    // v3.4.0 增量渲染：先画 80 行，滚动到底部再追加下一批（500+ 商品也不卡）
    var shown = 0;
    function makeRow(v) {
      var row = document.createElement('div');
      row.className = 'mscb-item';
      // 每行一个勾选框：不勾的不采集、不导出（默认全勾）
      var ck = document.createElement('input');
      ck.type = 'checkbox';
      ck.className = 'mscb-ck';
      ck.checked = v.sel !== false;
      ck.onchange = function () { v.sel = ck.checked; setStat('已捕获 ' + items.size + ' 个商品（已选 ' + selCount() + ' 个）'); syncSelBar(); };
      row.appendChild(ck);
      var thumb = document.createElement('div');
      thumb.className = 'mscb-thumb';
      if (v.imgs && v.imgs[0]) {
        var im = document.createElement('img');
        im.src = v.imgs[0];
        im.loading = 'lazy';
        im.onerror = function () { im.style.display = 'none'; };
        thumb.appendChild(im);
      }
      var txt = document.createElement('div');
      txt.className = 'mscb-txt';
      var t1 = document.createElement('div');
      t1.className = 'mscb-t1';
      t1.textContent = v.title || '（标题待补）';
      var t2 = document.createElement('div');
      t2.className = 'mscb-t2';
      t2.textContent = 'ID ' + v.id + ' · ' + ((v.imgs || []).length) + ' 张图';
      txt.appendChild(t1); txt.appendChild(t2);
      row.appendChild(thumb); row.appendChild(txt);
      // v2.6.0 每行模板下拉：不同类目选不同模板（建单时按模板自动分组）
      {
        var tsel = document.createElement('select');
        tsel.className = 'mscb-rowsel';
        tsel.title = '这个商品用哪套模板';
        var oDef = document.createElement('option');
        oDef.value = ''; oDef.textContent = '默认模板';
        tsel.appendChild(oDef);
        [xtCatalog.generic].concat(cfg.tplPresets || []).forEach(function (p) {
          var o = document.createElement('option');
          o.value = p.name; o.textContent = p.name;
          tsel.appendChild(o);
        });
        tsel.value = v.tplKey || '';
        tsel.onchange = function () { v.tplManual = v.tplKey = tsel.value; };
        row.appendChild(tsel);
      }
      return row;
    }
    function drawChunk() {
      var batch = arr.slice(shown, shown + 80);
      batch.forEach(function (v) { listEl.appendChild(makeRow(v)); });
      shown += batch.length;
      var old = listEl.querySelector('.mscb-more');
      if (old) old.remove();
      if (shown < arr.length) {
        var more = document.createElement('div');
        more.className = 'mscb-more';
        more.textContent = '⬇️ 已显示 ' + shown + ' / ' + arr.length + ' 个，继续下滑自动加载（发送时按勾选 ' + sel + ' 个带上）';
        listEl.appendChild(more);
      }
    }
    drawChunk();
    listEl.onscroll = function () {
      if (listEl.scrollTop + listEl.clientHeight >= listEl.scrollHeight - 60 && shown < arr.length) drawChunk();
    };
    syncSelBar();
  }

  function build() {
    var style = document.createElement('style');
    style.textContent = [
      '.mscb-root{all:initial;font-family:-apple-system,"PingFang SC","Microsoft YaHei",Arial,sans-serif}',
      '.mscb-root *{box-sizing:border-box}',
      '@keyframes mscb-pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.18)}}',
      // v2.9.0 小猫咪动态化：待机呼吸 + 说话时跳一下 + 气泡弹消息
      '@keyframes mscb-idle{0%,86%,100%{transform:scale(1) rotate(0)}90%{transform:scale(1.08) rotate(-6deg)}94%{transform:scale(1.04) rotate(6deg)}}',
      '@keyframes mscb-jump{0%,100%{transform:translateY(0) scale(1)}30%{transform:translateY(-12px) scale(1.1)}60%{transform:translateY(-4px) scale(.97)}}',
      '@keyframes mscb-pop{0%{opacity:0;transform:translateY(8px) scale(.6)}60%{transform:translateY(-3px) scale(1.06)}100%{opacity:1;transform:translateY(0) scale(1)}}',
      '@keyframes mscb-fadeout{to{opacity:0;transform:translateY(6px) scale(.9)}}',
      '.mscb-ball{animation:mscb-idle 6s ease-in-out infinite}',
      '.mscb-ball.jump{animation:mscb-jump .8s ease}',
      '.mscb-bubble{position:fixed;right:80px;bottom:138px;z-index:2147483001;max-width:280px;padding:10px 13px;',
      'background:#fff;border:1.5px solid #ffb27a;border-radius:14px 14px 3px 14px;box-shadow:0 8px 24px rgba(245,81,30,.22);',
      'font-size:12.5px;color:#8a3d10;line-height:1.55;display:none;cursor:pointer;transform-origin:right bottom}',
      '.mscb-bubble.show{display:block;animation:mscb-pop .38s cubic-bezier(.34,1.56,.64,1)}',
      '.mscb-bubble.bye{animation:mscb-fadeout .3s ease forwards}',
      '.mscb-bubble b{color:#f5511e}',
      '.mscb-ball{position:static;width:56px;height:56px;border-radius:50%;',
      'cursor:pointer;box-shadow:0 6px 18px rgba(245,81,30,.35);user-select:none;overflow:visible;background:transparent}',
      '.mscb-ball .mscb-mascot{width:100%;height:100%;border-radius:50%;object-fit:cover;display:block;',
      'border:2.5px solid #fff;box-shadow:0 6px 18px rgba(245,81,30,.35)}',
      // v3.2.0 面板打开时球自动藏起来；v3.2.1 旧版紫色AI球(content.js)已删除，右下角只留小猫一个入口
      '.mscb-grip{position:absolute;width:16px;height:16px;z-index:5;opacity:.55}',
      '.mscb-grip:hover{opacity:1}',
      '.mscb-grip.tl{left:0;top:0;border-top:3px solid #9fb0c3;border-left:3px solid #9fb0c3;border-top-left-radius:12px;cursor:nwse-resize}',
      '.mscb-grip.tr{right:0;top:0;border-top:3px solid #9fb0c3;border-right:3px solid #9fb0c3;border-top-right-radius:12px;cursor:nesw-resize}',
      '.mscb-grip.bl{left:0;bottom:0;border-bottom:3px solid #9fb0c3;border-left:3px solid #9fb0c3;border-bottom-left-radius:12px;cursor:nesw-resize}',
      '.mscb-grip.br{right:0;bottom:0;border-bottom:3px solid #9fb0c3;border-right:3px solid #9fb0c3;border-bottom-right-radius:12px;cursor:nwse-resize}',
      '.mscb-root:has(.mscb-panel.open) .mscb-ball{display:none!important}',
      '.mscb-head .mscb-mascot-sm{width:26px;height:26px;border-radius:50%;object-fit:cover;margin-right:8px;flex:0 0 auto;vertical-align:middle}',
      '.mscb-ball:hover{filter:brightness(1.07)}',
      '.mscb-badge{position:absolute;top:-4px;right:-4px;min-width:18px;height:18px;border-radius:9px;background:#1f2d3d;',
      'color:#fff;font-size:11px;line-height:18px;text-align:center;padding:0 4px;display:none}',
      // v3.4.8 默认加宽到 760px（≤92vw 自适应小屏），更高 88vh —— 宽面板触发横向双栏，不再又窄又长挡住页面
      '.mscb-panel{position:fixed;right:18px;bottom:120px;z-index:2147483002;width:min(760px,92vw);max-height:88vh;container-type:inline-size;container-name:mscbbp;background:#fff;',
      'border-radius:16px;box-shadow:0 18px 50px rgba(15,30,50,.28),0 2px 8px rgba(15,30,50,.12);display:none;flex-direction:column;overflow:hidden}',
      '.mscb-panel.open{display:flex}',
      '.mscb-head{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:linear-gradient(120deg,#1f2d3d 55%,#b23c18);color:#fff;font-size:14px;font-weight:600}',
      '.mscb-x{cursor:pointer;opacity:.8;font-size:20px;line-height:1;padding:2px 8px;transition:opacity .15s,transform .15s}',
      '.mscb-x:hover{opacity:1;transform:scale(1.15)}',
      '.mscb-body{padding:12px 14px;overflow:auto}',
      '.mscb-body::-webkit-scrollbar,.mscb-list::-webkit-scrollbar,.mscb-log::-webkit-scrollbar,.mscb-chat::-webkit-scrollbar{width:7px}',
      '.mscb-body::-webkit-scrollbar-thumb,.mscb-list::-webkit-scrollbar-thumb,.mscb-log::-webkit-scrollbar-thumb,.mscb-chat::-webkit-scrollbar-thumb{background:#e3b7a2;border-radius:4px}',
      '.mscb-body::-webkit-scrollbar-thumb:hover,.mscb-list::-webkit-scrollbar-thumb:hover{background:#f5511e}',
      '.mscb-stat{font-size:13px;color:#33475b;margin-bottom:8px}',
      '.mscb-list{border:1px solid #e6ebf2;border-radius:10px;max-height:230px;overflow:auto;margin-bottom:10px}',
      '.mscb-list:empty::after{content:"🐱 还没有商品：往下滑动页面加载列表，或点「🔄 补采集」重新读取";display:block;padding:26px 14px;text-align:center;color:#9aa7b4;font-size:12px;line-height:1.7}',
      '.mscb-item{display:flex;align-items:center;gap:8px;padding:7px 9px;border-bottom:1px solid #f0f3f8;transition:background .15s}',
      '.mscb-item:hover{background:#fff6f0}',
      '.mscb-ck{flex:0 0 auto;width:15px;height:15px;margin:0;cursor:pointer;accent-color:#f5511e}',
      '.mscb-selbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:12px;color:#55677a;margin-bottom:6px}',
      '.mscb-selinfo{font-weight:700;color:#c0560a;background:#fff4ec;border:1px solid #ffd9bd;border-radius:12px;padding:2px 10px;margin-left:auto}',
      // v3.4.1 按数量模式：勾上后从上往下自动选前 N 个
      '.mscb-bycnt{display:flex;align-items:center;gap:4px;cursor:pointer;user-select:none;color:#33475b;font-weight:600}',
      '.mscb-bycnt input{width:14px;height:14px;margin:0;accent-color:#c81623;cursor:pointer}',
      '.mscb-count{width:56px;padding:3px 6px;border:1px solid #d8e0ea;border-radius:8px;font-size:12.5px;font-weight:700;color:#c81623;text-align:center;outline:none}',
      '.mscb-count:disabled{background:#f5f7fa;color:#8899a8}',
      '.mscb-count:focus{border-color:#f5511e}',
      '.mscb-selbar label{display:flex;align-items:center;gap:5px;cursor:pointer}',
      '.mscb-selbar input{width:14px;height:14px;margin:0;cursor:pointer;accent-color:#f5511e}',
      '.mscb-item:last-child{border-bottom:0}',
      '.mscb-thumb{width:46px;height:46px;border-radius:8px;background:#f5f7fa;flex:0 0 auto;overflow:hidden;border:1px solid #eef2f7}',
      '.mscb-thumb img{width:100%;height:100%;object-fit:cover;display:block}',
      '.mscb-txt{min-width:0;flex:1}',
      '.mscb-t1{font-size:12.5px;color:#1f2d3d;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.mscb-t2{font-size:11.5px;color:#8899a8;margin-top:2px}',
      '.mscb-more{font-size:11.5px;color:#8899a8;padding:7px 9px;text-align:center}',
      '.mscb-cfg{display:grid;grid-template-columns:78px minmax(0,1fr);gap:6px 8px;align-items:center;font-size:12.5px;color:#33475b;margin-bottom:10px}',
      '.mscb-cfg input{width:100%;min-width:0;box-sizing:border-box;padding:6px 8px;border:1px solid #d8e0ea;border-radius:7px;font-size:12.5px;color:#1f2d3d;outline:none}',
      '.mscb-cfg input:focus{border-color:#f5511e}',
      // v3.4.1 统一操作按钮：同一行、同高 44px、同圆角同字重；启动为橙红主按钮，其余白底描边
      // v3.4.9 双栏变窄后四个按钮挤一行会截成「补…」→ 启动独占一行，暂停/续跑/补采集第二行平铺，文字完整显示
      '.mscb-acts{display:flex;gap:8px;flex-wrap:wrap}',
      '.mscb-start{flex:1 1 100%;min-width:0;height:42px;padding:0 10px;border:0;border-radius:11px;',
      'background:linear-gradient(135deg,#ff4d4f,#c81623);color:#fff;font-size:14.5px;font-weight:700;',
      'cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;box-shadow:0 6px 16px rgba(200,22,35,.32);letter-spacing:.3px;transition:all .15s}',
      '.mscb-start:hover{filter:brightness(1.06);transform:translateY(-1px)}',
      '.mscb-start:disabled{opacity:.62;cursor:default;transform:none}',
      '.mscb-pause,.mscb-resume,.mscb-refetch{flex:1 1 auto;min-width:86px;height:42px;padding:0 8px;border:1px solid #d8e0ea;',
      'background:#fff;border-radius:11px;font-size:12.5px;font-weight:600;color:#33475b;cursor:pointer;',
      'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:all .15s}',
      '.mscb-pause:hover,.mscb-resume:hover,.mscb-refetch:hover{border-color:#f5511e;color:#f5511e;transform:translateY(-1px)}',
      '.mscb-pause:disabled{opacity:.5;cursor:default;transform:none}',
      '.mscb-btn{flex:1;padding:9px 10px;border:1px solid #d8e0ea;background:#fff;border-radius:9px;font-size:13px;color:#33475b;cursor:pointer}',
      '.mscb-btn:hover{border-color:#f5511e;color:#f5511e}',
      '.mscb-one{width:100%;padding:13px;background:linear-gradient(135deg,#ff7a45,#f5511e);color:#fff;border:0;border-radius:11px;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 6px 16px rgba(245,81,30,.3)}',
      '.mscb-one:disabled{opacity:.62;cursor:default}',
      // v2.3.0 红色一键自动化按钮（在橙色按钮上方）
      '.mscb-auto{width:100%;padding:13px;background:linear-gradient(135deg,#ff4d4f,#c81623);color:#fff;border:0;border-radius:11px;',
      'font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 6px 16px rgba(200,22,35,.32);letter-spacing:.3px}',
      '.mscb-auto:hover{filter:brightness(1.06)}',
      '.mscb-auto:disabled{opacity:.62;cursor:default}',
      '.mscb-inv{border:1px solid #d8e0ea;background:#fff;color:#c81623;border-radius:6px;padding:2px 8px;cursor:pointer;font-size:12px}',
      '.mscb-inv:hover{background:#fff1f0}',
      // 红色方框勾选（面板列表行 + 全选框）
      '.mscb-ck{accent-color:#c81623;width:16px;height:16px;border:2px solid #c81623;border-radius:3px;cursor:pointer}',
      '.mscb-selbar input{accent-color:#c81623;width:15px;height:15px;border:2px solid #c81623;border-radius:3px;cursor:pointer}',
      // 进度条
      '.mscb-prog{margin-top:10px;padding:9px 10px;border:1px solid #ffd6d6;background:#fff8f8;border-radius:9px;display:none}',
      '.mscb-prog.show{display:block}',
      '.mscb-prog-text{font-size:12px;color:#c81623;line-height:1.5;margin-bottom:6px;word-break:break-all}',
      '.mscb-prog-bar{height:8px;border-radius:4px;background:#ffe9e9;overflow:hidden;margin-top:7px}',
      '.mscb-prog-bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#ffa940,#f5511e,#c81623);transition:width .4s ease;position:relative}',
      '.mscb-prog-bar i::after{content:"";position:absolute;inset:0;background:repeating-linear-gradient(45deg,rgba(255,255,255,.28) 0 8px,transparent 8px 16px);animation:mscbStripe .9s linear infinite}',
      '@keyframes mscbStripe{from{background-position:0 0}to{background-position:22px 0}}',
      '.mscb-prog.done .mscb-prog-bar i::after{animation:none;opacity:0}',
      '.mscb-links{margin-top:8px;max-height:110px;overflow:auto}',
      '.mscb-links-title{font-size:12px;color:#1f7a3d;margin-bottom:4px}',
      '.mscb-link{display:block;font-size:11px;color:#2f6fd0;text-decoration:none;white-space:nowrap;overflow:hidden;',
      'text-overflow:ellipsis;line-height:1.7}',
      '.mscb-link:hover{text-decoration:underline}',
      '.mscb-send{background:linear-gradient(135deg,#ff7a45,#f5511e);color:#fff;border:0;font-weight:600}',
      '.mscb-send:hover{color:#fff;filter:brightness(1.06)}',
      '.mscb-send:disabled{opacity:.6;cursor:default;filter:none}',
      '.mscb-log{margin-top:10px;max-height:120px;overflow:auto;font-size:12px;color:#55677a;line-height:1.7;background:#f8fafc;border:1px solid #eef2f7;border-radius:10px;padding:8px 10px}',
      '.mscb-line{white-space:pre-wrap;word-break:break-all;padding:1px 0;border-radius:4px;transition:background .15s}',
      '.mscb-line:hover{background:#eef4ff}',
      '.mscb-ts{color:#9aa7b4;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:11px;margin-right:4px}',
      '.mscb-line.ok{color:#0f8a3d}',
      '.mscb-line.warn{color:#b25e00}',
      '.mscb-line.err{color:#c81623;font-weight:600}',
      '.mscb-line.info{color:#2563eb}',
      '.mscb-open{margin-top:8px}',
      '.mscb-go{width:100%;padding:9px;border:1px dashed #f5511e;background:#fff6f2;color:#f5511e;border-radius:9px;font-size:13px;cursor:pointer}',
      // v2.3.1：右上角⚙设置 + 数量弹窗
      '.mscb-gear{cursor:pointer;font-size:16px;line-height:1;padding:0 3px;opacity:.85}',
      '.mscb-gear:hover{opacity:1;transform:rotate(30deg)}',
      '.mscb-setbox{display:none;margin:0 0 10px;padding:10px;border:1px solid #e6ebf2;background:#fafcff;border-radius:10px}',
      '.mscb-setbox.open{display:block}',
      '.mscb-set-t{font-size:12px;font-weight:600;color:#33475b;margin-bottom:8px}',
      '.mscb-hint{font-size:11px;color:#8899a8;line-height:1.55;margin:6px 0 0}',
      '.mscb-mask{position:fixed;inset:0;z-index:2147483003;background:rgba(31,45,61,.35);display:none;',
      'align-items:center;justify-content:center}',
      '.mscb-mask.open{display:flex}',
      '.mscb-dialog{width:320px;background:#fff;border-radius:14px;padding:16px;box-shadow:0 12px 40px rgba(0,0,0,.25)}',
      '.mscb-dialog h4{margin:0 0 10px;font-size:14px;color:#1f2d3d}',
      '.mscb-dialog label{display:block;font-size:12px;color:#55677a;margin-bottom:5px}',
      '.mscb-dialog input{width:100%;padding:8px 10px;border:1px solid #d8e0ea;border-radius:8px;font-size:13px;outline:none}',
      '.mscb-dialog input:focus{border-color:#f5511e}',
      '.mscb-dialog-btns{display:flex;gap:8px;margin-top:14px}',
      '.mscb-dialog-btns button{flex:1;padding:9px;border-radius:8px;font-size:13px;cursor:pointer;border:1px solid #d8e0ea;background:#fff;color:#33475b}',
      '.mscb-dialog-btns .mscb-dlg-ok{background:#f5511e;border-color:#f5511e;color:#fff;font-weight:600}',
      // v2.5.0：小猫咪 AI 助手入口 + 双标签面板（AI问答 / 洗图工作台）
      // 个人信息条
      '.mscb-user{display:flex;align-items:center;gap:8px;margin-bottom:10px}',
      '.mscb-tierchip{padding:4px 10px;border-radius:9px;background:#1f2d3d;color:#fff;font-size:11.5px;font-weight:600}',
      '.mscb-quota{flex:1;text-align:right;font-size:11.5px;color:#55677a}',
      '.mscb-quota b{color:#c81623;font-size:12.5px}',
      // v3.2.8 去掉「AI问答/工作台」双标签：面板打开直接显示洗图工作台
      '.mscb-work{display:block}',
      // v3.4.8 横向布局：宽面板（≥720px）左栏=模板/选品/操作，右栏=进度/结果/链接/日志
      '.mscb-wl,.mscb-wr{min-width:0}',
      '@container mscbbp (min-width:720px){',
      '  .mscb-work{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:0 16px;align-items:start}',
      '  .mscb-wl{grid-column:1}',
      '  .mscb-wr{grid-column:2}',
      '  .mscb-list{max-height:340px}',
      '  .mscb-log{max-height:220px}',
      '}',
      // 窄面板回到单列时保持原有上下顺序（wl 在前 wr 在后，天然等价旧排版）
      // v3.2.9 双视图：点小猫球=AI 问答视图（没有工作台）；点模式方块=工作台视图（只显示该模式内容）
      '.mscb-panel[data-view="ai"] .mscb-work{display:none!important}',
      '.mscb-ai{display:none;flex-direction:column}',
      '.mscb-panel[data-view="ai"] .mscb-ai{display:flex}',
      '.mscb-guide{border:1px solid #ffd9a8;background:#fff8ef;border-radius:10px;padding:9px 12px;margin-bottom:10px}',
      '.mscb-guide h5{margin:0 0 5px;font-size:12.5px;color:#8a5300}',
      '.mscb-guide ol{margin:0;padding-left:20px;font-size:12px;line-height:1.85;color:#5b4630}',
      '.mscb-guide b{color:#c0560a}',
      '.mscb-chat{border:1px solid #e6ebf2;border-radius:10px;background:#fafcff;height:230px;overflow:auto;padding:8px;margin-bottom:8px}',
      '.mscb-msg{max-width:88%;padding:7px 10px;border-radius:10px;font-size:12.5px;line-height:1.55;margin-bottom:6px;word-break:break-all;white-space:pre-wrap}',
      '.mscb-msg.bot{background:#eef4ff;color:#1f2d3d}',
      '.mscb-msg.me{background:#ff7a45;color:#fff;margin-left:auto}',
      '.mscb-chips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px}',
      '.mscb-chip{padding:5px 10px;border:1px solid #d8e0ea;background:#fff;border-radius:14px;font-size:11.5px;color:#33475b;cursor:pointer}',
      '.mscb-chip:hover{border-color:#f5511e;color:#f5511e}',
      '.mscb-airow{display:flex;gap:6px}',
      '.mscb-aiin{flex:1;min-width:0;padding:8px 10px;border:1px solid #d8e0ea;border-radius:9px;font-size:12.5px;outline:none}',
      '.mscb-aiin:focus{border-color:#f5511e}',
      '.mscb-aisend{padding:8px 14px;border:0;border-radius:9px;background:#f5511e;color:#fff;font-size:12.5px;font-weight:600;cursor:pointer}',
      // v3.4.1 面板内 modewrap/mode 大按钮样式已随 HTML 一起删除（悬浮区 dock 三方块是唯一模式入口）
      // v3.2.7 悬浮区整体（方块+小猫）可一起拖动，位置记忆
      '.mscb-float{position:fixed;right:18px;bottom:64px;z-index:2147483001;display:flex;flex-direction:column;align-items:flex-end;gap:8px}',
      '.mscb-dock{display:flex;flex-direction:column;gap:6px;align-items:flex-end}',
      '.mscb-dockbtn{display:block;width:92px;padding:8px 0;border:1px solid #d8e0ea;background:#fff;border-radius:9px;',
      'font-size:12px;font-weight:600;color:#1f2d3d;cursor:pointer;box-shadow:0 3px 10px rgba(31,45,61,.12);user-select:none}',
      '.mscb-dockbtn.on{background:#f5511e;border-color:#f5511e;color:#fff}',
      '.mscb-dockbtn:hover{filter:brightness(1.06)}',
      '.mscb-root:has(.mscb-panel.open) .mscb-float{display:none!important}',
      // v3.3.0 通用按钮动效：所有操作按钮统一 hover 微浮起
      '.mscb-pause,.mscb-resume,.mscb-refetch,.mscb-export,.mscb-inv,.mscb-catonly{transition:all .15s}',
      '.mscb-pause:hover,.mscb-resume:hover,.mscb-refetch:hover,.mscb-inv:hover,.mscb-catonly:hover{transform:translateY(-1px)}',
      '.mscb-export{width:100%;padding:10px;border:1px solid #d8e0ea;background:#fff;border-radius:9px;',
      'font-size:13px;color:#33475b;cursor:pointer}',
      '.mscb-export:hover{border-color:#f5511e;color:#f5511e}',
      // v3.4.3 RPA 单独测试按钮（醒目红底大按钮，与「启动全自动」同风格）
      '.mscb-rpatest{width:100%;margin-top:10px;padding:12px;border:none;background:linear-gradient(135deg,#ff5a2b,#f5511e);',
      'border-radius:11px;font-size:14px;font-weight:700;color:#fff;cursor:pointer;transition:all .15s;',
      'box-shadow:0 4px 12px rgba(245,81,30,.35);letter-spacing:.5px}',
      '.mscb-rpatest:hover{filter:brightness(1.08);transform:translateY(-1px);box-shadow:0 6px 16px rgba(245,81,30,.45)}',
      '.mscb-rpatest:disabled{opacity:.55;cursor:default;transform:none}',
      // v3.4.4 迷你运行条：任务运行时收起大面板与悬浮区，页面完全让给 RPA，只留 日志+进度+时间+暂停
      '.mscb-mini{position:fixed;left:18px;bottom:64px;z-index:2147483002;width:330px;background:#fff;border:1px solid #e6ebf2;',
      'border-radius:12px;box-shadow:0 8px 30px rgba(15,35,60,.18);display:none;flex-direction:column;overflow:hidden;font-size:12px}',
      '.mscb-mini.show{display:flex}',
      '.mscb-root.mscb-run .mscb-float,.mscb-root.mscb-run .mscb-bubble,.mscb-root.mscb-run .mscb-panel{display:none!important}',
      '.mscb-mini-head{display:flex;align-items:center;gap:8px;padding:8px 10px;background:linear-gradient(135deg,#ff5a2b,#f5511e);color:#fff;font-weight:700}',
      '.mscb-mini-dot{width:8px;height:8px;border-radius:50%;background:#7fe0a2;flex:none;animation:mscbMiniPulse 1.2s ease-in-out infinite}',
      '@keyframes mscbMiniPulse{0%,100%{opacity:1}50%{opacity:.3}}',
      '.mscb-mini-title{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:12.5px}',
      '.mscb-mini-head button{border:none;border-radius:7px;padding:4px 9px;font-size:12px;cursor:pointer;font-weight:600;background:rgba(255,255,255,.28);color:#fff;flex:none}',
      '.mscb-mini-head button:hover{background:rgba(255,255,255,.42)}',
      '.mscb-mini-prog{height:5px;background:#f0f3f8}',
      '.mscb-mini-prog i{display:block;height:100%;width:0;background:linear-gradient(90deg,#f5511e,#ff8a3d);transition:width .4s}',
      '.mscb-mini-time{padding:5px 10px 2px;color:#8a6d3b;font-size:11px;font-weight:600}',
      '.mscb-mini-log{height:132px;overflow-y:auto;padding:4px 10px 8px;font-family:Menlo,Consolas,monospace;font-size:11px;line-height:1.7;color:#33475b;background:#fafcff}',
      '.mscb-dark .mscb-mini{background:#1b2431;border-color:#26334a}',
      '.mscb-dark .mscb-mini-log{background:#141b26;color:#9fb0c5}',
      '.mscb-dark .mscb-mini-time{color:#ffca7a}',
      '.mscb-dark .mscb-mini-prog{background:#26334a}',
      '.mscb-tpl{border:1px solid #e6ebf2;background:#fafcff;border-radius:10px;margin-bottom:10px;overflow:hidden}',
      '.mscb-tpl-t{display:flex;align-items:center;justify-content:space-between;padding:9px 10px;',
      'font-size:12.5px;font-weight:600;color:#33475b;cursor:pointer;user-select:none}',
      '.mscb-tpl-t:hover{background:#f2f7ff}',
      '.mscb-tpl-t .arr{font-size:10px;color:#8899a8;transition:transform .15s}',
      '.mscb-tpl.open .arr{transform:rotate(180deg)}',
      '.mscb-tpl-b{display:none;padding:2px 10px 10px}',
      '.mscb-tpl.open .mscb-tpl-b{display:block}',
      '.mscb-tpl-chks{display:flex;flex-wrap:wrap;gap:6px 12px;margin-bottom:8px}',
      '.mscb-tpl-chks label{display:flex;align-items:center;gap:5px;font-size:12.5px;color:#33475b;cursor:pointer}',
      '.mscb-tpl-chks input{width:15px;height:15px;margin:0;accent-color:#c81623;border:2px solid #c81623;border-radius:3px;cursor:pointer}',
      '.mscb-tpl-fixed{display:grid;grid-template-columns:70px minmax(0,1fr);gap:6px 8px;align-items:center}',
      '.mscb-tpl-fixed label{font-size:12px;color:#55677a;text-align:right}',
      '.mscb-tpl-fixed input{width:100%;min-width:0;box-sizing:border-box;padding:6px 8px;border:1px solid #d8e0ea;',
      'border-radius:7px;font-size:12.5px;color:#1f2d3d;outline:none}',
      '.mscb-tpl-fixed input:focus{border-color:#f5511e}',
      '.mscb-hint{font-size:11px;color:#8899a8;line-height:1.55;margin:6px 0 0}',
      '.mscb-panel{right:100px}',
      // v2.6.0 检查模式 / 补采集 / 结果区 / 预览弹窗 / 模板预设
      '.mscb-checkrow{display:flex;align-items:center;gap:6px;margin-top:8px;font-size:12.5px;color:#33475b}',
      '.mscb-checkrow input{width:15px;height:15px;margin:0;accent-color:#c81623;cursor:pointer}',
      '.mscb-checkrow .q{width:16px;height:16px;border-radius:50%;background:#eef2f7;color:#8899a8;font-size:11px;line-height:16px;text-align:center;cursor:help;flex:0 0 auto}',
      // v3.4.1 refetch 并入操作按钮排（统一样式在上面），这里删掉旧的小胶囊样式
      '.mscb-prog-time{font-size:11.5px;color:#8899a8;margin-top:5px}',
      '.mscb-res{display:none;margin-top:10px;border:1px solid #e6ebf2;border-radius:10px;overflow:hidden;background:#fff}',
      '.mscb-res.show{display:block;max-height:44vh;overflow:auto}',
      '.mscb-resbtns{display:flex;gap:8px;margin-top:8px;flex-wrap:wrap;align-items:center}',
      '.mscb-resbtns button{flex:1 1 auto;min-width:0;padding:11px 8px;border:0;border-radius:10px;font-size:12.5px;font-weight:600;cursor:pointer;white-space:nowrap}',
      '.mscb-rprev{background:#1f2d3d;color:#fff}',
      '.mscb-rcsv{background:#eef4ff;color:#2456c4}',
      '  .mscb-logbar{margin-top:10px;display:flex;justify-content:space-between;align-items:center;font-size:12px;color:#6b7688}',
      '  .mscb-logdl{margin:0;padding:3px 10px;font-size:12px;background:#eef4ff;color:#2456c4;border:1px solid #c9d8f0;border-radius:8px;cursor:pointer}',
      '  .mscb-skip{margin:0 8px 0 0;padding:3px 10px;font-size:12px;background:#fff4e5;color:#b25e00;border:1px solid #f0c88a;border-radius:8px;cursor:pointer}',
      '  .mscb-skip:hover{background:#ffe9c7}',
      '  .mscb-helpbtn{margin:0 8px 0 0;padding:3px 10px;font-size:12px;background:#eef7ee;color:#1e7a3c;border:1px solid #bfe0c8;border-radius:8px;cursor:pointer}',
      '  .mscb-helpbtn:hover{background:#d9f2e0}',
      '  .mscb-updbtn{margin:0 8px 0 0;padding:3px 10px;font-size:12px;background:#eef2fb;color:#2456b3;border:1px solid #bcc9e8;border-radius:8px;cursor:pointer}',
      '  .mscb-updbtn:hover{background:#dde7fa}',
      '  .mscb-mask.mscb-sheetmask{position:fixed;inset:0;background:rgba(8,18,38,.55);z-index:2147483646;display:flex;align-items:center;justify-content:center}',
      '  .mscb-sheet{background:#fff;border-radius:14px;max-width:700px;width:92%;max-height:82vh;overflow:auto;padding:24px 30px;box-shadow:0 10px 40px rgba(0,0,0,.3);font-size:13.5px;color:#2c3e50;line-height:1.75}',
      '  .mscb-sheet h2{font-size:17px;color:#1a3c6e;margin:18px 0 8px;border-left:4px solid #2f6fd6;padding-left:10px}',
      '  .mscb-sheet h2:first-child{margin-top:0}',
      '  .mscb-sheet h3{font-size:14px;color:#2c5aa0;margin:14px 0 6px}',
      '  .mscb-sheet ol,.mscb-sheet ul{margin:6px 0;padding-left:22px}',
      '  .mscb-sheet li{margin:4px 0}',
      '  .mscb-sheet details{background:#f4f7fb;border-radius:8px;padding:8px 12px;margin:8px 0}',
      '  .mscb-sheet summary{cursor:pointer;font-weight:600;color:#1a3c6e}',
      '  .mscb-sheet kbd{background:#1a3c6e;color:#fff;padding:1px 7px;border-radius:5px;font-size:12px;white-space:nowrap}',
      '  .mscb-sheet .warn{background:#fff7e8;border-left:4px solid #e6a23c;padding:8px 12px;border-radius:0 8px 8px 0;margin:10px 0}',
      '  .mscb-sheet .tip{background:#eefaf0;border-left:4px solid #42b983;padding:8px 12px;border-radius:0 8px 8px 0;margin:10px 0}',
      '  .mscb-sheet .ob-btns{display:flex;gap:10px;justify-content:flex-end;margin-top:18px}',
      '  .mscb-sheet .ob-btn{padding:7px 18px;border-radius:9px;border:1px solid #c9d8f0;background:#eef4ff;color:#2456c4;font-size:13.5px;cursor:pointer}',
      '  .mscb-sheet .ob-btn.primary{background:#2f6fd6;border-color:#2f6fd6;color:#fff}',
      '  .mscb-sheet .ob-skip{color:#8a97a8;font-size:12.5px;cursor:pointer;margin-right:auto;background:none;border:none;text-decoration:underline}',
      '  .mscb-sheet .ob-step{font-size:12px;color:#8a97a8;margin-bottom:10px}',
      '  .mscb-sheet .ob-ok{color:#1e7a3c;font-weight:600}',
      '  .mscb-sheet .ob-no{color:#b25e00;font-weight:600}',
      '  .mscb-sheet table{border-collapse:collapse;width:100%;margin:10px 0;font-size:13px}',
      '  .mscb-sheet th,.mscb-sheet td{border:1px solid #d8e1ec;padding:6px 9px;text-align:left;vertical-align:top}',
      '  .mscb-sheet th{background:#eef3fa;color:#1a3c6e}',
      '  .mscb-logdl:hover{background:#dfeaff}',
      '.mscb-rrpa{background:linear-gradient(135deg,#ff7a45,#f5511e);color:#fff}',
      '.mscb-resbtns button:disabled{opacity:.5;cursor:default}',
      '.mscb-resrow{display:flex;gap:9px;padding:9px 11px;border-bottom:1px solid #f0f3f8;align-items:center}',
      '.mscb-resrow:last-child{border-bottom:0}',
      '.mscb-resthumb{width:52px;height:52px;border-radius:8px;background:#f5f7fa;flex:0 0 auto;overflow:hidden;cursor:pointer;border:1px solid #e8eef6}',
      '.mscb-resthumb img{width:100%;height:100%;object-fit:cover;display:block}',
      '.mscb-resmid{flex:1;min-width:0}',
      '.mscb-rest1{display:flex;align-items:center;gap:7px;font-size:12.5px;color:#1f2d3d;line-height:1.35}',
      '.mscb-resname{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.mscb-rescnt{flex:0 0 auto;font-size:11px;font-weight:700;color:#8a5300;background:#fff3e0;border:1px solid #ffd591;border-radius:999px;padding:1px 7px;font-variant-numeric:tabular-nums;letter-spacing:.2px}',
      '.mscb-rescnt.ok{color:#176c3a;background:#eefaf1;border-color:#b7e2c4}',
      '.mscb-rest2{font-size:11px;color:#8899a8;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.mscb-resbar{height:6px;border-radius:999px;background:#f0f3f8;overflow:hidden;margin-top:5px}',
      '.mscb-resbar i{display:block;height:100%;background:linear-gradient(90deg,#ff9a6b,#f5511e);transition:width .4s ease;border-radius:999px}',
      '.mscb-resacts{flex:0 0 auto;display:flex;gap:4px}',
      '.mscb-resacts button{width:28px;height:28px;padding:0;border:1px solid #e2e8f1;background:#fff;border-radius:8px;font-size:13px;line-height:1;cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center}',
      '.mscb-resacts button:hover{border-color:#f5511e;color:#f5511e;background:#fff7f4}',
      '.mscb-resacts button:disabled{opacity:.45;cursor:default}',
      // v3.7.33 断点续跑横幅
      '.mscb-jobbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 10px;padding:9px 11px;border-radius:10px;background:#fff7e6;border:1px solid #ffd591;color:#8a5300;font-size:12px;line-height:1.5}',
      '.mscb-jobbar.done{background:#eefaf1;border-color:#b7e2c4;color:#176c3a}',
      '.mscb-jobbar b{font-weight:700}',
      '.mscb-jobbar .mscb-jbtns{display:flex;gap:6px;margin-left:auto;flex:0 0 auto}',
      '.mscb-jobbar .mscb-jbtns button{border:1px solid currentColor;background:#fff;color:inherit;border-radius:7px;font-size:11.5px;padding:3px 9px;cursor:pointer;font-weight:600}',
      '.mscb-jobbar .mscb-jbtns button:hover{background:#f5511e;color:#fff;border-color:#f5511e}',
      // v3.6.3 历史单（洗图台磁盘上的旧单，结果区只显示当前单）
      '.mscb-histwrap{margin-top:10px;border:1px dashed #d8e0ea;border-radius:10px;overflow:hidden}',
      '.mscb-histhead{display:flex;align-items:center;gap:6px;padding:8px 10px;font-size:12px;font-weight:700;color:#55677a;cursor:pointer;background:#f8fafc;user-select:none}',
      '.mscb-histhead:hover{background:#f0f4f9}',
      '.mscb-histcount{margin-left:auto;font-weight:600;color:#8a97a8;font-size:11px}',
      '.mscb-histlist{display:none;border-top:1px solid #eef1f6;max-height:180px;overflow:auto}',
      '.mscb-histwrap.open .mscb-histlist{display:block}',
      '.mscb-histrow{display:flex;gap:8px;padding:7px 10px;border-bottom:1px solid #f4f6fa;align-items:center}',
      '.mscb-histrow:last-child{border-bottom:0}',
      '.mscb-histt{flex:1;min-width:0;font-size:12px;color:#33475b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.mscb-histmeta{font-size:10.5px;color:#8a97a8;flex:0 0 auto}',
      '.mscb-histbtns{display:flex;gap:4px;flex:0 0 auto}',
      '.mscb-histbtns button{border:1px solid #d8e0ea;background:#fff;border-radius:6px;font-size:11px;padding:2px 6px;cursor:pointer}',
      '.mscb-histbtns button:hover{background:#f5511e;color:#fff;border-color:#f5511e}',
      // v3.2.6 预览网格：4 列排布，每张图带序号/类型标签 + 重生成/看提示词按钮
      // v3.6.0 图片 1:1 正方形展示（contain 不裁切），格子随弹窗加宽自动增列
      '.mscb-pvgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(186px,1fr));gap:12px;max-height:66vh;overflow:auto;padding:2px 2px 6px}',
      // v3.7.1 标题横跨整行：原来它按普通格子占一格，把每个链接后面的图整体挤歪一格（第 4 列显示成标题、末尾多出空格）
      '.mscb-pvgrid > .mscb-pvtitle{grid-column:1/-1;margin:10px 0 2px;padding-left:8px;border-left:3px solid #f5511e;font-weight:700;color:#33475b;line-height:1.4}',
      '.mscb-pvcard{display:flex;flex-direction:column;gap:5px;min-width:0;background:#fff;border:1px solid #eef2f8;border-radius:10px;padding:7px}',
      '.mscb-pvbar{display:flex;align-items:center;gap:5px;font-size:11px;font-weight:700;color:#1f2d3d;white-space:nowrap;overflow:hidden}',
      '.mscb-pvtyp{flex:0 1 auto;color:#f5511e;background:#fff1ec;border-radius:5px;padding:1px 6px;font-size:10px;font-weight:600;overflow:hidden;text-overflow:ellipsis}',
      '.mscb-pvbtns{margin-left:auto;display:flex;gap:3px;flex:0 0 auto}',
      '.mscb-pvbtns button{border:1px solid #e2e8f1;background:#fff;border-radius:6px;font-size:11px;padding:1px 5px;cursor:pointer;line-height:1.5}',
      '.mscb-pvbtns button:hover{background:#f5511e;color:#fff;border-color:#f5511e}',
      '.mscb-pvcard img{width:100%;aspect-ratio:1/1;object-fit:contain;border-radius:7px;cursor:pointer;background:#f5f7fa;display:block}',
      '.mscb-pvmiss{width:100%;aspect-ratio:1/1;display:flex;align-items:center;justify-content:center;background:#f5f7fa;border-radius:7px;color:#8a97a8;font-size:10px;text-align:center;padding:0 4px;box-sizing:border-box}',
      '.mscb-pvmiss-retry{cursor:pointer;color:#f5511e;background:#fff1ec}',
      '.mscb-pvmiss-retry:hover{background:#ffe4d9}',
      // v3.6.0 原图 vs 洗后 对比弹窗
      // v3.7.2 整单对比：左列全部采集原图，右列全部洗后成品图，按张数对齐成对滚动
      '.mscb-cmpscroll{max-height:72vh;overflow:auto;padding-right:2px}',
      '.mscb-cmphead{display:flex;gap:12px;position:sticky;top:0;background:#fff;z-index:1;padding:4px 0 8px}',
      '.mscb-cmp-h b{color:#f5511e;font-weight:800;margin:0 5px;letter-spacing:.5px}',
      '.mscb-cmphead span{flex:1;text-align:center;font-size:13px;font-weight:700;color:#1f2d3d}',
      '.mscb-cmprows{display:flex;flex-direction:column;gap:16px}',
      '.mscb-cmprow{display:flex;gap:12px;align-items:flex-start}',
      '.mscb-cmpcell{flex:1;min-width:0;display:flex;flex-direction:column;gap:5px;align-items:center}',
      '.mscb-cmpcell img{width:100%;height:min(30vh,300px);object-fit:contain;background:#f5f7fa;border-radius:10px;cursor:zoom-in}',
      '.mscb-cmpempty{width:100%;height:min(30vh,300px);display:flex;align-items:center;justify-content:center;background:#f5f7fa;border-radius:10px;color:#8a97a8;font-size:11px;text-align:center;padding:0 6px;box-sizing:border-box}',
      '.mscb-cmpcell .mscb-cmpnote{font-size:11px;color:#8a97a8;text-align:center}',
      '.mscb-cmptitle{width:100%;background:#f5f7fa;border:1px solid #e3eaf3;border-radius:10px;padding:8px 10px;font-size:12px;line-height:1.5;color:#2c3e50;word-break:break-all;text-align:left}',
      '.mscb-cmptitle b{color:#f5511e;font-size:12px}',
      // v3.6.0 错误提醒弹窗（不自动消失）
      '.mscb-errdlg{border:2px solid #f5222d;box-shadow:0 12px 44px rgba(245,34,45,.28)}',
      '.mscb-errdlg h4{color:#cf1322}',
      '.mscb-errdlg h4.flash{animation:mscbErrFlash .8s ease 2}',
      '@keyframes mscbErrFlash{0%,100%{opacity:1}50%{opacity:.25}}',
      '.mscb-errlist{max-height:38vh;overflow:auto;background:#fff1f0;border:1px solid #ffa39e;border-radius:8px;padding:8px 10px;font-size:12px;line-height:1.8;color:#cf1322;word-break:break-all}',
      '.mscb-errrow{padding:2px 0;border-bottom:1px dashed #ffd6d6}',
      '.mscb-errrow:last-child{border-bottom:none}',
      '.mscb-pvtitle{font-size:12px;color:#55677a;margin:2px 0 8px;word-break:break-all}',
      '.mscb-note-ta{width:100%;min-height:80px;padding:8px 10px;border:1px solid #d8e0ea;border-radius:8px;font-size:12.5px;outline:none;resize:vertical;box-sizing:border-box;font-family:inherit}',
      '.mscb-note-ta:focus{border-color:#f5511e}',
      '.mscb-tpl-presetrow{display:flex;gap:6px;margin:8px 0 6px}',
      '.mscb-tpl-presetrow input{flex:1;min-width:0;padding:6px 8px;border:1px solid #d8e0ea;border-radius:7px;font-size:12px;outline:none}',
      '.mscb-tpl-presetrow button{padding:6px 10px;border:1px solid #d8e0ea;background:#fff;border-radius:7px;font-size:12px;cursor:pointer;white-space:nowrap}',
      '.mscb-presets{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:6px}',
      '.mscb-preset{display:flex;align-items:center;gap:4px;padding:4px 6px 4px 10px;border:1px solid #d8e0ea;background:#fff;border-radius:14px;font-size:11.5px;color:#33475b;cursor:pointer}',
      '.mscb-preset:hover{border-color:#f5511e;color:#f5511e}',
      '.mscb-preset .px{color:#c81623;font-weight:700;padding:0 2px}',
      // v2.9.0 类目化模板：类目绑定 + 提示词补充
      '.mscb-tpl-autorow{font-size:11.5px;color:#55677a;margin:2px 0 6px}',
      '.mscb-tpl-autorow input{vertical-align:-2px;accent-color:#f5511e}',
      '.mscb-batchtpl{display:flex;align-items:center;gap:6px;margin-top:6px;font-size:11.5px;color:#55677a}',
      '.mscb-batchtpl select{flex:1;min-width:0;padding:5px 6px;border:1px solid #d8e0ea;border-radius:7px;font-size:12px;outline:none}',
      '.mscb-batchtpl button{padding:5px 10px;border:1px solid #d8e0ea;background:#fff;border-radius:7px;font-size:12px;cursor:pointer;white-space:nowrap}',
      '.mscb-rowsel{flex:0 0 auto;max-width:92px;padding:3px 4px;border:1px solid #d8e0ea;border-radius:6px;font-size:11px;color:#55677a;outline:none;background:#fff}',
      // v2.7.0 类目筛选 / 搜索 / 链接清单 / 打分 / 缩放
      '.mscb-filter{display:flex;gap:6px;margin-bottom:6px}',
      '.mscb-search{flex:1;min-width:0;padding:6px 8px;border:1px solid #d8e0ea;border-radius:8px;font-size:12px;outline:none}',
      '.mscb-search:focus{border-color:#f5511e}',
      '.mscb-cat{flex:0 0 118px;padding:6px 4px;border:1px solid #d8e0ea;border-radius:8px;font-size:12px;outline:none;background:#fff}',
      '.mscb-catonly{padding:6px 10px;border:1px solid #d8e0ea;background:#fff;border-radius:8px;font-size:12px;color:#33475b;cursor:pointer;white-space:nowrap}',
      '.mscb-catonly:hover{border-color:#f5511e;color:#f5511e}',
      '.mscb-align{padding:6px 10px;border:1px solid #d8e0ea;background:#fff;border-radius:8px;font-size:12px;color:#33475b;cursor:pointer;white-space:nowrap}',
      '.mscb-align:hover{border-color:#f5511e;color:#f5511e}',
      '.mscb-linkbtns{display:flex;gap:6px;margin-top:6px}',
      '.mscb-linkbtns button{flex:1;padding:8px;border:1px solid #d8e0ea;background:#fff;border-radius:9px;font-size:12.5px;color:#33475b;cursor:pointer}',
      '.mscb-linkbtns button:hover{border-color:#f5511e;color:#f5511e}',
      '.mscb-rr2{background:#fff;border:1px solid #ffd6d6 !important;color:#c81623 !important;flex:0 0 118px !important}',
      '.mscb-rate{display:flex;gap:3px;flex:0 0 auto}',
      '.mscb-rate button{padding:4px 6px;border:1px solid #d8e0ea;background:#fff;border-radius:7px;font-size:12px;cursor:pointer}',
      '.mscb-rate button.on1{background:#eaf3de;border-color:#3b6d11;color:#3b6d11}',
      '.mscb-rate button.on0{background:#fcebeb;border-color:#a32d2d;color:#a32d2d}',
      '.mscb-zoombtns{display:flex;gap:4px}',
      '.mscb-zoombtns button{width:22px;height:22px;border:0;border-radius:6px;background:rgba(255,255,255,.16);color:#fff;font-size:12px;cursor:pointer;line-height:1}',
      '.mscb-zoombtns button:hover{background:rgba(255,255,255,.3)}',
      // v2.7.1 全屏模式：小页面一键铺满大屏，看全局
      // v3.2.3 全屏自适应：铺满浏览器窗口，内部滚动区按窗口高度自动伸缩
      '.mscb-panel.mscb-full{width:100vw;height:100vh;max-height:100vh;right:0;bottom:0;border-radius:0}',
      '.mscb-panel.mscb-full .mscb-body{max-height:calc(100vh - 46px)}',
      '.mscb-panel.mscb-full .mscb-list{max-height:max(calc(100vh - 340px),260px)}',
      '.mscb-panel.mscb-full .mscb-res{max-height:max(calc(100vh - 230px),200px)}',
      '.mscb-panel.mscb-full .mscb-log{max-height:max(calc(100vh - 540px),120px)}',
      '.mscb-zfull.on{background:rgba(255,255,255,.42)!important}',
      // v2.8.0 经营小看板
      '.mscb-dash{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0 2px}',
      '.mscb-dash span{font-size:11.5px;font-weight:600;color:#33475b;background:#fff;border:1px solid #e6ebf2;border-radius:9px;padding:4px 10px;white-space:nowrap;box-shadow:0 1px 4px rgba(31,45,61,.07)}',
      '.mscb-dash span:nth-child(1){background:#fff4ec;border-color:#ffd9bd;color:#c0560a}',
      '.mscb-dash span:nth-child(2){background:#f0f6ff;border-color:#c9dcff;color:#2456b8}',
      '.mscb-dash span:nth-child(3){background:#f0fbf2;border-color:#c4ecd0;color:#0f8a3d}',
      '.mscb-dash span:nth-child(4){background:#f6f1ff;border-color:#dccfff;color:#6b3fc9}',
      '.mscb-dash span:nth-child(5){background:#fff0f3;border-color:#ffc9d4;color:#b8244a}',

      // ---------- v3.4.0 A. 启动按钮呼吸光效（跑单时机器在干活的感觉） ----------
      '@keyframes mscbBreath{0%,100%{box-shadow:0 6px 16px rgba(200,22,35,.32),0 0 0 0 rgba(245,81,30,.5)}50%{box-shadow:0 6px 16px rgba(200,22,35,.32),0 0 0 12px rgba(245,81,30,0)}}',
      '@keyframes mscbBreathY{0%,100%{box-shadow:0 6px 16px rgba(200,140,20,.3),0 0 0 0 rgba(255,176,32,.5)}50%{box-shadow:0 6px 16px rgba(200,140,20,.3),0 0 0 12px rgba(255,176,32,0)}}',
      '.mscb-start.running{animation:mscbBreath 1.5s ease-out infinite}',
      '.mscb-start.paused{background:linear-gradient(135deg,#ffb020,#e8890c)!important;animation:mscbBreathY 1.5s ease-out infinite}',

      // ---------- v3.4.0 C. 成品图灯箱：滚轮缩放 / 拖动查看 / 双击还原 ----------
      '.mscb-zoommask{position:fixed;inset:0;z-index:2147483100;background:rgba(8,12,18,.86);display:none;align-items:center;justify-content:center;cursor:grab}',
      '.mscb-zoommask.open{display:flex}',
      '.mscb-zoomcap{position:absolute;top:16px;left:0;right:0;text-align:center;color:#eef2f8;font-size:13px;font-weight:600;letter-spacing:.3px;text-shadow:0 2px 8px rgba(0,0,0,.6);pointer-events:none}',
      '.mscb-zoomp,.mscb-zoomn{position:absolute;top:50%;transform:translateY(-50%);width:44px;height:64px;display:none;align-items:center;justify-content:center;font-size:34px;line-height:1;color:#fff;background:rgba(255,255,255,.10);border-radius:10px;cursor:pointer;user-select:none;z-index:3}',
      '.mscb-zoomp{left:18px}.mscb-zoomn{right:18px}',
      '.mscb-zoommask.multi .mscb-zoomp,.mscb-zoommask.multi .mscb-zoomn{display:flex}',
      '.mscb-zoomp:hover,.mscb-zoomn:hover{background:rgba(245,81,30,.85)}',
      '.mscb-zoomimg{max-width:86vw;max-height:86vh;transform-origin:center center;user-select:none;-webkit-user-drag:none;border-radius:8px;box-shadow:0 24px 70px rgba(0,0,0,.55)}',
      '.mscb-zoomx{position:fixed;top:16px;right:26px;font-size:32px;color:#fff;cursor:pointer;opacity:.85;line-height:1}',
      '.mscb-zoomx:hover{opacity:1}',
      '.mscb-zoomtip{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);color:#cfd8e3;font-size:12.5px;background:rgba(255,255,255,.1);border-radius:14px;padding:6px 14px;pointer-events:none}',

      // ---------- v3.4.0 E. 新手引导蒙层 ----------
      '.mscb-tourmask .mscb-dialog{width:460px;max-width:92vw}',
      '.mscb-tourstep{padding:6px 2px 2px}',
      '.mscb-tourstep h5{margin:0 0 8px;font-size:16.5px;color:#1f2d3d}',
      '.mscb-tourstep p{margin:0;font-size:13px;line-height:1.8;color:#55677a;word-break:break-all}',
      '.mscb-tourdots{display:flex;gap:6px;justify-content:center;margin:12px 0 4px}',
      '.mscb-tourdots i{width:8px;height:8px;border-radius:50%;background:#d8e0ea}',
      '.mscb-tourdots i.on{background:#f5511e;width:20px;border-radius:4px}',
      '.mscb-tourbtns{display:flex;gap:8px;margin-top:10px}',
      '.mscb-tourbtns .mscb-tourskip{flex:0 0 auto;padding:10px 16px;border:1px solid #d8e0ea;background:#fff;border-radius:9px;font-size:13px;color:#55677a;cursor:pointer}',
      '.mscb-tourbtns .mscb-tournext{flex:1;padding:10px;border:0;border-radius:9px;background:linear-gradient(135deg,#ff7a45,#f5511e);color:#fff;font-size:13.5px;font-weight:700;cursor:pointer}',
      '.mscb-tourbtn{background:none;border:1px solid #ffd9a8;border-radius:12px;padding:2px 10px;font-size:11.5px;color:#c0560a;cursor:pointer;margin-left:8px}',
      '.mscb-tourbtn:hover{background:#fff4ec}',

      // ---------- v3.4.0 D. 深色模式（自动跟随系统） ----------
      '.mscb-dark .mscb-panel{background:#1b2431;color:#dbe4f0}',
      '.mscb-dark .mscb-stat,.mscb-dark .mscb-selbar,.mscb-dark .mscb-hint,.mscb-dark .mscb-checkrow{color:#9fb0c5}',
      '.mscb-dark .mscb-list{background:#202b3b;border-color:#2c3a4e}',
      '.mscb-dark .mscb-item{border-color:#26334a;color:#dbe4f0}',
      '.mscb-dark .mscb-item:hover{background:#243146}',
      '.mscb-dark .mscb-thumb{background:#26334a;border-color:#2c3a4e}',
      '.mscb-dark .mscb-t1{color:#e6edf7}',
      '.mscb-dark .mscb-t2{color:#8fa2ba}',
      '.mscb-dark input,.mscb-dark select,.mscb-dark textarea{background:#202b3b!important;border-color:#2c3a4e!important;color:#dbe4f0!important}',
      '.mscb-dark input[type=checkbox]{accent-color:#f5511e}',
      '.mscb-dark .mscb-mode,.mscb-dark .mscb-dockbtn,.mscb-dark .mscb-pause,.mscb-dark .mscb-resume,.mscb-dark .mscb-refetch,',
      '.mscb-dark .mscb-export,.mscb-dark .mscb-inv,.mscb-dark .mscb-catonly,.mscb-dark .mscb-preset-save,.mscb-dark .mscb-tpl-preview,',
      '.mscb-dark .mscb-batchok,.mscb-rowsel-dark{background:#202b3b;border-color:#2c3a4e;color:#c7d3e4}',
      '.mscb-dark .mscb-mode.on{background:#f5511e;border-color:#f5511e;color:#fff}',
      '.mscb-dark .mscb-tpl{background:#202b3b;border-color:#2c3a4e}',
      '.mscb-dark .mscb-tpl-t{color:#c7d3e4}',
      '.mscb-dark .mscb-tpl-t:hover{background:#243146}',
      '.mscb-dark .mscb-log{background:#141b26;border-color:#26334a;color:#9fb0c5}',
      '.mscb-dark .mscb-line:hover{background:#243146}',
      '.mscb-dark .mscb-dash span{background:#202b3b;border-color:#2c3a4e;color:#c7d3e4}',
      '.mscb-dark .mscb-dash span:nth-child(1){background:#33260f;border-color:#5a3d12;color:#ffca7a}',
      '.mscb-dark .mscb-dash span:nth-child(2){background:#12233f;border-color:#27436e;color:#9ec2ff}',
      '.mscb-dark .mscb-dash span:nth-child(3){background:#0f2c18;border-color:#275e37;color:#7fe0a2}',
      '.mscb-dark .mscb-dash span:nth-child(4){background:#221440;border-color:#43307a;color:#c3a6ff}',
      '.mscb-dark .mscb-dash span:nth-child(5){background:#3a1420;border-color:#6e2740;color:#ff9eb4}',
      '.mscb-dark .mscb-bubble{background:#202b3b;color:#ffd9bd;border-color:#b2602f}',
      '.mscb-dark .mscb-dialog{background:#202b3b;color:#dbe4f0}',
      '.mscb-dark .mscb-guide{background:#2a2113;border-color:#5a3d12}',
      '.mscb-dark .mscb-guide h5{color:#ffca7a}',
      '.mscb-dark .mscb-guide ol{color:#d9bd93}',
      '.mscb-dark .mscb-guide b{color:#ffb066}',
      '.mscb-dark .mscb-chat{background:#141b26;border-color:#26334a}',
      '.mscb-dark .mscb-msg.bot{background:#243146;color:#dbe4f0}',
      '.mscb-dark .mscb-chip,.mscb-dark .mscb-tourbtns .mscb-tourskip{background:#202b3b;border-color:#2c3a4e;color:#c7d3e4}',
      '.mscb-dark .mscb-prog{background:#202b3b;border-color:#5a3d12}',
      '.mscb-dark .mscb-prog-text{color:#e6edf7}',
      '.mscb-dark .mscb-prog-bar{background:#26334a}',
      '.mscb-dark .mscb-tourstep h5{color:#e6edf7}',
      '.mscb-dark .mscb-tourstep p{color:#9fb0c5}',
      '.mscb-dark .mscb-quota{color:#9fb0c5}',
      '.mscb-dark .mscb-user{background:#202b3b;border-color:#2c3a4e}',
      '.mscb-dark .mscb-link{color:#7fb0ff}',
      '.mscb-dark .mscb-more{color:#8fa2ba}',
      '.mscb-dark .mscb-rate button{background:#202b3b;border-color:#2c3a4e;color:#c7d3e4}',

      // ==================== v3.7.0 主题系统 ====================
      // 变量驱动的主题层：置于全部旧规则之后，同优先级后写胜出。
      // 每个主题都显式成对设置 背景+文字，杜绝"背景挡住字体看不清"。
      '.mscb-root{',
      '--th-bg:#fff;--th-fg:#1f2d3d;--th-muted:#4e5f70;--th-faint:#6b7785;',
      '--th-card:#f8fafc;--th-card2:#eef4ff;--th-border:#e6ebf2;--th-border2:#d8e0ea;--th-imgbg:#f5f7fa;',
      '--th-accent:#f5511e;--th-accent2:#c81623;--th-onacc:#fff;',
      '--th-headbg:linear-gradient(120deg,#1f2d3d 55%,#b23c18);--th-headfg:#fff;',
      '--th-input:#fff;--th-btn:#fff;--th-btnfg:#33475b;--th-link:#2f6fd0;',
      '--th-ok:#0f8a3d;--th-warn:#b25e00;--th-err:#c81623;--th-info:#2563eb;',
      '--th-progbg:#fff8f8;--th-progbd:#ffd6d6;--th-barbg:#ffe9e9;',
      '--th-tint:#fff4ec;--th-tintfg:#c0560a;--th-tintbd:#ffd9bd;--th-hover:#fff6f0;',
      '--th-errbg:#fff1f0;--th-errbd:#ffa39e;--th-errfg:#cf1322}',
      // 黑白极简：纯白底 + 近黑文字 + 纯黑主按钮（状态色保留低饱和红绿，保证可读）
      '.mscb-root[data-theme=bw]{',
      '--th-bg:#fff;--th-fg:#171717;--th-muted:#3d3d3d;--th-faint:#666666;',
      '--th-card:#f7f7f7;--th-card2:#ececec;--th-border:#e3e3e3;--th-border2:#cfcfcf;--th-imgbg:#f2f2f2;',
      '--th-accent:#171717;--th-accent2:#000;--th-onacc:#fff;',
      '--th-headbg:#171717;--th-headfg:#fff;',
      '--th-input:#fff;--th-btn:#fff;--th-btnfg:#333;--th-link:#171717;',
      '--th-ok:#2e7d46;--th-warn:#8a6d00;--th-err:#c0392b;--th-info:#4d4d4d;',
      '--th-progbg:#fafafa;--th-progbd:#d9d9d9;--th-barbg:#ebebeb;',
      '--th-tint:#f2f2f2;--th-tintfg:#171717;--th-tintbd:#d9d9d9;--th-hover:#f5f5f5;',
      '--th-errbg:#f6f6f6;--th-errbd:#c8c8c8;--th-errfg:#c0392b}',
      // 暗夜黑：深底浅字，所有卡片/输入框同步加深，文字全面转浅色
      '.mscb-root[data-theme=dark]{',
      '--th-bg:#161d28;--th-fg:#e6edf7;--th-muted:#a8b9cc;--th-faint:#93a5bd;',
      '--th-card:#1d2735;--th-card2:#243146;--th-border:#2a3850;--th-border2:#33425c;--th-imgbg:#26334a;',
      '--th-accent:#ff7a45;--th-accent2:#f5511e;--th-onacc:#fff;',
      '--th-headbg:#10161f;--th-headfg:#fff;',
      '--th-input:#1d2735;--th-btn:#1d2735;--th-btnfg:#c7d3e4;--th-link:#7fb0ff;',
      '--th-ok:#46c37b;--th-warn:#f0b45a;--th-err:#ff6b66;--th-info:#6ea8ff;',
      '--th-progbg:#1d2735;--th-progbd:#4a5a75;--th-barbg:#2a3850;',
      '--th-tint:#2c2417;--th-tintfg:#ffb066;--th-tintbd:#5a3d12;--th-hover:#243146;',
      '--th-errbg:#3a1d1f;--th-errbd:#6e2a2e;--th-errfg:#ff8f8a}',
      // 海洋蓝
      '.mscb-root[data-theme=ocean]{',
      '--th-accent:#1677ff;--th-accent2:#0958d9;',
      '--th-headbg:linear-gradient(120deg,#0b2d55,#1677ff);',
      '--th-tint:#eef5ff;--th-tintfg:#0b53c4;--th-tintbd:#bfdcff;--th-hover:#f0f6ff;--th-card2:#e8f1ff;--th-link:#1677ff;--th-info:#1677ff}',
      // 森林绿
      '.mscb-root[data-theme=forest]{',
      '--th-accent:#12803c;--th-accent2:#0f6b32;',
      '--th-headbg:linear-gradient(120deg,#0b3320,#12803c);',
      '--th-tint:#ecf9f0;--th-tintfg:#15803d;--th-tintbd:#b7e6c6;--th-hover:#f0faf3;--th-card2:#e4f6ea;--th-link:#15803d;--th-info:#0f8a3d}',
      // 葡萄紫
      '.mscb-root[data-theme=grape]{',
      '--th-accent:#7c3aed;--th-accent2:#6d28d9;',
      '--th-headbg:linear-gradient(120deg,#2a1554,#7c3aed);',
      '--th-tint:#f4efff;--th-tintfg:#6d28d9;--th-tintbd:#dbcaff;--th-hover:#f7f3ff;--th-card2:#efe8ff;--th-link:#6d28d9;--th-info:#7c3aed}',

      // ---- 主题应用层（背景与文字成对设置） ----
      '.mscb-root .mscb-panel{background:var(--th-bg);color:var(--th-fg)}',
      '.mscb-root .mscb-head{background:var(--th-headbg);color:var(--th-headfg)}',
      // 主文字 / 次级文字 / 弱文字
      '.mscb-root .mscb-t1,.mscb-root .mscb-rest1,.mscb-root .mscb-histt,.mscb-root .mscb-pvbar,',
      '.mscb-root .mscb-cmphead span,.mscb-root .mscb-dialog h4,.mscb-root .mscb-tourstep h5{color:var(--th-fg)}',
      '.mscb-root .mscb-stat,.mscb-root .mscb-selbar,.mscb-root .mscb-checkrow,.mscb-root .mscb-cfg,',
      '.mscb-root .mscb-tpl-t,.mscb-root .mscb-tpl-chks label,.mscb-root .mscb-set-t,.mscb-root .mscb-bycnt,',
      '.mscb-root .mscb-quota,.mscb-root .mscb-tourstep p,.mscb-root .mscb-pvtitle,.mscb-root .mscb-dialog label,',
      '.mscb-root .mscb-tpl-fixed label,.mscb-root .mscb-tpl-autorow,.mscb-root .mscb-batchtpl,.mscb-root .mscb-histhead{color:var(--th-muted)}',
      '.mscb-root .mscb-t2,.mscb-root .mscb-rest2,.mscb-root .mscb-histmeta,.mscb-root .mscb-histcount,.mscb-root .mscb-ts,',
      '.mscb-root .mscb-hint,.mscb-root .mscb-more,.mscb-root .mscb-prog-time,.mscb-root .mscb-cmpnote,',
      '.mscb-root .mscb-pvmiss,.mscb-root .mscb-tpl-t .arr,.mscb-root .mscb-list:empty::after{color:var(--th-faint)}',
      // 列表 / 卡片 / 输入框
      '.mscb-root .mscb-list{border-color:var(--th-border)}',
      '.mscb-root .mscb-item{border-color:var(--th-border)}',
      '.mscb-root .mscb-item:hover{background:var(--th-hover)}',
      '.mscb-root .mscb-thumb,.mscb-root .mscb-resthumb{background:var(--th-imgbg);border-color:var(--th-border)}',
      '.mscb-root .mscb-resrow{border-color:var(--th-border)}',
      '.mscb-root .mscb-histrow{border-color:var(--th-border)}',
      '.mscb-root .mscb-histwrap{border-color:var(--th-border2)}',
      '.mscb-root .mscb-histhead{background:var(--th-card)}',
      '.mscb-root .mscb-histhead:hover{background:var(--th-card2)}',
      '.mscb-root .mscb-histlist{border-color:var(--th-border)}',
      '.mscb-root .mscb-setbox,.mscb-root .mscb-tpl,.mscb-root .mscb-chat{background:var(--th-card);border-color:var(--th-border)}',
      '.mscb-root .mscb-tpl-t:hover{background:var(--th-card2)}',
      '.mscb-root .mscb-res{border-color:var(--th-border)}',
      '.mscb-root input:not([type=checkbox]):not([type=radio]),.mscb-root select,.mscb-root textarea{background:var(--th-input);border-color:var(--th-border2);color:var(--th-fg)}',
      '.mscb-root input:focus,.mscb-root select:focus,.mscb-root textarea:focus{border-color:var(--th-accent)}',
      '.mscb-root input::placeholder,.mscb-root textarea::placeholder{color:var(--th-faint)}',
      '.mscb-root input[type=checkbox]{accent-color:var(--th-accent)}',
      '.mscb-root .mscb-ck,.mscb-root .mscb-selbar input,.mscb-root .mscb-tpl-chks input,.mscb-root .mscb-checkrow input,',
      '.mscb-root .mscb-tpl-autorow input{accent-color:var(--th-accent);border-color:var(--th-border2)}',
      '.mscb-root .mscb-count{background:var(--th-input);color:var(--th-accent2);border-color:var(--th-border2)}',
      '.mscb-root .mscb-count:disabled{background:var(--th-card);color:var(--th-faint)}',
      // 次级按钮（白底描边那一族）
      '.mscb-root .mscb-btn,.mscb-root .mscb-pause,.mscb-root .mscb-resume,.mscb-root .mscb-refetch,',
      '.mscb-root .mscb-export,.mscb-root .mscb-catonly,.mscb-root .mscb-chip,.mscb-root .mscb-preset,',
      '.mscb-root .mscb-rate button,.mscb-root .mscb-dockbtn,.mscb-root .mscb-linkbtns button,',
      '.mscb-root .mscb-tpl-presetrow button,.mscb-root .mscb-batchtpl button,.mscb-root .mscb-resacts button,',
      '.mscb-root .mscb-histbtns button,.mscb-root .mscb-pvbtns button,.mscb-root .mscb-dialog-btns button,',
      '.mscb-root .mscb-tourbtns .mscb-tourskip,.mscb-root .mscb-rowsel,.mscb-root .mscb-cat{background:var(--th-btn);color:var(--th-btnfg);border-color:var(--th-border2)}',
      '.mscb-root .mscb-btn:hover,.mscb-root .mscb-pause:hover,.mscb-root .mscb-resume:hover,.mscb-root .mscb-refetch:hover,',
      '.mscb-root .mscb-export:hover,.mscb-root .mscb-catonly:hover,.mscb-root .mscb-chip:hover,.mscb-root .mscb-preset:hover,',
      '.mscb-root .mscb-linkbtns button:hover,.mscb-root .mscb-resacts button:hover{border-color:var(--th-accent);color:var(--th-accent)}',
      '.mscb-root .mscb-histbtns button:hover,.mscb-root .mscb-pvbtns button:hover{background:var(--th-accent);color:var(--th-onacc);border-color:var(--th-accent)}',
      // 主按钮（彩色渐变那一族，文字恒为 --th-onacc 白）
      '.mscb-root .mscb-start,.mscb-root .mscb-auto,.mscb-root .mscb-one,.mscb-root .mscb-send,.mscb-root .mscb-rpatest,',
      '.mscb-root .mscb-rrpa,.mscb-root .mscb-aisend,.mscb-root .mscb-tourbtns .mscb-tournext,',
      '.mscb-root .mscb-dialog-btns .mscb-dlg-ok{background:linear-gradient(135deg,var(--th-accent),var(--th-accent2));color:var(--th-onacc);border-color:transparent}',
      '.mscb-root .mscb-dockbtn.on{background:var(--th-accent);border-color:var(--th-accent);color:var(--th-onacc)}',
      '.mscb-root .mscb-msg.me{background:var(--th-accent);color:var(--th-onacc)}',
      // 强调色点缀
      '.mscb-root .mscb-selinfo,.mscb-root .mscb-pvtyp{background:var(--th-tint);color:var(--th-tintfg);border-color:var(--th-tintbd)}',
      '.mscb-root .mscb-go{background:var(--th-tint);color:var(--th-accent);border-color:var(--th-accent)}',
      '.mscb-root .mscb-inv{color:var(--th-accent2)}',
      '.mscb-root .mscb-inv:hover{background:var(--th-tint)}',
      '.mscb-root .mscb-link{color:var(--th-link)}',
      '.mscb-root .mscb-links-title{color:var(--th-ok)}',
      '.mscb-root .mscb-quota b{color:var(--th-accent2)}',
      '.mscb-root .mscb-preset .px{color:var(--th-accent2)}',
      '.mscb-root .mscb-bubble{background:var(--th-card);color:var(--th-fg);border-color:var(--th-accent)}',
      '.mscb-root .mscb-bubble b{color:var(--th-accent)}',
      '.mscb-root .mscb-tourbtn{border-color:var(--th-tintbd);color:var(--th-tintfg)}',
      '.mscb-root .mscb-tourbtn:hover{background:var(--th-tint)}',
      '.mscb-root .mscb-tourdots i{background:var(--th-border2)}',
      '.mscb-root .mscb-tourdots i.on{background:var(--th-accent)}',
      '.mscb-root .mscb-checkrow .q{background:var(--th-card2);color:var(--th-faint)}',
      // 日志
      '.mscb-root .mscb-log,.mscb-root .mscb-mini-log{background:var(--th-card);border-color:var(--th-border);color:var(--th-muted)}',
      '.mscb-root .mscb-line:hover{background:var(--th-card2)}',
      '.mscb-root .mscb-line.ok{color:var(--th-ok)}',
      '.mscb-root .mscb-line.warn{color:var(--th-warn)}',
      '.mscb-root .mscb-line.err{color:var(--th-err)}',
      '.mscb-root .mscb-line.complete{color:var(--th-err);font-weight:800;font-size:13px}',
      '.mscb-root .mscb-envcheck,.mscb-root .mscb-tts-test{padding:5px 9px;border:1px solid var(--th-border);border-radius:6px;background:var(--th-card);color:var(--th-fg);cursor:pointer}',
      '.mscb-root .mscb-envcheck:disabled{opacity:.5;cursor:default}',
      '.mscb-root .mscb-donemask h4{color:var(--th-err)}',
      '.mscb-head>span:last-of-type{flex-wrap:wrap;justify-content:flex-end}',
      '.mscb-head .mscb-rpatest{width:auto;max-width:none;margin:0;padding:5px 10px;border:1px solid rgba(255,255,255,.6);border-radius:6px;background:#fff;color:#ad2d10;font-size:12px;font-weight:700;white-space:nowrap}',
      '.mscb-root .mscb-line.info{color:var(--th-info)}',
      // 进度
      '.mscb-root .mscb-prog{background:var(--th-progbg);border-color:var(--th-progbd)}',
      '.mscb-root .mscb-prog-text{color:var(--th-accent2)}',
      '.mscb-root .mscb-prog-bar,.mscb-root .mscb-resbar{background:var(--th-barbg)}',
      '.mscb-root .mscb-prog-bar i,.mscb-root .mscb-resbar i{background:linear-gradient(90deg,var(--th-accent),var(--th-accent2))}',
      // 弹窗 / 预览 / 对比 / 错误提醒（全部显式 背景+文字）
      '.mscb-root .mscb-dialog{background:var(--th-bg);color:var(--th-fg)}',
      '.mscb-root .mscb-pvcard img,.mscb-root .mscb-cmpcell img{background:var(--th-imgbg)}',
      '.mscb-root .mscb-cmpempty{background:var(--th-imgbg);color:var(--th-faint)}',
      '.mscb-root .mscb-cmphead{background:var(--th-bg)}',
      '.mscb-root .mscb-pvmiss{background:var(--th-imgbg)}',
      '.mscb-root .mscb-pvmiss.mscb-pvmiss-retry{background:var(--th-tint);color:var(--th-tintfg);border:1px solid var(--th-tintbd)}',
      '.mscb-root .mscb-errlist{background:var(--th-errbg);border-color:var(--th-errbd);color:var(--th-errfg)}',
      '.mscb-root .mscb-errdlg h4{color:var(--th-errfg)}',
      '.mscb-root .mscb-errrow{border-color:var(--th-errbd)}',
      '.mscb-root .mscb-guide{background:var(--th-tint);border-color:var(--th-tintbd)}',
      '.mscb-root .mscb-guide h5,.mscb-root .mscb-guide b{color:var(--th-tintfg)}',
      '.mscb-root .mscb-guide ol{color:var(--th-muted)}',
      '.mscb-root .mscb-msg.bot{background:var(--th-card2);color:var(--th-fg)}',
      // 结果区按钮两个特殊色
      '.mscb-root .mscb-resbtns .mscb-rprev{background:var(--th-headbg);color:var(--th-headfg)}',
      '.mscb-root .mscb-resbtns .mscb-rcsv{background:var(--th-tint);color:var(--th-tintfg)}',
      '.mscb-root .mscb-rr2{background:var(--th-btn)!important;color:var(--th-err)!important;border-color:var(--th-err)!important}',
      // 迷你运行条
      '.mscb-root .mscb-mini{background:var(--th-bg);border-color:var(--th-border)}',
      '.mscb-root .mscb-mini-head{background:linear-gradient(135deg,var(--th-accent),var(--th-accent2));color:var(--th-onacc)}',
      '.mscb-root .mscb-mini-prog{background:var(--th-barbg)}',
      '.mscb-root .mscb-mini-prog i{background:linear-gradient(90deg,var(--th-accent),var(--th-accent2))}',
      '.mscb-root .mscb-mini-time{color:var(--th-warn)}',
      // 会员芯片 / 把手 / 滚动条
      '.mscb-root .mscb-tierchip{background:var(--th-headbg);color:var(--th-headfg)}',
      '.mscb-root .mscb-grip.tl,.mscb-root .mscb-grip.tr{border-top-color:var(--th-faint)}',
      '.mscb-root .mscb-grip.bl,.mscb-root .mscb-grip.br{border-bottom-color:var(--th-faint)}',
      '.mscb-root .mscb-grip.tl,.mscb-root .mscb-grip.bl{border-left-color:var(--th-faint)}',
      '.mscb-root .mscb-grip.tr,.mscb-root .mscb-grip.br{border-right-color:var(--th-faint)}',
      '.mscb-root .mscb-body::-webkit-scrollbar-thumb,.mscb-root .mscb-list::-webkit-scrollbar-thumb,',
      '.mscb-root .mscb-log::-webkit-scrollbar-thumb,.mscb-root .mscb-chat::-webkit-scrollbar-thumb{background:var(--th-border2)}',
      // 暗夜专属：看板五色小芯片改深底浅字（浅底芯片在黑面板上会刺眼）
      '.mscb-root[data-theme=dark] .mscb-dash span{background:#1d2735;border-color:#2a3850;color:#c7d3e4}',
      '.mscb-root[data-theme=dark] .mscb-dash span:nth-child(1){background:#33260f;border-color:#5a3d12;color:#ffca7a}',
      '.mscb-root[data-theme=dark] .mscb-dash span:nth-child(2){background:#12233f;border-color:#27436e;color:#9ec2ff}',
      '.mscb-root[data-theme=dark] .mscb-dash span:nth-child(3){background:#0f2c18;border-color:#275e37;color:#7fe0a2}',
      '.mscb-root[data-theme=dark] .mscb-dash span:nth-child(4){background:#221440;border-color:#43307a;color:#c3a6ff}',
      '.mscb-root[data-theme=dark] .mscb-dash span:nth-child(5){background:#3a1420;border-color:#6e2740;color:#ff9eb4}',
      // 看板里的「📄 导出」胶囊跟随主题
      '.mscb-root .mscb-dash .mscb-dashexp{cursor:pointer;background:var(--th-btn);border-color:var(--th-accent);color:var(--th-accent)}',
      // 黑白主题：看板小芯片统一走灰阶，避免残留彩色
      '.mscb-root[data-theme=bw] .mscb-dash span{background:#f7f7f7;border-color:#dcdcdc;color:#333}',
      '.mscb-root[data-theme=bw] .mscb-dash .mscb-dashexp{background:#fff;border-color:#171717;color:#171717}',
      // 主题切换菜单（头部 🎨 按钮）
      '.mscb-thwrap{position:relative}',
      '.mscb-thbtn{width:22px;height:22px;border:0;border-radius:6px;background:rgba(255,255,255,.16);color:#fff;font-size:13px;cursor:pointer;line-height:1;padding:0}',
      '.mscb-thbtn:hover{background:rgba(255,255,255,.3)}',
      '.mscb-thmenu{position:absolute;top:27px;right:0;z-index:99;min-width:136px;padding:5px;display:none;flex-direction:column;gap:2px;',
      'background:var(--th-bg);border:1px solid var(--th-border);border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,.28)}',
      '.mscb-thmenu.open{display:flex}',
      '.mscb-thmenu button{display:flex;align-items:center;gap:8px;border:0;background:transparent;color:var(--th-fg);',
      'font-size:12px;padding:6px 8px;border-radius:7px;cursor:pointer;text-align:left;white-space:nowrap}',
      '.mscb-thmenu button:hover{background:var(--th-card2)}',
      '.mscb-thmenu button.on{background:var(--th-tint);color:var(--th-tintfg);font-weight:700}',
      '.mscb-thdot{width:12px;height:12px;border-radius:50%;flex:0 0 auto;border:1px solid rgba(0,0,0,.18)}',
      "/* Append last to the existing style array. Opt-in only; existing state/zoom/drag rules own behavior. */\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay){\n  --glass-shell:rgba(250,251,253,.91);--glass-solid:#f8f9fb;--glass-card:rgba(255,255,255,.70);\n  --glass-input:rgba(255,255,255,.90);--glass-hover:rgba(229,233,239,.85);--glass-edge:rgba(91,103,123,.20);\n  --glass-fg:#24262b;--glass-muted:#4d5561;--glass-faint:#58616e;--glass-tint:rgba(232,236,242,.75);\n  --glass-primary:#b73b12;--glass-primary-deep:#9d2f10;--glass-on-primary:#fff;--glass-focus:#a3340f;\n  --glass-shadow:0 18px 48px rgba(24,34,49,.19),inset 0 1px 0 rgba(255,255,255,.88);\n  --glass-radius:16px;--glass-pill:999px;--glass-blur:22px;\n  --th-bg:var(--glass-solid);--th-fg:var(--glass-fg);--th-muted:var(--glass-muted);--th-faint:var(--glass-faint);\n  --th-card:var(--glass-card);--th-card2:var(--glass-tint);--th-input:var(--glass-input);--th-btn:var(--glass-input);--th-btnfg:var(--glass-fg);\n  --th-headbg:var(--glass-card);--th-headfg:var(--glass-fg);--th-border:var(--glass-edge);--th-border2:var(--glass-edge);\n  --th-accent:var(--glass-primary);--th-accent2:var(--glass-primary-deep);--th-onacc:var(--glass-on-primary);\n  --th-tint:rgba(255,228,214,.66);--th-tintfg:#8b3012;--th-tintbd:rgba(183,59,18,.23);--th-hover:var(--glass-hover);\n  --th-link:#225cad;--th-imgbg:#edf0f4;--th-ok:#176c3a;--th-warn:#885100;--th-err:#b5202a;--th-info:#225cad;\n  --th-progbg:var(--glass-card);--th-progbd:var(--glass-edge);--th-barbg:rgba(99,109,126,.16);\n  --th-errbg:#fff1f1;--th-errbd:#d8969c;--th-errfg:#ad1723;\n  color:var(--th-fg);font-family:-apple-system,BlinkMacSystemFont,\"SF Pro Text\",\"Helvetica Neue\",\"PingFang SC\",\"Microsoft YaHei\",sans-serif;\n  font-size:13px;line-height:1.5;letter-spacing:normal;font-variant-numeric:tabular-nums;\n  -webkit-font-smoothing:antialiased;caret-color:var(--glass-primary);color-scheme:light;\n}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay)[data-theme=bw]{--glass-solid:#f6f7f8;--glass-shell:rgba(250,251,252,.94);--glass-tint:rgba(225,228,232,.80);--th-link:#30343a;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay)[data-theme=ocean]{--glass-solid:#f1f6fb;--glass-shell:rgba(242,248,253,.92);--glass-tint:rgba(217,233,248,.78);--th-link:#174f8d;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay)[data-theme=forest]{--glass-solid:#f1f7f3;--glass-shell:rgba(243,250,246,.92);--glass-tint:rgba(220,237,225,.78);--th-link:#22613c;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay)[data-theme=grape]{--glass-solid:#f7f3fa;--glass-shell:rgba(249,245,253,.92);--glass-tint:rgba(233,224,245,.78);--th-link:#613c92;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay)[data-theme=dark]{\n  --glass-shell:rgba(29,32,39,.94);--glass-solid:#20232a;--glass-card:rgba(48,53,63,.88);--glass-input:rgba(42,47,57,.97);\n  --glass-hover:rgba(67,75,89,.96);--glass-tint:rgba(60,68,82,.88);--glass-edge:rgba(214,222,236,.22);\n  --glass-fg:#f1f3f7;--glass-muted:#c2cad6;--glass-faint:#b1bccd;--glass-focus:#ffb28e;\n  --glass-shadow:0 20px 52px rgba(0,0,0,.36),inset 0 1px 0 rgba(255,255,255,.16);\n  --th-tint:#493024;--th-tintfg:#ffc4a7;--th-tintbd:#916047;--th-link:#a8cdff;--th-imgbg:#303642;\n  --th-ok:#8de2b1;--th-warn:#ffd18b;--th-err:#ff9ca6;--th-info:#a8cdff;--th-errbg:#472a30;--th-errbd:#9e6169;--th-errfg:#ffb1b9;\n  color-scheme:dark;\n}\n/* Frost only bounded shells, never body, mask, image or every nested row. */\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-panel,.mscb-dialog,.mscb-mini,.mscb-thmenu){\n  background:var(--glass-shell);color:var(--th-fg);border-radius:var(--glass-radius);box-shadow:var(--glass-shadow);\n  -webkit-backdrop-filter:blur(var(--glass-blur)) saturate(125%);backdrop-filter:blur(var(--glass-blur)) saturate(125%);\n}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-head,.mscb-mini-head){background:var(--glass-card);color:var(--th-fg);border-bottom:1px solid var(--glass-edge);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-head{padding:12px 16px;gap:12px;align-items:center;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-head>span:last-of-type{gap:6px;flex-wrap:wrap;min-width:0;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-body{background:transparent;padding:16px;color:var(--th-fg);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(button,input,select,textarea){font-family:inherit;font-size:inherit;line-height:1.4;letter-spacing:inherit;box-sizing:border-box;}\n/* Visual !important is limited to incumbent inline/legacy !important paints, not state or layout. */\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) button{\n  border-radius:var(--glass-pill)!important;border:1px solid var(--glass-edge);background:var(--glass-input);color:var(--th-fg);\n  min-height:32px;padding:6px 12px;box-shadow:inset 0 1px 0 rgba(255,255,255,.28);\n  transition:background-color 160ms ease-out,border-color 160ms ease-out,box-shadow 160ms ease-out;\n}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-head,.mscb-zoombtns,.mscb-thmenu) button{background:var(--glass-input)!important;color:var(--th-fg)!important;border-color:var(--glass-edge)!important;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-start,.mscb-auto,.mscb-one,.mscb-send,.mscb-rrpa,.mscb-aisend,.mscb-dlg-ok,.mscb-done-refresh,.mscb-tournext){\n  background:linear-gradient(180deg,var(--glass-primary),var(--glass-primary-deep))!important;color:var(--glass-on-primary)!important;border-color:transparent!important;font-weight:650;\n  box-shadow:inset 0 1px 0 rgba(255,255,255,.24),0 3px 8px rgba(144,49,15,.16);\n}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-dockbtn.on,.mscb-mode.on){background:var(--glass-primary)!important;color:var(--glass-on-primary)!important;border-color:transparent!important;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-head .mscb-rpatest{background:var(--th-tint)!important;color:var(--th-tintfg)!important;border-color:var(--th-tintbd)!important;width:auto;margin:0;white-space:nowrap;font-size:12px;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-envcheck,.mscb-tts-test,.mscb-pvbtns button,.mscb-histbtns button,.mscb-done-close){background:var(--glass-input);color:var(--th-fg);border-color:var(--glass-edge);}\n@media (hover:hover){\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) button:not(:disabled):hover{background:var(--glass-hover);border-color:var(--glass-primary);box-shadow:inset 0 1px 0 rgba(255,255,255,.30),0 3px 9px rgba(33,42,56,.10);}\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-start,.mscb-auto,.mscb-one,.mscb-send,.mscb-rrpa,.mscb-aisend,.mscb-dlg-ok,.mscb-done-refresh,.mscb-tournext):not(:disabled):hover{background:var(--glass-primary-deep)!important;}\n}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) button:not(:disabled):active{box-shadow:inset 0 2px 5px rgba(24,32,44,.20);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(button,input,select,textarea,a,[tabindex]):focus-visible{outline:2px solid var(--glass-focus);outline-offset:3px;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(button,input,select,textarea):disabled{opacity:.55;cursor:not-allowed;box-shadow:none;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(input:not([type=checkbox]):not([type=radio]),select,textarea){\n  background:var(--glass-input)!important;color:var(--th-fg)!important;border:1px solid var(--glass-edge)!important;border-radius:12px;padding:8px 10px;max-width:100%;\n}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(input[type=checkbox],input[type=radio]){accent-color:var(--glass-primary);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(input,textarea)::placeholder{color:var(--th-faint);opacity:1;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(input,select,textarea)[aria-invalid=true]{border-color:var(--th-err)!important;outline-color:var(--th-err);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-list,.mscb-histwrap,.mscb-setbox,.mscb-tpl,.mscb-chat,.mscb-guide,.mscb-prog,.mscb-log,.mscb-mini-log){\n  background:var(--glass-card);color:var(--th-fg);border-color:var(--glass-edge);border-radius:var(--glass-radius);box-shadow:none;\n}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-item,.mscb-resrow,.mscb-histrow,.mscb-errrow){border-color:var(--glass-edge);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-item,.mscb-histrow):hover{background:var(--glass-hover);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-user,.mscb-histhead,.mscb-cmphead,.mscb-tpl-t){background:var(--glass-tint);color:var(--th-fg);border-color:var(--glass-edge);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-user,.mscb-dash span,.mscb-tierchip,.mscb-selinfo,.mscb-pvtyp,.mscb-chip){border-radius:var(--glass-pill);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-dash span,.mscb-tierchip){background:var(--glass-tint)!important;color:var(--th-fg)!important;border-color:var(--glass-edge)!important;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-t1,.mscb-rest1,.mscb-histt,.mscb-pvbar,.mscb-pvtitle,.mscb-dialog h4){color:var(--th-fg);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-t2,.mscb-rest2,.mscb-histmeta,.mscb-histcount,.mscb-hint,.mscb-more,.mscb-stat,.mscb-ts,.mscb-mini-time){color:var(--th-muted);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-t1,.mscb-rest1,.mscb-histt,.mscb-histmeta,.mscb-line,.mscb-donetext){overflow-wrap:anywhere;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-log,.mscb-mini-log){font-family:inherit;font-size:12px;line-height:1.65;color:var(--th-muted);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-line:hover{background:var(--glass-tint);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-line.ok{color:var(--th-ok);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-line.warn{color:var(--th-warn);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-line.err,.mscb-line.complete){color:var(--th-err);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-line.complete{font-weight:800;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-line.info{color:var(--th-info);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-prog-bar,.mscb-resbar,.mscb-mini-prog){background:var(--th-barbg);border-radius:var(--glass-pill);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-prog-bar,.mscb-resbar,.mscb-mini-prog) i{background:linear-gradient(90deg,var(--glass-primary),var(--glass-primary-deep));border-radius:var(--glass-pill);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-pvcard,.mscb-cmpcell,.mscb-pvmiss,.mscb-cmpempty){background:var(--glass-card);color:var(--th-fg);border-radius:var(--glass-radius);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-pvcard img,.mscb-cmpcell img){background:var(--th-imgbg);border-radius:12px;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-cmpnote,.mscb-pvmiss){color:var(--th-muted);}\n/* Both ordinary descendants and the two body-mounted dynamic masks opt in. */\n.mscb-root.mscb-glass .mscb-mask,.mscb-glass-overlay.mscb-mask{background:rgba(27,32,41,.29);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-dialog{padding:20px;max-width:calc(100vw - 24px);max-height:calc(100dvh - 32px);overflow-y:auto;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-dialog h4{font-size:17px;line-height:1.4;font-weight:700;letter-spacing:-.015em;margin:0 0 12px;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-donemask,.mscb-errmask) h4{color:var(--th-err);font-weight:800;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-donetext{color:var(--th-fg);line-height:1.6;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-dialog-btns{gap:8px;flex-wrap:wrap;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-dialog-btns button{min-height:36px;}\n/* Also covers the current direct-child completion buttons before wrapper patch is merged. */\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-donemask .mscb-dialog>button{margin:8px 6px 0 0;min-height:36px;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-errlist{background:var(--th-errbg);color:var(--th-errfg);border-color:var(--th-errbd);border-radius:12px;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-mini{border-color:var(--glass-edge);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-mini-log{border-radius:0 0 var(--glass-radius) var(--glass-radius);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-bubble{background:var(--glass-solid);color:var(--th-fg);border-radius:var(--glass-radius);border-color:var(--glass-edge);box-shadow:0 8px 24px rgba(24,34,49,.16);}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) ::selection{background:#f5c5ae;color:#28231f;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-body,.mscb-list,.mscb-log,.mscb-chat,.mscb-mini-log){scrollbar-color:var(--glass-edge) transparent;}\n:is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-body,.mscb-list,.mscb-log,.mscb-chat)::-webkit-scrollbar-thumb{background:var(--glass-edge);border-radius:999px;}\n@media(max-width:640px){\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-panel{left:8px!important;right:8px!important;width:calc(100vw - 16px)!important;max-width:calc(100vw - 16px);max-height:calc(100dvh - 16px);bottom:max(8px,env(safe-area-inset-bottom))!important;zoom:1!important;transform:none!important;}\n  .mscb-root.mscb-glass .mscb-mask,.mscb-glass-overlay.mscb-mask{width:100vw;height:100dvh;left:0;top:0;right:auto;bottom:auto;}\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-head{padding:10px 12px;gap:8px;flex-wrap:wrap;}\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-head>span:last-of-type{max-width:100%;justify-content:flex-start;}\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-body{padding:12px;}\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) button{min-height:36px;}\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(input:not([type=checkbox]):not([type=radio]),select,textarea){font-size:16px;}\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-dialog-btns,.mscb-resbtns,.mscb-linkbtns,.mscb-histbtns){gap:8px;flex-wrap:wrap;}\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-dialog{padding:16px;}\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) .mscb-mini{max-width:calc(100vw - 24px);}\n}\n@supports not ((backdrop-filter:blur(1px)) or (-webkit-backdrop-filter:blur(1px))){\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-panel,.mscb-dialog,.mscb-mini,.mscb-thmenu){background:var(--glass-solid);}\n}\n@media(prefers-reduced-transparency:reduce){\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay){--glass-shell:var(--glass-solid);--glass-card:var(--glass-solid);--glass-input:var(--glass-solid);}\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-panel,.mscb-dialog,.mscb-mini,.mscb-thmenu){background:var(--glass-solid);-webkit-backdrop-filter:none;backdrop-filter:none;}\n}\n@media(prefers-reduced-motion:reduce){\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay),:is(.mscb-root.mscb-glass,.mscb-glass-overlay) *{transition:none!important;animation:none!important;scroll-behavior:auto!important;}\n}\n@media(forced-colors:active){\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) :is(.mscb-panel,.mscb-dialog,.mscb-mini,.mscb-thmenu){background:Canvas;color:CanvasText;box-shadow:none;-webkit-backdrop-filter:none;backdrop-filter:none;outline:1px solid CanvasText;}\n  :is(.mscb-root.mscb-glass,.mscb-glass-overlay) button{forced-color-adjust:auto;background:ButtonFace!important;color:ButtonText!important;border-color:ButtonText!important;}\n}\n",
      '.mscb-root.mscb-glass .mscb-head :is(.mscb-thbtn,.mscb-zoombtns button){display:inline-grid;place-items:center;box-sizing:border-box;width:34px;height:34px;min-width:34px;min-height:34px;padding:0;line-height:1;flex:none}',
      '@media(max-width:640px){.mscb-root.mscb-glass .mscb-head :is(.mscb-thbtn,.mscb-zoombtns button){width:36px;height:36px;min-width:36px;min-height:36px}}',
      '.mscb-root .mscb-head .mscb-thbtn{width:auto;min-width:48px;padding:0 6px;white-space:nowrap}.mscb-root.mscb-glass .mscb-head .mscb-thbtn{width:auto;min-width:48px;padding:0 6px}',
      '/* FIX: thbtn width:auto 必须压过上面 :is() 规则(4类1元素)，否则「主题」文字被挤成 34px 与「＋」粘连 */',
      '.mscb-root.mscb-glass .mscb-head .mscb-thbtn{width:auto!important;min-width:64px!important;height:34px!important;padding:0 10px!important;gap:4px}',
      '.mscb-root :is(.mscb-newapi,.mscb-rpatest){padding:5px 9px;border:1px solid var(--th-border);border-radius:9px;background:var(--th-card);color:var(--th-fg);cursor:pointer;white-space:nowrap}',
      // v3.7.26 头部紧凑化：按键收紧成一排，去掉大片空白
      '.mscb-root .mscb-head{padding:7px 10px!important;gap:6px!important}',
      '.mscb-root .mscb-head>span:last-of-type{gap:4px!important;flex-wrap:nowrap!important;overflow-x:auto}',
      '.mscb-root .mscb-head button{min-height:24px!important;height:24px;padding:0 8px!important;font-size:12px!important;white-space:nowrap;line-height:1}',
      '.mscb-root .mscb-head .mscb-zoombtns{gap:3px!important}',
      '.mscb-root .mscb-head .mscb-zoombtns button{min-height:22px!important;height:22px;width:20px!important;padding:0!important;font-size:11px!important}',
      '.mscb-root .mscb-head .mscb-mascot-sm{width:22px!important;height:22px!important;margin-right:5px!important}',
      // v3.7.26 模板设置大弹窗
      '.mscb-tpldlg{width:min(780px,94vw)!important;max-height:86vh!important;overflow-y:auto!important}',
      '.mscb-tpldlg .mscb-tpl{margin-bottom:0!important}',
      '.mscb-tpl-open{font-weight:700;width:100%;text-align:left}',
      // v3.7.26 按数量快捷选择下拉
      '.mscb-selmode{padding:4px 8px;border:1px solid #d8e0ea;border-radius:8px;font-size:12.5px;font-weight:700;color:#c81623;outline:none;cursor:pointer;background:#fff}',
      '.mscb-selmode:focus{border-color:#f5511e}',
      // v3.7.26 模板弹窗内的风格/模特下拉
      '.mscb-tpl-presetrow select{padding:4px 8px;border:1px solid #d8e0ea;border-radius:8px;font-size:12px;outline:none;cursor:pointer;background:#fff;color:#33475b}',
      '.mscb-tpl-presetrow select:focus{border-color:#f5511e}',
    ].join('');
    document.head.appendChild(style);

    // v3.7.0 主题清单（key / 名称 / 菜单色点）
    var MSCB_THEMES = [
      { k: 'auto',    n: '跟随系统', c: 'linear-gradient(135deg,#ffffff 50%,#161d28 50%)' },
      { k: 'classic', n: '经典橙红', c: '#f5511e' },
      { k: 'bw',      n: '黑白极简', c: '#171717' },
      { k: 'dark',    n: '暗夜黑',   c: 'linear-gradient(135deg,#161d28,#33425c)' },
      { k: 'ocean',   n: '海洋蓝',   c: '#1677ff' },
      { k: 'forest',  n: '森林绿',   c: '#16a34a' },
      { k: 'grape',   n: '葡萄紫',   c: '#7c3aed' }
    ];
    var themeMenuHtml = MSCB_THEMES.map(function (t) {
      return '<button data-th="' + t.k + '"><span class="mscb-thdot" style="background:' + t.c + '"></span>' + t.n + '</button>';
    }).join('');

    var root = document.createElement('div');
    root.className = 'mscb-root mscb-glass';
    // v3.7.82 防重复注入：插件重载/内容脚本二次注入时，旧 root 的弹窗按钮绑定全部失效（点取消没反应=弹窗卡死），
    // 注入前先移除页面上残留的旧面板，保证绑定永远落在当前这个节点上
    try { document.querySelectorAll('.mscb-root').forEach(function (r0) { r0.remove(); }); } catch (eRm) {}
    root.innerHTML = [
      // v3.2.7 悬浮区合并：三个模式方块 + 小橘猫 一个整体，可一起拖动到任意位置
      '<div class="mscb-float">',
      '<div class="mscb-dock">',
      '<button class="mscb-dockbtn" data-m="auto" title="选中商品后全程自动：采集→洗图→检查→RPA上传">⚡ 全自动</button>',
      '<button class="mscb-dockbtn" data-m="semi" title="每张图先人工确认再上传">🧩 半自动</button>',
      '<button class="mscb-dockbtn" data-m="single" title="一个链接洗一轮，适合试水">✨ 单个</button>',
      '</div>',
      // 右下角入口：小猫咪 AI 助手（真吉祥物图；点击打开面板；面板打开时自动隐藏）
      '<div class="mscb-ball" title="按住拖动=移动悬浮区；点一下=打开洗图猫面板"><img class="mscb-mascot" alt="洗图猫"><span class="mscb-badge"></span></div>',
      '</div>',
      '<div class="mscb-bubble" title="点我打开面板"></div>',
      '<div class="mscb-panel">',
      // v3.2.7 四角可调手柄：拖动角落任意调整面板大小（位置/大小都会记住）
      '<span class="mscb-grip tl" title="拖我调大小"></span><span class="mscb-grip tr" title="拖我调大小"></span><span class="mscb-grip bl" title="拖我调大小"></span><span class="mscb-grip br" title="拖我调大小"></span>',
      '<div class="mscb-head"><img class="mscb-mascot-sm" alt=""><span>洗图猫AI助手 <span style="opacity:.55;font-size:11px;font-weight:400">v' + (function () { try { return chrome.runtime.getManifest().version; } catch (e) { return '3.5.6'; } })() + '</span></span>',
      '<span style="display:flex;align-items:center;gap:6px"><span class="mscb-thwrap"><button class="mscb-thbtn" title="换主题：黑白 / 暗夜 / 海蓝 / 森绿 / 葡萄紫 / 跟随系统">🎨 主题</button><span class="mscb-thmenu">' + themeMenuHtml + '</span></span><span class="mscb-zoombtns"><button class="mscb-zoomin" title="放大面板（最大 2 倍）">＋</button><button class="mscb-zoomout" title="缩小面板">－</button><button class="mscb-zfull" title="小窗 / 全屏切换">⛶</button></span><button class="mscb-headpause" type="button" title="暂停本单派新图和后续导入；已发出的请求会自然结束" disabled>⏸ 一键暂停</button><button class="mscb-rpatest" type="button" title="上传原版测试 1–5 到妙手图片空间并校验 5 条导入表，不创建或发布商品">🔌 接口测试</button><button class="mscb-editpg" title="单商品编辑页洗图+改标题（先在采集箱点「编辑」打开一个商品）" style="background:none;border:1px solid rgba(255,255,255,.35);border-radius:6px;color:#fff;font-size:12px;padding:2px 6px;cursor:pointer">📝 编辑页</button><button class="mscb-refresh" title="重置当前任务、重新开始一个新单（已生成的图和已建链接保留在洗图台）" style="background:none;border:1px solid rgba(255,255,255,.35);border-radius:6px;color:#fff;font-size:12px;padding:2px 6px;cursor:pointer">🔄 新任务</button><span class="mscb-x">×</span></span></div>',
      '<div class="mscb-body">',

      // 个人信息条：会员级别 + 生图额度
      '<div class="mscb-user">',
      '<span class="mscb-tierchip">🧪 安装预览</span><button class="mscb-newapi" type="button" title="打开接口设置">🔑 连接 New API</button><button class="mscb-envcheck" type="button" title="无费用检查两路模型是否可见">🩺 环境检测</button>',
      '<span class="mscb-quota">🎨 生图额度：<b class="mscb-quota-n">以 New API 账户为准</b></span>',
      '</div>',

      // v3.2.9 AI 问答视图：点小猫球打开——只有问答和操作指引，没有工作台
      '<div class="mscb-ai">',
      '<div class="mscb-guide"><h5>📋 操作步骤（照着 1234 走）<button class="mscb-tourbtn" title="从头再看一遍使用引导">📖 引导</button></h5><ol>',
      '<li><b>确定模板</b>：工作台最上方「🧩 模板设置」勾改什么、填固定值，可存预设/按类目自动套</li>',
      '<li><b>选链接</b>：列表勾选商品，配合搜索、类目筛选和「只选筛选结果」</li>',
      '<li><b>选模式</b>：⚡全自动（洗图→自动建链接）/ 🧩半自动（导出表格人工洗）/ ✨单个（编辑页精修）</li>',
      '<li><b>启动</b>：▶启动开跑；⏸暂停随时停；🔄补采集重读列表；🔄续跑接回上次任务（四个按钮并排）</li>',
      '<li><b>导出表格</b>：半自动专属，48 列 CSV 去洗图猫网站上传洗图</li>',
      '<li><b>看日志</b>：每张图的秒级时间/链接/张数/耗时/状态一目了然</li>',
      '</ol></div>',
      '<div class="mscb-chat"></div>',
      '<div class="mscb-chips">',
      '<button class="mscb-chip" data-q="怎么用？">怎么用？</button>',
      '<button class="mscb-chip" data-q="全自动怎么跑？">全自动怎么跑？</button>',
      '<button class="mscb-chip" data-q="半自动怎么跑？">半自动怎么跑？</button>',
      '<button class="mscb-chip" data-q="单个怎么跑？">单个怎么跑？</button>',
      '<button class="mscb-chip" data-q="出图要多长时间？">出图要多长时间？</button>',
      '<button class="mscb-chip" data-q="生图额度怎么算？">额度怎么算？</button>',
      '</div>',
      '<div class="mscb-airow"><input class="mscb-aiin" placeholder="问小猫咪：怎么洗图 / 额度 / 模板…"><button class="mscb-aisend">发送</button></div>',
      '</div>',

      // v3.2.9 工作台视图：点模式方块打开，只显示该模式的内容；按操作顺序从上往下
      '<div class="mscb-work show">',
      // v3.4.8 双栏：左栏=模板/选品/操作，右栏=看板/进度/结果/日志（窄面板自动退回上下排）
      '<div class="mscb-wl">',

      // ① 确定模板：先定改什么、固定值（客户第一件事）
      // v3.7.26 模板设置改为弹出大窗：工作区只留入口按钮，设置内容挂在根级 tplmask 弹窗里
      '<div class="mscb-batchtpl"><button type="button" class="mscb-tpl-open" title="弹出大窗口：勾改什么、填固定值、选生图模式（复刻/POD）、管理预设">🧩 模板设置（点开大窗设置）</button></div>',

      // ② 选择链接：搜索/筛选 + 勾选（v3.4.1 加「按数量」：从上往下自动勾前 N 个）
      '<div class="mscb-batchtpl"><button type="button" class="mscb-newdraft">＋ 自建商品草稿</button></div>',
      '<div class="mscb-stat">正在自动采集当前页…</div>',
      // v2.7.0 类目筛选 + 搜索（采集完按类目一键筛，配合批量套模板）
      '<div class="mscb-filter"><input class="mscb-search" placeholder="搜标题 / ID"><select class="mscb-cat"></select><button class="mscb-catonly" title="把当前筛选出来的商品保留勾选，其余取消勾选（配合批量套模板很好用）">只选筛选结果</button></div>',
      '<div class="mscb-selbar"><label><input type="checkbox" class="mscb-all" checked> 全选</label><button class="mscb-inv" title="把当前勾选状态反过来">反选</button><button class="mscb-align" title="把面板列表重排成和页面当前列表一样的顺序（按标题匹配页面行；面板里不在当前页的商品挪到末尾）。页面改过筛选/排序后点一下，列表就能和页面从上往下一一对应">↕ 按页面对齐</button><select class="mscb-selmode" title="快速选择要跑的商品：从列表第一个开始自动勾选。选「自定义」可填任意数量"><option value="all">全选本页</option><option value="5">前 5 个</option><option value="10">前 10 个</option><option value="20">前 20 个</option><option value="50">前 50 个</option><option value="100">前 100 个</option><option value="custom">自定义数量…</option></select><input type="number" class="mscb-count" min="1" value="10" title="自定义数量：从列表第一个开始自动勾选前 N 个" style="display:none"><span class="mscb-selinfo">未采集</span></div>',
      '<div class="mscb-list"></div>',

      // v3.4.1 面板内的三模式大按钮行已删除（右下角悬浮区三个方块就是唯一模式入口，别再重复）

      // ③ 启动 / 暂停 / 续跑 / 补采集 并排（v3.4.1 四个按钮统一尺寸/圆角/字重，启动为主按钮）
      '<div class="mscb-acts" style="margin-top:2px">',
      '<button class="mscb-start">▶ 启动全自动</button>',
      '<button class="mscb-pause" disabled>⏸ 暂停</button>',
      '<button class="mscb-resume" title="页面刷新/浏览器重开后，从服务器接回上次任务：洗图继续盯进度，已完成则恢复预览/重跑/建链接">🔄 续跑</button>',
      '<button class="mscb-refetch" title="重新读取采集箱列表并补齐详情（不会启动任何流程）">🔄 补采集</button>',
      '</div>',

      // v3.5.2 一键导出：不看勾选/不分批，把当前已抓取的全部商品（含全字段）一次导出
      '<button class="mscb-export mscb-expall" title="导出的是「原表格」：当前已抓取的全部商品原始数据（标题/图片/属性原样导出，未做任何修改、未洗图），一次导成 48 列 CSV，不看勾选、不分批">📤 一键导出已抓取数据（原始未修改 · 全部字段）</button>',

      // 检查模式：洗完先预览再建链接（鼠标移到 ? 上有说明）
      '<div class="mscb-checkrow"><input type="checkbox" class="mscb-check" checked>',
      '<span>🔍 检查模式（洗完先预览再建链接）</span>',
      '<span class="q" title="开启后：全自动洗完图不马上建链接，先在下方预览每个链接的成品图；满意就点「一键上传并跑RPA」，不满意的单个链接可「重跑」，还可以填「修改建议」后再重跑。关闭则洗完自动建链接，全程无人值守。">?</span></div>',

      // v3.5.8 导入方式：直连优先（快）/ RPA 优先（真实人工流程）
      '<div class="mscb-checkrow"><input type="checkbox" class="mscb-apifirst" checked>',
      '<span>⚡ 直连导入优先（2~5秒，失败自动改走 RPA 点按钮）</span>',
      '<span class="q" title="勾选：直接调妙手导入接口提交表格，2~5 秒完成，不会碰页面按钮，任何浏览器都能跑；万一接口报错自动回退 RPA。取消勾选：走 RPA（在页面上真实点「导入→导入创建产品→导出妙手产品再导入」，和手点一模一样，看得见，但慢且依赖浏览器点击通道）。">?</span></div>',

      // v3.6.0 TTS 语音提示：开始采集/采集完成/开始洗图/洗图完成/开始上传/上传完成
      '<div class="mscb-checkrow"><input type="checkbox" class="mscb-tts" checked>',
      '<span>🔊 语音提示（采集/洗图/上传 开始与完成播报）</span><button class="mscb-tts-test" type="button">语音试播</button>',
      '<span class="q" title="勾选后六个关键节点会用中文女声语音播报：开始采集 → 采集完成 → 开始洗图 → 洗图完成 → 开始自动化上传 → 上传完成。用浏览器自带语音，不花钱不联网。取消勾选即静音。">?</span></div>',

      // v3.4.3 RPA 单独测试：内置 5 品测试表，一键走完 RPA 全链路（不洗图不扣费）

      // ⑤ 导出表格（半自动专属）——v3.6.0 注明：这是页面抓取的原始数据，未经任何修改
      '<div class="mscb-semi" style="display:none;margin-top:8px">',
      '<button class="mscb-export" title="导出的是「原表格」：从当前页面采集箱抓取的原始数据（标题/图片/属性原样导出，未做任何修改、未洗图）。拿到洗图台网站上传后才开始洗图；洗完的成品表格由洗图台另外生成。">📤 导出原表格（48列 · 页面抓取数据，未修改）</button>',
      '</div>',

      '</div>',

      // ===== 右栏：看板 / 进度 / 结果 / 日志 =====
      '<div class="mscb-wr">',
      // v2.8.0 经营小看板：今日单量/出图/扣费/均耗时/差评率
      '<div class="mscb-dash"></div>',

      // v3.7.33 断点续跑横幅：上次任务没跑完时在顶部提示「继续」，已出的图不重出
      '<div class="mscb-jobbar" style="display:none"></div>',
      '<div class="mscb-prog"><div class="mscb-prog-text">待命：进采集箱自动备好数据，按「启动」才开始</div><div class="mscb-prog-bar"><i></i></div></div>',
      '<div class="mscb-prog-time"></div>',
      '<div class="mscb-res"></div>',
      '<div class="mscb-resbtns">',
      '<button style="display:none" class="mscb-rprev">🖼️ 全部预览</button>',
      '<button style="display:none" class="mscb-rcsv" title="下载洗图台已转换的 48 列导入表（图链已是洗好的图），导入前可先打开核对">📤 导出已转换表格</button>',
      '<button style="display:none" class="mscb-lcsv" title="本机直连模式专用：把本单已生成的 48 列导入表（图链已换成本机洗好的图）下载到本地，可直接拖进妙手「导入」手动导入——直连导入失败时的兑底">📤 导出导入表（手动导入兑底）</button>',
      '<button class="mscb-rrpa" disabled title="生成完成后可上传并导入">🚀 一键上传并导入</button>',
      '<button style="display:none" class="mscb-rr2 mscb-rrepair" title="把生成失败/缺图的产品自动补一轮（只补缺失的，不重复计费）">🩹 补失败图</button>',
      '<button style="display:none" class="mscb-rr2 mscb-rrfail" title="补图后仍失败的链接逐个重跑（带各自的修改建议）">🔁 全部重跑失败项</button>',
      '</div>',
      // v3.6.3 历史单 / v3.7.37 固定显示：框常驻（无记录时显示占位提示），点击展开列表
      '<div class="mscb-histwrap">',
      '<div class="mscb-histhead"><span class="mscb-histname">🕘 历史任务</span><span class="mscb-histcount">暂无</span></div>',
      '<div class="mscb-histlist"><div class="mscb-histmeta" style="padding:8px 12px;color:#98a2b3">暂无历史任务 · 本机跑完一单后会自动记录在这里（可预览/续跑）</div></div>',
      '</div>',
      '<div class="mscb-links"></div>',
      '<div class="mscb-linkbtns" style="display:none">',
      '<button class="mscb-lcopy">📋 复制全部链接</button>',
      '<button class="mscb-lexp">📄 导出链接清单（留底）</button>',
      '</div>',
      '<div class="mscb-logbar"><span style="font-weight:600">运行日志</span><span><button type="button" class="mscb-updbtn" title="检查新版本：有更新会自动下载到「下载/洗图猫/」文件夹">🔄 更新</button><button type="button" class="mscb-helpbtn" title="打开图文帮助教程">❓ 帮助</button><button type="button" class="mscb-skip" style="display:none" title="某个链接/批次卡住不想等：立即放行当前等待，没返回的图按跳过处理，流程继续往下走（稍后可补图）">⏭ 跳过等待</button><button type="button" class="mscb-logdl" title="把面板全部运行日志（含时间戳，最近 1200 条）存成 txt 发给技术支持">📋 导出日志</button></span></div>',
      '<div class="mscb-log" role="log" aria-live="polite" aria-relevant="additions"></div>',
      '</div>',
      '</div>',
      '</div></div>',

      // v3.4.0 成品图灯箱（点预览图放大：滚轮缩放/拖动/双击还原）
      '<div class="mscb-mask mscb-zoommask"><span class="mscb-zoomcap"></span><span class="mscb-zoomp" title="上一张（←）">‹</span><span class="mscb-zoomn" title="下一张（→）">›</span><img class="mscb-zoomimg" alt=""><span class="mscb-zoomx">×</span><span class="mscb-zoomtip">← → 切换 · 滚轮缩放 · 按住拖动 · 双击还原 · Esc 关闭</span></div>',
      // v3.4.0 新手引导蒙层（首次安装弹出，可重看）
      '<div class="mscb-mask mscb-tourmask"><div class="mscb-dialog"><h4>🐱 洗图猫使用引导</h4>',
      '<div class="mscb-tourstep"></div>',
      '<div class="mscb-tourdots"></div>',
      '<div class="mscb-tourbtns"><button class="mscb-tourskip">跳过</button><button class="mscb-tournext mscb-dlg-ok">下一步</button></div>',
      '</div></div>',

      // v2.6.0 弹窗：暂停三选 / 成品图预览 / 修改建议
      '<div class="mscb-mask mscb-pausemask"><div class="mscb-dialog"><h4>⏸ 已暂停</h4>',
      '<p class="mscb-hint" style="margin:0 0 10px">流程已停在下一步边界（服务器洗图继续进行）。接下来想做什么？</p>',
      '<p class="mscb-pd-bill mscb-hint" style="margin:0 0 10px;padding:8px 10px;background:#fff7e6;border:1px solid #ffd591;border-radius:8px;color:#874d00;font-size:12px"></p>',
      '<div class="mscb-dialog-btns" style="flex-direction:column">',
      '<button class="mscb-pd-exp">📤 立即导出表格（48列）</button>',
      '<button class="mscb-pd-studio">🖥️ 打开洗图工作台</button>',
      '<button class="mscb-pd-go mscb-dlg-ok">▶ 继续自动跑完</button>',
      '</div></div></div>',
      '<div class="mscb-mask mscb-pvmask"><div class="mscb-dialog" style="width:min(1100px,96vw)">',
      '<h4 class="mscb-pv-h">🖼️ 成品图预览</h4>',
      '<p class="mscb-pvtitle"></p>',
      '<div class="mscb-pvgrid"></div>',
      '<div class="mscb-dialog-btns"><button class="mscb-pv-reload" title="把没显示出来的图重新拉一遍（会自动换地址绕开浏览器缓存的失败结果）">🔄 重新加载未显示的图</button><button class="mscb-pv-x">关闭</button></div>',
      '</div></div>',
      // v3.6.0 原图 vs 洗后 对比弹窗（v3.7.2 改整单对比：左列全部原图，右列全部洗后，按张数对齐，滚动查看）
      '<div class="mscb-mask mscb-cmpmask"><div class="mscb-dialog" style="width:min(1150px,96vw)">',
      '<h4 class="mscb-cmp-h">🆚 ORIGINAL <b>VS</b> AFTER · 整单对比</h4>',
      '<p class="mscb-cmp-bt"></p>',
      '<div class="mscb-cmpscroll"><div class="mscb-cmphead"><span>ORIGINAL · 采集原图（未修改）</span><span>AFTER · 洗后成品图（点图放大）</span></div><div class="mscb-cmprows"></div></div>',
      '<div class="mscb-dialog-btns"><button class="mscb-cmp-x">关闭</button></div>',
      '</div></div>',
      // v3.6.0 错误提醒弹窗：红色错误集中在这里，不自动消失，手动关闭（任务继续跑）
      '<div class="mscb-mask mscb-donemask" role="dialog" aria-modal="true" aria-labelledby="mscb-done-title"><div class="mscb-dialog" style="width:min(500px,92vw)">',
      '<h4 id="mscb-done-title">上传完成，请刷新页面</h4><p class="mscb-donetext" role="status"></p>',
      '<div class="mscb-dialog-btns"><button class="mscb-done-refresh mscb-dlg-ok">刷新页面查看链接</button><button class="mscb-done-close">稍后刷新</button></div></div></div>',
      '<div class="mscb-mask mscb-errmask"><div class="mscb-dialog mscb-errdlg" style="width:min(560px,92vw)">',
      '<h4>🚨 出错提醒（不会自动关闭，处理完点「知道了」）</h4>',
      '<div class="mscb-errlist"></div>',
      '<div class="mscb-dialog-btns"><button class="mscb-err-copy">📋 复制全部错误</button><button class="mscb-err-x mscb-dlg-ok">知道了</button></div>',
      '</div></div>',
      // v3.7.26 模板设置大弹窗（根级挂载，点工作区「🧩 模板设置」打开；含 v3.7.26 生图模式单选）
      '<div class="mscb-mask mscb-tplmask"><div class="mscb-dialog mscb-tpldlg"><h4>🧩 模板设置</h4>',
      '<div class="mscb-tpl open">',
      '<div class="mscb-tpl-b" style="display:block">',
      '<div class="mscb-tpl-chks">',
      '<label><input type="checkbox" class="mscb-tpl-ck" data-k="img" checked> 改图</label>',
      '<label><input type="checkbox" class="mscb-tpl-ck" data-k="zh" checked> 中文标题</label>',
      '<label><input type="checkbox" class="mscb-tpl-ck" data-k="en"> 英文标题</label>',
      '<label><input type="checkbox" class="mscb-tpl-ck" data-k="attrs" checked> 其他参数（材质等）</label>',
      '</div>',
      '<div class="mscb-tpl-fixed"></div>',
      '<p class="mscb-hint">勾选 = 这一步要做；下面填了固定值的字段会一直用你填的值（自动记住，下次打开还在）。</p>',
      '<div class="mscb-tpl-presetrow"><span style="font-size:12px;color:#55677a;white-space:nowrap">生图模式</span><label style="display:flex;align-items:center;gap:4px;font-size:12.5px;color:#33475b;cursor:pointer"><input type="radio" name="mscb-imgmode" class="mscb-imgmode" value="keep"> 原样复刻</label><label style="display:flex;align-items:center;gap:4px;font-size:12.5px;color:#33475b;cursor:pointer"><input type="radio" name="mscb-imgmode" class="mscb-imgmode" value="pod"> POD改造</label><span class="mscb-hint" style="flex:1;margin:0">复刻=保持商品原样白底精修出图；POD=允许 AI 改图案/配色/造型/场景，把采集品改造成新品</span></div>',
      '<div class="mscb-tpl-podrow" style="display:none;align-items:center;gap:8px;margin:6px 0 0 0"><span style="font-size:12px;color:#55677a;white-space:nowrap">改造幅度</span><select class="mscb-podlv" style="padding:4px 8px;border:1px solid #d6dde8;border-radius:8px;font-size:12.5px;color:#33475b"><option value="light">轻改造（商品原样，只换背景/场景/拍摄方式）</option><option value="mid">标准改造（可换配色/装饰/场景，图案主体保留）</option><option value="strong">强改造（图案主题可重新设计，和原图明显不同）</option></select><span class="mscb-hint" style="flex:1;margin:0">选 POD 后生效；嫌和原图太像就选「强改造」</span></div>',
      '<div class="mscb-tpl-presetrow"><span style="font-size:12px;color:#55677a;white-space:nowrap">画面风格</span><select class="mscb-tplstyle" title="整体画面调性，套用到本单全部出图；留空=AI 按商品自动"></select><span class="mscb-hint" style="flex:1;margin:0">12 种常用风格可选；留空=AI 按商品自动搭配</span></div>',
      '<div class="mscb-tpl-presetrow"><span style="font-size:12px;color:#55677a;white-space:nowrap">模特设置</span><select class="mscb-model-race" title="模特图分镜的模特人种；留空=AI 自定"></select><select class="mscb-model-face" title="模特是否露脸：部分类目 AI 容易面部失真，可选不露脸规避"></select><select class="mscb-model-shot" title="模特景别：全身/半身/特写"></select><span class="mscb-hint" style="flex:1;margin:0">只作用于「模特图」分镜；全部留空=AI 自定</span></div>',
      '<div class="mscb-tpl-presetrow"><input class="mscb-preset-name" placeholder="预设名，如：圣诞木质 / 3C数码 / 母婴"><button class="mscb-preset-save">💾 存为预设</button><button class="mscb-tpl-preview" title="把全局规则+类目补充+固定值+修改建议拼成最终提示词，启动前先看一眼">👁 预览最终提示词</button></div>',
      '<div class="mscb-tpl-presetrow"><input class="mscb-preset-cats" placeholder="绑定类目关键词（如：家居收纳,置物架）"><input class="mscb-preset-prompt" placeholder="提示词补充，如：桌面收纳场景、柔和自然光"></div>',
      '<div class="mscb-tpl-presetrow"><span style="font-size:12px;color:#55677a;white-space:nowrap">每品出图</span><button type="button" class="mscb-imgn-chip" data-n="5">5张·省费</button><button type="button" class="mscb-imgn-chip" data-n="8">8张</button><button type="button" class="mscb-imgn-chip" data-n="10">10张·全套</button><input type="number" class="mscb-imgn" min="1" max="10" value="10" title="每个商品生成的成品图数量：1=仅卖点主图；10=原版全套（1张卖点主图+9张分镜）；可直接填 1-10 任意数"><span class="mscb-hint" style="flex:1;margin:0">张（出图数越少越省生图费；1=仅主图，10=主图+9分镜全套）</span></div>',
      '<div class="mscb-tpl-presetrow"><span style="font-size:12px;color:#55677a;white-space:nowrap">图源模式</span><select class="mscb-imgsrc" style="padding:3px 6px;border:1px solid #d3dde8;border-radius:6px;font-size:12.5px"><option value="auto">自动（图链优先，省空间）</option><option value="url">要图链 URL（外链直写）</option><option value="space">要图片（上传妙手图片空间）</option></select><span style="font-size:12px;color:#55677a;white-space:nowrap;margin-left:8px">体积</span><select class="mscb-imgsize" style="padding:3px 6px;border:1px solid #d3dde8;border-radius:6px;font-size:12.5px"><option value="original">原样不压</option><option value="auto">标准 ≤500KB</option><option value="small">小体积 ≤300KB</option><option value="tiny">超小 ≤150KB（缩边1200px）</option></select></div>',
      '<div class="mscb-tpl-presetrow"><span style="font-size:12px;color:#55677a;white-space:nowrap">单品裂变</span><input type="number" class="mscb-fiss" min="1" max="10" value="1" title="每个商品裂变出几条新链接：1=不裂变；3=AI 按不同风格/场景/人群方向生成 3 条差异化新链接"><span class="mscb-hint" style="flex:1;margin:0">份（1=不裂变；≥2 时建议把每品出图调到 1~3 张控制费用）</span></div>',
      '<div class="mscb-tpl-autorow"><label><input type="checkbox" class="mscb-autotpl" checked> 按类目自动套模板（新采集的商品自动匹配绑定类目的预设）</label></div>',
      '<div class="mscb-presets"></div>',
      '<div class="mscb-batchtpl"><span>批量套给所选商品：</span><select class="mscb-batchsel"></select><button class="mscb-batchok">套用</button></div>',
      '<p class="mscb-hint">一页里有不同类目？先在列表每行下拉里给单个商品选模板，或勾选后用上面「批量套用」。建单时按模板自动分组。</p>',
      '<div class="mscb-batchtpl"><button type="button" class="mscb-aimatch" title="AI 根据每个商品的标题和类目，从你的模板预设中逐个选最合适的；没有可用预设时 AI 会按类目自动建一套模板并分配">🤖 AI 自动匹配模板</button><span style="flex:1;font-size:11.5px;color:#55677a">勾选商品后点这里，AI 按类目/平台逐个配模板（国内/跨境都适用）</span></div>',
      '<div class="mscb-batchtpl"><button type="button" class="mscb-remembercat" title="只勾一个已分配店铺的商品；使用该商品目前的类目模板，不影响其他店铺">记住本店此类模板</button></div>',
      '</div>',
      '</div>',
      '<div class="mscb-dialog-btns"><button class="mscb-tpldlg-x">完成，关闭</button></div>',
      '</div></div>',
      // v3.7.84 「修改建议」弹窗已彻底移除（用户拍板：容易误点且没人用）；noteByPid 数据层保留供提示词预览引用
      // v3.4.4 迷你运行条：点测试/启动后大面板自动收起，左下角只留这个小条（不挡页面任何按钮）
      '<div class="mscb-mini">',
      '<div class="mscb-mini-head"><span class="mscb-mini-dot"></span><span class="mscb-mini-title">任务运行中…</span>',
      '<button class="mscb-mini-pause">⏸ 暂停</button></div>',
      '<div class="mscb-mini-prog"><i></i></div>',
      '<div class="mscb-mini-time">已用 0秒</div>',
      '<div class="mscb-mini-log"></div>',
      '</div>'
    ].join('');
    document.body.appendChild(root);

    statEl = root.querySelector('.mscb-stat');
    listEl = root.querySelector('.mscb-list');
    var panel = root.querySelector('.mscb-panel');
    var iAll = root.querySelector('.mscb-all');
    progEl = root.querySelector('.mscb-prog');
    linksEl = root.querySelector('.mscb-links');
    // 老流程按钮已移除，置空避免误触发（oneClick 里都有 if 保护）
    oneBtn = null;
    autoBtn = null;
    startBtn = root.querySelector('.mscb-start');
    pauseBtn = root.querySelector('.mscb-pause');
    semiExtraRow = root.querySelector('.mscb-semi');
    // v2.6.0：结果区 / 时间行 / 大按钮组
    resEl = root.querySelector('.mscb-res');
    timeEl = root.querySelector('.mscb-prog-time');
    resBtnsEl = root.querySelector('.mscb-resbtns');

    // v3.2.0 吉祥物真图：球 + 面板标题的小猫头（mascot.png 经 web_accessible_resources 暴露）
    try {
      var mu = chrome.runtime.getURL ? chrome.runtime.getURL('mascot.png') : '';
      if (mu) root.querySelectorAll('.mscb-mascot, .mscb-mascot-sm').forEach(function (im) { im.src = mu; });
    } catch (eM) {}

    // 悬浮球：展开/收起面板；×：收起
    var ball = root.querySelector('.mscb-ball');
    // v3.2.7 悬浮区（三个模式方块 + 小橘猫）整体拖动：按住任意一个拖即可，位置记忆；拖完不触发点击
    var justDragged = false;
    var floatEl = root.querySelector('.mscb-float');
    function restoreFloatPos() {
      if (cfg.fx != null && cfg.fy != null && floatEl) {
        floatEl.style.right = 'auto'; floatEl.style.bottom = 'auto';
        floatEl.style.left = cfg.fx + 'px'; floatEl.style.top = cfg.fy + 'px';
      }
    }
    restoreFloatPos();
    function makeFloatDraggable(el) {
      el.addEventListener('mousedown', function (ev) {
        if (ev.button !== 0 || ev.target.classList && ev.target.classList.contains('mscb-dockbtn')) return;   // 方块本身留给点击
        var fr = floatEl.getBoundingClientRect();
        var sx = ev.clientX, sy = ev.clientY, moved = false;
        function mm(e) {
          if (!moved && Math.abs(e.clientX - sx) + Math.abs(e.clientY - sy) < 6) return;
          moved = true;
          var nx = Math.max(4, Math.min(window.innerWidth - 60, fr.left + e.clientX - sx));
          var ny = Math.max(4, Math.min(window.innerHeight - 60, fr.top + e.clientY - sy));
          floatEl.style.right = 'auto'; floatEl.style.bottom = 'auto';
          floatEl.style.left = nx + 'px'; floatEl.style.top = ny + 'px';
        }
        function mu() {
          document.removeEventListener('mousemove', mm); document.removeEventListener('mouseup', mu);
          if (moved) {
            justDragged = true; setTimeout(function () { justDragged = false; }, 300);
            var r = floatEl.getBoundingClientRect();
            cfg.fx = Math.round(r.left); cfg.fy = Math.round(r.top); saveCfg();
            log('🖱 悬浮区已移动：小猫咪和三个模式方块以后就待在这里');
          }
        }
        document.addEventListener('mousemove', mm); document.addEventListener('mouseup', mu);
        ev.preventDefault();
      });
    }
    makeFloatDraggable(floatEl);
    makeFloatDraggable(ball);
    ball.onclick = function () {
      if (justDragged) return;   // 拖动结束的那一下不当作点击
      var opening = !panel.classList.contains('open');
      if (opening) { setView('ai'); render(); }   // v3.2.9 点小猫球 = AI 问答视图（不是工作台）
      panel.classList.toggle('open');
    };
    // v3.2.7 面板本体：标题栏拖动换位置 + 四角手柄调大小（位置/大小记忆）
    var headEl = root.querySelector('.mscb-head');
    function restorePanelPos() {
      if (cfg.px != null && cfg.py != null && !cfg.full) {
        panel.style.right = 'auto'; panel.style.bottom = 'auto';
        panel.style.left = cfg.px + 'px'; panel.style.top = cfg.py + 'px';
      }
      if (cfg.pw > 0 && cfg.ph > 0 && !cfg.full) {
        // v3.4.8 旧版本默认 420px 窄面板（约 29%），升级后第一次打开自动放宽到新版默认，
        // 让横向双栏立刻生效；之后手动拖动/缩放仍照常记住
        if (cfg.pw < 40) { try { delete cfg.pw; delete cfg.ph; saveCfg(); } catch (e) {} }
        else { panel.style.width = cfg.pw + 'vw'; panel.style.maxHeight = cfg.ph + 'vh'; }
      }
    }
    restorePanelPos();
    // 指针捕获让标题栏跨过列表仍连续跟随；按实际可见位置计算，不把缩放偏移写进位置。
    if (headEl) {
      var headDrag = null;
      headEl.style.cursor = 'grab'; headEl.style.touchAction = 'none';
      function positionPanel(x, y) {
        var r = panel.getBoundingClientRect();
        if (cfg.full || innerWidth <= 640 || !r.width) return;
        var nx = Math.max(0, Math.min(innerWidth - r.width, x));
        var ny = Math.max(0, Math.min(Math.max(0, innerHeight - r.height), y));
        if (Math.abs(nx - r.left) < 0.5 && Math.abs(ny - r.top) < 0.5) return;
        if (panel.style.right !== 'auto' || panel.style.bottom !== 'auto' || !panel.style.left || !panel.style.top) {
          panel.style.right = 'auto'; panel.style.bottom = 'auto';
          panel.style.left = '0px'; panel.style.top = '0px';
          r = panel.getBoundingClientRect();
        }
        panel.style.left = (parseFloat(panel.style.left) + nx - r.left) + 'px';
        panel.style.top = (parseFloat(panel.style.top) + ny - r.top) + 'px';
      }
      function keepPanelOnScreen() {
        var r = panel.getBoundingClientRect();
        positionPanel(r.left, r.top);
      }
      new ResizeObserver(keepPanelOnScreen).observe(panel);
      window.addEventListener('resize', keepPanelOnScreen);
      headEl.addEventListener('pointerdown', function (ev) {
        if (cfg.full || innerWidth <= 640 || ev.button !== 0 || ev.target.closest('button,a,input,.mscb-x,.mscb-thmenu')) return;
        var r = panel.getBoundingClientRect();
        headDrag = { id: ev.pointerId, x: ev.clientX, y: ev.clientY, left: r.left, top: r.top };
        headEl.setPointerCapture(ev.pointerId);
        headEl.style.cursor = 'grabbing';
        ev.preventDefault(); ev.stopPropagation();
      });
      headEl.addEventListener('pointermove', function (ev) {
        var d = headDrag;
        if (!d || d.id !== ev.pointerId) return;
        if (!(ev.buttons & 1) && ev.pointerType === 'mouse') { finishHeadDrag(ev); return; }
        positionPanel(d.left + ev.clientX - d.x, d.top + ev.clientY - d.y);
        d.moved = true;
      });
      function finishHeadDrag(ev) {
        if (!headDrag || headDrag.id !== ev.pointerId) return;
        if (headDrag.moved) {
          cfg.px = parseFloat(panel.style.left); cfg.py = parseFloat(panel.style.top); saveCfg();
        }
        headDrag = null; headEl.style.cursor = 'grab';
      }
      ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(function (name) { headEl.addEventListener(name, finishHeadDrag); });
    }
    root.querySelectorAll('.mscb-grip').forEach(function (g) {
      g.addEventListener('mousedown', function (ev) {
        ev.stopPropagation(); ev.preventDefault();
        if (ev.button !== 0) return;
        var toLeft = /tl|bl/.test(g.className);
        var toTop = /tl|tr/.test(g.className);
        var r = panel.getBoundingClientRect();
        var sx = ev.clientX, sy = ev.clientY, sw = r.width, sh = r.height;
        function mm(e) {
          var w = Math.max(360, Math.min(window.innerWidth - 24, toLeft ? sw + (sx - e.clientX) : sw + (e.clientX - sx)));
          var h = Math.max(320, Math.min(window.innerHeight - 24, toTop ? sh + (sy - e.clientY) : sh + (e.clientY - sy)));
          panel.style.width = w + 'px'; panel.style.maxHeight = h + 'px';
          cfg.pw = Math.round(w / window.innerWidth * 100);
          cfg.ph = Math.round(h / window.innerHeight * 100);
        }
        function mu() {
          document.removeEventListener('mousemove', mm); document.removeEventListener('mouseup', mu);
          saveCfg(); log('📐 面板大小已调整并记住（也可用右上角 ＋/－/⛶）');
        }
        document.addEventListener('mousemove', mm); document.addEventListener('mouseup', mu);
      });
    });
    root.querySelector('.mscb-x').onclick = function () { panel.classList.remove('open'); };
    // v3.5.0 一键刷新：清空当前任务（服务器 + 面板），回到「勾商品 → 启动」的初始状态，开始一个新单
    root.querySelector('.mscb-refresh').onclick = async function () {
      if (!window.confirm('确定重置并开始一个新任务吗？\n\n· 当前这单的进度/结果区会被清空\n· 已生成的图片文件和已建的链接保留在洗图台，不会丢')) return;
      document.querySelectorAll('.mscb-log,.mscb-mini-log').forEach(function (box) { box.textContent = ''; box.scrollTop = 0; });
      logBuf.length = 0;   // v3.7.63 清日志同时清导出缓冲
      var btn = this; btn.disabled = true; btn.textContent = '🔄 重置中…';
      try {
        var base = washBaseOf(), code = String(cfg.code || '').trim();
        if (base && code) {
          var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code);
          await relay(base + '/api/reset?' + auth, {});
        }
      } catch (e) { log('⚠️ 服务器重置失败（' + (e && e.message || e) + '），仅清空本地面板'); }
      busy = false; paused = false; rerunning = false; repairBusy = false;
      wash.on = false; wash.done = false; wash.rpa = false; wash.serverActive = false; wash.batchAt = 0;
      wash.state = {}; wash.products = []; wash.links = []; wash.selPids = {};
      wash.plan = 0; wash.gen = 0; wash.t0 = 0; wash.startedAt = 0; wash.finishedAt = 0; wash.generationTiming = null; wash.serverNow = 0;
      wash.lastProgAt = 0;
      try { progEl.classList.remove('show'); } catch (e) {}
      washRender(); dashRender();
      btn.disabled = false; btn.textContent = '🔄 新任务';
      log('🔄 已重置：勾选商品选好模式，点「启动」开始新任务');
      setStat('已重置，勾选商品点「启动全自动」开始新任务');
    };
    // v3.2.1 旧紫色AI球已删：编辑页单商品面板从这里唤起（同页面两个内容脚本同处一个隔离世界，用 window 事件通信）
    root.querySelector('.mscb-editpg').onclick = function () {
      panel.classList.remove('open');
      window.dispatchEvent(new Event('ms-open-edit-panel'));
    };
    // v2.9.0 气泡消息：点一下气泡 = 打开面板
    var bub = root.querySelector('.mscb-bubble');
    if (bub) bub.onclick = function () {
      setView('work');
      panel.classList.add('open');
      render();
      bub.classList.remove('show');
    };

    // ---------- 模式切换：批量全自动 / 批量半自动 / 单个自动（记住上次选的） ----------
    // v3.4.1 面板内 modewrap 已删，模式高亮只管悬浮区三个方块
    function applyMode() {
      var m = ['auto', 'semi', 'single'].indexOf(cfg.mode) >= 0 ? cfg.mode : 'auto';
      root.querySelectorAll('.mscb-dockbtn').forEach(function (b) {
        b.classList.toggle('on', b.getAttribute('data-m') === m);
      });
      if (semiExtraRow) semiExtraRow.style.display = m === 'semi' ? '' : 'none';
      if (startBtn && !busy) applyModeBtnText();
    }
    // v3.7.4 暴露给闭包外：autoOne/rpaFromCheck/init 的 finally 里也调它（闭包外直接调会 ReferenceError）
    window.__mscbApplyMode = applyMode;
    // 人为按「启动」才开始：全自动=洗图+RPA；半自动=采集入工作台；单个=编辑页精修（都不自动执行）
    async function startFlow() {
      if (busy) { log('⏳ 任务进行中，可点「⏸ 暂停」控制节奏'); return; }
      panel.classList.add('open');
      // v3.7.22 恢复全自动：回归预览版曾在此拦截「全自动暂不可用」，现按原版放行。
      // 无洗图台地址时 autoOne 会自动转本地直连模式（生图/改标题走客户自己的 New API 令牌）。
      var requestState;
      try { requestState = await chrome.runtime.sendMessage({cmd:'xtNewApiStatus'}); } catch (e) {}
      if (!requestState || !requestState.ok || !requestState.data.connected) {
        log('🔑 生图还没保存生效：导入站点 JSON 后要等它自动保存（旧版要手动点「保存站点池」），填了改标题模型也要点「验证并保存连接」；两样配一样就能跑。正在打开设置页…');
        needSetup(); return;
      }
      // v3.0.0 跑单前体检：余额/连通性/素材齐全，有问题先报，绝不跑到一半才停（单个模式走编辑页 RPA，不依赖洗图台，跳过）
      if (cfg.mode !== 'single') {
        log('🩺 跑单前体检中…');
        var pf;
        try { pf = await preflight(cfg.mode); } catch (eP) { pf = { ok: false, problems: ['体检出错：' + String(eP && eP.message || eP).slice(0, 60)] }; }
        if (!pf.ok) {
          log('❌ 体检未通过（' + pf.problems.length + ' 项），先解决再启动：');
          pf.problems.forEach(function (p) { log('   · ' + p); });
          catSay('😿 体检没通过：<b>' + String(pf.problems[0]).slice(0, 46) + '</b>，先解决再启动哦');
          return;
        }
        if (washBaseOf()) log('🩺 体检通过：勾选 ' + pf.sel + ' 个商品，预计本单约 ¥' + Number(pf.est || 0).toFixed(2));
        else log('🩺 体检通过：勾选 ' + pf.sel + ' 个商品（本地直连模式，生图走你自己的令牌）');
      }
      if (pauseBtn) { pauseBtn.disabled = false; pauseBtn.textContent = '⏸ 暂停'; }
      paused = false;
      // v3.4.6 不再启动即收起：直连/洗图不碰页面，面板保持展开；回退 RPA 时才由 importSend 收起
      wash.gen = 0; wash.lowWarned = false;   // v2.8.0：新任务扣费从零计
      if (cfg.mode === 'semi') oneClick();
      else if (cfg.mode === 'single') singleMode();
      else autoOne();
    }
    var pausePending = false;
    var headPause = root.querySelector('.mscb-headpause');
    function syncPauseControls() {
      [pauseBtn, headPause, root.querySelector('.mscb-mini-pause')].forEach(function (b) {
        if (!b) return;
        b.disabled = pausePending || (!busy && !wash.serverActive && !paused);
        b.textContent = pausePending ? '正在确认…' : paused ? '▶ 继续' : '⏸ 一键暂停';
      });
    }
    async function togglePause() {
      if (pausePending || (!busy && !wash.serverActive && !paused)) return;
      var on = !paused;
      if (on) paused = true; // 先停本地下一步，不能在等待后端确认时提交导入
      pausePending = true;
      syncPauseControls();
      try {
        if (wash.serverActive && wash.batchAt) {
          var base = washBaseOf(), code = String(cfg.code || '').trim();
          var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
            + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
          pauseNeedsAck = false;
          await setServerPause(base, auth, on, wash.batchAt);
          log(on ? '⏸ 已停止派新图；已发出的请求会跑完，后续导入已暂停。' : '▶ 已继续派图和后续流程。');
        } else {
          pauseNeedsAck = on;
          log(on ? '⏸ 本地流程已暂停；已经发出的请求不会撤回。' : '▶ 已继续。');
        }
        paused = on;
        if (on) setProg(null, '⏸ 已暂停，点击顶部「继续」恢复。');
      } catch (e) {
        paused = true;
        log('⚠️ 暂停/继续未确认：' + (e && e.message || e) + '。请核对任务状态。');
      } finally { pausePending = false; syncPauseControls(); }
    }
    // v3.4.4 迷你运行条：任务开始收起大面板/悬浮区（页面完全让给 RPA），左下角只留迷你条；跑完自动弹回完整面板
    function miniShow(on) {
      var mini = root.querySelector('.mscb-mini');
      if (!mini) return;
      if (on) {
        miniT0 = Date.now();
        var mlog = mini.querySelector('.mscb-mini-log'); if (mlog) mlog.innerHTML = '';
        var mb = mini.querySelector('.mscb-mini-prog i'); if (mb) mb.style.width = '0%';
        var mti = mini.querySelector('.mscb-mini-time'); if (mti) mti.textContent = '已用 0秒';
        var mp = mini.querySelector('.mscb-mini-pause'); if (mp) { mp.textContent = '⏸ 暂停'; mp.disabled = false; }
        panel.classList.remove('open');
        root.classList.add('mscb-run');
        mini.classList.add('show');
        setTimeout(function () {   // 跑完自动恢复：轮询 busy，结束就收起迷你条、弹回面板看预览/日志
          var t = setInterval(function () {
            if (!mini.classList.contains('show') || !document.body.contains(mini)) { clearInterval(t); return; }
            if (!busy) {
              clearInterval(t);
              mini.classList.remove('show');
              root.classList.remove('mscb-run');
              panel.classList.add('open');
              log('🏁 任务结束，已恢复完整面板');
            }
          }, 1000);
        }, 3000);
      } else {
        mini.classList.remove('show');
        root.classList.remove('mscb-run');
      }
    }
    var miniPauseBtn = root.querySelector('.mscb-mini-pause');
    if (miniPauseBtn) miniPauseBtn.onclick = function () { togglePause(); };
    // v3.2.9 视图切换：ai = 只显示 AI 问答；work = 只显示工作台（该模式内容）
    function setView(v) {
      panel.setAttribute('data-view', v === 'ai' ? 'ai' : 'work');
      if (v === 'ai') helloOnce();
    }
    root.querySelectorAll('.mscb-mode').forEach(function (b) {
      b.onclick = function () {
        if (busy) { log('⏳ 任务进行中，跑完再切模式'); return; }
        cfg.mode = b.getAttribute('data-m');
        saveCfg();
        applyMode();
        log('已切到「' + b.textContent.trim() + '」模式');
      };
    });
    // v3.2.9 悬浮模式条：点哪个方块就打开哪个模式的专属页面（工作台视图）
    root.querySelectorAll('.mscb-dockbtn').forEach(function (b) {
      b.onclick = function () {
        if (busy) { log('⏳ 任务进行中，跑完再切模式'); return; }
        cfg.mode = b.getAttribute('data-m');
        saveCfg();
        applyMode();
        setView('work');
        panel.classList.add('open');
        render();
        log('已打开「' + b.textContent.trim() + '」页面：①模板 → ②选链接 → ③模式 → ④启动');
      };
    });
    startBtn.onclick = startFlow;
    pauseBtn.onclick = togglePause;
    headPause.onclick = togglePause;

    // ---------- v3.2.9 AI 问答：点小猫球才进入（工作台视图里没有问答区） ----------
    var chatEl = root.querySelector('.mscb-chat');
    function addMsg(t, cls) {
      if (!chatEl) return;
      var d = document.createElement('div');
      d.className = 'mscb-msg ' + cls;
      d.textContent = t;
      chatEl.appendChild(d);
      chatEl.scrollTop = chatEl.scrollHeight;
    }
    function aiAnswer(q) {
      q = String(q || '');
      if (/额度|生图|张数|多少张|用量/.test(q))
        return '🎨 本版用于安装预览。额度按个人 New API 账户计算，插件不承诺赠送额度。';
      if (/全自动.*跑|怎么.*全自动|全自动是什么|全自动怎么/.test(q))
        return '⚡ 批量全自动 3 步：\n1️⃣ 点「⚡ 全自动」方块进入全自动页面\n2️⃣ 顶部「模板设置」定改什么，列表勾好商品（可搜索/类目筛选）\n3️⃣ 按「▶ 启动全自动」：洗图→建链接全程自动，可随时 ⏸ 暂停。';
      if (/半自动|导出表格|表格/.test(q))
        return '🧩 批量半自动：\n1️⃣ 点「🧩 半自动」方块进入半自动页面\n2️⃣ 勾好商品后按「🖥️ 一键导入工作台」或「📤 导出表格」（48列 CSV）\n3️⃣ 去洗图猫网站上传洗图，下载新表后在妙手里手动导入。';
      if (/单个|单品|单链接|编辑/.test(q))
        return '✨ 单个自动：\n先在采集箱点开某个商品的「编辑」抽屉，再点「✨ 单个」方块，按「启动」——我会把 AI 新标题和新图写进编辑页，你核对后点妙手的「保存修改」。';
      if (/多久|多快|多长时间|太慢|好慢|速度|等待|25秒|要多久/.test(q))
        return '⏱ 出图速度说明：\n· 单张图最快也要约 25 秒——AI 逐张精修，这已是满阀门上限\n· 任务越多越快：多链接/多张图并行生成，整体远快于一张张等\n· 进度条下方实时显示「预计剩余 · 实际已用 · 产能」，不用盯着等';
      if (/模板|改什么|固定|材质|参数|预设/.test(q))
        return '🧩 模板设置（工作台最上方）：\n· 勾「改图/中文标题/英文标题/其他参数」决定做哪几步\n· 固定值（材质、风格、尺寸、场景）自动记住，每次都用\n· 可存预设、按类目自动套，点「👁 预览最终提示词」提前看效果。';
      if (/暂停|停止|停一下/.test(q))
        return '⏸ 任务运行中随时点「⏸ 暂停」，流程停在下一步边界，暂停时会弹出扣费统计；再点「继续」接着跑。';
      if (/扣费|费用|花了|多少钱|计费|余额/.test(q))
        return '💳 扣费规则：生成成功一张扣一张（按单价 ¥' + (wash.chargeRate || 0.06).toFixed(2) + '/张），失败和暂停都不扣。进度条下方实时显示「已扣费 X 张 · ¥Y」。';
      if (/续跑|断点|接回|恢复任务|补采集|重新采集/.test(q))
        return '🔄 按钮说明：\n· 续跑：页面刷新/重开后从服务器接回上次任务\n· 补采集：重新读取采集箱列表并补齐详情（不启动流程）';
      if (/检查模式|预览|重跑|修改建议|不满意/.test(q))
        return '🔍 检查模式（启动按钮下方勾选）：开启后洗完先预览每个链接的成品图，满意再「一键上传并跑RPA」，不满意可重跑/填修改建议；关闭则洗完自动建链接。';
      if (/全选|反选|勾选|多选|选择|筛选|搜索/.test(q))
        return '✅ 选链接：列表每行有勾选框；顶部「全选/反选」批量操作，搜索框按标题/ID 搜，类目下拉筛选，再点「只选筛选结果」保留勾选。';
      if (/你好|您好|hi|hello|在吗|嗨/.test(q))
        return '喵～我是洗图猫AI助手 🐱 想上手就照上面的「操作步骤」走；具体问题随时问我！';
      return '这个问题我还在学习喵～ 🐱\n可以问我：怎么用 / 全自动怎么跑 / 半自动怎么跑 / 模板 / 额度 / 出图多快。';
    }
    function ask(q) {
      q = String(q || '').trim();
      if (!q) return;
      addMsg(q, 'me');
      root.querySelector('.mscb-aiin').value = '';
      setTimeout(function () { addMsg(aiAnswer(q), 'bot'); }, 350);
    }
    var aiIn = root.querySelector('.mscb-aiin');
    root.querySelector('.mscb-aisend').onclick = function () { ask(aiIn.value); };
    aiIn.onkeydown = function (e) { if (e.key === 'Enter') ask(aiIn.value); };
    root.querySelectorAll('.mscb-chip').forEach(function (c) {
      c.onclick = function () { ask(c.getAttribute('data-q')); };
    });
    // v3.2.9 新安装首次指引：欢迎语 + 步骤导读（只弹一次）
    function helloOnce() {
      if (cfg.hello) return;
      cfg.hello = true; saveCfg();
      addMsg('喵～欢迎用洗图猫！🐱 右侧浮条：点小猫=这里（问答+指引），点⚡/🧩/✨方块=对应模式的工作台页面。\n页面里从上往下就是操作顺序：①模板 → ②选链接 → ③选模式 → ④启动/暂停/补采/续跑 → ⑤导出表格 → ⑥日志。', 'bot');
      catSay('🐱 第一次来？先看上面「操作步骤」，或点下面的常见问题问我～');
      log('👋 新手指引：①确定模板 → ②选链接 → ③选模式 → ④启动（暂停/补采/续跑并排）→ ⑤导出表格 → ⑥看日志');
      setTimeout(startTour, 500);   // v3.4.0 首次安装自动弹引导蒙层
    }

    // ---------- v3.4.0 E. 新手引导蒙层：4 步讲清入口和顺序，可跳过/重看 ----------
    var TOUR = [
      { t: '🐱 欢迎来到洗图猫！', d: '右下角浮条：点小猫 = 问答 + 使用指引（就是刚才那个页面）；点 ⚡/🧩/✨ 方块 = 对应模式的专属工作台页面。整个浮条可以按住拖到任意位置。' },
      { t: '🧩 第一步：确定模板', d: '工作台最上方「① 模板设置」：勾选要改什么（图/标题/参数）、填固定值（材质/风格/尺寸/场景），可存预设、按类目自动套。点「👁 预览最终提示词」提前看 AI 会怎么画。' },
      { t: '✅ 第二步：选链接', d: '在商品列表勾选要做的商品：搜索框搜标题/ID，类目下拉筛选，点「只选筛选结果」一键保留筛选出来的。每行还能单独指定用哪套模板。' },
      { t: '⚡ 第三步：选模式并启动', d: '⚡全自动（洗图→自动建链接）/ 🧩半自动（导出表格去网站人工洗）/ ✨单个（编辑页 AI 精修）。选好按「▶ 启动」开跑；⏸暂停、🔄续跑、🔄补采集都在按钮排上。' },
      { t: '🖼️ 第四步：看进度与验收', d: '跑单时看进度条和小猫身上的实时百分比；日志每秒记录每张图的链接/张数/耗时/状态。洗完在结果区预览成品图（点图可放大），不满意可重跑/填修改建议；经营看板随时给老板看数据。' }
    ];
    var tourIdx = 0;
    var tourMask = root.querySelector('.mscb-tourmask');
    function tourRender() {
      var st = root.querySelector('.mscb-tourstep');
      var dots = root.querySelector('.mscb-tourdots');
      var next = root.querySelector('.mscb-tournext');
      st.innerHTML = '<h5>' + TOUR[tourIdx].t + '</h5><p>' + TOUR[tourIdx].d + '</p>';
      dots.innerHTML = TOUR.map(function (_, i) { return '<i class="' + (i === tourIdx ? 'on' : '') + '"></i>'; }).join('');
      next.textContent = tourIdx === TOUR.length - 1 ? '🚀 开始使用' : '下一步';
    }
    function startTour() {
      tourIdx = 0;
      tourRender();
      tourMask.classList.add('open');
    }
    root.querySelector('.mscb-tournext').onclick = function () {
      if (tourIdx < TOUR.length - 1) { tourIdx++; tourRender(); return; }
      tourMask.classList.remove('open');
      setView('work');
      panel.classList.add('open');
      render();
      log('🚀 引导完成：工作台从上往下就是操作顺序，有问题随时点小猫问我');
    };
    root.querySelector('.mscb-tourskip').onclick = function () {
      tourMask.classList.remove('open');
      log('已跳过引导：点 AI 问答页的「📖 引导」可随时再看');
    };
    root.querySelector('.mscb-tourbtn').onclick = startTour;

    // ---------- v3.4.0 C. 成品图灯箱：滚轮缩放 / 拖动查看 / 双击还原 / Esc 关闭 ----------
    var zm = root.querySelector('.mscb-zoommask');
    var zi = root.querySelector('.mscb-zoomimg');
    var zcap = root.querySelector('.mscb-zoomcap');
    var zPrev = root.querySelector('.mscb-zoomp'), zNext = root.querySelector('.mscb-zoomn');
    var zScale = 1, zX = 0, zY = 0, zDrag = null, zSeq = [], zPos = 0;
    function zApply() { zi.style.transform = 'translate(' + zX + 'px,' + zY + 'px) scale(' + zScale + ')'; }
    // v3.7.34 灯箱支持整组切换：点哪张就放哪张（之前只传单个地址，容易串成同一条链接的第一张）
    function zShow() {
      if (!zSeq.length) return;
      if (zPos < 0) zPos = 0;
      if (zPos > zSeq.length - 1) zPos = zSeq.length - 1;
      var cur = zSeq[zPos] || {};
      zi.style.display = '';
      loadImgViaBg(zi, cur.u);
      zScale = 1; zX = 0; zY = 0; zApply();
      if (zcap) zcap.textContent = (cur.cap || '') + (zSeq.length > 1 ? '　·　第 ' + (zPos + 1) + '/' + zSeq.length + ' 张' : '');
      zm.classList.toggle('multi', zSeq.length > 1);
      zm.classList.add('open');
    }
    function zStep(d) { if (zSeq.length < 2) return; zPos += d; if (zPos < 0) zPos = zSeq.length - 1; if (zPos >= zSeq.length) zPos = 0; zShow(); }
    zoomApi = {
      open: function (src, cap) {
        zSeq = [{ u: src, cap: cap || '' }]; zPos = 0; zShow();
      },
      openSeq: function (list, pos) {
        zSeq = (list || []).filter(function (x) { return x && x.u; });
        zPos = Math.max(0, Math.min(Number(pos) || 0, zSeq.length - 1));
        zShow();
      }
    };
    if (zPrev) zPrev.onclick = function (e) { e.stopPropagation(); zStep(-1); };
    if (zNext) zNext.onclick = function (e) { e.stopPropagation(); zStep(1); };
    function closeZoom() { zm.classList.remove('open'); }
    root.querySelector('.mscb-zoomx').onclick = closeZoom;
    zm.onclick = function (e) { if (e.target === zm) closeZoom(); };
    zi.addEventListener('wheel', function (e) {
      e.preventDefault();
      zScale = Math.min(6, Math.max(0.4, zScale * (e.deltaY < 0 ? 1.12 : 0.89)));
      zApply();
    }, { passive: false });
    zi.addEventListener('dblclick', function () { zScale = 1; zX = 0; zY = 0; zApply(); });
    zi.addEventListener('mousedown', function (e) {
      zDrag = { x: e.clientX, y: e.clientY, dx: zX, dy: zY };
      zm.style.cursor = 'grabbing';
      e.preventDefault();
    });
    document.addEventListener('mousemove', function (e) {
      if (!zDrag) return;
      zX = zDrag.dx + e.clientX - zDrag.x; zY = zDrag.dy + e.clientY - zDrag.y; zApply();
    });
    document.addEventListener('mouseup', function () { zDrag = null; zm.style.cursor = 'grab'; });
    document.addEventListener('keydown', function (e) {
      if (!zm.classList.contains('open')) return;
      if (e.key === 'Escape') return closeZoom();
      if (e.key === 'ArrowLeft') { e.preventDefault(); zStep(-1); }
      if (e.key === 'ArrowRight') { e.preventDefault(); zStep(1); }
    });

    // ---------- v3.6.0 原图 vs 洗后 对比弹窗（v3.7.2 整单对比：传数组，按张数对齐成行） ----------
    var cm = root.querySelector('.mscb-cmpmask');
    var cmRows = root.querySelector('.mscb-cmprows');
    var cmBT = root.querySelector('.mscb-cmp-bt');
    function cmpCell(url, note) {
      var cell = document.createElement('div'); cell.className = 'mscb-cmpcell';
      if (url) {
        var im = document.createElement('img'); im.alt = '对比图';
        im.title = note + '（点开放大）';
        im.onclick = function () { if (zoomApi) zoomApi.open(url); };
        loadImgViaBg(im, url, null, true);   // 原图走后台代理：源站（Temu/Amazon 等）防盗链会拒绝妙手页面的 Referer
        cell.appendChild(im);
      } else {
        var emp = document.createElement('div'); emp.className = 'mscb-cmpempty';
        emp.textContent = '（无对应图）';
        cell.appendChild(emp);
      }
      var nt = document.createElement('div'); nt.className = 'mscb-cmpnote'; nt.textContent = note;
      cell.appendChild(nt);
      return cell;
    }
    compareApi = {
      open: function (origUrls, washUrls, label, titles) {
        if (!Array.isArray(origUrls)) origUrls = origUrls ? [origUrls] : [];
        if (!Array.isArray(washUrls)) washUrls = washUrls ? [washUrls] : [];
        cmRows.innerHTML = '';
        // v3.7.82 标题对比：客户要求同时比对原标题 vs 洗后标题（含英文）
        if (titles && (titles.zh || titles.en || titles.orig)) {
          var th = document.createElement('div'); th.className = 'mscb-cmprow';
          var esc = function (s2) { return String(s2 || '').replace(/[<>&]/g, function (c) { return ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' })[c]; }); };
          th.innerHTML = '<div class="mscb-cmpcell"><div class="mscb-cmptitle"><b>原标题</b><br>' + (esc(titles.orig) || '（无）') + '</div></div>'
            + '<div class="mscb-cmpcell"><div class="mscb-cmptitle"><b>洗后标题' + (titles.en ? '（中+英）' : '') + '</b><br>' + (esc(titles.zh) || '（未改标题，保持原样）') + (titles.en ? '<br><span style="color:#2f6fd6">EN: ' + esc(titles.en) + '</span>' : '') + '</div></div>';
          cmRows.appendChild(th);
        }
        var n = Math.max(origUrls.length, washUrls.length);
        var hasOrig = origUrls.filter(Boolean);
        for (var i = 0; i < n; i++) {
          var row = document.createElement('div'); row.className = 'mscb-cmprow';
          // v3.7.67 源图不够时用第 1 张原图垫位：场景图/分镜图没有一一对应的原图，不再显示「无对应图」
          var oUrl = origUrls[i] || hasOrig[0] || '';
          row.appendChild(cmpCell(oUrl, '原图 #' + (i + 1) + (origUrls[i] ? '' : (hasOrig.length ? '（源图共 ' + hasOrig.length + ' 张，用第 1 张垫位）' : ''))));
          row.appendChild(cmpCell(washUrls[i], '洗后 #' + (i + 1) + (washUrls[i] ? ' · ' + pvImgType(i) : '')));
          cmRows.appendChild(row);
        }
        if (!n && !titles) { log('ℹ️ 这个链接没有可对比的图'); return; }
        cmBT.textContent = label ? ('整单对比 · ' + label) : '整单对比：左边采集原图，右边洗后成品';
        cm.classList.add('open');
      }
    };
    function closeCompare() { cm.classList.remove('open'); }
    root.querySelector('.mscb-cmp-x').onclick = closeCompare;
    cm.onclick = function (e) { if (e.target === cm) closeCompare(); };
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && cm.classList.contains('open')) closeCompare(); });

    // ---------- v3.6.0 错误提醒弹窗：只能手动关（点遮罩/Esc 都不关，防止错过后续错误） ----------
    var em = root.querySelector('.mscb-errmask');
    root.querySelector('.mscb-err-x').onclick = function () { em.classList.remove('open'); };
    root.querySelector('.mscb-err-copy').onclick = function () {
      var txt = [...em.querySelectorAll('.mscb-errrow')].map(function (r) { return r.textContent; }).join('\n');
      try {
        navigator.clipboard.writeText(txt).then(function () { log('📋 错误内容已复制，可发给客服/老板排查'); });
      } catch (e) { log('ℹ️ 复制失败，请手动框选错误内容复制'); }
    };

    root.querySelector('.mscb-envcheck').onclick = environmentCheck;
    root.querySelector('.mscb-newapi').onclick = needSetup;
    root.querySelector('.mscb-rpatest').onclick = testImportInterface;
    var doneMask = root.querySelector('.mscb-donemask');
    doneMask.querySelector('.mscb-done-close').onclick = function () { doneMask.classList.remove('open'); };
    doneMask.onkeydown = function (e) {
      if (e.key === 'Escape') { doneMask.classList.remove('open'); return; }
      if (e.key === 'Tab') { e.preventDefault(); var first = doneMask.querySelector('.mscb-done-refresh'), last = doneMask.querySelector('.mscb-done-close'); (document.activeElement === first ? last : first).focus(); }
    };
    doneMask.querySelector('.mscb-done-refresh').onclick = function () {
      if (busy || rerunning || repairBusy) { log('⏳ 当前任务还在处理，完成后再刷新'); return; }
      window.location.reload();
    };
    root.querySelector('.mscb-tts-test').onclick = function () {
      if (cfg.tts === false) { log('ℹ️ 请先勾选「语音提示」，再点试播'); return; }
      stopSpeech();
      speak('洗图完成，所有链接图片已齐全。');
      speak('上传完成，请刷新页面查看链接。');
    };
    // ---------- v3.7.0 主题系统：黑白 / 暗夜 / 海蓝 / 森绿 / 葡萄 / 跟随系统 ----------
    function resolveTheme() {
      var t = cfg.theme || 'auto';
      if (t === 'auto') return (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'classic';
      for (var i = 0; i < MSCB_THEMES.length; i++) if (MSCB_THEMES[i].k === t) return t;
      return 'classic';
    }
    function applyTheme() {
      root.setAttribute('data-theme', resolveTheme());
      var cur = cfg.theme || 'auto';
      var menu = root.querySelector('.mscb-thmenu');
      if (menu) [...menu.querySelectorAll('button')].forEach(function (b) {
        b.classList.toggle('on', b.getAttribute('data-th') === cur);
      });
    }
    applyTheme();
    try {
      var mqDark = window.matchMedia('(prefers-color-scheme: dark)');
      var onDark = function () { applyTheme(); };   // 跟随系统模式下系统一切换面板马上跟
      if (mqDark.addEventListener) mqDark.addEventListener('change', onDark);
      else if (mqDark.addListener) mqDark.addListener(onDark);
    } catch (eD) {}
    // 主题菜单交互：点 🎨 开合，点选项即换即存，点别处收起
    var thBtn = root.querySelector('.mscb-thbtn'), thMenu = root.querySelector('.mscb-thmenu');
    if (thBtn && thMenu) {
      thBtn.onclick = function (e) { e.stopPropagation(); thMenu.classList.toggle('open'); };
      document.addEventListener('click', function (e) {
        if (!thMenu.contains(e.target) && e.target !== thBtn) thMenu.classList.remove('open');
      });
      [...thMenu.querySelectorAll('button')].forEach(function (b) {
        b.onclick = function () {
          cfg.theme = b.getAttribute('data-th');
          saveCfg();
          applyTheme();
          thMenu.classList.remove('open');
          log('🎨 主题已切换：' + b.textContent.trim());
        };
      });
    }

    // ---------- v3.4.0 A. 启动按钮状态光效：跑单呼吸橙光 / 暂停黄色 ----------
    setInterval(function () {
      startBtn.classList.toggle('running', busy && !paused);
      startBtn.classList.toggle('paused', !!paused && busy);
      if (paused && busy) startBtn.textContent = '⏸ 已暂停（点旁边「继续」）';
      else applyModeBtnText();
      syncPauseControls();
    }, 2000);
    function applyModeBtnText() {
      if (busy || !startBtn) return;
      startBtn.textContent = cfg.mode === 'semi' ? '🖥️ 一键导入工作台'
        : cfg.mode === 'single' ? '✨ 启动单个自动'
        : '🚀 启动全自动';
    }

    // 半自动专属：导出表格（人工点，人工拿去网站洗）
    var expBtn = root.querySelector('.mscb-export:not(.mscb-expall)');
    if (expBtn) expBtn.onclick = async function () {
      if (busy) return;
      busy = true;
      expBtn.disabled = true;
      progEl.classList.add('show');
      try { await tableMode(); }
      catch (e) { log('❌ ' + (e && e.message ? e.message : e)); }
      finally { busy = false; expBtn.disabled = false; }
    };

    // v3.5.2 一键导出已抓取数据：有勾选只导勾选的（测试单链接场景），没勾选才导全部
    var expAllBtn = root.querySelector('.mscb-expall');
    if (expAllBtn) expAllBtn.onclick = function () {
      if (busy) return;
      var all = [], sel = [];
      items.forEach(function (v) {
        if (v.title && v.imgs && v.imgs.length) {
          all.push(v);
          if (v.sel !== false) sel.push(v);
        }
      });
      if (!all.length) { log('❌ 还没有已抓取的数据：等列表加载完，或点「🔄 补采集」抓一轮'); return; }
      if (sel.length && sel.length < all.length) {
        var got = exportRows(sel, '按选中');
        if (got) log('📤 一键导出完成：' + got + ' 个勾选商品 · 48 列全字段（没勾的不导；要导全部先点「全选」再点本按钮）');
      } else {
        var got2 = exportRows(all, '全部已抓取');
        if (got2) log('📤 一键导出完成：' + got2 + ' 个商品 · 48 列全字段（当前没有勾选，默认导全部）');
      }
    };

    // ---------- 模板设置：改什么 + 固定值（长期记忆；v3.7.26 移入大弹窗，标题折叠行已去掉） ----------
    var tplBox = root.querySelector('.mscb-tpl');
    var tplT = root.querySelector('.mscb-tpl-t');
    if (tplT) tplT.onclick = function () { tplBox.classList.toggle('open'); };
    root.querySelectorAll('.mscb-tpl-ck').forEach(function (ck) {
      var k = ck.getAttribute('data-k');
      ck.checked = !!(cfg.tpl && cfg.tpl[k]);
      ck.onchange = function () {
        cfg.tpl[k] = ck.checked;
        saveCfg();
        log('🧩 模板已更新：' + (ck.checked ? '✅' : '❌') + ' ' + ck.parentNode.textContent.trim() + '（已记住）');
      };
    });
    // v3.7.26 生图模式单选：keep=原样复刻 / pod=POD改造；v3.7.69 POD 改造幅度三档
    function podRowSync() {
      var row = root.querySelector('.mscb-tpl-podrow');
      if (row) row.style.display = ((cfg.tpl.imgMode || 'keep') === 'pod') ? 'flex' : 'none';
    }
    root.querySelectorAll('.mscb-imgmode').forEach(function (r) {
      r.checked = (cfg.tpl.imgMode || 'keep') === r.value;
      r.onchange = function () {
        if (!r.checked) return;
        cfg.tpl.imgMode = r.value;
        saveCfg();
        podRowSync();
        log('🧩 生图模式：' + (r.value === 'pod' ? 'POD改造（' + ({light:'轻改造',mid:'标准改造',strong:'强改造'}[cfg.tpl.podLevel || 'mid']) + '）' : '原样复刻（保持商品原样）') + '（已记住）');
      };
    });
    var podlvSel = root.querySelector('.mscb-podlv');
    if (podlvSel) {
      podlvSel.value = cfg.tpl.podLevel || 'mid';
      podlvSel.onchange = function () {
        cfg.tpl.podLevel = podlvSel.value;
        saveCfg();
        log('🧩 POD 改造幅度：' + ({light:'轻改造（商品原样，只换呈现）',mid:'标准改造（图案主体保留）',strong:'强改造（图案可重新设计）'}[podlvSel.value]) + '（已记住，下一单生效）');
      };
    }
    podRowSync();
    // v3.7.26 画面风格 / 模特设置（人种/露脸/景别）
    var styleSel = root.querySelector('.mscb-tplstyle');
    if (styleSel) {
      styleSel.innerHTML = '<option value="">不指定（AI 自动搭配）</option>' + Object.keys(TPL_STYLE_LABELS).map(function (k) { return '<option value="' + k + '">' + TPL_STYLE_LABELS[k] + '</option>'; }).join('');
      styleSel.value = cfg.tpl.style || '';
      styleSel.onchange = function () {
        cfg.tpl.style = styleSel.value;
        saveCfg();
        log('🧩 画面风格：' + (styleSel.value ? TPL_STYLE_LABELS[styleSel.value] : '不指定（AI 自动）') + '（已记住，套用全部出图）');
      };
    }
    ['race', 'face', 'shot'].forEach(function (mk) {
      var sel = root.querySelector('.mscb-model-' + mk);
      if (!sel) return;
      var labels = TPL_MODEL_LABELS[mk];
      var firstTxt = mk === 'race' ? '人种：不指定（AI 自定）' : (mk === 'face' ? '露脸：不指定' : '景别：不指定');
      sel.innerHTML = '<option value="">' + firstTxt + '</option>' + Object.keys(labels).map(function (k) { return '<option value="' + k + '">' + labels[k] + '</option>'; }).join('');
      sel.value = (cfg.tpl.model && cfg.tpl.model[mk]) || '';
      sel.onchange = function () {
        if (!cfg.tpl.model || typeof cfg.tpl.model !== 'object') cfg.tpl.model = { race: '', face: '', shot: '' };
        cfg.tpl.model[mk] = sel.value;
        saveCfg();
        log('🧩 模特设置 · ' + (mk === 'race' ? '人种' : mk === 'face' ? '露脸' : '景别') + '：' + (sel.value ? labels[sel.value] : '不指定') + '（已记住，只作用于「模特图」分镜）');
      };
    });
    var imgnIn = root.querySelector('.mscb-imgn');
    if (imgnIn) {
      imgnIn.value = Math.max(1, Math.min(10, Number(cfg.imgN) || 10));
      imgnIn.onchange = function () {
        cfg.imgN = Math.max(1, Math.min(10, Number(imgnIn.value) || 10));
        imgnIn.value = cfg.imgN;
        saveCfg();
        log('🧩 每品出图数已设为 ' + cfg.imgN + ' 张（已记住）');
      };
    }
    root.querySelectorAll('.mscb-imgn-chip').forEach(function (chip) {   // v3.7.73 出图数量快捷档
      chip.style.cssText = 'margin:0 6px 0 0;padding:3px 10px;font-size:12px;background:#eef7ee;color:#1e7a3c;border:1px solid #bfe0c8;border-radius:8px;cursor:pointer';
      chip.onclick = function () {
        cfg.imgN = Number(chip.dataset.n) || 10;
        if (imgnIn) imgnIn.value = cfg.imgN;
        saveCfg();
        root.querySelectorAll('.mscb-imgn-chip').forEach(function (c2) { c2.style.background = (c2 === chip) ? '#c9ecd4' : '#eef7ee'; });
        log('🧩 每品出图数已设为 ' + cfg.imgN + ' 张（快捷档，已记住）——每品成本按张数等比下降');
      };
      if (Number(chip.dataset.n) === (Number(cfg.imgN) || 10)) chip.style.background = '#c9ecd4';
    });
    var fissIn = root.querySelector('.mscb-fiss');
    if (fissIn) {
      fissIn.value = Math.max(1, Math.min(10, Number(cfg.fiss) || 1));
      fissIn.onchange = function () {
        cfg.fiss = Math.max(1, Math.min(10, Number(fissIn.value) || 1));
        fissIn.value = cfg.fiss;
        saveCfg();
        log('🧩 单品裂变已设为每品 ' + (cfg.fiss > 1 ? cfg.fiss + ' 条新链接' : '不裂变') + '（已记住）');
      };
    }
    var srcSel = root.querySelector('.mscb-imgsrc');   // v3.7.75 图源模式：auto=外链优先+base64才上传；url=要图链；space=一律上传图片空间
    if (srcSel) {
      srcSel.value = (cfg.imgSrc === 'space') ? 'space' : (cfg.imgSrc === 'url' ? 'url' : (cfg.imgDirect === false ? 'space' : 'auto'));
      srcSel.onchange = function () {
        cfg.imgSrc = srcSel.value;
        cfg.imgDirect = (srcSel.value === 'space') ? false : true;   // 兼容旧逻辑
        saveCfg();
        log('🧩 图源模式：' + ({ auto: '自动（上游图链优先，返回 base64 才上传图片空间）', url: '要图链 URL（外链直写入表，要求图链长期有效）', space: '要图片（一律上传妙手图片空间，拿妙手图链最稳）' }[srcSel.value]) + '（已记住）');
      };
    }
    var sizeSel = root.querySelector('.mscb-imgsize');   // v3.7.75 体积档位
    if (sizeSel) {
      sizeSel.value = cfg.imgSize || 'auto';
      sizeSel.onchange = function () {
        cfg.imgSize = sizeSel.value;
        saveCfg();
        log('🧩 体积档位：' + ({ original: '原样不压（图最清晰，上传较慢）', auto: '标准（超过 500KB 才压，不缩边）', small: '小体积（≤300KB，长边≤2000px）', tiny: '超小（≤150KB，长边≤1200px，适合手机端/省流量）' }[sizeSel.value]) + '（已记住）');
      };
    }
    var fixedBox = root.querySelector('.mscb-tpl-fixed');
    TPL_FIELDS.forEach(function (f) {
      var lb = document.createElement('label');
      lb.textContent = f.label;
      var inp = document.createElement('input');
      inp.type = 'text';
      inp.placeholder = f.ph;
      inp.setAttribute('data-fk', f.k);
      inp.value = (cfg.tpl && cfg.tpl.fixed && cfg.tpl.fixed[f.k]) || '';
      inp.onchange = function () {
        if (!cfg.tpl.fixed) cfg.tpl.fixed = {};
        cfg.tpl.fixed[f.k] = inp.value.trim();
        saveCfg();
        if (inp.value.trim()) log('🧩 固定值已记住：' + f.label + ' = ' + inp.value.trim());
      };
      fixedBox.appendChild(lb);
      fixedBox.appendChild(inp);
    });
    // v3.5.1 类目属性（填进转换表「类目属性」列）：源采集没带属性时用这里补，同品类配一次长期记住
    var caLb = document.createElement('label');
    caLb.textContent = '类目属性';
    var caInp = document.createElement('input');
    caInp.type = 'text';
    caInp.placeholder = '如：材料:木质;安装类型:壁挂;产品类型:装饰牌（分号分隔，随启动自动填进表格）';
    caInp.value = cfg.catAttrs || '';
    caInp.onchange = function () {
      cfg.catAttrs = caInp.value.trim();
      saveCfg();
      if (cfg.catAttrs) log('🧩 类目属性已记住（每单自动填进转换表）：' + cfg.catAttrs);
    };
    fixedBox.appendChild(caLb);
    fixedBox.appendChild(caInp);

    // ---------- 全选 / 反选 / 逐条多选（列表行自带勾选框） ----------
    iAll.onchange = function () {
      var on = iAll.checked;
      items.forEach(function (v) { v.sel = on; });
      render();
    };
    var invBtn = root.querySelector('.mscb-inv');
    if (invBtn) invBtn.onclick = function () {
      items.forEach(function (v) { v.sel = (v.sel === false); });
      iAll.checked = false;
      render();
    };

    // ---------- v2.6.0 检查模式（洗完先预览再建链接） ----------
    var ckCheck = root.querySelector('.mscb-check');
    if (ckCheck) {
      ckCheck.checked = cfg.check !== false;
      ckCheck.onchange = function () {
        cfg.check = ckCheck.checked;
        saveCfg();
        log(cfg.check
          ? '🔍 检查模式已开启：全自动洗完图先预览，满意再点「一键上传并跑 RPA」'
          : '⚡ 检查模式已关闭：洗完图自动建链接，全程无人值守');
      };
    }

    // ---------- v3.5.8 直连导入优先（快） vs RPA 优先 ----------
    var ckApi = root.querySelector('.mscb-apifirst');
    if (ckApi) {
      ckApi.checked = cfg.apiFirst !== false;
      ckApi.onchange = function () {
        cfg.apiFirst = ckApi.checked;
        saveCfg();
        log(cfg.apiFirst
          ? '⚡ 已切「直连导入优先」：调妙手导入接口，2~5 秒完成，失败才回退 RPA'
          : '🤖 已切「RPA 优先」：在页面上真实点导入按钮走人工流程（慢，且依赖浏览器点击通道）');
      };
    }

    // ---------- v3.6.0 TTS 语音提示开关 ----------
    var ckTts = root.querySelector('.mscb-tts');
    if (ckTts) {
      ckTts.checked = cfg.tts !== false;
      ckTts.onchange = function () {
        cfg.tts = ckTts.checked;
        saveCfg();
        if (!cfg.tts) stopSpeech();
        log(cfg.tts ? '🔊 语音提示已开：采集/洗图/上传 开始与完成会语音播报' : '🔇 语音提示已关');
        if (cfg.tts) speak('语音提示已开启');
      };
    }

    // ---------- v2.6.0 一键补采集（重新读列表 + 补详情，不启动流程） ----------
    var rfBtn = root.querySelector('.mscb-refetch');
    if (rfBtn) rfBtn.onclick = async function () {
      if (busy) { log('⏳ 任务进行中，跑完再补采集'); return; }
      rfBtn.disabled = true;
      try {
        log('🔄 手动补采集：重新读取列表…');
        var n = await pull(true);
        await fillDetails();
        log('✅ 补采集完成，共 ' + (n || items.size) + ' 个商品（未启动任何流程）');
      } catch (e) {
        log('❌ 补采集失败：' + (e && e.message ? e.message : e));
      } finally { rfBtn.disabled = false; }
    };

    // ---------- v3.7.26 模板设置大弹窗：打开/关闭 ----------
    var tplOpenBtn = root.querySelector('.mscb-tpl-open');
    var tplMask = root.querySelector('.mscb-tplmask');
    if (tplOpenBtn && tplMask) {
      tplOpenBtn.onclick = function () { tplMask.classList.add('open'); };
      var tplX = tplMask.querySelector('.mscb-tpldlg-x');
      if (tplX) tplX.onclick = function () { tplMask.classList.remove('open'); };
      tplMask.addEventListener('click', function (e) { if (e.target === tplMask) tplMask.classList.remove('open'); });
    }

    // ---------- v2.7.1 一键续跑（断点恢复，从服务器接回任务） ----------
    var rsBtn = root.querySelector('.mscb-resume');
    if (rsBtn) rsBtn.onclick = async function () {
      rsBtn.disabled = true;
      try { await resumeWash(); }
      finally { rsBtn.disabled = false; }
    };

    // ---------- v2.7.0 类目筛选 + 搜索 + 只选筛选结果 ----------
    var searchIn = root.querySelector('.mscb-search');
    var catSel = root.querySelector('.mscb-cat');
    if (searchIn) searchIn.oninput = function () { filtQ = searchIn.value.trim(); render(); };
    if (catSel) catSel.onchange = function () { filtCat = catSel.value; render(); };
    // ---------- v3.4.1 按数量模式：从上往下自动勾选前 N 个；手动取消勾选数字跟着变 ----------
    var byCount = root.querySelector('.mscb-bycount');
    var countIn = root.querySelector('.mscb-count');
    // v3.7.26 按数量人性化：下拉快捷选择（替代原「按数量」勾选框）
    var selMode = root.querySelector('.mscb-selmode');
    function pickFirstN(n, quiet) {
      n = Math.max(1, Math.round(Number(n) || 1));
      var arr = filteredItems();
      var ids = {};
      arr.slice(0, n).forEach(function (v) { ids[String(v.id)] = 1; });
      items.forEach(function (v) { v.sel = !!ids[String(v.id)]; });
      render();
      if (!quiet) log('🔢 已从上往下自动勾选前 ' + Math.min(n, arr.length) + ' 个（当前列表共 ' + arr.length + ' 个）');
    }
    if (selMode && countIn) {
      selMode.value = 'all';
      selMode.onchange = function () {
        var v = selMode.value;
        if (v === 'all') {
          countIn.style.display = 'none';
          items.forEach(function (x) { x.sel = true; });
          render();
          log('✅ 已全选本页全部商品');
        } else if (v === 'custom') {
          countIn.style.display = '';
          countIn.focus();
          pickFirstN(Number(countIn.value) || 10);
        } else {
          countIn.style.display = 'none';
          countIn.value = v;
          pickFirstN(v);
        }
      };
      if (countIn) countIn.onchange = function () { pickFirstN(countIn.value); };   // 自定义数量：回车/失焦应用
    }
    function applyByCount() {
      if (!byCount || !byCount.checked || !countIn) return;
      var n = Math.max(1, Math.round(Number(countIn.value) || 1));
      var arr = filteredItems();
      var ids = {};
      arr.slice(0, n).forEach(function (v) { ids[String(v.id)] = 1; });
      items.forEach(function (v) { v.sel = !!ids[String(v.id)]; });
      render();
      log('🔢 按数量：已从上往下自动勾选前 ' + Math.min(n, arr.length) + ' 个（共 ' + arr.length + ' 个）');
    }
    if (byCount) byCount.onchange = function () {
      countIn.disabled = !byCount.checked;
      if (byCount.checked) applyByCount();
      else log('🔢 按数量模式已关：恢复手动勾选');
    };
    // v3.7.26：countIn.onchange 已由上方 selMode 逻辑接管（自定义数量）
    var catOnlyBtn = root.querySelector('.mscb-catonly');
    if (catOnlyBtn) catOnlyBtn.onclick = function () {
      var shown = filteredItems();
      if (!shown.length) { log('ℹ️ 当前筛选没有商品'); return; }
      var ids = {};
      shown.forEach(function (v) { ids[String(v.id)] = 1; });
      var n = 0;
      items.forEach(function (v) { v.sel = !!ids[String(v.id)]; if (v.sel) n++; });
      render();
      log('✅ 已只选筛选结果：' + n + ' 个商品（其余已取消勾选），可配合「批量套模板」按类目分配');
    };
    // v3.7.90 按页面对齐：面板列表是采集时的 API 顺序，页面后来改过筛选/排序后两边位置对不上。
    // 读当前页面每行的标题文本，按标题把面板商品重排成页面顺序（面板里不在当前页的商品挪到末尾）。
    var alignBtn = root.querySelector('.mscb-align');
    if (alignBtn) alignBtn.onclick = function () {
      function xtNorm(s) { return String(s || '').toLowerCase().replace(/[\s\u3000]+/g, ''); }
      // 读页面虚拟表格行（妙手表格 class 是 pro-virtual-table）
      var rows = document.querySelectorAll('.pro-virtual-table__body tr, .pro-virtual-table__body [class*="__row"], .pro-virtual-table:not(.pro-virtual-table__header) tr');
      var texts = [];
      rows.forEach(function (r) {
        var t = xtNorm(r.innerText);
        if (t && t.length >= 6 && texts.indexOf(t) < 0) texts.push(t);
      });
      if (!texts.length) { log('❌ 读不到页面商品行（页面还没加载出来？），滚动一下列表再点'); return; }
      var used = {};
      var ordered = [], missRows = 0;
      texts.forEach(function (nR) {
        var head = nR.slice(0, 14);
        var hit = null;
        items.forEach(function (v) {
          if (hit || used[String(v.id)]) return;
          var nT = xtNorm(v.title);
          if (!nT) return;
          if (nT.indexOf(head) >= 0 || head.indexOf(nT.slice(0, 14)) >= 0) hit = v;
        });
        if (hit) { used[String(hit.id)] = 1; ordered.push(hit); } else missRows++;
      });
      if (!ordered.length) { log('❌ 页面行和面板商品一个都对不上（页面可能已是另一批数据），先点「补采集」'); return; }
      var rest = [];
      items.forEach(function (v) { if (!used[String(v.id)]) rest.push(v); });
      var nm = new Map();
      ordered.forEach(function (v) { nm.set(String(v.id), v); });
      rest.forEach(function (v) { nm.set(String(v.id), v); });
      items = nm;
      render();
      log('↕ 已按页面顺序对齐：匹配上 ' + ordered.length + ' 行（页面未匹配 ' + missRows + ' 行，面板里不在当前页的 ' + rest.length + ' 个挪到末尾）');
    };

    // ---------- v2.7.0 链接清单：复制 / 导出留底 ----------
    var lb = root.querySelector('.mscb-linkbtns');
    if (lb) {
      lb.querySelector('.mscb-lcopy').onclick = copyLinks;
      lb.querySelector('.mscb-lexp').onclick = exportLinksCsv;
    }
    // 补失败图大按钮
    if (resBtnsEl) resBtnsEl.querySelector('.mscb-rrepair').onclick = async function () {
      if (busy || rerunning || repairBusy) { log('⏳ 当前有任务在跑，稍等'); return; }
      // v3.7.32 本地直连单：走本地补图（只补缺失的图）
      if ((wash.products || []).some(function (x) { return x.local; })) {
        busy = true;
        try {
          var lf = await localRepairAll();
          setProg(100, lf ? ('⚠️ 补图完成，仍缺 ' + lf + ' 张，可点某链接的 🔁 重跑') : '✅ 补图完成：所有图已齐全');
        } finally { busy = false; washRender(); }
        return;
      }
      var base = washBaseOf();
      var code = String(cfg.code || '').trim();
      if (!base || !code) { log('❌ 先在面板里填好洗图台地址和口令'); needSetup(); return; }
      var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
        + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
      busy = true; progEl.classList.add('show');
      try {
        var left = await washRepair(base, auth);
        setProg(100, left ? '⚠️ 补图完成，仍有 ' + left + ' 个链接不完整，可单个 🔁 重跑' : '✅ 补图完成：所有链接图已齐全');
      } catch (e) {
        setProg(null, '❌ 补图失败：' + (e && e.message ? e.message : e));
      } finally { busy = false; washRender(); }
    };
    // v3.0.0 全部重跑失败项
    if (resBtnsEl) resBtnsEl.querySelector('.mscb-rrfail').onclick = function () { rerunFailed(); };

    function historyTimingText(h) {
      var t = h.generationTiming;
      var date = function (value) {
        if (typeof value !== 'number' || !isFinite(value) || value <= 0) return '未记录';
        var parts = new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).formatToParts(new Date(value));
        var part = function (type) { var found = parts.find(function (x) { return x.type === type; }); return found ? found.value : ''; };
        return part('year') + '-' + part('month') + '-' + part('day') + ' ' + part('hour') + ':' + part('minute') + ':' + part('second');
      };
      var duration = function (value) {
        if (typeof value !== 'number' || !isFinite(value) || value < 0) return '未记录';
        var seconds = Math.floor(value / 1000), hours = Math.floor(seconds / 3600), minutes = Math.floor(seconds % 3600 / 60);
        return (hours ? hours + '小时' : '') + (minutes ? minutes + '分' : '') + (seconds % 60) + '秒';
      };
      var lines = [h.n + ' 张' + (h.current ? ' · 当前单' : '')];
      if (h.timingUnavailable) lines.push('计时记录不可用；成品保留，不据此重复生图或收费');
      if (!t) {
        lines.push('文件更新时间（北京）：' + date(h.fileUpdatedAt || h.at));
        lines.push('真实生成完成时间及实际历时：未记录');
        return lines.join('\n');
      }
      if (t.originalKnown && t.finishedAt) {
        lines.push('生成完成时间（北京）：' + date(t.finishedAt));
        lines.push('实际历时：' + duration(t.elapsedMs) + '（首次派发至首次齐套，含等待/暂停/重试）');
      } else if (t.originalKnown && t.startedAt) {
        lines.push(h.inProgress ? '生成进行中，完成时间尚未记录' : '尚无真实齐套完成时间');
        lines.push('首次派发时间（北京）：' + date(t.startedAt));
      } else lines.push('首次生成完成时间及全单实际历时：未记录');
      var a = t.latestAttempt;
      if (a && a.kind !== 'generate') {
        var kind = a.kind === 'regenerate' ? '本次重做' : a.kind === 'resume' ? '本次恢复补跑' : '本次补跑';
        lines.push(kind + (a.finishedAt ? '完成时间（北京）：' + date(a.finishedAt) + ' · 实际历时：' + duration(a.elapsedMs) : h.inProgress ? '进行中，完成时间尚未记录' : '未齐套或完成时间未记录') + '（不是原始全单历时）');
      }
      lines.push('历时为墙钟时间，不是纯模型推理时间');
      return lines.join('\n');
    }

    // ---------- v3.6.3 历史单（洗图台磁盘上的旧单，防误覆盖后找回） ----------
    var histWrap = root.querySelector('.mscb-histwrap');
    if (histWrap) {
      var histListEl = histWrap.querySelector('.mscb-histlist');
      var histCountEl = histWrap.querySelector('.mscb-histcount');
      var loadHist = async function () {
        // v3.7.33 本机有任务快照时，历史框优先显示「本机任务（可恢复）」，不再依赖洗图台接口
        if (renderHistLocal()) return;
        try {
          var base = washBaseOf(), code = String(cfg.code || '').trim();
          if (!base || !code) return;
          var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code);
          var r = await relay(base + '/api/past-products?' + auth, {});
          var list = (r && r.list) || [];
          if (!list.length) return;   // v3.7.37 框固定显示：洗图台也没有旧单就保留「暂无」占位，不再隐藏
          var nameEl0 = histWrap.querySelector('.mscb-histname');
          if (nameEl0) nameEl0.textContent = '🕘 历史单（洗图台磁盘）';
          histCountEl.textContent = list.length + ' 个';
          histListEl.innerHTML = '';
          list.forEach(function (h) {
            var row = document.createElement('div'); row.className = 'mscb-histrow';
            var t = document.createElement('div'); t.className = 'mscb-histt';
            t.textContent = h.title || ('产品 ' + h.pid);
            t.title = t.textContent + '（pid ' + h.pid + '）';
            var meta = document.createElement('div'); meta.className = 'mscb-histmeta';
            meta.textContent = historyTimingText(h);
            meta.style.whiteSpace = 'pre-line'; meta.style.lineHeight = '1.5';
            meta.title = meta.textContent;
            var btns = document.createElement('div'); btns.className = 'mscb-histbtns';
            var mkS = function () { return { pid: String(h.pid), srcPid: String(h.pid), title: h.title, total: h.n, done: h.n, fail: 0, status: 'done', lastErr: '' }; };
            var bPv = document.createElement('button'); bPv.textContent = '🔍';
            bPv.title = '预览这单的 ' + h.n + ' 张成品图';
            bPv.onclick = function () { openPreview([mkS()]); };
            var bDl = document.createElement('button'); bDl.textContent = '⬇️';
            bDl.title = '把这单 ' + h.n + ' 张图全部下载到本地';
            bDl.onclick = function () { dlProduct(mkS()); };
            btns.appendChild(bPv); btns.appendChild(bDl);
            row.appendChild(t); row.appendChild(meta); row.appendChild(btns);
            histListEl.appendChild(row);
          });
        } catch (e) { log('ℹ️ 洗图台历史单接口暂不可用（' + String(e && e.message || e).slice(0, 40) + '）；本机跑完的单会记在「历史任务」里'); }
      };
      histWrap.querySelector('.mscb-histhead').onclick = function () {
        histWrap.classList.toggle('open');
        if (histWrap.classList.contains('open')) loadHist();
      };
      // v3.7.3 探测失败不再永久隐藏：构建时失败自动重试 3 次；面板打开期间每 15s 补探一次（接口抖一下就回来的场景）
      var histTries = 0;
      var histProbe = async function () {
        var before = histWrap.style.display;
        await loadHist();
        if (histWrap.style.display === 'none' && before === 'none' && histTries < 3) {
          histTries++;
          setTimeout(histProbe, 4000 * histTries);
        } else if (histWrap.style.display !== 'none') histTries = 0;
      };
      histProbe();
      // v3.7.33 断点续跑：面板一打开就提示「上次任务」，并渲染历史任务框（本机快照优先）
      try { renderJobBar(); renderHistLocal(); } catch (eJb) {}
      setInterval(function () {
        if (histWrap.style.display !== 'none') return;
        var p = document.querySelector('.mscb-panel');
        if (p && p.classList.contains('open')) loadHist();
      }, 15000);
    }

    // ---------- v2.7.1 面板缩放（0.7~2.0 记住大小）+ 一键全屏 ----------
    var zoomIn = root.querySelector('.mscb-zoomin');
    var zoomOut = root.querySelector('.mscb-zoomout');
    var zoomFull = root.querySelector('.mscb-zfull');
    function applyZoom() {
      panel.classList.toggle('mscb-full', !!cfg.full);
      if (zoomFull) zoomFull.classList.toggle('on', !!cfg.full);
      // v3.2.3 缩放改用 transform 锚定右下角，并按浏览器窗口自适应钳制：
      // 放大后视觉尺寸 = 布局尺寸 × zoom，钳制保证不超出窗口（96vw / 92vh）
      if (cfg.full) {           // 全屏铺满窗口，忽略缩放/位置/自定义大小
        panel.style.transform = '';
        panel.style.maxWidth = '';
        panel.style.maxHeight = '';
        panel.style.left = ''; panel.style.top = '';
        panel.style.right = ''; panel.style.bottom = '';
        panel.style.width = '';
        return;
      }
      var z = cfg.zoom || 1;
      if (z !== 1) {
        panel.style.transform = 'scale(' + z + ')';
        panel.style.transformOrigin = 'bottom right';
        panel.style.maxWidth = Math.floor(96 / z) + 'vw';
        panel.style.maxHeight = Math.floor(92 / z) + 'vh';
      } else {
        panel.style.transform = '';
        panel.style.maxWidth = '';
        panel.style.maxHeight = '';
      }
    }
    if (zoomIn) zoomIn.onclick = function () {
      cfg.zoom = Math.min(2.0, Math.round(((cfg.zoom || 1) + 0.1) * 10) / 10);
      saveCfg(); applyZoom();
    };
    if (zoomOut) zoomOut.onclick = function () {
      cfg.zoom = Math.max(0.7, Math.round(((cfg.zoom || 1) - 0.1) * 10) / 10);
      saveCfg(); applyZoom();
    };
    if (zoomFull) zoomFull.onclick = function () {
      cfg.full = !cfg.full;
      saveCfg(); applyZoom();
      if (!cfg.full) restorePanelPos();   // v3.2.7 退出全屏恢复自定义位置/大小
      log(cfg.full ? '⛶ 已全屏：面板铺满大屏，方便看全局；再点 ⛶ 恢复小窗' : '回到小窗模式');
    };
    applyZoom();

    root.querySelector('.mscb-newdraft').onclick = function () {
      chrome.runtime.sendMessage({cmd:'xtNewApiOpenDraft'}).catch(function () { log('❌ 自建草稿页面未打开，请重新加载插件'); });
    };
    root.querySelector('.mscb-remembercat').onclick = function () {
      var selected = Array.from(items.values()).filter(function (v) { return v.sel !== false; });
      if (selected.length !== 1) { log('ℹ️ 请只勾选一个已核对模板的商品'); return; }
      var row = selected[0], key = xtCatalog.preferenceKey(catalogRow(row)), preset = presetOf(row.tplKey);
      if (!key || !preset) { log('⚠️ 需要一条有明确店铺、完整类目和可用模板的商品，先补采详情'); return; }
      cfg.catalogPreferences = Object.assign({}, cfg.catalogPreferences, { [key]: preset.name });
      saveCfg(); render();
      log('✅ 已记住本店此类模板「' + preset.name + '」，不影响其他店铺或类目。');
    };

    // ---------- v3.7.27 AI 自动匹配模板：混合类目商品逐个配模板，无预设时 AI 按类目自动建 ----------
    if (root.querySelector('.mscb-aimatch')) {
      root.querySelector('.mscb-aimatch').onclick = async function () {
        var btn = root.querySelector('.mscb-aimatch');
        if (busy || rerunning || repairBusy || envChecking) { log('⏳ 请等当前任务结束后再匹配模板'); return; }
        var sel = Array.from(items.values()).filter(function (v) { return v.sel !== false && v.title; });
        if (!sel.length) { log('ℹ️ 请先勾选要匹配模板的商品'); return; }
        btn.disabled = true;
        try {
          var ps = (cfg.tplPresets || []).map(function (p) {
            return { name: p.name, cats: p.cats || [], prompt: String(p.prompt || '').slice(0, 50) };
          });
          var assigned = 0, groups = {}, created = [];
          for (var g0 = 0; g0 < sel.length; g0 += 20) {
            var chunk = sel.slice(g0, g0 + 20);
            var listing = chunk.map(function (v, i) {
              return (i + 1) + '. ' + String(v.title).slice(0, 30) + (fullCategory(v) ? '｜类目：' + fullCategory(v).slice(0, 40) : '');
            }).join('\n');
            var sys = '你是跨境电商和国内电商通用的商品模板匹配助手。根据商品标题和类目，为每个商品选择最合适的模板。' +
              '只输出一个 JSON 对象，不要任何解释。';
            if (ps.length) {
              sys += '\n可选模板：\n' + ps.map(function (p) {
                return '- ' + p.name + (p.cats.length ? '（绑定类目：' + p.cats.join('/') + '）' : '') + (p.prompt ? '｜场景：' + p.prompt : '');
              }).join('\n') + '\n- 通用保真（不改动，安全兜底）\n输出格式：{"items":[{"i":序号,"tpl":"模板名"}]}，序号从 1 开始，没有合适模板就用"通用保真"。';
            } else {
              sys += '\n当前没有任何预设模板。请先把商品按类目分成若干组（如：圣诞木质摆件、3C数码配件、母婴用品），每组一套模板。' +
                '输出格式：{"items":[{"i":序号,"tpl":"组名"}],"newPresets":[{"name":"组名","prompt":"该类目商品的拍摄场景与画面建议，30字内，适合该平台的卖点风格","cats":["类目关键词1","关键词2"]}]}。';
            }
            var r = await chrome.runtime.sendMessage({ cmd: 'chat', messages: [{ role: 'system', content: sys }, { role: 'user', content: listing }] });
            if (!r || !r.ok) throw new Error('AI 请求失败：' + ((r && r.error) || '未知'));
            var j = null;
            try { j = JSON.parse(String(r.data).replace(/```json|```/g, '').trim()); } catch (eJ) {}
            if (!j || !Array.isArray(j.items)) throw new Error('AI 返回格式不对');
            // AI 建议的新模板先落库（无预设模式）
            if (Array.isArray(j.newPresets)) {
              cfg.tplPresets = cfg.tplPresets || [];
              j.newPresets.forEach(function (np) {
                if (!np || !np.name) return;
                var nm = String(np.name).slice(0, 20);
                if (cfg.tplPresets.some(function (p) { return p.name === nm; }) || nm === '通用保真') return;
                var base = JSON.parse(JSON.stringify(cfg.tpl || {}));
                base.imgMode = base.imgMode || 'keep';
                cfg.tplPresets.push({ name: nm, tpl: base, prompt: String(np.prompt || '').slice(0, 100), cats: Array.isArray(np.cats) ? np.cats.map(String).slice(0, 6) : [] });
                created.push(nm);
                ps.push({ name: nm, cats: [], prompt: String(np.prompt || '').slice(0, 50) });
              });
            }
            j.items.forEach(function (m) {
              var v = chunk[(m && m.i) - 1];
              if (!v) return;
              var t = String((m && m.tpl) || '').trim();
              if (t && t !== '通用保真') { v.tplManual = v.tplKey = t; assigned++; groups[t] = (groups[t] || 0) + 1; }
              else { v.tplManual = v.tplKey = ''; groups['通用保真'] = (groups['通用保真'] || 0) + 1; }
            });
          }
          saveCfg(); renderPresets(); render();
          var sum = Object.keys(groups).map(function (k) { return k + '×' + groups[k]; }).join('、');
          log('🤖 AI 已为 ' + sel.length + ' 个商品匹配模板' + (sum ? '：' + sum : '') + (created.length ? '（新建模板：' + created.join('/') + '）' : ''));
          catSay('🤖 喵！AI 帮你把 ' + sel.length + ' 个商品的模板都配好了' + (sum ? '（' + sum + '）' : '') + '，可以点启动了～');
        } catch (e) {
          log('❌ AI 自动匹配失败：' + String(e.message || e).slice(0, 100));
        } finally { btn.disabled = false; }
      };
    }

    // ---------- v2.6.0 模板预设：存多套 + 批量套给所选商品 ----------
    var presetNameIn = root.querySelector('.mscb-preset-name');
    var presetsEl = root.querySelector('.mscb-presets');
    var batchSel = root.querySelector('.mscb-batchsel');
    // 把当前勾选/固定值刷回 UI（应用预设后调用）
    function tplSyncUI() {
      root.querySelectorAll('.mscb-tpl-ck').forEach(function (ck) {
        ck.checked = !!(cfg.tpl && cfg.tpl[ck.getAttribute('data-k')]);
      });
      root.querySelectorAll('.mscb-imgmode').forEach(function (r) {   // v3.7.26 生图模式跟随
        r.checked = (cfg.tpl && (cfg.tpl.imgMode || 'keep')) === r.value;
      });
      var podRow = root.querySelector('.mscb-tpl-podrow');   // v3.7.69 改造幅度跟随
      if (podRow) podRow.style.display = ((cfg.tpl && (cfg.tpl.imgMode || 'keep')) === 'pod') ? 'flex' : 'none';
      var podlvSel = root.querySelector('.mscb-podlv');
      if (podlvSel) podlvSel.value = (cfg.tpl && cfg.tpl.podLevel) || 'mid';
      var stSel = root.querySelector('.mscb-tplstyle');   // v3.7.26 风格/模特设置跟随
      if (stSel) stSel.value = (cfg.tpl && cfg.tpl.style) || '';
      ['race', 'face', 'shot'].forEach(function (mk) {
        var ms = root.querySelector('.mscb-model-' + mk);
        if (ms && cfg.tpl && cfg.tpl.model) ms.value = cfg.tpl.model[mk] || '';
      });
      TPL_FIELDS.forEach(function (f) {
        var inp = fixedBox.querySelector('input[data-fk="' + f.k + '"]');
        if (inp) inp.value = (cfg.tpl && cfg.tpl.fixed && cfg.tpl.fixed[f.k]) || '';
      });
    }
    function renderPresets() {
      if (!presetsEl) return;
      presetsEl.innerHTML = '';
      (cfg.tplPresets || []).forEach(function (p) {
        var chip = document.createElement('span');
        chip.className = 'mscb-preset';
        var nm = document.createElement('b');
        nm.textContent = p.name + (p.builtin ? '（内置）' : '') + ((p.cats && p.cats.length) ? '·' + p.cats[0] + (p.cats.length > 1 ? '等' + p.cats.length + '类目' : '') : '');
        nm.title = (p.builtin ? '内置大类目模板，可改可删\n' : '') + (p.cats && p.cats.length ? '绑定类目：' + p.cats.join('/') + '\n' : '')
          + (p.prompt ? '提示词补充：' + p.prompt + '\n' : '') + '点应用这套模板';
        nm.style.cursor = 'pointer';
        nm.onclick = function () {
          cfg.tpl = JSON.parse(JSON.stringify(p.tpl));
          saveCfg(); tplSyncUI();
          log('🧩 已应用模板预设「' + p.name + '」（新商品默认用它）');
        };
        var del = document.createElement('span');
        del.className = 'px';
        del.textContent = '×';
        del.title = '删除这个预设';
        del.onclick = function (ev) {
          ev.stopPropagation();
          cfg.tplPresets = cfg.tplPresets.filter(function (x) { return x !== p; });
          saveCfg(); renderPresets(); render();
          log('🗑 已删除模板预设「' + p.name + '」（已套用的商品回落到默认模板）');
        };
        chip.appendChild(nm); chip.appendChild(del);
        presetsEl.appendChild(chip);
      });
      if (batchSel) {
        batchSel.innerHTML = '';
        var o0 = document.createElement('option');
        o0.value = '__def'; o0.textContent = '默认模板';
        batchSel.appendChild(o0);
        [xtCatalog.generic].concat(cfg.tplPresets || []).forEach(function (p) {
          var o = document.createElement('option');
          o.value = p.name; o.textContent = p.name;
          batchSel.appendChild(o);
        });
      }
    }
    if (root.querySelector('.mscb-preset-save')) {
      // v3.0.0 提示词试算预览
      var pvBtn = root.querySelector('.mscb-tpl-preview');
      if (pvBtn) pvBtn.onclick = function () { promptPreview().catch(function (e) { log('❌ 预览失败：' + (e && e.message ? e.message : e)); }); };
      var catsIn = root.querySelector('.mscb-preset-cats');
      var promptIn = root.querySelector('.mscb-preset-prompt');
      var autoCk = root.querySelector('.mscb-autotpl');
      if (autoCk) {
        autoCk.checked = cfg.autoTpl !== false;
        autoCk.onchange = function () { cfg.autoTpl = autoCk.checked; saveCfg(); };
      }
      root.querySelector('.mscb-preset-save').onclick = function () {
        var nm = (presetNameIn && presetNameIn.value || '').trim();
        if (!nm || nm === xtCatalog.generic.name) { log('❌ 请另填一个预设名，「通用保真」为系统保留项'); return; }
        var cats = (catsIn && catsIn.value || '').split(/[,，、\/>|]/).map(function (s) { return s.trim(); }).filter(Boolean);
        var prompt = (promptIn && promptIn.value || '').trim();
        if (cats.length && !prompt) log('ℹ️ 绑定了类目但没填提示词补充：该类目将沿用服务端默认提示词，只套模板勾选项');
        cfg.tplPresets = cfg.tplPresets || [];
        var exist = presetOf(nm);
        if (exist) { exist.tpl = JSON.parse(JSON.stringify(cfg.tpl)); exist.cats = cats; exist.prompt = prompt; }
        else cfg.tplPresets.push({ name: nm, tpl: JSON.parse(JSON.stringify(cfg.tpl)), cats: cats, prompt: prompt });
        saveCfg();
        if (presetNameIn) presetNameIn.value = '';
        renderPresets(); render();
        log('💾 模板预设「' + nm + '」已保存' + (cats.length ? '（绑定类目：' + cats.join('/') + '）' : '') + (prompt ? '（提示词补充已带上）' : '') + '；列表每行下拉可选用，勾选后可批量套用');
        if (cats.length && cfg.autoTpl !== false) { autoTplAssign(); catSay('🧩 喵！已记住「' + nm + '」绑定的类目，新采集的商品我会自动帮它套上～'); }
      };
    }
    if (root.querySelector('.mscb-batchok')) {
      root.querySelector('.mscb-batchok').onclick = function () {
        if (!batchSel) return;
        var k = batchSel.value === '__def' ? '' : batchSel.value;
        var n = 0;
        items.forEach(function (v) { if (v.sel !== false) { v.tplManual = v.tplKey = k; n++; } });
        render();
        log(n ? '🧩 已把「' + (k || '默认模板') + '」套给所选 ' + n + ' 个商品（建单时按模板自动分组）'
              : 'ℹ️ 没有勾选任何商品，先勾再套');
      };
    }

    // ---------- v2.6.0 结果区大按钮：全部预览 / 一键上传并跑 RPA ----------
    if (resBtnsEl) {
      resBtnsEl.querySelector('.mscb-rprev').onclick = function () { openPreview(null); };
      resBtnsEl.querySelector('.mscb-rrpa').onclick = function () { if (localRunMode) localPublishNow(); else rpaFromCheck(); };   // v3.7.87 本地模式走发布当前
      // v3.4.6 导出已转换表格：让服务器生成 48 列导入表（图链已换成洗好的图）并下载，导入前可核对
      resBtnsEl.querySelector('.mscb-rcsv').onclick = async function () {
        var base = washBaseOf();
        var code = String(cfg.code || '').trim();
        if (!base || !code) { log('❌ 先在面板里填好洗图台地址和口令'); needSetup(); return; }
        var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code)
          + '&sharecode=' + encodeURIComponent(String(cfg.share || ''));
        try {
          log('📤 生成已转换表格（48 列，图链已是洗好的图）…');
          var info = await relay(base + '/api/csv?' + auth, { base: imgBaseNorm(cfg.imgBase) || IMG_BASE_DEFAULT, share: String(cfg.share || ''), partial: true });
          if (!info || !info.ok) throw new Error((info && info.error) || '生成失败');
          var csvText = await relayText(base + '/api/download-csv?' + auth, 'GET');
          if (!csvText || csvText.indexOf(',') < 0) throw new Error('表格内容为空');
          var blob = new Blob(['\ufeff' + csvText], { type: 'text/csv;charset=utf-8' });
          var a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = info.name || '已转换表格.csv';
          document.body.appendChild(a); a.click(); a.remove();
          log('✅ 已下载 ' + a.download + '（下载目录），可用 Excel 打开核对图片链接列');
        } catch (e) {
          log('❌ 导出失败：' + ((e && e.message) || e));
        }
      };
      // v3.7.63 本机直连：导出本单已生成的 48 列导入表（直连导入失败时手动拖进妙手）
      var lexpBtn = resBtnsEl.querySelector('.mscb-lcsv');
      if (lexpBtn) lexpBtn.onclick = function () { exportLocalRows(); };
    }
    // v3.7.63 运行日志一键导出：把缓冲里最近 1200 条（带完整时间戳）存成 txt，发给技术支持即可定位问题
    var skipBtn = root.querySelector('.mscb-skip');
    if (skipBtn) skipBtn.onclick = function () {
      if (!busy) { log('ℹ️ 当前没在跑单，不需要跳过'); return; }
      xtSkipFlag = true;
      log('⏭ 已请求跳过：当前卡住的批次等待会立即放行（未返回的图按跳过处理，稍后可补图）');
    };
    // ---------- v3.7.74 内嵌帮助 + 新手引导 ----------
    var HELP_HTML = [
      '<h2>🐱 洗图猫 · 图文帮助</h2>',
      '<p>遇到问题先看最下面的「常见问题」，还解决不了点 <kbd>📋 导出日志</kbd> 把 txt 发给技术支持。</p>',
      '<h2>一、装好插件后先做 3 件事（只需一次）</h2>',
      '<ol>',
      '<li><b>打开设置页</b>：点面板里的 <kbd>接口设置 / 连接 New API</kbd>。</li>',
      '<li><b>连接生图（二选一）</b>：<br>① <b>竞速模式（推荐）</b>：站点池页签 → <kbd>📥 导入站点 JSON</kbd>（选管理员发给你的站点池文件）→ 等自动读取模型 → <kbd>保存站点池</kbd>；<br>② <b>自己的 API</b>：填 Base URL（一般以 /v1 结尾）+ API Key（sk- 开头）→ 读取模型 → 选择模型 → 保存。<br>选了站点池就不用再填生图 API；改标题模型（DeepSeek）是可选的，不填也能出图。</li>',
      '<li><b>连接改标题模型</b>（DeepSeek 等对话模型）：填地址和 Key → 点 <kbd>测试</kbd> 能返回文字 → 保存。<b>不连的话标题保持原样、英文标题是空的。</b></li>',
      '</ol>',
      '<h2>二、日常跑单（每次都这么做）</h2>',
      '<ol>',
      '<li><b>采集商品</b>：妙手采集箱正常采集，面板会按页面顺序抓到列表，勾掉不想洗的。</li>',
      '<li><b>选模板参数</b>：每品出图（<b>5张·省费</b>常用；10张=全套）；裂变 1=不裂变；改中文/英文标题按需勾；生图模式「原样复刻」保原样 /「POD改造」做成新品（选 POD 后可挑改造幅度：<b>强改造=和原图拉开差距</b>）。改完会记住。</li>',
      '<li><b>点「启动」</b>：进度条和日志实时走（每张图：链接/第几张/站点/耗时/大小），跑完自动上传妙手并提交导入。</li>',
      '<li><b>核对</b>：结果区 🆚 看对比图、💬 看提示词，商品已在妙手采集箱等着上架。</li>',
      '</ol>',
      '<h2>三、实用按钮速查</h2>',
      '<table><tr><th>按钮</th><th>什么时候用</th></tr>',
      '<tr><td><kbd>⏭ 跳过等待</kbd></td><td>某链接卡住不想等：点一下立即放行继续，没返回的图稍后补，不影响已出图的导入。</td></tr>',
      '<tr><td><kbd>🩹 补图 / 补失败图</kbd></td><td>某链接图没出全：只补缺的，已出的不重复扣费，补完自动重新提交导入。</td></tr>',
      '<tr><td><kbd>📤 导出导入表</kbd></td><td>自动导入一直失败时的兜底：下载表格，在妙手「导入 → 导出妙手产品再导入」手动拖入。</td></tr>',
      '<tr><td><kbd>历史任务 · 继续</kbd></td><td>中途刷新/关浏览器后：从快照续跑，已出图的复用，不重复扣费。</td></tr>',
      '<tr><td><kbd>📋 导出日志</kbd></td><td>遇到任何问题：导出带时间戳的日志发技术支持，一秒定位。</td></tr></table>',
      '<h2>四、常见问题（点开看答案）</h2>',
      '<details><summary>提示「读不到导入配置 / NO_SETTING」</summary><p>新账号第一次会这样，照这个顺序一次就能通：① 点面板右上角 <kbd>📤 导出导入表</kbd> 导出一份空白模板；② 到妙手采集箱「导入 → 导出妙手产品再导入」页签把这份模板拖入；③ <b>不用等导入成功</b>，回采集页刷新一下；④ 面板点「新任务开始」即可全链路跑通。之后本机永久存档，全自动不再提示。</p></details>',
      '<details><summary>英文标题是空的</summary><p>① 模板里勾了「生成英文标题」吗（跑单日志开头有播报）；② 改标题模型连了吗、测试能返回文字吗；③ 那条链接导入成功了吗——导入失败的不会回填标题，先解决导入再补。</p></details>',
      '<details><summary>图片空间容量不足（30013）</summary><p>妙手图片空间满了：删掉不用的图片，或把「每品出图」调小（如 5 张）。</p></details>',
      '<details><summary>生图慢 / 等很久</summary><p>竞速单张上限 420 秒，等不及点 <kbd>⏭ 跳过等待</kbd>；经常慢就把日志发给技术支持排查提速。</p></details>',
      '<details><summary>SKU 颜色图和主图一样</summary><p>数量/尺寸型规格沿用主图属正常省费；颜色/款式型会按每个 SKU 特点单独生图。全用了主图说明生成失败走了兜底，点「补图」重试。</p></details>',
      '<details><summary>POD 模式出的图和原图太像</summary><p>改造幅度选 <kbd>强改造</kbd>：图案主题重新设计，和原图明显不同；太夸张退回「标准改造」。</p></details>',
      '<details><summary>想看 AI 收到的完整提示词</summary><p>跑完后在结果区点某张图的 💬 按钮。</p></details>',
      '<div class="warn"><b>升级插件版本</b>：务必解压覆盖到原来的文件夹（路径不能变），再到 chrome://extensions 点「重新加载」——换新文件夹会丢历史任务。</div>',
      '<div class="tip"><b>省钱小抄</b>：每品出图 5 张 · 不裂变 · 沿用主图的规格不扣费 · 中断用历史任务续跑不重复扣费。</div>'
    ].join('');
    function openSheet(html) {
      // v3.7.84 修复：openSheet 的遮罩改用独立类 mscb-sheetmask——
      // 之前为了让帮助弹窗可见，把 .mscb-mask 全局改成 display:flex，
      // 结果把所有靠 .open 控制显隐的弹窗（修改建议/完成/报错/预览等）全部强制可见，
      // 客户看到「修改建议一直卡在屏幕上关不掉」就是这个原因
      document.querySelectorAll('.mscb-sheetmask').forEach(function (m0) { m0.remove(); });
      var mask = document.createElement('div');
      mask.className = 'mscb-mask mscb-sheetmask';
      var sheet = document.createElement('div');
      sheet.className = 'mscb-sheet';
      sheet.innerHTML = html;
      mask.appendChild(sheet);
      document.body.appendChild(mask);
      mask.addEventListener('click', function (ev) { if (ev.target === mask) mask.remove(); });
      return sheet;
    }
    root.querySelector('.mscb-helpbtn').onclick = function () { openSheet(HELP_HTML); };
    // v3.7.88 在线更新：v3.7.92 起写死更新地址（GitHub+jsDelivr，国内一般可直连；
    // 客户 cfg.updateUrl 仍可覆盖），update.json 格式见插件导出目录示例
    var XT_UPDATE_URL = 'https://cdn.jsdelivr.net/gh/qq499797400-cpu/ximao-updates@main/update.json';
    try { XT_UPDATE_URL = String(cfg.updateUrl || '').trim(); } catch (eUU) {}
    function xtVerNum(v) {
      var a = String(v || '').split('.').map(function (x) { return parseInt(x, 10) || 0; });
      while (a.length < 3) a.push(0);
      return a[0] * 1000000 + a[1] * 1000 + a[2];
    }
    async function xtCheckUpdate(manual) {
      if (!XT_UPDATE_URL) { if (manual) log('ℹ️ 在线更新还没接入：等服务器域名就绪后由新版插件写死更新地址，到时点这个按钮即可检查并自动下载新版'); return; }
      if (manual) log('🔄 正在检查更新…');
      var r = await new Promise(function (res) { chrome.runtime.sendMessage({ cmd: 'xtCheckUpdate', url: XT_UPDATE_URL }, function (rr) { res(rr || { ok: false, error: '后台无响应' }); }); });
      if (!r || !r.ok) { if (manual) log('❌ 检查更新失败：' + ((r && r.error) || '网络不通')); return; }
      var d = r.data || {};
      var curV = chrome.runtime.getManifest().version;
      if (xtVerNum(d.version) <= xtVerNum(curV)) { if (manual) log('✅ 已是最新版本 v' + curV + '，无需更新'); return; }
      log('🆕 发现新版本 v' + d.version + (d.note ? '：' + String(d.note).slice(0, 60) : ''));
      if (!window.confirm('发现新版本 v' + d.version + (d.note ? '\n更新内容：' + d.note : '') + '\n\n点「确定」自动下载新版压缩包（存到 下载/洗图猫/ 文件夹）\n下载后 3 步升级：解压覆盖原来的插件文件夹 → chrome://extensions 点「重新加载」→ F5 刷新妙手页面')) return;
      chrome.runtime.sendMessage({ cmd: 'download', url: d.zip, filename: '洗图猫-v' + d.version + '-客户版.zip' });
      log('⬇️ 新版压缩包已开始下载到「下载/洗图猫/」——解压覆盖原插件文件夹 → chrome://extensions 点「重新加载」→ F5 刷新页面，升级完成');
    }
    root.querySelector('.mscb-updbtn').onclick = function () { xtCheckUpdate(true); };
    if (XT_UPDATE_URL) { setTimeout(function () { xtCheckUpdate(false); }, 8000); setInterval(function () { xtCheckUpdate(false); }, 6 * 3600 * 1000); }   // 自动检查：首开 8s 一次，之后每 6 小时
    // v3.7.74 新手引导：首次安装自动弹，走完或跳过后记住不再弹；引导里自动检测连接状态
    async function obCheck() {
      try {
        var s = await chrome.runtime.sendMessage({ cmd: 'xtNewApiStatus' });
        return !!(s && s.ok && s.data && s.data.connected);
      } catch (e) { return false; }
    }
    async function maybeOnboard() {
      if (cfg.onboarded) return;
      var step = 0, sheet = null, live = null;
      var STEPS = [
        { t: '👋 欢迎使用洗图猫', h: '<p>我是你的洗图助手，跟着我 4 步就能跑通第一单（全程大约 3 分钟）：</p><ol><li>绑定生图（站点池竞速 或 你自己的 API）</li><li>绑定改标题模型（DeepSeek 等）</li><li>测试接口</li><li>跑第一单</li><p style="margin:6px 0 0">点「下一步」开始。随时可以点左下角「跳过引导」，之后点面板 <kbd>❓ 帮助</kbd> 随时回来看教程。</p></ol>' },
        { t: '① 绑定生图（二选一）', h: function () {
            return '<p><b>方式 A：竞速站点池（推荐，多站自动比速）</b></p><ol><li>点面板 <kbd>接口设置</kbd> → 「站点池」页签</li><li>点 <kbd>📥 导入站点 JSON</kbd>，选发给你的站点池文件</li><li>等自动读完模型（每站会自动选好可用模型）</li><li>点 <kbd>保存站点池</kbd></li></ol><p><b>方式 B：自己的 API</b></p><ol><li>「连接」页填 Base URL（一般以 /v1 结尾）+ API Key（sk- 开头）</li><li>点「读取模型」→ 选模型 → <kbd>保存</kbd></li></ol><p id="mscb-ob-live">正在检测连接状态…</p>';
          } },
        { t: '② 绑定改标题模型（可选） + ③ 测试接口', h: '<p><b>改标题模型</b>（改中文标题/生成英文标题用，<b>不填也能正常出图</b>，只是标题保持采集原样）：</p><ol><li>「接口设置」里填 DeepSeek 等对话模型的地址和 Key</li><li>点 <kbd>测试</kbd> —— 能返回一段文字就是通的</li><li><kbd>保存</kbd></li></ol><p>只配了站点池、没填 DeepSeek 也能点「验证并保存连接」，不会被拦。</p>' },
        { t: '④ 跑第一单', h: '<p>回妙手采集箱：</p><ol><li>勾选几个商品（建议先 2~3 个试水）</li><li>模板里把「每品出图」选 <kbd>5张·省费</kbd>（先跑通再加量）</li><li>点 <kbd>启动</kbd> —— 进度条和日志实时走，跑完自动上传并导入妙手</li><li>跑完在结果区点 🆚 看对比、💬 看提示词</li></ol><p>中途卡住点 <kbd>⏭ 跳过等待</kbd>，图没出全点 <kbd>🩹 补图</kbd>，有疑问点 <kbd>❓ 帮助</kbd>。</p><div class="tip">搞定后点「我搞定了，开始用」关闭本引导。</div>' }
      ];
      function render() {
        var st = STEPS[step];
        var body = typeof st.h === 'function' ? st.h() : st.h;
        sheet.innerHTML = '<div class="ob-step">新手引导 · 第 ' + (step + 1) + '/' + STEPS.length + ' 步（<span style="cursor:pointer;text-decoration:underline" id="mscb-ob-skip2">跳过引导</span>）</div>' +
          '<h2>' + st.t + '</h2>' + body +
          '<div class="ob-btns"><button type="button" class="ob-skip" id="mscb-ob-skip">跳过引导，以后再说</button>' +
          (step > 0 ? '<button type="button" class="ob-btn" id="mscb-ob-prev">上一步</button>' : '') +
          '<button type="button" class="ob-btn primary" id="mscb-ob-next">' + (step === STEPS.length - 1 ? '✅ 我搞定了，开始用' : '下一步 →') + '</button></div>';
        sheet.querySelector('#mscb-ob-next').onclick = function () {
          if (step === STEPS.length - 1) { cfg.onboarded = true; saveCfg(); sheet.closest('.mscb-mask').remove(); log('🎉 新手引导完成！随时点「❓ 帮助」回看教程'); return; }
          step++; render();
        };
        var pv = sheet.querySelector('#mscb-ob-prev');
        if (pv) pv.onclick = function () { step--; render(); };
        sheet.querySelector('#mscb-ob-skip').onclick = skipAll;
        var sk2 = sheet.querySelector('#mscb-ob-skip2');
        if (sk2) sk2.onclick = skipAll;
        if (step === 1) {
          live = sheet.querySelector('#mscb-ob-live');
          var pollN = 0;
          var obPoll = setInterval(function () {   // 每 3s 复检，绑定保存后提示自动变绿；面板关了自动停
            if (!document.body.contains(sheet)) { clearInterval(obPoll); return; }
            pollN++;
            obCheck().then(function (ok) {
              if (!document.body.contains(live)) { clearInterval(obPoll); return; }
              if (ok || pollN > 60) {
                clearInterval(obPoll);
                live.innerHTML = ok
                  ? '<span class="ob-ok">✅ 检测到生图已连接——这步已完成，直接点「下一步」。</span>'
                  : '<span class="ob-no">⏳ 还没检测到连接：按上面任一方式绑定并保存；不想现在弄就点「跳过引导」。</span>';
              }
            });
          }, 3000);
        }
      }
      function skipAll() { cfg.onboarded = true; saveCfg(); sheet.closest('.mscb-mask').remove(); log('ℹ️ 已跳过新手引导：之后点「❓ 帮助」随时看教程'); }
      sheet = openSheet('<div style="text-align:center;color:#8a97a8">加载中…</div>');
      render();
    }
    setTimeout(maybeOnboard, 800);
    var logDl = root.querySelector('.mscb-logdl');
    if (logDl) logDl.onclick = function () {
      if (!logBuf.length) { log('ℹ️ 还没有日志可导（先跑一次或等面板输出日志）'); return; }
      var head = ['洗图猫运行日志', '导出时间：' + logBufTs(), '扩展版本：' + (chrome && chrome.runtime && chrome.runtime.getManifest ? chrome.runtime.getManifest().version : '未知'),
        '页面：' + location.href, '浏览器：' + navigator.userAgent, '日志条数：' + logBuf.length, ''.padEnd ? '──────────────' : '---', ''];
      var text = head.concat(logBuf).join('\r\n');
      var blob = new Blob(['\ufeff' + text], { type: 'text/plain;charset=utf-8' });
      var a = document.createElement('a');
      var d = new Date(), pd = function (x) { return (x < 10 ? '0' : '') + x; };
      a.href = URL.createObjectURL(blob);
      a.download = '洗图猫日志_' + d.getFullYear() + pd(d.getMonth() + 1) + pd(d.getDate()) + '_' + pd(d.getHours()) + pd(d.getMinutes()) + '.txt';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 8000);
      log('📄 已导出 ' + a.download + '（' + logBuf.length + ' 条日志），把这个文件发给技术支持即可');
    };
    // 预览弹窗关闭
    var pvMask = document.querySelector('.mscb-pvmask');
    if (pvMask) {
      pvMask.querySelector('.mscb-pv-x').onclick = function () { pvMask.classList.remove('open'); };
      var pvRe = pvMask.querySelector('.mscb-pv-reload');
      if (pvRe) pvRe.onclick = function () {
        var n = 0;
        Array.prototype.forEach.call(pvMask.querySelectorAll('.mscb-pvgrid img[data-pid]'), function (im) {
          if (im.style.display !== 'none') return;
          var pid = im.getAttribute('data-pid'), idx = Number(im.getAttribute('data-idx'));
          if (isNaN(idx)) return;
          var u = washImgUrl(pid, idx);
          delete imgBad[u];
          var box = im.parentNode.querySelector('.mscb-pvmiss');
          if (box) { box.style.display = 'none'; box.onclick = null; box.innerHTML = '⏳ 生成中/未生成'; }
          im.style.display = '';
          im.src = bustUrl(u);
          n++;
        });
        log(n ? '🔄 正在重新加载 ' + n + ' 张没显示出来的图…' : 'ℹ️ 所有图都已正常显示，无需重载');
      };
    }
    // v3.7.84 「修改建议」弹窗整体移除（DOM+函数+绑定全删），不会再出现也无需绑定

    // 自动补详情：抓到列表后把缺图/缺标题的补齐（只补数据，不启动任何流程）
    var autoTimer = setInterval(function () {
      if (!cfg.autoDetail) return;
      if (!items.size) return;
      var need = 0;
      items.forEach(function (v) { if ((!v.imgs || v.imgs.length < 3) || !v.title) need++; });
      if (!need || need > 120) return;
      clearInterval(autoTimer);
      fillDetails();
    }, 4000);

    renderPresets();
    applyModeSafe();
  }

  /* ---------------- 接收页面钩子的列表数据 ---------------- */
  window.addEventListener('message', function (ev) {
    if (ev.source !== window) return;
    var d = ev.data;
    if (!d || d.source !== 'ms-ai-hook') return;
    // v3.7.66 自愈存档：页面自己提交导入任务时截获完整 setting，存档后全自动直连永久可用
    if (d.importSetting && String(d.importSetting).length > 2) {
      try {
        chrome.storage.local.set({ xtSettingTpl: String(d.importSetting) });
        log('🛰 已存档妙手导入配置（刚才这次导入的完整配置）——本机之后全自动直连，不再需要任何手动步骤');
      } catch (eS) {}
    }
    // v3.7.66 店铺接口探测：存最近一次店铺清单响应，供诊断/识别 shopIds
    if (d.shopProbe && d.shopProbe.text) {
      try { chrome.storage.local.set({ xtShopProbe: { url: d.shopProbe.url, text: d.shopProbe.text, at: d.shopProbe.at } }); } catch (eP) {}
    }
    // 编辑页详情整包（hook v2.2.7 起带全字段）：被动捕获合并进 raw，回去列表页直接可用
    if (d.detailId && d.info && typeof d.info === 'object') {
      if (applyDetail(d.detailId, d.info)) render();
      return;
    }
    if (!d.list || !d.list.items) return;
    if (d.list.url && d.list.url !== lastListUrl) {
      lastListUrl = d.list.url;
      log('🛰 页面接口：' + d.list.url.replace(/^https?:\/\/[^/]+/, ''));
    }
    var n = ingest(d.list.items);
    if (n) {   // v3.2.7 跟随式抓取：页面自己加载多少就记录多少，实时刷新面板
      render();
      setStat('🛰 跟随模式：已记录 ' + items.size + ' 个链接（滑到哪抓到哪）');
      // v3.7.26 翻页/切换筛选自动跟随：新商品进来后去抖 2.5 秒自动补齐详情（POST 同接口 URL 不变，靠新商品触发）
      if (!busy && !rerunning && !autoGrabbing) {
        clearTimeout(passiveFillTimer);
        passiveFillTimer = setTimeout(async function () {
          if (busy || rerunning || autoGrabbing) return;
          autoGrabbing = true;
          try {
            var needN = 0;
            items.forEach(function (v) { if (v.title && (!v.raw || !v.imgs || v.imgs.length < 1)) needN++; });
            if (needN) {
              log('🛰 检测到新页/筛选商品（' + needN + ' 个待补详情），自动补齐…');
              await fillDetails();
              render();
              log('✅ 新页商品已自动补齐详情，可继续勾选跑单');
            }
          } catch (e) {
            log('⚠️ 自动补详情失败：' + String(e && e.message || e).slice(0, 80) + '（可点「🔄 补采集」）');
          } finally { autoGrabbing = false; }
        }, 2500);
      }
    }
  });

  var built = false, rootEl = null;

  // 面板在所有妙手页面常驻；但「自动采集」只在采集箱页做（别的页没有列表数据可抓）
  function isCollectPage() {
    return true;
  }
  function onCollectPage() {
    return /collect_box/i.test(location.pathname);
  }

  // v3.4.9 页面刷新后自动恢复任务进度：任务状态本来就在洗图台服务器上，
  // 只要插件重新拉一次 /api/status，就能把结果区/进度/按钮原样重建出来
  async function restoreWash() {
    try {
      var base = washBaseOf(), code = String(cfg.code || '').trim();
      if (!base || !code) return;
      var auth = 'code=' + encodeURIComponent(code) + '&admin=' + encodeURIComponent(code);
      var st = await statusSafe(base + '/api/status?' + auth, {});
      if (!st || !st.products || !st.products.length) return;
      wash.on = true;   // v3.6.2 服务端有单就点亮结果区，否则 washRender 直接 return（刷新后结果区空白的真凶）
      washSync(st, { silentComplete: true }); washRender(); washTimeLine();
      log('💾 已恢复上一单进度：' + (st.status === 'done' ? '✅ 已完成' : settledWash(st) ? '⚠️ 已结束，待补图' : '🏃 进行中') + ' '
        + washDoneSum() + '/' + (st.planImgs || wash.plan || 0) + ' 张'
        + (wash.done ? '——导出表格/一键上传按钮照常可用' : '，跑完自动更新'));
      if (!settledWash(st)) { paused = !!st.paused; startWashMonitor({ readOnly: true }); }
      else if (missingWashProducts().length) { if (progEl) progEl.classList.add('show'); setProg(Math.round(100 * washDoneSum() / Math.max(1, wash.plan)), washTerminalText(), true); }
    } catch (e) { /* 洗图台没连上就静默，不打扰 */ }
  }

  // 妙手是单页应用：脚本常驻，先恢复配置再建面板（不销毁，切页复用已抓的数据）
  function sync() {
    var on = isCollectPage();
    if (on && !built) {
      loadCfg(function () {
        migrateCfg();
        // 模板结构兜底：老版本配置里没有 tpl 时补默认值
        if (!cfg.tpl || typeof cfg.tpl !== 'object') cfg.tpl = {};
        cfg.tpl.img = cfg.tpl.img !== false;
        cfg.tpl.zh = cfg.tpl.zh !== false;
        cfg.tpl.en = !!cfg.tpl.en;
        cfg.tpl.attrs = cfg.tpl.attrs !== false;
        if (cfg.tpl.imgMode !== 'pod') cfg.tpl.imgMode = 'keep';   // v3.7.26 生图模式兜底
        if (!cfg.tpl.model || typeof cfg.tpl.model !== 'object') cfg.tpl.model = { race: '', face: '', shot: '' };   // v3.7.26 模特设置兜底
        ['race', 'face', 'shot'].forEach(function (mk) { if (cfg.tpl.model[mk] === undefined) cfg.tpl.model[mk] = ''; });
        if (!cfg.tpl.style) cfg.tpl.style = '';   // v3.7.26 画面风格兜底
        if (!cfg.tpl.fixed || typeof cfg.tpl.fixed !== 'object') cfg.tpl.fixed = {};
        if (cfg.mode !== 'semi' && cfg.mode !== 'auto' && cfg.mode !== 'single') cfg.mode = 'auto';
        // v2.6.0：检查模式默认开；模板预设列表兜底
        if (cfg.check === undefined) cfg.check = true;
        if (!Array.isArray(cfg.tplPresets)) cfg.tplPresets = [];
        // v3.1.0 内置大类目：一个预设都没有时种入（用户删光 = 明确不要，不复活；自己建过则不打扰）
        if (!cfg.tplPresets.length) {
          cfg.tplPresets = BUILTIN_PRESETS.map(function (p) { return JSON.parse(JSON.stringify(p)); });
          log('🧩 已内置 6 个大类目模板（圣诞节日/3C数码/家居家具/母婴玩具/服装配饰/户外运动），可改可删；其余类目使用通用保真');
        }
        // v2.7.0：打分记录 / 速度采样 / 缩放 兜底
        if (!cfg.ratings || typeof cfg.ratings !== 'object') cfg.ratings = {};
        ratingsByPid = cfg.ratings;   // 直接引用同一对象，改打分即自动持久化
        if (!Array.isArray(cfg.speedLog)) cfg.speedLog = [];
        if (!(cfg.zoom > 0)) cfg.zoom = 1;
        if (cfg.full === undefined) cfg.full = false;   // v2.7.1 全屏状态
        if (!cfg.notes || typeof cfg.notes !== 'object') cfg.notes = {};
        noteByPid = cfg.notes;   // v2.7.1：修改建议直接引用持久化对象
        // v2.8.0：经营看板记录 + 余额预警阈值兜底
        if (!Array.isArray(cfg.runLog)) cfg.runLog = [];
        if (!(cfg.lowBal > 0)) cfg.lowBal = 10;

        try { build(); } catch (eB) { try { console.error('[洗图猫] build异常（已阻止反复重建）', eB); } catch (e2) {} }   // v3.7.26 安全网
        rootEl = document.querySelector('.mscb-root');
        built = true;
        dashRender();   // v2.8.0：打开面板就显示今日经营小看板
        // 旧工作台不在直连版验证副本中恢复。

        // v3.4.1 进页面就自动按采集页数量抓取（页面显示 500/页 就抓 500），抓完自动补详情；
        // 之后客户翻页/下滑时页面自己加载的仍由 hook 被动继续记录，主动抓取只在进页和「补采集」时发生
        if (onCollectPage()) {
          setStat('正在按当前页数量自动采集…');
          log('🛰 进页面自动采集：按当前页数量抓取（每页大小优先读页面真实参数，不再有 100 上限）');
          (async function () {
            try {
              var n = await pull(true);
              await fillDetails();
              setStat('已捕获 ' + items.size + ' 个商品（已选 ' + selCount() + ' 个）');
              log('✅ 自动采集完成：' + (n || items.size) + ' 个商品，详情已补齐，选好模式点「启动」即可');
            } catch (e) {
              setStat('自动采集失败：' + (e && e.message ? e.message : e) + '；可点「🔄 补采集」重试');
            }
          })();
        } else {
          setStat('当前页面不能采集列表；进「产品采集 → 公用采集箱」会自动按页数量采集');
        }
      });
    }
    // v3.7.26 翻页/筛选自动重采：hook 捕获到新的列表请求（客户翻页/切筛选/搜索）时自动重抓当前页
    if (on && built && !busy && !rerunning && !autoGrabbing && lastListUrl && lastGrabSig && lastListUrl !== lastGrabSig) {
      autoGrabbing = true;
      log('🛰 检测到翻页/筛选变化，自动重新采集当前页…');
      (async function () {
        try {
          var n = await pull(true);
          await fillDetails();
          render();
          log('✅ 自动重采完成：' + (n || items.size) + ' 个商品（新页商品已进入列表，可继续勾选跑单）');
        } catch (e) {
          log('⚠️ 自动重采失败：' + String(e && e.message || e).slice(0, 80) + '（可点「🔄 补采集」）');
        } finally { autoGrabbing = false; }
      })();
    }
    if (rootEl) rootEl.style.display = on ? '' : 'none';
  }

  function boot() {
    sync();
    setInterval(sync, 1200);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
