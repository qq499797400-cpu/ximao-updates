'use strict';
const XT_API='https://api.jaykou.com/v1';
const XT_DS='https://api.deepseek.com';
const XT_DS_MODEL='deepseek-flash';
const XT_IMAGE='gpt-image-2-5-pool';
const xtKeyError={401:'New API 令牌无效，请重新绑定。',402:'New API 额度不足。',403:'New API 拒绝请求，请检查令牌权限或账户额度。',429:'New API 当前限流，请稍后重试。'};
function xtOwnerSettings(sender, runtime){
 return sender.id===runtime.id&&sender.url===runtime.getURL('newapi-settings.html');
}
function xtLocalStore(){
 // The keys live at the extension origin, not in ERP-origin storage or a content script.
 let opened;
 return async (mode,value)=>{
  if(!opened)opened=new Promise((resolve,reject)=>{
   const q=indexedDB.open('xitumao-newapi-connection',1);
   q.onupgradeneeded=()=>q.result.createObjectStore('settings');
   q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);
  }).catch(e=>{opened=null;throw e;});
  const db=await opened;
  return new Promise((resolve,reject)=>{
   const tx=db.transaction('settings',mode==='get'?'readonly':'readwrite'),os=tx.objectStore('settings');
   const req=mode==='get'?os.get('connection'):mode==='clear'?os.delete('connection'):os.put(value,'connection');
   tx.oncomplete=()=>resolve(req.result);
   tx.onerror=tx.onabort=()=>reject(tx.error);
  });
 };
}
function xtNewApi(store=xtLocalStore(),request=(...args)=>fetch(...args)){
 const sharedText=id=>!/(?:image|flux|imagen|dall.e|video|veo|sora|suno|audio|whisper|tts|embedding|rerank|moderation|seedance|banana|^sd-|^wan-)/i.test(id);
 // v3.7.22 支持自定义生图网关（如付费 QA 网关）：https 标准端口，自动补 /v1
 function normBase(u){
  if(typeof u!=='string'||!u.trim())return XT_API;
  let url;try{url=new URL(u.trim());}catch{throw Error('生图网关地址无效。');}
  if(url.protocol!=='https:'||url.username||url.password||url.port)throw Error('生图网关必须是 https 标准端口的地址。');
  if(!/\/v1\/?$/.test(url.pathname))url.pathname=url.pathname.replace(/\/+$/,'')+'/v1';
  return url.origin+url.pathname.replace(/\/+$/,'');
 }
 const gateName=base=>base===XT_DS?'DeepSeek':(base===XT_API?'Jaykou':'生图网关');
 // ===== v3.7.30 站点池：平滑加权轮询 + 故障切换 + 冷却 =====
 const xtPoolCd={},xtPoolStat={},xtPoolCur={};
 // v3.7.55 拆成「全部站点」与「启用站点」两层：面板要显示关掉的站，否则用户再也打不开，再保存就永久丢失
 function xtPoolNorm(s){
  return {name:String(s.name||new URL(s.base).host),base:s.base,key:s.key,model:s.model||XT_IMAGE,
   weight:Math.max(1,Number(s.weight)||1),on:s.on!==false,cost:Number(s.cost)||0,spoofOrigin:s.spoofOrigin||'',note:s.note||'',
   req:(s.req||s.format||'').startsWith('json')?'json':'form',outFmt:s.outFmt||'',outComp:Number(s.outComp)||70,conc:Number(s.conc)||0};
 }
 function xtPoolAll(conn){
  if(conn&&conn.poolOn===false)return [];
  const preset=(typeof XT_POOL_PRESET!=='undefined'&&Array.isArray(XT_POOL_PRESET))?XT_POOL_PRESET:[];
  const list=(Array.isArray(conn?.pool)&&conn.pool.length)?conn.pool:preset;
  return list.filter(s=>s&&typeof s.base==='string'&&typeof s.key==='string').map(xtPoolNorm);
 }
 function xtPoolList(conn){
  return xtPoolAll(conn).filter(s=>s.on!==false);
 }
 function xtPoolPick(list){
  // 平滑加权轮询：权重状态必须按站点名持久化（每次 xtPoolList 都是新对象）
  const now=Date.now(),alive=list.filter(s=>(xtPoolCd[s.name]||0)<=now),use=alive.length?alive:list;
  let total=0,pick=null,pickCur=-Infinity;
  for(const s of use){
   const c=(xtPoolCur[s.name]||0)+s.weight;
   xtPoolCur[s.name]=c;total+=s.weight;
   if(c>pickCur){pickCur=c;pick=s;}
  }
  xtPoolCur[pick.name]=pickCur-total;
  return pick;
 }
 function xtPoolOrder(list){
  const first=xtPoolPick(list);
  return [first].concat(list.filter(s=>s!==first).sort((a,b)=>b.weight-a.weight));
 }
 function xtPoolFailover(e){
  return /HTTP (?:401|402|403|404|408|429|5\d\d)|failed to fetch|networkerror|timeout|超时|无法连接|ERR_/i.test(String(e&&e.message||e));
 }
 // v3.7.85 网络层失败识别：fetch 直接抛 TypeError（DNS/连不上/被墙），报错文案是「无法连接/Failed to fetch/ERR_」
 const xtNetRe=/failed to fetch|networkerror|无法连接|ERR_|timeout|超时|network/i;
 function xtAllNetDown(errs,poolLen){
  return poolLen>0&&errs.length>0&&errs.every(x=>xtNetRe.test(x));
 }
 function xtPoolHdr(st){ return st&&st.spoofOrigin?{Origin:st.spoofOrigin,Referer:st.spoofOrigin+'/'}:undefined; }
 async function errBody(res){   // v3.7.27 带上网关错误响应体，排障一目了然
  try{const t=await res.text();return (t&&t.length<400)?('｜响应：'+t.slice(0,250)):'';}catch{ return ''; }
 }
 async function ask(base,path,key,body,hdr,signal){
  const res=await askOnce(base,path,key,body,hdr,signal);
  const RETRYABLE=[400,408,429,500,502,503,504];
  if(!res.ok&&path==='/images/edits'&&RETRYABLE.includes(res.status)){
   let last=res,tries=0;
   for(let i=0;i<3;i++){
    if(signal&&signal.aborted)throw Error('已取消');
    await new Promise(r=>setTimeout(r,3000+i*3000));
    const retry=await askOnce(base,path,key,body,hdr,signal);
    if(retry.ok)return retry.json();
    last=retry;tries=i+1;
    if(!RETRYABLE.includes(retry.status))break;
   }
   throw Error(gateName(base)+'：'+(xtKeyError[last.status]||('请求失败（HTTP '+last.status+'，已自动重试 '+tries+' 次）。'))+(await errBody(last)));
  }
  if(!res.ok)throw Error(gateName(base)+'：'+(xtKeyError[res.status]||('请求失败（HTTP '+res.status+'）。'))+(await errBody(res)));
  return res.json();
 }
 async function askOnce(base,path,key,body,hdr,signal){
  if(base!==XT_API&&base!==XT_DS&&!(typeof base==='string'&&base.startsWith('https://')))throw Error('不支持的 API 域名。');
  if(typeof key!=='string'||!/^sk-[A-Za-z0-9_-]{10,252}$/.test(key))throw Error('请填写 '+gateName(base)+' 自己签发的 sk- 模型密钥。');
  const headers=Object.assign({},hdr||{},{Authorization:'Bearer '+key});
  let method='GET';
  if(body!=null){
   method='POST';
   if(!(body instanceof FormData)){headers['Content-Type']='application/json';body=JSON.stringify(body);}
  }
  return await request(base+path,{method,body,headers,credentials:'omit',redirect:'error',signal:xtSignal(path==='/images/edits'?420000:method==='GET'?10000:45000,signal)});
 }
 // v3.7.32 SW 保活：有生图在飞时每 20s 心跳一次，防止 MV3 service worker 空闲被杀
 // （被杀的典型症状：页面报 “message channel closed before a response was received”）
 let xtKaTimer=null,xtKaN=0;
 function xtKeepAlive(on){
  xtKaN+=on?1:-1;
  if(xtKaN>0&&!xtKaTimer){try{xtKaTimer=setInterval(function(){try{chrome.runtime.getPlatformInfo(function(){});}catch(e){}},20000);}catch(e){xtKaTimer=null;}}
  if(xtKaN<=0&&xtKaTimer){clearInterval(xtKaTimer);xtKaTimer=null;}
 }
 // 超时 + 竞速取消 合并成一个 signal
 function xtSignal(ms,extra){
  const t=AbortSignal.timeout(ms);
  if(!extra)return t;
  if(typeof AbortSignal.any==='function')return AbortSignal.any([t,extra]);
  const c=new AbortController(),kill=()=>{try{c.abort();}catch(e){}};
  t.addEventListener('abort',kill);extra.addEventListener('abort',kill);
  if(extra.aborted)kill();
  return c.signal;
 }
 async function modelIds(base,key){
  const data=(await ask(base,'/models',key))?.data;
  if(!Array.isArray(data))throw Error('接口未返回模型列表。');
  return [...new Set(data.map(x=>x?.id).filter(x=>typeof x==='string'&&x.length<=128))];
 }
 async function imageModels(key,base,image){
  base=base||XT_API;image=image||XT_IMAGE;
  const ids=await modelIds(base,key);
  if(!ids.includes(image))throw Error(gateName(base)+' 未开放生图模型 '+image+'，请检查令牌分组或改用可用模型。');
  return ids;
 }
 function config(c){
  const source=c?.source==='deepseek'||(!c?.key&&!c?.source)?'deepseek':'jaykou';
  return {source,dsConfigured:!!c?.dsKey,imageConfigured:!!c?.key,connected:!!(c?.key&&c?.title&&(source!=='deepseek'||c?.dsKey)),
   title:c?.title||(source==='deepseek'?XT_DS_MODEL:''),image:c?.image||XT_IMAGE,base:c?.base||XT_API};
 }
 function readKeys(c,input,source,dsInput,title,base,image){
  const useDs=source==='deepseek';
  return {key:input||c?.key,source:useDs?'deepseek':'jaykou',
   dsKey:useDs?(dsInput||c?.dsKey):undefined,
   title:useDs?(title||c?.title||XT_DS_MODEL):(title||(c?.source!=='deepseek'?c?.title:'')),
   base:normBase(base)||c?.base||XT_API,image:image||c?.image||XT_IMAGE};
 }
 async function titleCall(c,messages,testing=false){
  const ds=c.source==='deepseek';
  if(!c.title)throw Error('请先选择一个改标题模型。');
  const body={model:c.title,messages,stream:false};
  if(ds)body.thinking={type:'disabled'};
  if(testing)body.max_tokens=32;
  const r=await ask(ds?XT_DS:c.base||XT_API,'/chat/completions',ds?c.dsKey:c.key,body);
  const title=r?.choices?.[0]?.message?.content;
  if(typeof title!=='string'||!title.trim())throw Error('标题模型没有返回正文。');
  return title.trim();
 }
 async function genAt(st,input,prompt,signal){
  xtKeepAlive(true);
  try{ return await genAt2(st,input,prompt,signal); }
  finally{ xtKeepAlive(false); }
 }
 // v3.7.54 JSON 请求格式：sub2api/nbility/codekey 等网关只收 JSON body（images 对象数组），multipart 会 400
 async function blobB64(blob){
  const buf=new Uint8Array(await blob.arrayBuffer());
  let bin='';
  for(let i=0;i<buf.length;i+=32768)bin+=String.fromCharCode(...buf.subarray(i,i+32768));
  return btoa(bin);
 }
 async function genAt2(st,input,prompt,signal){
  const base=st.base||XT_API,image=st.model||XT_IMAGE,key=st.key;
  if(!(input instanceof Blob)||!input.size||input.size>20*1024*1024)throw Error('参考图为空或超过大小上限。');
  const hdr=xtPoolHdr(st);
  const mime='image/'+(input.type==='image/jpeg'?'jpeg':'png');
  let r;
  if(st.req==='json'){
   const b64=await blobB64(input);
   const body={model:image,prompt:String(prompt||'').slice(0,18000),images:[{image_url:'data:'+mime+';base64,'+b64}],n:1,size:'1024x1024'};
   // v3.7.77 收敛请求参数（用户拍板）：上游只负责按 size 出 1K 图，格式/压缩一律回传后本地 xtRecompress 做——
   // 少一个参数少一个报错点，上游报错就是整单卡点
   r=await ask(base,'/images/edits',key,body,hdr,signal);
  } else {
   const form=new FormData();
   form.set('model',image);form.set('image',input,'reference.'+(input.type==='image/jpeg'?'jpg':'png'));
   form.set('prompt',String(prompt||'').slice(0,18000));form.set('size','1024x1024');form.set('n','1');
   // v3.7.78 请求瘦到最简：只有 model/image/prompt/size/n 五个字段，上游只负责出 1K 图。
   // b64 或图链都接（两条解析路径都在），返回什么用什么，不再向上游要任何格式/压缩参数——
   // 参数越多报错点越多，之前"一直报错"的大头就是这些可有可无的参数撞上各家网关的兼容性差异
   r=await ask(base,'/images/edits',key,form,hdr,signal);
  }
  const row=r?.data?.[0], b64=row?.b64_json;
  if(typeof b64==='string'&&b64.length&&b64.length<=28*1024*1024)
   return {dataUrl:'data:image/'+(b64.startsWith('/9j/')?'jpeg':'png')+';base64,'+b64};
  if(typeof row?.url==='string'){
   let url;try{url=new URL(row.url,base+'/');}catch{throw Error('网关返回了无效图链。');}
   // v3.7.42 放宽：站点常用外站图床（如 jaykou 只回图链、不支持 b64），安全下载转 Base64——禁内网地址、免凭证、限大小
   if(!/^https?:$/i.test(url.protocol))throw Error('网关返回了无效图链。');
   if(/^(localhost|127\.|10\.|192\.168\.|169\.254\.|0\.|\[::1\]|172\.(1[6-9]|2\d|3[01])\.)/i.test(url.hostname))throw Error('接口返回了内网图链，未访问。');
   const asset=await request(url.href,{method:'GET',credentials:'omit',redirect:'error',signal:AbortSignal.timeout(60000)});
   const mime=(asset.headers.get('content-type')||'').split(';')[0].trim();
   if(!asset.ok||!/^image\/(?:jpeg|png|webp)$/.test(mime)||!asset.body)throw Error('网关图链无法读取成图片。');
   const reader=asset.body.getReader(),parts=[];let n=0;
   try{
    while(true){const v=await reader.read();if(v.done)break;n+=v.value.length;
     if(n>20*1024*1024)throw Error('接口返回图片过大。');parts.push(v.value);}
   }finally{await reader.cancel().catch(()=>{});}
   let binary=''; for(const part of parts)for(let i=0;i<part.byteLength;i+=32768)binary+=String.fromCharCode(...part.subarray(i,i+32768));
   return {dataUrl:'data:'+mime+';base64,'+btoa(binary),srcUrl:url.href};
  }
  if(r?.task_id||r?.taskId||row?.task_id||row?.taskId||/queued|processing|running|pending/i.test(String(r?.status||'')))
   throw Error('网关返回了异步任务，尚没有图片。请先查生成记录和扣费，不要重复点测试。');
  throw Error('网关返回成功响应，但没有图片数据或图链。未提交妙手。');
 }
 async function generate(key,input,prompt,base,image){
  return genAt({name:'',key,base:base||XT_API,model:image||XT_IMAGE},input,prompt);
 }
 async function poolRace(input,prompt){
  const c=await store('get'),pool=xtPoolList(c);
  if(!pool.length)return poolGenerate(input,prompt);
  const ctrl=new AbortController(),t0=Date.now();
  const runs=pool.map(st=>genAt(st,input,prompt,ctrl.signal).then(r=>{
   ctrl.abort();   // 先到先用，取消其余在飞请求
   xtPoolStat[st.name]={ok:(xtPoolStat[st.name]?.ok||0)+1,fail:xtPoolStat[st.name]?.fail||0,ms:Date.now()-t0,at:Date.now(),bytes:Math.round((r.dataUrl||'').length*0.75),win:true};
   return Object.assign({},r,{station:st.name,race:true,ms:Date.now()-t0});   // v3.7.68 ms 传回页面，日志可显示每张图在哪个站耗时多少
  }).catch(e=>{
   if(!ctrl.signal.aborted)
    xtPoolStat[st.name]={ok:xtPoolStat[st.name]?.ok||0,fail:(xtPoolStat[st.name]?.fail||0)+1,ms:Date.now()-t0,at:Date.now(),err:String(e&&e.message||e).slice(0,120)};
   throw e;
  }));
  try{ return await Promise.any(runs); }
  catch(agg){
   const errs=(agg&&agg.errors||[]).map(e=>String(e&&e.message||e)).filter(x=>x&&!/已取消|abort/i.test(x));
   pool.forEach(s=>{xtPoolCd[s.name]=Date.now()+30000;});
   // v3.7.85 全站网络层失败时给出可自救的明确诊断，不再笼统报「无法连接」
   if(xtAllNetDown(errs,pool.length))throw Error('站点池 '+pool.length+' 个站全部网络不通（'+String(errs[0]).slice(0,60)+'）。这台电脑到站点池的直连被拦：请检查本机网络，再到「接口设置→站点池→📡 一键读取全部模型」逐站体检，把结果发给管理员。');
   throw Error(errs[0]||'所有站点都失败了，稍后重试。');
  }
 }
 async function poolGenerate(input,prompt){
  const c=await store('get'),pool=xtPoolList(c);
  if(!pool.length){
   if(!c?.key)throw Error('请先配置生图令牌。');
   return generate(c.key,input,prompt,c.base||XT_API,c.image||XT_IMAGE);
  }
  let last=null,netN=0;
  for(const st of xtPoolOrder(pool)){
   const t0=Date.now();
   try{
    const r=await genAt(st,input,prompt);
    xtPoolStat[st.name]={ok:(xtPoolStat[st.name]?.ok||0)+1,fail:xtPoolStat[st.name]?.fail||0,ms:Date.now()-t0,at:Date.now(),bytes:Math.round((r.dataUrl||'').length*0.75)};
    return Object.assign({},r,{station:st.name,ms:Date.now()-t0});   // v3.7.68
   }catch(e){
    last=e;
    if(xtNetRe.test(String(e&&e.message||e)))netN++;   // v3.7.85
    xtPoolCd[st.name]=Date.now()+45000;
    xtPoolStat[st.name]={ok:xtPoolStat[st.name]?.ok||0,fail:(xtPoolStat[st.name]?.fail||0)+1,ms:Date.now()-t0,at:Date.now(),err:String(e&&e.message||e).slice(0,140)};
    if(!xtPoolFailover(e))break;   // 内容/审核类错误不换站，避免重复扣费
   }
  }
  // v3.7.85 全站都栽在网络层（非 HTTP 业务码）：明确告知是这台电脑到站点池不通，并给体检入口
  if(netN===pool.length)throw Error('站点池 '+pool.length+' 个站全部网络不通（'+String(last&&last.message||'').slice(0,60)+'）。这台电脑到站点池的直连被拦：请检查本机网络，再到「接口设置→站点池→📡 一键读取全部模型」逐站体检，把结果发给管理员。');
  throw last||Error('站点池没有可用站点。');
 }
 function xtPoolPublic(conn){
  const now=Date.now();
  return xtPoolAll(conn).map(s=>({name:s.name,base:s.base,model:s.model,weight:s.weight,on:s.on!==false,cost:s.cost||0,note:s.note||'',
   req:s.req,outFmt:s.outFmt,outComp:s.outComp,conc:s.conc,
   cooling:Math.max(0,Math.round(((xtPoolCd[s.name]||0)-now)/1000)),stat:xtPoolStat[s.name]||null}));
 }
 return {
  async status(){const c=await store('get'),s=config(c),pool=xtPoolPublic(c);s.pool=pool;s.poolMode=(c&&c.poolMode==='weighted')?'weighted':'race';
   if(pool.length){s.imageConfigured=true;s.connected=s.connected||pool.length>0;}
   return s;},
  async list(input){
   const c=await store('get'), key=input||c?.key;
   return {models:(await imageModels(key,c?.base,c?.image)).filter(sharedText),image:c?.image||XT_IMAGE};
  },
  // v3.7.53 先读取模型再选择：不校验目标模型是否存在，原样返回网关可用模型清单
  async modelList(base,keyIn){
   const c=await store('get');
   const b=normBase(base||c?.base||XT_API);
   const k=keyIn||c?.key;
   if(!k)throw Error('请先填写 sk- 模型令牌，再读取模型。');
   const ids=await modelIds(b,k);
   const isImg=id=>/gpt-image|dall|image|imagen|flux|banana|seedream|seedance|kolors|qwen-image|^sd[-_.]|midjourney|mj[-_]/i.test(id);
   const img=ids.filter(isImg), txt=ids.filter(x=>!isImg(x)&&sharedText(x));
   return {base:b, ids, image:img, text:txt, current:c?.image||XT_IMAGE};
  },
  async connect(input,title,source='jaykou',dsInput,base,image){
   const saved=await store('get');
   const c=readKeys(saved,input,source,dsInput,title,base,image);
   const pool=xtPoolList(saved);
   if(pool.length){
    // v3.7.65 二选一：已配置站点池（竞速/权重）时生图走站点池，不再要求填生图网关地址/密钥
    // v3.7.80 改标题也不再强制：没填 DeepSeek 同样能保存（生图正常，只是标题不改/SKU 图走主图兜底）；填了才校验
    // v3.7.86 修复：存量 jaykou 令牌 + 没选标题模型时，之前会误报「Jaykou 令牌未开放可选标题模型」把保存拦死——
    // 现在只有用户真的填了标题模型（c.title）才校验，否则一律放行（生图走站点池，改标题可选）
    if(c.source==='deepseek'&&c.dsKey){
     const ids=await modelIds(XT_DS,c.dsKey);
     if(ids.includes(c.title)){} else if(ids.includes(XT_DS_MODEL)){c.title=XT_DS_MODEL;}
     else if(ids.includes('deepseek-chat')){c.title='deepseek-chat';}
     else throw Error('DeepSeek 密钥未开放可用标题模型（'+c.title+' / deepseek-chat 均未开放）。');
    } else if(c.key&&c.title){
     const ids=await imageModels(c.key,c.base,c.image);
     if(c.base===XT_API&&!ids.filter(sharedText).includes(c.title)){
      throw Error('Jaykou 令牌未开放所选标题模型；改标题可切换为 DeepSeek 并填独立密钥，或清空标题模型（生图不受影响）。');
     }
    }
    await store('set',c);
    return config(c);
   }
   if(!c.key)throw Error('生图还没配置好：站点池没保存（去「站点池」页签点「保存站点池」，导入 JSON 后会自动保存），且生图网关密钥也没填。两样配一样就行。');
   const ids=await imageModels(c.key,c.base,c.image);
   if(c.source==='deepseek'){
    const ids=await modelIds(XT_DS,c.dsKey);
    if(ids.includes(c.title)){} else if(ids.includes(XT_DS_MODEL)){c.title=XT_DS_MODEL;}
    else if(ids.includes('deepseek-chat')){c.title='deepseek-chat';}
    else throw Error('DeepSeek 密钥未开放可用标题模型（'+c.title+' / deepseek-chat 均未开放）。');
   }else if(c.base===XT_API&&(!c.title||!ids.filter(sharedText).includes(c.title))){
    throw Error('Jaykou 令牌未开放可选标题模型；请切换为 DeepSeek 并填写独立密钥。');
   }
   await store('set',c);
   return config(c);
  },
  async diagnose(){
   const c=await store('get'), report=async work=>{try{await work();return {ok:true};}catch(e){return {ok:false,error:e.message||'连接失败'};}};
   const pool=xtPoolList(c);
   const image=pool.length
    ? await report(async()=>{const bad=[];for(const st of pool){try{await modelIds(st.base,st.key);}catch(e){bad.push(st.name+'：'+(e.message||''));}}if(bad.length)throw Error(bad.join('；'));})
    : await report(()=>imageModels(c?.key,c?.base,c?.image));
   const title=await report(async()=>{
    if(!c?.title)throw Error('尚未保存改标题配置。');
    const ds=c.source==='deepseek';
    if(!(await modelIds(ds?XT_DS:c.base||XT_API,ds?c.dsKey:c.key)).includes(c.title))throw Error('标题模型未开放。');
   });
   return {image,title};
  },
  async disconnect(){await store('clear');return config(null);},
  async chat(messages){
   const c=await store('get');
   if(!config(c).connected&&!c?.title)throw Error('改标题模型未配置：生图不受影响，标题会保持原样；需要改标题/英文标题时到「接口设置」填 DeepSeek 密钥。');
   return titleCall(c,messages);
  },
  async image(input,prompt){
   const c=await store('get');
   // 默认竞速（所有站点同时下单，最快）；省钱可切回 weighted 权重分流
   return (c&&c.poolMode==='weighted')?poolGenerate(input,prompt):poolRace(input,prompt);
  },
  async testTitle(input,source,dsInput,title){
   const c=readKeys(await store('get'),input,source,dsInput,title);
   return {sample:await titleCall(c,[{role:'user',content:'只输出一个不超过10个字的中文商品标题：蓝色收纳盒。不要加解释。'}],true),model:c.title};
  },
  async pool(){ const c=await store('get'); return {mode:(c&&c.poolMode==='weighted')?'weighted':'race',list:xtPoolPublic(c)}; },
  async setPool(list,on,mode){
   const c=(await store('get'))||{};
   const clean=Array.isArray(list)?list.filter(s=>s&&typeof s.base==='string'&&typeof s.key==='string')
    .map(s=>({name:String(s.name||''),base:s.base,key:s.key,model:s.model||XT_IMAGE,weight:Math.max(1,Math.min(100,Number(s.weight)||1)),
     on:s.on!==false,spoofOrigin:s.spoofOrigin||'',note:s.note||'',cost:Number(s.cost)||0,
     req:String(s.req||s.format||'').startsWith('json')?'json':'form',outFmt:s.outFmt||'',outComp:Number(s.outComp)||70,conc:Number(s.conc)||0})):[];
   await store('set',Object.assign({},c,{pool:clean,poolOn:on!==false,poolMode:mode==='weighted'?'weighted':'race'}));
   return {mode:mode==='weighted'?'weighted':'race',list:xtPoolPublic(await store('get'))};
  },
  async testImage(input,ref,base,image){
   const pr='将参考图改成简洁蓝白两色平面图，保留 QA 测试标记，不添加人物、商品或其他信息。';
   if(input)return generate(input,ref,pr,base||XT_API,image||XT_IMAGE);
   return (await store('get'))?.poolMode==='weighted'?poolGenerate(ref,pr):poolRace(ref,pr);
  }
 };
}
