'use strict';
const el=id=>document.getElementById(id);
const key=el('key'), status=el('status'), title=el('title'), source=el('source'), dsKey=el('ds-key');
const poolBox=el('pool-list'), poolStatus=el('pool-status');
let poolCache=[], poolMode='race', poolModels={};
async function call(cmd,data={}){
 const r=await chrome.runtime.sendMessage({cmd,...data});
 if(!r?.ok)throw Error(r?.error||'插件后台无响应。');
 return r.data;
}
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
// v3.7.53 先读取模型、下拉选择、再保存：图片模型优先排前，只留真正可用的清单
async function fetchImageModels(base,key){
 const r=await call('xtNewApiModelList',{base,key});
 const ids=(Array.isArray(r?.image)&&r.image.length)?r.image:(Array.isArray(r?.ids)?r.ids:[]);
 if(!ids.length)throw Error('该网关没返回任何生图模型，请检查令牌分组或换站。');
 return {ids,current:r.current||''};
}
function sync(){
 const ds=source.value==='deepseek';
 el('ds-config').hidden=!ds;el('shared-config').hidden=ds;
 el('test-ds').textContent=ds?'测试 DeepSeek':'测试 Jaykou 改标题';
}
function values(){const b=el('image-url').value.trim();return {key:key.value.trim(),dsKey:dsKey.value.trim(),source:source.value,title:title.value,base:b,image:el('image-model').value.trim()||undefined};}
function statText(s){
 if(!s||(!s.ok&&!s.fail))return '未接活';
 const bits=[];
 if(s.ok)bits.push('成功 '+s.ok);
 if(s.fail)bits.push('失败 '+s.fail);
 if(s.ms)bits.push((s.ms/1000).toFixed(1)+'s');
 if(s.bytes)bits.push(Math.round(s.bytes/1024)+'KB');
 return bits.join(' · ');
}
function modelSelect(name,model,i){
 const cur=String(model||''),list=poolModels[name]||[];
 const opts=list.length
  ? list.map(m=>'<option value="'+esc(m)+'"'+(m===cur?' selected':'')+'>'+esc(m)+'</option>').join('')
  : '<option value="'+esc(cur)+'" selected>'+esc(cur||'（未选模型）')+'</option>';
 const tip=list.length?'换模型直接选，改完点「保存站点池」':'点右侧「读取模型」拉取该站可用模型';
 return '<select class="pm-sel" data-i="'+i+'" title="'+esc(tip)+'">'+opts+'</select>';
}
function fmtSelect(st,i){
 const cur=(String(st.req||st.format||'').startsWith('json'))?'json':'form';
 return '<select class="pf-sel" data-i="'+i+'" title="请求体格式：绝大多数站用 JSON；老网关用 multipart 表单">'
  +'<option value="json"'+(cur==='json'?' selected':'')+'>JSON</option>'
  +'<option value="form"'+(cur==='form'?' selected':'')+'>表单</option></select>';
}
// v3.7.62 内置站点地址打码：客户只见站点名/模型/状态，不见 URL（密钥本就不显示）
function maskUrl(u){
 u=String(u||'');
 if(!u)return '';
 try{const a=new URL(u);return a.protocol+'//'+a.host.slice(0,5)+'••••••（已隐藏）';}
 catch(e){return u.slice(0,10)+'••••••';}
}
function renderPool(list){
 poolCache=list.map(x=>({...x}));
 const total=poolCache.filter(x=>x.on).reduce((a,b)=>a+b.weight,0)||1;
 poolBox.replaceChildren(...poolCache.map((s,i)=>{
  const row=document.createElement('div');
  row.className='pool-row';
  const share=Math.round((s.on?s.weight:0)/total*100);
  row.innerHTML=
   '<label class="po"><input type="checkbox" data-i="'+i+'" '+(s.on?'checked':'')+'> <b>'+
   String(s.name||'站点'+(i+1))+'</b> <small>'+(s.cost?('¥'+s.cost+'/张'):'')+'</small></label>'+
   '<input class="pw" type="number" min="1" max="100" step="1" data-i="'+i+'" value="'+Number(s.weight)+'" title="权重">'+
   '<span class="ps">占比 '+share+'%</span>'+
   '<span class="pm">'+modelSelect(s.name,s.model,i)+((s.cooling?' · 冷却 '+s.cooling+'s':''))+'</span>'+
   '<span class="pd">'+statText(s.stat)+'</span>'+
   '<span class="pn">'+fmtSelect(s,i)+' <button type="button" class="pget" data-get="'+i+'" title="拉取该站可用模型">读取模型</button> <button type="button" class="pdel" data-del="'+i+'" title="删除该站点">✕ 删除</button> '+String(s.note||'')+'</span>'+
   (s.hide
    ?'<input class="pu" data-i="'+i+'" value="🔒 '+esc(maskUrl(s.base))+'" readonly title="API 地址已打码隐藏（内置站点）：生图/读取模型不受影响，需要改地址请联系管理员">'
    :'<input class="pu" data-i="'+i+'" value="'+esc(s.base||'')+'" placeholder="https://…/v1（API 地址，读取模型用，可修改）" title="API 地址：读取模型/生图都用它，可直接修改">');
  return row;
 }));
 const onN=poolCache.filter(x=>x.on).length;
 poolStatus.textContent = !poolCache.length
  ? '站点池为空：请在下方填入你自己的 API 地址和 sk- 密钥，点「➕ 添加站点」。（没加站点时走下方「生图网关」）'
  : (poolMode==='race'
  ? ('竞速模式：每张图同时向 '+onN+' 站下单，谁先回来用谁，其余取消（成本约 ×'+onN+'，出图最快）。')
  : ('权重分流：每张图只走 1 站，权重合计 '+total+'，越大分到越多张；失败自动切下一站并冷却 45 秒。'));
}
function syncMode(){
 document.querySelectorAll('input[name="pool-mode"]').forEach(r=>{r.checked=(r.value===poolMode);});
}
async function loadPool(){
 try{
  const r=await call('xtNewApiPool');
  poolMode=(r&&r.mode)||'race';
  renderPool(Array.isArray(r)?r:(r&&r.list)||[]);
  syncMode();
 }catch(e){ poolStatus.textContent='站点池读取失败：'+(e.message||e); }
}
function bindPool(){
 poolBox.addEventListener('change',e=>{
  const i=Number(e.target.dataset.i);
  if(e.target.classList.contains('pu')){
   const v=e.target.value.trim();
   poolCache[i].base=v;
   poolStatus.textContent='已把「'+String(poolCache[i].name||'站点')+'」的地址改为 '+(v||'（空）')+'，改完点「读取模型」验证，再点「保存站点池」生效。';
   return;
  }
  if(e.target.classList.contains('pm-sel')){
   poolCache[i].model=e.target.value;
   poolStatus.textContent='已把「'+String(poolCache[i].name||'站点')+'」的模型改为 '+e.target.value+'，点「保存站点池」生效。';
   return;
  }
  if(e.target.classList.contains('pf-sel')){
   poolCache[i].req=e.target.value;
   poolStatus.textContent='已把「'+String(poolCache[i].name||'站点')+'」的请求格式改为 '+e.target.value+'，点「保存站点池」生效。';
   return;
  }
  if(e.target.type==='checkbox')poolCache[i].on=e.target.checked;
  if(e.target.type==='number')poolCache[i].weight=Math.max(1,Math.min(100,Number(e.target.value)||1));
  renderPool(poolCache);
 });
 poolBox.addEventListener('click',async e=>{
  const getBtn=e.target.closest('[data-get]');
  if(getBtn){
   const i=Number(getBtn.dataset.get),st=poolCache[i];
   if(!st)return;
   getBtn.disabled=true;poolStatus.textContent='正在读取「'+String(st.name||'站点')+'」的模型清单…';
   try{
    const {ids}=await fetchImageModels(st.base,st.key);
    poolModels[st.name]=ids;
    if(!ids.includes(st.model))st.model=ids[0];
    renderPool(poolCache);
    poolStatus.textContent='✅ 「'+String(st.name||'站点')+'」可用生图模型 '+ids.length+' 个：'+ids.slice(0,6).join('、')+(ids.length>6?'…':'')+'。选好后点「保存站点池」。';
   }catch(err){ poolStatus.textContent='读取失败：'+(err.message||err); }
   finally{ getBtn.disabled=false; }
   return;
  }
  const b=e.target.closest('[data-del]'); if(!b)return;
  poolCache.splice(Number(b.dataset.del),1);
  renderPool(poolCache);
  poolStatus.textContent='已移除该站点，点「保存站点池」生效。';
 });
 el('add-models').addEventListener('click',async()=>{
  const base=el('add-base').value.trim(), k=el('add-key').value.trim(), btn=el('add-models');
  if(!/^https:\/\/.+/i.test(base)){poolStatus.textContent='❌ 先在地址栏填 API 地址（https:// 开头），再读取模型。';return;}
  if(!/^sk-[A-Za-z0-9_-]{8,}$/.test(k)){poolStatus.textContent='❌ 先填 sk- 密钥，再读取模型。';return;}
  btn.disabled=true;poolStatus.textContent='正在读取该站模型清单…';
  try{
   const {ids}=await fetchImageModels(base,k);
   const sel=el('add-model');
   sel.replaceChildren(...ids.map(x=>new Option(x,x)));
   sel.selectedIndex=0;
   poolStatus.textContent='✅ 读到 '+ids.length+' 个生图模型：'+ids.slice(0,8).join('、')+(ids.length>8?'…':'')+'。选中后再点「添加站点」。';
  }catch(err){ poolStatus.textContent='读取失败：'+(err.message||err); }
  finally{ btn.disabled=false; }
 });
 el('add-base').addEventListener('input',()=>{el('add-model').replaceChildren(new Option('模型（先读取）',''));});
 el('add-key').addEventListener('input',()=>{el('add-model').replaceChildren(new Option('模型（先读取）',''));});
 el('pool-add').addEventListener('click',()=>{
  const base=el('add-base').value.trim(), key=el('add-key').value.trim(), model=el('add-model').value.trim();
  if(!/^https:\/\/.+/i.test(base)){poolStatus.textContent='❌ API 地址要以 https:// 开头（例如 https://你的网关.com/v1）。';return;}
  if(!/^sk-[A-Za-z0-9_-]{8,}$/.test(key)){poolStatus.textContent='❌ 密钥格式像 sk-xxxx，请检查后重填。';return;}
  if(!model){poolStatus.textContent='❌ 还没选模型：先点「读取模型」，在下拉里选一个生图模型，再添加站点。';return;}
  poolCache.push({name:el('add-name').value.trim()||('站点'+(poolCache.length+1)),base:base,key:key,
   model:model,req:el('add-req').value||'json',weight:Math.max(1,Math.min(100,Number(el('add-weight').value)||10)),on:true});
  ['add-name','add-base','add-key'].forEach(id=>{el(id).value='';});
  el('add-model').replaceChildren(new Option('模型（先读取）',''));
  renderPool(poolCache);
  poolStatus.textContent='已添加，点「保存站点池」生效。可继续添加多个站点。';
 });
 el('pool-save').addEventListener('click',async()=>{
  poolStatus.textContent='正在保存站点池…';
  try{ const r=await call('xtNewApiPoolSet',{list:poolCache,on:true,mode:poolMode}); poolMode=(r&&r.mode)||poolMode; renderPool((r&&r.list)||poolCache); poolStatus.textContent=poolMode==='race'?'✅ 已保存：竞速模式，每张图会同时向 '+poolCache.filter(x=>x.on).length+' 站下单。':'✅ 已保存：权重分流，每张图只走 1 站。'; }
  catch(e){ poolStatus.textContent='保存失败：'+(e.message||e); }
 });
 // v3.7.55 一键植入内置站点（编译进 pool-preset.js 的 16 站，含密钥/模型/格式/权重）
 el('pool-preset').addEventListener('click',async()=>{
  const preset=(typeof XT_POOL_PRESET!=='undefined'&&Array.isArray(XT_POOL_PRESET))?XT_POOL_PRESET:[];
  if(!preset.length){poolStatus.textContent='这个包没有内置站点（客户版）：请用「📥 导入站点 JSON」或手动添加。';return;}
  if(poolCache.length&&!confirm('将用内置 '+preset.length+' 站替换当前 '+poolCache.length+' 站配置，确定吗？'))return;
  poolStatus.textContent='正在植入 '+preset.length+' 个内置站点…';
  poolCache=preset.map(s=>Object.assign({},s,{hide:true}));
  renderPool(poolCache);
  try{
   const r=await call('xtNewApiPoolSet',{list:poolCache,on:true,mode:poolMode});
   poolMode=(r&&r.mode)||poolMode;
   renderPool((r&&r.list)||poolCache);
   const on=poolCache.filter(s=>s.on).length;
   poolStatus.textContent='✅ 已植入 '+poolCache.length+' 站并保存（启用 '+on+' 站，关掉的 3 站是额度/欠费/拥挤）。站点地址已打码，不影响生图。可直接点「测试生图」验证。';
   loadPool();
  }catch(e){ poolStatus.textContent='植入后保存失败：'+(e.message||e); }
 });
 el('pool-refresh').addEventListener('click',loadPool);
 el('pool-getall').addEventListener('click',()=>readAllModels());
async function readAllModels(autoSave){
 const btn=el('pool-getall');
 if(!poolCache.length){poolStatus.textContent='站点池为空：先导入站点 JSON 或手动添加站点。';return;}
 btn.disabled=true;
 const bad=[];
 for(let i=0;i<poolCache.length;i++){
  const st=poolCache[i];
  if(!st.key||!/^https:\/\/.+/i.test(st.base||'')){bad.push(String(st.name||'站点'+(i+1))+'：缺地址或密钥');continue;}
  poolStatus.textContent='📡 正在读取 '+(i+1)+'/'+poolCache.length+'「'+String(st.name||'站点')+'」的模型清单…';
  try{
   const {ids}=await fetchImageModels(st.base,st.key);
   if(!ids.length)throw new Error('没有可用生图模型');
   poolModels[st.name]=ids;
   if(!ids.includes(st.model))st.model=ids[0];
  }catch(err){bad.push(String(st.name||'站点'+(i+1))+'：'+(err.message||err));}
 }
 renderPool(poolCache);
 btn.disabled=false;
 if(bad.length){
  poolStatus.textContent='📡 读完：'+(poolCache.length-bad.length)+' 站成功，'+bad.length+' 站失败——'+bad.join('；')+'。'+(autoSave?'已自动保存站点池，失败的站可改行内地址后再读。':'失败站可改行内地址后重试，没问题就点「保存站点池」。');
 } else {
  poolStatus.textContent='📡 全部 '+poolCache.length+' 站模型已读取并自动选好第一个可用模型。'+(autoSave?'已自动保存，直接去面板跑单即可。':'点「保存站点池」生效。');
 }
 // v3.7.86 导入 JSON 场景自动保存：以前客户导入后直接去点「验证并保存连接」，
 // 站点池还没落库，connect 把导入内容当成没配置 → 报「没 api/要填 jaykou」——导入即保存，杀掉这个两步陷阱
 if(autoSave&&poolCache.length){
  try{ const r=await call('xtNewApiPoolSet',{list:poolCache,on:true,mode:poolMode}); poolMode=(r&&r.mode)||poolMode; renderPool((r&&r.list)||poolCache); }catch(eE){ poolStatus.textContent+='（自动保存失败：'+(eE.message||eE)+'，请手动点「保存站点池」）'; }
 }
}
 // v3.7.54 一键导入站点池 JSON（洗图台导出的 {stations:[…]} 或裸数组），base+key 相同的站不重复导入
 el('pool-import').addEventListener('click',()=>el('pool-file').click());
 el('pool-file').addEventListener('change',async()=>{
  const f=el('pool-file').files[0];
  if(!f)return;
  el('pool-file').value='';
  let j;
  try{j=JSON.parse(await f.text());}catch(e){poolStatus.textContent='❌ 不是合法 JSON：'+String(e).slice(0,80);return;}
  const arr=Array.isArray(j)?j:(Array.isArray(j.stations)?j.stations:[]);
  if(!arr.length){poolStatus.textContent='❌ 没找到站点清单：文件里应有 stations 数组。';return;}
  const seen=new Set(poolCache.map(s=>s.base+'|'+s.key));
  let add=0,skip=0;
  for(const s of arr){
   // v3.7.61 兼容多种字段名：地址 base/baseUrl/url/apiBase/api_url/apiUrl；密钥 apiKey/key/token/sk；模型 model/imageModel/image_model/image
   const key=String(s.apiKey||s.key||s.token||s.sk||'');
   const base=String(s.base||s.baseUrl||s.url||s.apiBase||s.api_url||s.apiUrl||'');
   if(!key||!/^https:\/\/.+/i.test(base)){skip++;continue;}
   const id=base+'|'+key;
   if(seen.has(id)){skip++;continue;}
   seen.add(id);
   poolCache.push({name:String(s.name||s.remark||s.title||('站点'+(poolCache.length+1))),base,key,
    model:String(s.model||s.imageModel||s.image_model||s.image||'gpt-image-2'),req:String(s.req||s.format||'').startsWith('json')?'json':'form',
    outFmt:s.outFmt||'',outComp:Number(s.outComp)||70,conc:Number(s.conc)||0,cost:Number(s.cost)||0,
    spoofOrigin:s.spoofOrigin||'',note:String(s.note||s.remark2||''),weight:Math.max(1,Math.min(100,Number(s.weight)||10)),on:true});
   add++;
  }
  renderPool(poolCache);
  if(!add){poolStatus.textContent='❌ 导入 0 站：文件里每条站点都要有 API 地址（base/url 等字段）和 sk- 密钥。';return;}
  poolStatus.textContent='导入完成：新增 '+add+' 站'+(skip?('，跳过重复/无效 '+skip+' 条'):'')+'。正在自动读取全部模型并保存…';
  readAllModels(true);
 });
}
function show(s){
 source.value=s.source||'deepseek';
 el('disconnect').hidden=!(s.connected||s.imageConfigured);
 key.placeholder=s.imageConfigured?'已保存；留空沿用原令牌':'粘贴你的 sk- 密钥';
 dsKey.placeholder=s.dsConfigured?'已保存；留空沿用原密钥':'粘贴 DeepSeek 官方 sk- 密钥';
 if(s.base&&!poolCache.length)el('image-url').value=s.base;
 const imSel=el('image-model'),imCur=String(s.image||'');
 if(imCur&&![...imSel.options].some(o=>o.value===imCur))imSel.replaceChildren(new Option(imCur,imCur));
 if(imCur)imSel.value=imCur;
 if(s.source==='jaykou'&&s.title){title.replaceChildren(new Option(s.title,s.title));title.disabled=false;}
 sync();
 if(Array.isArray(s.pool)&&s.pool.length){poolMode=s.poolMode||'race';renderPool(s.pool);syncMode();}
 status.textContent=s.connected?'已保存。改标题：'+s.title+'；生图：'+(s.pool&&s.pool.length?('站点池 '+s.pool.length+' 站'):s.image)+'。实际出图请点「测试生图」。':'尚未连接。两路可分别测试，通过后再保存。';
}
function action(id,output,run){
 const button=el(id);
 button.addEventListener('click',async()=>{
  button.disabled=true;
  try{await run();}catch(e){const msg=e.name==='TimeoutError'?'请求超时，请先查看生成记录或扣费再重试。':e instanceof TypeError?'连接或读取回图失败，请检查网络和 Jaykou 的生成记录。':e.message||'连接失败。';el(output).textContent=msg;ttsSay('测试失败，'+msg.slice(0,40));}
  finally{button.disabled=false;}
 });
}
// v3.7.43 设置页语音提醒：环境测试（连接/测图/测标题）每一步都有声音
function ttsSay(text){
 try{
  if(!('speechSynthesis' in window))return;
  const vs=speechSynthesis.getVoices().filter(v=>/^zh|cmn/i.test(v.lang||''));
  const fem=vs.filter(v=>/ting|婷婷|xiaoxiao|晓晓|xiaoyi|小艺|hui|慧|meijia|美佳|yao|瑶|female|女/i.test(v.name||''))[0]||vs[0];
  const u=new SpeechSynthesisUtterance(text);
  u.lang='zh-CN';u.rate=1;u.volume=0.95;
  if(fem)u.voice=fem;
  speechSynthesis.cancel();
  speechSynthesis.speak(u);
 }catch(e){}
}
source.addEventListener('change',sync);
bindPool();
call('xtNewApiStatus').then(show,()=>{status.textContent='无法读取插件连接状态。';});
loadPool();
key.addEventListener('input',()=>{title.replaceChildren();title.disabled=true;});
action('models','title-status',async()=>{
 const r=await call('xtNewApiModels',{key:key.value.trim()});
 title.replaceChildren(...r.models.map(x=>new Option(x,x)));
 title.disabled=!r.models.length;
 el('title-status').textContent=r.models.length?'选一个文本模型，再测试或保存。':'Jaykou 令牌未开放文本模型，可改用 DeepSeek 独立密钥。';
});
el('image-models').addEventListener('click',async()=>{
 const btn=el('image-models'),st=el('image-model-status'),base=el('image-url').value.trim(),k=key.value.trim();
 if(!k){st.textContent='❌ 先填生图模型令牌（sk- 开头），再读取模型。';return;}
 btn.disabled=true;st.textContent='正在请求 /v1/models 拉取模型清单…';
 try{
  const {ids,current}=await fetchImageModels(base,k);
  const sel=el('image-model'),keep=sel.value||current;
  sel.replaceChildren(...ids.map(x=>new Option(x,x)));
  sel.value=ids.includes(keep)?keep:ids[0];
  st.textContent='✅ 读到 '+ids.length+' 个生图模型：'+ids.slice(0,8).join('、')+(ids.length>8?'…':'')+'。选好后点「验证并保存连接」。';
 }catch(e){ st.textContent='读取失败：'+(e.message||e); }
 finally{ btn.disabled=false; }
});
action('test-ds','title-status',async()=>{
 if(!confirm('将调用 1 次标题模型，可能产生少量用量；不会改妙手商品。继续吗？'))return;
 el('title-status').textContent='正在测试改标题…';
 const r=await call('xtNewApiTestTitle',values());
 el('title-status').textContent='通过 · '+r.model+' · '+(r.ms/1000).toFixed(1)+' 秒 · '+r.sample.slice(0,120);
 ttsSay('改标题测试通过，用时'+(r.ms/1000).toFixed(0)+'秒。');
});
action('test-image','image-status',async()=>{
 if(!confirm('将用内置参考图测试生成 1 张，可能扣额度；不会上传妙手。继续吗？'))return;
 const img=el('image-result');img.hidden=true;img.removeAttribute('src');
 el('image-status').textContent='正在请求图生图，最多等待 3 分钟，请保持这个设置页打开…';
 const t=performance.now(),ref=await fetch(chrome.runtime.getURL('test-ref.jpg'));
 if(!ref.ok)throw Error('找不到本地测试参考图。');
 const r=await xtNewApi().testImage(key.value.trim(),await ref.blob(),el('image-url').value.trim()||undefined,(el('image-model')&&el('image-model').value.trim())||undefined);
 img.src=r.dataUrl;
 try{await img.decode();}catch{img.removeAttribute('src');throw Error('已收到响应，但图片无法解码。');}
 img.hidden=false;
 el('image-status').textContent='已收到可解码图片 · '+img.naturalWidth+'×'+img.naturalHeight+' · '+((performance.now()-t)/1000).toFixed(1)+' 秒 · 站点 '+(r.station||'自有')+'。';
 ttsSay('生图测试通过，出图正常，环境检查通过。');
 loadPool();
});
action('connect','status',async()=>{
 status.textContent='正在核对两路模型权限…';
 const r=await call('xtNewApiConnect',values());
 key.value='';dsKey.value='';show(r);
 ttsSay('连接成功，环境检查通过。');
});
// v3.7.80 吸顶快捷保存条：按钮转发到原按钮（不用滑到页面底部也能保存）
el('pool-save2').addEventListener('click',()=>el('pool-save').click());
el('connect2').addEventListener('click',()=>el('connect').click());
action('disconnect','status',async()=>{
 const r=await call('xtNewApiDisconnect');
 key.value='';dsKey.value='';title.replaceChildren();title.disabled=true;show(r);
});
